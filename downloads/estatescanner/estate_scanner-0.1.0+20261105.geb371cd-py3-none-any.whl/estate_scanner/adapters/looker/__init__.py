"""Stub registration for Looker -- see adapters/qlik/__init__.py for why
this is deliberately this small."""

from estate_scanner.core.platform import PlatformAuthenticator, PlatformClient
from estate_scanner.core.registry import PlatformDescriptor, register_platform


class LookerAuthenticator(PlatformAuthenticator):
    platform = "looker"


class LookerClient(PlatformClient):
    platform = "looker"


register_platform(
    PlatformDescriptor(
        key="looker", display_name="Looker", status="coming_soon",
        authenticator_cls=LookerAuthenticator, client_cls=LookerClient, auth_mode="unknown",
    )
)

"""FastAPI app factory: mounts the API routers, then the frontend static
files as a fallback. Runs entirely on 127.0.0.1 (see desktop.py) -- no
route here ever calls out to anything but the target BI platform itself,
the local SQLite file, and (only when asked, with a code the person typed)
BimDash's pairing endpoint.
"""

from __future__ import annotations

from pathlib import Path
from urllib.parse import urlsplit

from fastapi import FastAPI
from fastapi.exception_handlers import request_validation_exception_handler
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from estate_scanner import adapters  # noqa: F401 -- import registers every platform
from estate_scanner.storage import db

from .routes import bimdash, estate, export, graph, platforms, scans

STATIC_DIR = Path(__file__).parent / "static"

# The page is served from this machine and only ever asks the API from there. Names the Host and Origin of an /api request may carry.
LOOPBACK_HOSTS = frozenset({"127.0.0.1", "localhost", "::1"})
EXTRA_HOSTS: set[str] = set()  # empty in the product; the tests' client names itself "testserver"


def _hostname(value: str | None) -> str | None:
    """The host of a ``Host`` header (``name:port``)."""
    try:
        return urlsplit("//" + value).hostname if value else None
    except ValueError:
        return None


def _origin_hostname(value: str) -> str | None:
    """The host of an ``Origin`` header (``scheme://name:port``; ``null`` has none)."""
    try:
        return urlsplit(value).hostname
    except ValueError:
        return None


def create_app(db_path: str | Path | None = None) -> FastAPI:
    app = FastAPI(title="Estate Scanner")
    app.state.db_path = db_path or db.DEFAULT_DB_PATH

    # Ensure the schema exists before any request arrives.
    conn = db.connect(app.state.db_path)
    conn.close()

    @app.exception_handler(RequestValidationError)
    async def validation_without_the_input(request, exc):
        # FastAPI's default answer repeats each bad value as `input`. For Connect that value can be the
        # secret typed into the form (a hand-written client posting a number or a list where the string
        # goes), and a secret is never shown back. Where and why stay; the value goes.
        if request.url.path.endswith("/connect"):
            errors = [{k: v for k, v in e.items() if k not in ("input", "ctx", "url")} for e in exc.errors()]
            return JSONResponse({"detail": errors}, status_code=422)
        return await request_validation_exception_handler(request, exc)

    @app.middleware("http")
    async def only_this_machine(request, call_next):
        """Refuse an /api request that names another host or comes from another origin. A web page whose name is re-pointed at 127.0.0.1 after
        the browser loaded it (DNS rebinding) otherwise reaches every route as if it were this app's own page: start a scan, export, delete scan
        data, pair with BimDash. Simple cross-site requests are already stopped (a JSON body needs a preflight and there is no CORS); this closes
        the one way left. The static page is public code and is not guarded."""
        if request.url.path == "/api" or request.url.path.startswith("/api/"):
            allowed = LOOPBACK_HOSTS | EXTRA_HOSTS
            origin = request.headers.get("origin")
            if _hostname(request.headers.get("host")) not in allowed or (origin is not None and _origin_hostname(origin) not in allowed):
                return JSONResponse({"detail": "This address is not allowed."}, status_code=403)
        return await call_next(request)

    app.include_router(platforms.router, prefix="/api/platforms", tags=["platforms"])
    app.include_router(bimdash.router, prefix="/api/bimdash", tags=["bimdash"])
    app.include_router(scans.router, prefix="/api/scans", tags=["scans"])
    app.include_router(estate.router, prefix="/api/estate", tags=["estate"])
    app.include_router(export.router, prefix="/api/export", tags=["export"])
    app.include_router(graph.router, prefix="/api/graph", tags=["graph"])

    if STATIC_DIR.exists():
        app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="static")

    # This app only ever runs against a local webview or a developer's own
    # browser tab, never behind a CDN -- there's no upside to caching and a
    # real downside: the ds-preview.js loader fetches every .jsx source on
    # each page load, and a stale cached copy makes an edited screen look
    # like it never changed.
    @app.middleware("http")
    async def no_cache(request, call_next):
        response = await call_next(request)
        response.headers["Cache-Control"] = "no-store"
        return response

    return app

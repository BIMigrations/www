"""Amazon Redshift.

Two load routes, chosen by size. A small table goes in with batched
INSERTs, which needs nothing but the database connection. Anything large
is staged to S3 and pulled in with COPY, because Redshift is columnar and
row-at-a-time insertion of a few million rows is not a slow version of the
right answer -- it is the wrong mechanism.

That means "the customer owns a warehouse" also means "the customer owns
a staging bucket" for anything but toy volumes. Worth saying out loud in
the engagement checklist rather than discovering it on site.

Credentials come from the environment, never from the control database:
`REDSHIFT_PASSWORD` for the cluster, and the standard AWS chain (env vars,
profile or instance role) for S3. Nothing here logs either, and the COPY's
credential clause is never put in an event or an artefact.
"""

from __future__ import annotations

import contextlib
import datetime as _dt
import hashlib
import os
import re
import time
import uuid
from pathlib import Path
from typing import Any

from .base import (
    BULK_LOAD_ROW_THRESHOLD,
    ColumnSpec,
    LoadResult,
    TableSpec,
    WarehouseAdapter,
    WarehouseNotConfigured,
    read_csv_rows,
    varchar_size,
)

TABLE_FINGERPRINT = "bimcontrol:"       # prefix of the comment that records what a table was built from
TABLE_DATA_AS_OF = "bimcontrol-data-as-of:"   # prefix of the comment that records when a landed table's data was exported
_QUALIFIED_NAME = re.compile(r"\b([a-z_][a-z0-9_]*)\.([a-z_][a-z0-9_]*)\b")

# Domo's types, as they appear in `datasets.schema_columns_json`.
TYPE_MAP = {
    "STRING": None,           # sized from the data -- see column_ddl
    "LONG": "BIGINT",
    "INTEGER": "BIGINT",
    "DOUBLE": "DOUBLE PRECISION",
    "DECIMAL": "DECIMAL(38,6)",
    "DATE": "DATE",
    "DATETIME": "TIMESTAMP",
    "TIMESTAMP": "TIMESTAMP",
    "BOOLEAN": "BOOLEAN",
}

# Redshift rejects a table whose declared row width exceeds this.
MAX_ROW_BYTES = 4 * 1024 * 1024

# Rows per multi-row INSERT. Large enough that the round trip stops
# dominating, small enough to stay well under Redshift's 16MB statement
# limit on a wide table.
INSERT_BATCH_ROWS = 500


def column_ddl(column: ColumnSpec) -> str:
    """One column's DDL. String columns are sized from measured data."""
    source_type = (column.source_type or "STRING").upper()
    mapped = TYPE_MAP.get(source_type, None)
    if mapped is None:
        mapped = f"VARCHAR({varchar_size(column.max_bytes)})"
    return f'"{column.name}" {mapped}'


def create_table_sql(spec: TableSpec, replace: bool = True) -> str:
    columns = ",\n  ".join(column_ddl(c) for c in spec.columns)
    # CASCADE: views from earlier runs depend on the table; the pipeline recreates its views
    # after landing (create_view drops then creates), so dropping them here is safe.
    prefix = f'DROP TABLE IF EXISTS {spec.ref} CASCADE;\n' if replace else ""
    exists = "" if replace else "IF NOT EXISTS "
    return f'{prefix}CREATE TABLE {exists}{spec.ref} (\n  {columns}\n)'


def estimated_row_bytes(spec: TableSpec) -> int:
    total = 0
    for column in spec.columns:
        source_type = (column.source_type or "STRING").upper()
        if TYPE_MAP.get(source_type) is None:
            total += varchar_size(column.max_bytes)
        else:
            total += 8
    return total


def copy_sql(spec: TableSpec, s3_uri: str, credentials_clause: str) -> str:
    """The COPY statement.

    `credentials_clause` is interpolated rather than parameterised because
    Redshift's COPY takes no bind parameters. It is built from environment
    values only, never from anything a user or an estate supplied, and the
    statement is never logged.
    """
    return (
        f"COPY {spec.ref} FROM '{s3_uri}'\n"
        f"{credentials_clause}\n"
        "FORMAT AS CSV IGNOREHEADER 1\n"
        "TIMEFORMAT 'auto' DATEFORMAT 'auto'\n"
        # An empty field is NULL (Domo exports blanks, not NULLs). A field of only spaces is NOT: it is a value in Domo
        # ('    ' in 12.3M of Customer_Claims2's Rev Code, '     ' in SSIGroup's WLU Dept No) that a join, a filter on <> ''
        # and a group-by see, so BLANKSASNULL (which nulls it, text columns only) is not used. Measured 2026-10-23: Domo
        # 12,284,242 spaces + 4,994,512 empty = the 17,278,754 NULLs the landed copy held. The insert path never nulled them.
        "EMPTYASNULL\n"
        # Some rows of Domo's export end one field early (Intelligent Encounter v2, 397 columns: "Delimiter not found" on
        # column 396 of the first row); the missing trailing columns are empty in Domo.
        "FILLRECORD ACCEPTINVCHARS"
    )


class RedshiftAdapter(WarehouseAdapter):
    key = "redshift"
    display_name = "Amazon Redshift"

    def __init__(self, settings: dict[str, Any] | None = None):
        super().__init__(settings)
        self._conn = None
        self.reused_tables: list[str] = []   # tables create_table_as(reuse_within=) found already built

    # ---- lifecycle ------------------------------------------------------

    def connect(self) -> None:
        if self._conn is not None:
            return
        try:
            import psycopg2  # noqa: PLC0415 -- optional extra, imported on use
        except ImportError as exc:
            raise WarehouseNotConfigured(
                "Redshift support needs the 'warehouse' extra: pip install 'bimcontrol[warehouse]'"
            ) from exc

        missing = [k for k in ("host", "database", "user") if not self.settings.get(k)]
        if missing:
            raise WarehouseNotConfigured(
                f"Redshift settings are missing: {', '.join(missing)}. "
                "Set them on the project's warehouse settings."
            )
        password = os.environ.get("REDSHIFT_PASSWORD") or self.settings.get("password")
        if not password:
            raise WarehouseNotConfigured(
                "No Redshift password. Set REDSHIFT_PASSWORD in the environment "
                "(it is deliberately not stored in the control database)."
            )

        self._conn = psycopg2.connect(
            host=self.settings["host"],
            port=int(self.settings.get("port", 5439)),
            dbname=self.settings["database"],
            user=self.settings["user"],
            password=password,
            connect_timeout=int(self.settings.get("connect_timeout", 30)),
            # A big dataflow's EXPLAIN can run for minutes with the socket idle;
            # keepalives stop the network from dropping it (bimcontrol#64).
            keepalives=1,
            keepalives_idle=30,
            keepalives_interval=10,
            keepalives_count=5,
        )
        self._conn.autocommit = True

    def close(self) -> None:
        if self._conn is not None:
            self._conn.close()
            self._conn = None

    def _cursor(self):
        if self._conn is not None and getattr(self._conn, "closed", 0):
            self._conn = None  # the server or network dropped it: reconnect
        if self._conn is None:
            self.connect()
        return self._conn.cursor()

    # ---- schema and tables ----------------------------------------------

    def ensure_schema(self, schema: str) -> None:
        with self._cursor() as cursor:
            cursor.execute(f"CREATE SCHEMA IF NOT EXISTS {schema}")

    def create_table(self, spec: TableSpec, replace: bool = True) -> None:
        width = estimated_row_bytes(spec)
        if width > MAX_ROW_BYTES:
            raise WarehouseNotConfigured(
                f"{spec.ref} would declare {width:,} bytes per row, over Redshift's "
                f"{MAX_ROW_BYTES:,} limit. Narrow the columns or split the table."
            )
        with self._cursor() as cursor:
            cursor.execute(create_table_sql(spec, replace=replace))

    def building(self, schema: str, name: str):
        return self._building(schema, name)

    def table_created_at(self, schema: str, table: str) -> _dt.datetime | None:
        try:
            with self._cursor() as cursor:
                cursor.execute(
                    "SELECT c.relcreationtime FROM pg_class_info c JOIN pg_namespace n ON n.oid = c.relnamespace"
                    " WHERE n.nspname = %s AND c.relname = %s", (schema, table))
                found = cursor.fetchone()
        except Exception:  # noqa: BLE001 -- no catalogue access: cannot say
            return None
        return found[0] if found else None

    def mark_data_as_of(self, schema: str, table: str, as_of: _dt.datetime) -> None:
        try:
            with self._cursor() as cursor:
                cursor.execute(f"COMMENT ON TABLE {schema}.{table} IS '{TABLE_DATA_AS_OF}{as_of.isoformat(timespec='seconds')}'")
        except Exception:  # noqa: BLE001 -- not recorded: the creation time stands in (later than the data, so it under-reports)
            return

    def table_data_as_of(self, schema: str, table: str) -> _dt.datetime | None:
        try:
            with self._cursor() as cursor:
                cursor.execute(
                    "SELECT c.relcreationtime, obj_description(c.reloid, 'pg_class') FROM pg_class_info c"
                    " JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = %s AND c.relname = %s",
                    (schema, table))
                found = cursor.fetchone()
        except Exception:  # noqa: BLE001 -- no catalogue access: cannot say
            return None
        if not found:
            return None
        created, comment = found
        if comment and str(comment).startswith(TABLE_DATA_AS_OF):
            try:
                return _dt.datetime.fromisoformat(str(comment)[len(TABLE_DATA_AS_OF):])
            except ValueError:
                pass
        return created

    @staticmethod
    @contextlib.contextmanager
    def _building(schema: str, name: str):
        """One build of a table at a time on this machine. Three batch lanes copy the same shared source
        (Customer_AccountDetail, read by two dashboards in two lanes): the second one's DROP/CREATE met the first's
        table ("relation already exists"), the failure was logged as "could not check its columns" and its dataflow went
        on to read the view with the mixed-case names, which Redshift cannot resolve (Executive Summary-SW never
        refreshed). Waiting for the lock, the second lane finds the table built and reuses it."""
        try:
            import fcntl
        except ImportError:                        # not on Windows: a single desktop session builds one table at a time
            yield
            return
        from .. import paths
        directory = paths.home() / "locks"
        directory.mkdir(parents=True, exist_ok=True)
        with open(directory / f"{schema}.{name}.lock", "w") as handle:
            fcntl.flock(handle, fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(handle, fcntl.LOCK_UN)

    def create_table_as(
        self, schema: str, name: str, sql: str, reuse_within: _dt.timedelta | None = None,
    ) -> str:
        self.ensure_schema(schema)
        with self._building(schema, name):
            # A build of millions of rows runs for many minutes on one socket; a network blip ("could not receive data
            # from server: Operation timed out", YOY Clinic Posting Date-SW, Customer_Charge_Claims, 20M rows) said
            # nothing about the SQL and left the model an empty table. The session is gone and so is its statement:
            # build once more on a new connection. Any other error is the SQL's and is raised as it was.
            for attempt in (1, 2):
                try:
                    return self._create_table_as(schema, name, sql, reuse_within)
                except Exception as exc:  # noqa: BLE001 -- only a lost connection is retried
                    if attempt == 1 and self._connection_lost(exc):
                        self._conn = None
                        self._end_cut_build(schema, name)
                        continue
                    raise
            raise AssertionError("unreachable")

    def _end_cut_build(self, schema: str, name: str) -> None:
        """The session whose socket dropped can keep its CREATE TABLE AS running on the cluster until Redshift notices the
        dead peer; a retry then queues behind it (or builds 20M rows twice, or meets its half-made `__new` table). Ends that
        session's statement for this table and waits until it is gone. Best effort: if the cluster cannot be asked, the retry
        goes ahead as it did before (bimcontrol#378)."""
        try:
            with self._cursor() as cursor:
                cursor.execute(
                    "SELECT DISTINCT pid FROM stv_recents WHERE status = 'Running' AND pid <> pg_backend_pid() "
                    "AND (query ILIKE %s OR query ILIKE %s)",
                    (f"create table {schema}.{name} as %", f"create table {schema}.{name}__new as %"),
                )
                pids = [row[0] for row in cursor.fetchall()]
                for pid in pids:
                    cursor.execute("SELECT pg_terminate_backend(%s)", (pid,))
                for _ in range(20 if pids else 0):
                    cursor.execute("SELECT COUNT(*) FROM stv_recents WHERE status = 'Running' AND pid IN %s", (tuple(pids),))
                    if not cursor.fetchone()[0]:
                        break
                    time.sleep(3)
        except Exception:  # noqa: BLE001 -- the build is retried either way
            pass

    def _create_table_as(
        self, schema: str, name: str, sql: str, reuse_within: _dt.timedelta | None,
    ) -> str:
        statement = sql.strip().rstrip(";")
        fingerprint = self._fingerprint(statement) if reuse_within is not None else None
        if fingerprint is not None and self._built_from(schema, name, fingerprint, reuse_within):
            self.reused_tables.append(self.table_ref(schema, name))
            return self.table_ref(schema, name)
        with self._cursor() as cursor:
            # An earlier run published this name as a view; DROP TABLE refuses those.
            cursor.execute(
                "SELECT table_type FROM information_schema.tables WHERE table_schema = %s AND table_name = %s",
                (schema, name),
            )
            found = cursor.fetchone()
            if not found:
                cursor.execute(f"CREATE TABLE {schema}.{name} AS {statement}")
                if fingerprint is not None:
                    cursor.execute(f"COMMENT ON TABLE {schema}.{name} IS '{TABLE_FINGERPRINT}{fingerprint}'")
                return self.table_ref(schema, name)
            # Build beside the old table and swap in one transaction: a published model refreshing from this table
            # (a shared staged table, rebuilt by another lane) found it missing for the whole build otherwise
            # (Discharge Trend-SW: relation "<staging schema>.stage_customer_encounter_with_flags_daily_..._s4" does
            # not exist, the refresh failed and the dashboard could not be compared).
            kind = "VIEW" if "VIEW" in found[0].upper() else "TABLE"
            fresh = f"{name}__new"
            cursor.execute(f"DROP TABLE IF EXISTS {schema}.{fresh}")
            cursor.execute(f"CREATE TABLE {schema}.{fresh} AS {statement}")
            if fingerprint is not None:
                cursor.execute(f"COMMENT ON TABLE {schema}.{fresh} IS '{TABLE_FINGERPRINT}{fingerprint}'")
            cursor.execute("BEGIN")
            try:
                cursor.execute(f"DROP {kind} {schema}.{name} CASCADE")
                cursor.execute(f"ALTER TABLE {schema}.{fresh} RENAME TO {name}")
                cursor.execute("COMMIT")
            except Exception:
                try:
                    cursor.execute("ROLLBACK")
                except Exception:  # noqa: BLE001 -- a dropped connection: the server rolled back; keep the real error
                    pass
                raise
        return self.table_ref(schema, name)

    def _fingerprint(self, statement: str) -> str | None:
        """The query plus when each table it names was created (None: cannot tell, so rebuild).

        A table is only as good as what it was built from, and an input rebuilt
        since (a staged table above it, a re-landed source) has a new creation
        time. A view's creation time says nothing about its tables' data: that
        part is covered by the age limit, as every table built here is a snapshot.
        """
        names = sorted(set(_QUALIFIED_NAME.findall(statement)))
        stamps: list[tuple[str, str, Any]] = []
        try:
            with self._cursor() as cursor:
                for schema, relation in names:
                    cursor.execute(
                        "SELECT c.relcreationtime FROM pg_class_info c JOIN pg_namespace n ON n.oid = c.relnamespace"
                        " WHERE n.nspname = %s AND c.relname = %s",
                        (schema, relation),
                    )
                    found = cursor.fetchone()
                    if found:
                        stamps.append((schema, relation, found[0]))
        except Exception:  # noqa: BLE001 -- no catalogue access: just rebuild
            return None
        digest = hashlib.sha256(statement.encode())
        digest.update(repr(stamps).encode())
        return digest.hexdigest()[:40]

    def _built_from(self, schema: str, table: str, fingerprint: str, within: _dt.timedelta) -> bool:
        oldest = _dt.datetime.now(_dt.timezone.utc).replace(tzinfo=None) - within
        try:
            with self._cursor() as cursor:
                cursor.execute(
                    "SELECT 1 FROM pg_class_info c JOIN pg_namespace n ON n.oid = c.relnamespace"
                    " WHERE n.nspname = %s AND c.relname = %s AND c.relkind = 'r' AND c.relcreationtime >= %s"
                    " AND obj_description(c.reloid, 'pg_class') = %s",
                    (schema, table, oldest, f"{TABLE_FINGERPRINT}{fingerprint}"),
                )
                return cursor.fetchone() is not None
        except Exception:  # noqa: BLE001 -- no catalogue access: just rebuild
            return False

    def _built_since(self, schema: str, table: str, since: _dt.datetime) -> bool:
        try:
            with self._cursor() as cursor:
                cursor.execute(
                    "SELECT 1 FROM pg_class_info c JOIN pg_namespace n ON n.oid = c.relnamespace"
                    " WHERE n.nspname = %s AND c.relname = %s AND c.relkind = 'r' AND c.relcreationtime >= %s",
                    (schema, table, since),
                )
                return cursor.fetchone() is not None
        except Exception:  # noqa: BLE001 -- no catalogue access: just rebuild
            return False

    # pg_type OIDs of the text types: text, bpchar, varchar.
    _TEXT_OIDS = frozenset({25, 1042, 1043})

    def lowercase_copy(
        self, source_ref: str, schema: str, name: str, reuse_since: _dt.datetime | None = None,
        reuse_within: _dt.timedelta | None = None,
    ) -> str | None:
        # The reference is a table, a view or a parenthesised query (a connector's
        # configured SELECT). Describe it with case-sensitive identifiers on, which is
        # the only mode that reports a column's real case; the setting is per session.
        with self._cursor() as cursor:
            cursor.execute("SET enable_case_sensitive_identifier TO true")
        try:
            with self._cursor() as cursor:
                cursor.execute(f"SELECT * FROM {source_ref} LIMIT 0")
                described = [(column[0], len(column) > 1 and column[1] in self._TEXT_OIDS, column[1] if len(column) > 1 else None)
                             for column in cursor.description]
            columns = [column for column, _, _ in described]
            lowered = [column.lower() for column in columns]
            has_text = any(is_text for _, is_text, _ in described)
            if (columns == lowered and not has_text) or len(set(lowered)) != len(lowered):
                return None  # nothing to fold or empty, or folding would merge two columns
            if reuse_since is not None and self._built_since(schema, name, reuse_since):
                return self.table_ref(schema, name)

            def quoted(column: str) -> str:
                return '"' + column.replace(chr(34), chr(34) * 2) + '"'

            # Domo reads an empty string from a connector as null (Customer_Claims Redshift: 648,666 null CPT
            # codes in Domo, 132 null and 648,534 empty in the table), so a filter "is null" or a comparison on
            # the copy answers as it does in Domo.
            select = ", ".join(
                (self._empty_as_null(quoted(column), oid) if is_text else quoted(column)) + f" AS {quoted(column.lower())}"
                for column, is_text, oid in described
            )
            return self.create_table_as(schema, name, f"SELECT {select} FROM {source_ref}", reuse_within=reuse_within)
        finally:
            with self._cursor() as cursor:
                cursor.execute("SET enable_case_sensitive_identifier TO false")

    @staticmethod
    def _empty_as_null(quoted_column: str, oid: int | None) -> str:
        """The column with an empty string as null and a string of spaces kept: Redshift compares VARCHAR without its trailing
        spaces, so `NULLIF(c, '')` also nulls '  ' (import_customer.v_dailycharge_cost_alpha.modifer1: 9,351,360 rows equal ''
        and 6,153,330 are empty; Domo holds 16,018,259 null, no empty and 3,198,030 of spaces). Only a zero-length value is
        empty. A CHAR column keeps the comparison it had (its values are padded: a blank is never zero-length)."""
        if oid == 1042:
            return f"NULLIF({quoted_column}, '')"
        return f"CASE WHEN OCTET_LENGTH({quoted_column}) = 0 THEN NULL ELSE {quoted_column} END"

    def empty_text_as_null(self, sql: str) -> str | None:
        """The statement as a SELECT that returns an empty string in a text column as null, or None when it has no text column.

        Domo stores no empty string: a flow's output column that holds '' (a split with fewer parts, a value mapped
        to '') reads as null in the dataset, and so in every flow and card that reads it (customer Denials: Domo's
        'Denial Code 2' is null on 2,372,205 of 2,746,323 rows and empty on none; the converted SQL gave ''). Raises
        what the warehouse raises when the statement cannot be described; the caller keeps the statement then.
        """
        statement = sql.strip().rstrip(";")
        with self._cursor() as cursor:
            cursor.execute(f"SELECT * FROM (\n{statement}\n) AS _described LIMIT 0")
            columns = [(column[0], len(column) > 1 and column[1] in self._TEXT_OIDS, column[1] if len(column) > 1 else None)
                       for column in cursor.description]
        if not any(is_text for _, is_text, _ in columns):
            return None

        def quoted(name: str) -> str:
            return '"' + name.replace('"', '""') + '"'

        select = ", ".join(
            (self._empty_as_null(quoted(name), oid) if is_text else quoted(name)) + f" AS {quoted(name)}" for name, is_text, oid in columns
        )
        return f"SELECT {select}\nFROM (\n{statement}\n) AS _domo_output;"

    def create_view(self, schema: str, name: str, sql: str) -> str:
        self.ensure_schema(schema)
        statement = sql.strip().rstrip(";")
        # DROP then CREATE: CREATE OR REPLACE cannot change a column's type, which a re-run
        # after a converter fix legitimately does ("cannot change data type of view column").
        with self._cursor() as cursor:
            # CASCADE: views from an earlier run that read this one are rebuilt later in this run.
            cursor.execute(f"DROP VIEW IF EXISTS {schema}.{name} CASCADE")
            cursor.execute(f"CREATE VIEW {schema}.{name} AS {statement}")
        return self.table_ref(schema, name)

    def table_exists(self, schema: str, table: str) -> bool:
        with self._cursor() as cursor:
            cursor.execute(
                "SELECT 1 FROM information_schema.tables WHERE table_schema = %s AND table_name = %s",
                (schema, table),
            )
            return cursor.fetchone() is not None

    def table_has_column(self, schema: str, table: str, column: str) -> bool:
        with self._cursor() as cursor:
            cursor.execute(
                "SELECT 1 FROM information_schema.columns WHERE table_schema = %s AND table_name = %s AND column_name = %s",
                (schema, table, column),
            )
            return cursor.fetchone() is not None

    def row_count(self, schema: str, table: str) -> int:
        with self._cursor() as cursor:
            cursor.execute(f"SELECT COUNT(*) FROM {schema}.{table}")
            return int(cursor.fetchone()[0])

    def validate_sql(self, sql: str) -> tuple[bool, str | None]:
        """Plan the statement as the table it will become, without running it.

        A temp table with LIMIT 0 rather than EXPLAIN: it costs the same (measured on 30 customer
        outputs, 1-40 s either way) and also catches what only CREATE TABLE rejects, such as a
        duplicate column name (bimcontrol#123). Divide-by-zero and bad casts need data and still
        surface when the table is built.
        """
        statement = sql.strip().rstrip(";")
        for attempt in (1, 2):
            try:
                with self._cursor() as cursor:
                    cursor.execute("DROP TABLE IF EXISTS _bimcontrol_check")
                    cursor.execute(f"CREATE TEMP TABLE _bimcontrol_check AS SELECT * FROM (\n{statement}\n) AS _checked LIMIT 0")
            except Exception as exc:  # noqa: BLE001 -- the message is the finding
                # A dropped connection says nothing about the SQL: one failure
                # must not poison every statement validated after it.
                if attempt == 1 and self._connection_lost(exc):
                    self._conn = None
                    continue
                return False, str(exc).strip().splitlines()[0][:400]
            return True, None
        return False, "connection lost"

    def query_row(self, sql: str, timeout_seconds: int = 120) -> tuple[Any, ...] | None:
        """First row of a read-only query; stopped by the server after `timeout_seconds`, so that
        a check cannot sit in a lock chain with a build's DROP TABLE."""
        with self._cursor() as cursor:
            cursor.execute(f"SET statement_timeout = {int(timeout_seconds) * 1000}")
            try:
                cursor.execute(sql.strip().rstrip(";"))
                return tuple(cursor.fetchone())
            finally:
                cursor.execute("RESET statement_timeout")

    # pg_type OIDs -> the Domo-style type names the model uses.
    _TYPE_BY_OID = {
        16: "BOOLEAN", 20: "LONG", 21: "LONG", 23: "LONG", 700: "DOUBLE", 701: "DOUBLE", 1700: "DECIMAL",
        1082: "DATE", 1114: "DATETIME", 1184: "DATETIME",
    }

    def describe_sql(self, sql: str) -> list[tuple[str, str]] | None:
        # In the default mode: the converter writes identifiers for it, and a statement
        # that EXPLAIN accepts must be described the same way. Names come back lower-cased,
        # so callers match them case-insensitively.
        statement = sql.strip().rstrip(";")
        try:
            with self._cursor() as cursor:
                cursor.execute(f"SELECT * FROM (\n{statement}\n) AS _described LIMIT 0")
                return [(c[0], self._TYPE_BY_OID.get(c[1], "STRING")) for c in cursor.description]
        except Exception:  # noqa: BLE001 -- unknown is an answer; validate_sql reports the real failure
            return None

    @staticmethod
    def _connection_lost(exc: Exception) -> bool:
        import psycopg2  # noqa: PLC0415 -- optional extra

        if isinstance(exc, psycopg2.InterfaceError):
            return True
        return isinstance(exc, psycopg2.OperationalError) and any(
            m in str(exc).lower() for m in ("ssl", "connection", "server closed", "terminated",
                                            "could not receive data", "operation timed out")
        )

    # ---- loading --------------------------------------------------------

    def load_csv(self, spec: TableSpec, csv_path: Path, row_count: int | None = None) -> LoadResult:
        rows = row_count if row_count is not None else 0
        staging_configured = bool(self.settings.get("s3_bucket"))

        if rows >= BULK_LOAD_ROW_THRESHOLD and not staging_configured:
            raise WarehouseNotConfigured(
                f"{spec.ref} has {rows:,} rows, which needs an S3 staging bucket to load "
                "(set s3_bucket on the project's warehouse settings). Row-by-row insertion "
                "at this size is not viable against Redshift."
            )
        if staging_configured and rows >= BULK_LOAD_ROW_THRESHOLD:
            return self._copy_from_s3(spec, csv_path, rows)
        return self._insert_rows(spec, csv_path)

    def _insert_rows(self, spec: TableSpec, csv_path: Path) -> LoadResult:
        """Batched multi-row INSERTs.

        `execute_values` rather than `executemany`: psycopg2's executemany
        sends one statement per row, which measured at ~2 rows/second
        against a Redshift cluster over a VPN -- an hour for the ten small
        spreadsheets behind one dashboard. This builds a single
        `INSERT ... VALUES (...), (...), ...` per batch instead.

        Still only for small tables. Past BULK_LOAD_ROW_THRESHOLD the
        answer is COPY from S3, not a bigger batch.
        """
        from psycopg2.extras import execute_values  # noqa: PLC0415 -- optional extra

        columns = ", ".join(f'"{c.name}"' for c in spec.columns)
        # execute_values formats the statement with %: a column called "Margin %" must be doubled.
        statement = f"INSERT INTO {spec.ref} ({columns.replace('%', '%%')}) VALUES %s"
        loaded = 0
        with self._cursor() as cursor:
            for batch in read_csv_rows(csv_path, batch_size=INSERT_BATCH_ROWS):
                execute_values(cursor, statement, batch, page_size=INSERT_BATCH_ROWS)
                loaded += len(batch)
        return LoadResult(table_ref=spec.ref, rows_loaded=loaded, method="insert")

    def _copy_from_s3(self, spec: TableSpec, csv_path: Path, rows: int) -> LoadResult:
        try:
            import boto3  # noqa: PLC0415 -- optional extra, imported on use
        except ImportError as exc:
            raise WarehouseNotConfigured(
                "Staged loading needs the 'warehouse' extra: pip install 'bimcontrol[warehouse]'"
            ) from exc

        bucket = self.settings["s3_bucket"]
        prefix = (self.settings.get("s3_prefix") or "bimcontrol/landing").strip("/")
        key = f"{prefix}/{spec.table}-{uuid.uuid4().hex[:8]}.csv"
        size = csv_path.stat().st_size

        s3 = boto3.client("s3", region_name=self.settings.get("aws_region"))
        s3.upload_file(str(csv_path), bucket, key)
        try:
            with self._cursor() as cursor:
                cursor.execute(copy_sql(spec, f"s3://{bucket}/{key}", self._credentials_clause()))
            loaded = self.row_count(spec.schema, spec.table)
        finally:
            # The staged copy is disposable; leaving it behind accumulates
            # customer data in a bucket nobody is watching.
            if self.settings.get("keep_staged_files") is not True:
                s3.delete_object(Bucket=bucket, Key=key)

        warnings = []
        if loaded != rows:
            warnings.append(
                f"{spec.ref} loaded {loaded:,} rows but the source reported {rows:,}"
            )
        return LoadResult(
            table_ref=spec.ref, rows_loaded=loaded, method="copy_from_s3",
            bytes_staged=size, warnings=warnings,
        )

    def _credentials_clause(self) -> str:
        """How COPY authenticates to S3. An IAM role is the right answer;
        keys are the fallback for a laptop inside a customer's network."""
        role = self.settings.get("iam_role") or os.environ.get("REDSHIFT_COPY_IAM_ROLE")
        if role:
            return f"IAM_ROLE '{role}'"
        access_key = os.environ.get("AWS_ACCESS_KEY_ID")
        secret_key = os.environ.get("AWS_SECRET_ACCESS_KEY")
        if not (access_key and secret_key):
            raise WarehouseNotConfigured(
                "COPY needs either an IAM role (iam_role setting or REDSHIFT_COPY_IAM_ROLE) "
                "or AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY in the environment."
            )
        token = os.environ.get("AWS_SESSION_TOKEN")
        clause = f"CREDENTIALS 'aws_access_key_id={access_key};aws_secret_access_key={secret_key}"
        if token:
            clause += f";token={token}"
        return clause + "'"

    def check(self) -> dict[str, Any]:
        self.connect()
        try:
            with self._cursor() as cursor:
                cursor.execute("SELECT current_database(), current_user, version()")
                database, user, version = cursor.fetchone()
            return {
                "warehouse": self.key,
                "ok": True,
                "database": database,
                "user": user,
                "version": str(version).split(" on ")[0],
                "staging": "s3" if self.settings.get("s3_bucket") else "none (inserts only)",
            }
        finally:
            self.close()

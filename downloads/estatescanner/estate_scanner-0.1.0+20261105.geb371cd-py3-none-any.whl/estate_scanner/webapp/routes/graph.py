from __future__ import annotations

from fastapi import APIRouter, Depends

from estate_scanner import graph as graph_module

from ..deps import get_conn
from ..graph_cache import get_graph

router = APIRouter()


@router.get("/stats")
def stats(conn=Depends(get_conn), platform: str | None = None, instance: str | None = None):
    g = get_graph(conn, platform, instance)
    by_type: dict[str, int] = {}
    for _, attrs in g.nodes(data=True):
        by_type[attrs["type"]] = by_type.get(attrs["type"], 0) + 1
    return {"node_count": g.number_of_nodes(), "edge_count": g.number_of_edges(), "by_type": by_type}


@router.get("/most-connected")
def most_connected(conn=Depends(get_conn), platform: str | None = None, instance: str | None = None, top: int = 20):
    g = get_graph(conn, platform, instance)
    ranked = graph_module.most_connected(g, top_n=top)
    return [
        {"platform": attrs["platform"], "instance": attrs["instance"], "type": attrs["type"], "id": attrs["id"], "name": attrs["name"], "degree": degree}
        for _, attrs, degree in ranked
    ]

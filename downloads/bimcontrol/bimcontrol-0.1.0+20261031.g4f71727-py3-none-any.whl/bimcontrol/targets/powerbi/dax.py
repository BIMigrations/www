"""Domo beast modes, translated to DAX.

A deliberately small, honest translator. It handles the shapes that
dominate a real estate -- aggregates over a column, arithmetic between
them, CASE WHEN, IFNULL -- and refuses everything else rather than
guessing. A measure that is wrong in a way nobody notices is worse than
one that is obviously missing, so an untranslatable formula becomes a
`needs_review` item and a measure whose DAX says so.

Two Domo behaviours that do not survive a naive mapping:

- **`COUNT(x)` counts non-null values**, which is DAX's `COUNTA`, not
  `COUNT` (DAX's COUNT only counts numbers). Getting this wrong silently
  undercounts any text column.
- **Division must become `DIVIDE()`**, because Domo returns null on
  divide-by-zero while DAX's `/` returns infinity or an error.
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from contextvars import ContextVar
from dataclasses import dataclass
from decimal import ROUND_HALF_UP, Decimal

# `COUNT(DISTINCT x)` has to be tried before plain `COUNT(x)`.
AGGREGATES: list[tuple[str, str]] = [
    (r"COUNT\s*\(\s*DISTINCT\b\s*", "DISTINCTCOUNT("),
    (r"\bSUM\s*\(", "SUM("),
    (r"\bAVG\s*\(", "AVERAGE("),
    (r"\bAVERAGE\s*\(", "AVERAGE("),
    (r"\bMIN\s*\(", "MIN("),
    (r"\bMAX\s*\(", "MAX("),
    (r"\bCOUNT\s*\(", "COUNTA("),   # Domo COUNT = count of non-null
]

# The row-by-row form of each aggregate, for when its argument is an expression rather than a column.
ITERATORS = {
    "SUM(": "SUMX",
    "AVERAGE(": "AVERAGEX",
    "MIN(": "MINX",
    "MAX(": "MAXX",
    "COUNTA(": "COUNTAX",
}
COLUMN_REF_DAX = re.compile(r"'[^']+'\[[^\]]+\]")

# Scalar functions with a same-named DAX equivalent.
SCALARS = {
    "IFNULL": "COALESCE",
    "ABS": "ABS",
    "ROUND": "ROUND",
    "YEAR": "YEAR",
    "MONTH": "MONTH",
    "DAY": "DAY",
    "DAYOFMONTH": "DAY",
    "HOUR": "HOUR",
    "MINUTE": "MINUTE",
    "SECOND": "SECOND",
    "UPPER": "UPPER",
    "LOWER": "LOWER",
    "TRIM": "TRIM",
    "LEFT": "LEFT",
    "RIGHT": "RIGHT",
    "LENGTH": "LEN",
    "REPLACE": "SUBSTITUTE",
}

# Zero-argument "now" functions. Domo evaluates them when the card is queried; DAX does it per
# query in a measure and once per refresh in a calculated column.
NOW_FUNCTIONS = {"CURRENT_DATE": "TODAY()", "CURDATE": "TODAY()", "NOW": "NOW()"}

# Domo functions that need a shape change rather than a rename.
# MONTHNAME/DAYNAME have no DAX equivalent; FORMAT with a culture pattern
# is the faithful translation.
FORMAT_FUNCTIONS = {"MONTHNAME": "MMMM", "DAYNAME": "dddd"}

COLUMN_REF = re.compile(r"`([^`]+)`")

# Domo's DATE_FORMAT takes MySQL-style tokens; DAX's FORMAT takes .NET
# patterns. Only these are mapped; any other token refuses the formula.
DATE_TOKENS = {
    "%Y": "yyyy", "%y": "yy", "%m": "MM", "%d": "dd",
    "%b": "MMM", "%M": "MMMM", "%H": "HH", "%i": "mm", "%s": "ss",
}


BEAST_MODE_REF = re.compile(r"DOMO_BEAST_MODE\(\s*(\d+)\s*\)", re.IGNORECASE)
_MAX_REFERENCE_DEPTH = 10


def expand_references(
    formula: str, formulas: Mapping[str, str | None] | None, _chain: tuple[str, ...] = (),
) -> tuple[str, str | None]:
    """Inline `DOMO_BEAST_MODE(<id>)` with the referenced beast mode's formula.

    Domo lets one beast mode call another by id. The call means exactly the
    referenced formula, so it is substituted in parentheses, recursively.
    Returns (formula, None), or (formula, reason) when an id is not in
    `formulas`, the references loop, or they nest too deep.
    """
    error: str | None = None

    def replace(match: re.Match) -> str:
        nonlocal error
        ref = match.group(1)
        if error:
            return match.group(0)
        if ref in _chain:
            error = f"beast mode {ref} refers to itself"
            return match.group(0)
        if len(_chain) >= _MAX_REFERENCE_DEPTH:
            error = "beast mode references are nested too deeply"
            return match.group(0)
        inner = (formulas or {}).get(ref)
        if not inner or not inner.strip():
            error = f"beast mode {ref} is not in the scan"
            return match.group(0)
        expanded, inner_error = expand_references(inner, formulas, _chain + (ref,))
        if inner_error:
            error = inner_error
            return match.group(0)
        # Domo writes `DOMO_BEAST_MODE(1)AND x`: a word must not run into the closing parenthesis.
        following = match.string[match.end():match.end() + 1]
        return f"({expanded})" + (" " if following.isalnum() else "")

    expanded = BEAST_MODE_REF.sub(replace, formula)
    return expanded, error


def is_row_level(formula: str) -> bool:
    """True when the formula has no aggregate, so it is computed per row.

    A row-level beast mode (`DATE_FORMAT(`Month`,'%Y')`) is a column in
    Domo: cards group by it. In Power BI that is a calculated column, not
    a measure -- a measure cannot be a chart axis or a slicer value.
    """
    upper = " ".join((formula or "").upper().split())
    if not upper:
        return False
    return not re.search(r"\b(SUM|AVG|AVERAGE|MIN|MAX|COUNT)\s*\(", upper)


def _date_pattern(pattern: str) -> str | None:
    out, index = "", 0
    while index < len(pattern):
        if pattern[index] == "%":
            token = DATE_TOKENS.get(pattern[index:index + 2])
            if token is None:
                return None
            out, index = out + token, index + 2
        else:
            if pattern[index] in '"\\':
                return None
            out, index = out + pattern[index], index + 1
    return out


@dataclass
class DaxResult:
    expression: str
    ok: bool
    reason: str | None = None
    original: str | None = None


def _table_ref(table: str) -> str:
    """A DAX table reference; a quote inside the name is doubled."""
    return "'" + table.replace("'", "''") + "'"


def _columns_to_dax(formula: str, table: str) -> str:
    return COLUMN_REF.sub(lambda m: f"{_table_ref(table)}[{m.group(1)}]", formula)


_NUMBER_TEXT = r'"(-?\d+(?:\.\d+)?)"'


def numbers_for_numeric_columns(expression: str, table: str, numeric_columns: set[str]) -> str:
    """Domo compares a number column with '1' and gets the number's answer; DAX refuses to compare a
    number with text (DNFB - SW: `DNFB Charge Rank = "1"` made the calculated column an error and with
    it every card that groups by it). A text literal that reads as a number, set against a numeric
    column of `table`, becomes the number."""
    for column in numeric_columns:
        ref = re.escape(f"{_table_ref(table)}[{column.replace(']', ']]')}]")
        expression = re.sub(rf"({ref}\s*(?:=|<>|<=|>=|<|>)\s*){_NUMBER_TEXT}", r"\1\2", expression, flags=re.IGNORECASE)
        expression = re.sub(rf"{_NUMBER_TEXT}(\s*(?:=|<>|<=|>=|<|>)\s*{ref})", r"\1\2", expression, flags=re.IGNORECASE)

        def members(match: re.Match[str], ref=ref) -> str:
            items = [part.strip() for part in match.group(2).split(",")]
            if not all(re.fullmatch(_NUMBER_TEXT, item) for item in items):
                return match.group(0)
            return f"{match.group(1)}{{{', '.join(item.strip(chr(34)) for item in items)}}}"

        expression = re.sub(rf"({ref}\s+IN\s+)\{{([^{{}}]*)\}}", members, expression, flags=re.IGNORECASE)
    return expression


_NUMBER_LITERAL = r'(-?\d+(?:\.\d+)?)(?![\w."])'


def text_columns_against_numbers(expression: str, table: str, text_columns: set[str]) -> str:
    """The other way round: Domo compares a text column with 1 as numbers, DAX refuses
    (`CPT Code 5 > 1` made 'CPT Flag' an error column in the DirectQuery model of Special Projects - SW). An
    ordering comparison of a text column with a number reads the column as a number (text that is not one as 0); an equality with a number
    becomes the equality with that number's text."""
    for column in text_columns:
        ref = re.escape(f"{_table_ref(table)}[{column.replace(']', ']]')}]")
        guard = rf"(?<!VALUE\()"          # DAX names are case-insensitive: so is the match; text that is not a number reads as 0, as in Domo
        expression = re.sub(rf"{guard}({ref})(\s*(?:<=|>=|<|>)\s*){_NUMBER_LITERAL}", r"IFERROR(VALUE(\1), 0)\2\3", expression, flags=re.IGNORECASE)
        expression = re.sub(rf"{_NUMBER_LITERAL}(\s*(?:<=|>=|<|>)\s*){guard}({ref})", r"\1\2IFERROR(VALUE(\3), 0)", expression, flags=re.IGNORECASE)
        expression = re.sub(rf"({ref}\s*(?:=|<>)\s*){_NUMBER_LITERAL}", r'\1"\2"', expression, flags=re.IGNORECASE)
        expression = re.sub(rf"{_NUMBER_LITERAL}(\s*(?:=|<>)\s*{ref})", r'"\1"\2', expression, flags=re.IGNORECASE)
        # Arithmetic on the column (`Total Prod Hrs`/2080): text that is not a number ('ERROR:#REF!', left in the data by a
        # spreadsheet) made the whole column an error in DAX ("Cannot convert value 'ERROR:#REF!' of type Text to type Number":
        # Labor Benchmarking, 2 cards); in Domo it is 0. The operand next to `* / + -` is read as a number like the tests above.
        expression = re.sub(rf"(?<!VALUE\()({ref})(?=\s*[*/+\-]\s*[\w'(\"\-\[])", r"IFERROR(VALUE(\1), 0)", expression, flags=re.IGNORECASE)
        expression = re.sub(rf"([*/+\-]\s*)({ref})(?![\w\[])", r"\1IFERROR(VALUE(\2), 0)", expression, flags=re.IGNORECASE)
        # The operand of a `+` / `-` that guards against NULL (`VAR _l = T[col] ... _l - 5`) has no operator next to it.
        expression = re.sub(rf"(VAR _[lr] = )({ref})(?= (?:VAR|RETURN) )", r"\1IFERROR(VALUE(\2), 0)", expression, flags=re.IGNORECASE)
        # SUM of the column: DAX refuses it ("The function SUM cannot work with values of type String": 6 measures of Labor Benchmarking Final,
        # every visual that shows them errored); the values are read as numbers, text that is not one as 0, the reading Domo was measured to give in arithmetic (#302); its SUM was not measured.
        expression = re.sub(rf"(?<![\w.])SUM\(\s*({ref})\s*\)",
                            lambda found: f"SUMX({_table_ref(table)}, IFERROR(VALUE({found.group(1)}), 0))", expression, flags=re.IGNORECASE)
        previous = None
        while previous != expression:          # a DIVIDE inside a DIVIDE is reached on the next pass
            previous, expression = expression, _divide_text_columns(expression, ref)
    return expression


def _divide_text_columns(expression: str, ref: str) -> str:
    """`DIVIDE(T[text], x)` / `DIVIDE(x, T[text])`: an argument that is the text column alone is read as a number."""
    out, position = [], 0
    for match in re.finditer(r"DIVIDE\(", expression):
        if match.start() < position:
            continue
        depth, index = 1, match.end()
        while index < len(expression) and depth:
            depth += {"(": 1, ")": -1}.get(expression[index], 0)
            index += 1
        arguments = _split_arguments(expression[match.end():index - 1])
        if len(arguments) < 2 or not any(re.fullmatch(ref, a, re.IGNORECASE) for a in arguments[:2]):
            continue
        fixed = [f"IFERROR(VALUE({a}), 0)" if re.fullmatch(ref, a, re.IGNORECASE) else a for a in arguments[:2]] + arguments[2:]
        out += [expression[position:match.end()], ", ".join(fixed), ")"]
        position = index
    out.append(expression[position:])
    return "".join(out)




def _date_printed(ref: str, with_time: bool) -> str:
    """`2026-10-19` (or `2026-10-19 08:05:00`) from YEAR/MONTH/DAY: FORMAT is not allowed in a calculated column of a DirectQuery
    table and `ref & ""` cannot be folded to the source; this shape is and can (measured on the Emergency Admits-SW model)."""
    def two(part: str) -> str:
        return f'RIGHT("0" & {part}({ref}), 2)'
    text = f'YEAR({ref}) & "-" & {two("MONTH")} & "-" & {two("DAY")}'
    return text + (f' & " " & {two("HOUR")} & ":" & {two("MINUTE")} & ":" & {two("SECOND")}' if with_time else "")


def _switch_arguments(expression: str) -> list[str] | None:
    """The arguments after `TRUE()` of an expression that is one `SWITCH(TRUE(), ...)` from its first to its last character, else None.
    Commas inside parentheses, double quotes, single quotes (table names) and column brackets (`[a, b]`, `[a]]b]`) do not split."""
    text = expression.strip()
    head = "SWITCH(TRUE(), "
    if not text.startswith(head) or not text.endswith(")"):
        return None
    parts: list[str] = []
    depth, quote, current, index, end = 1, "", "", len(head), len(text) - 1
    while index < end:
        char = text[index]
        if quote:
            if char == quote:
                quote = ""
        elif char in "\"'":
            quote = char
        elif char == "[":                       # a column name runs to the first `]` not doubled
            stop = index + 1
            while stop < len(text) and not (text[stop] == "]" and text[stop + 1:stop + 2] != "]"):
                stop += 2 if text[stop] == "]" else 1
            current += text[index:stop + 1]
            index = stop + 1
            continue
        elif char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
            if depth == 0:                      # the SWITCH closed before the end: `SWITCH(...) & IF(...)`
                return None
        if char == "," and depth == 1 and not quote:
            parts.append(current.strip())
            current = ""
        else:
            current += char
        index += 1
    parts.append(current.strip())
    return parts if depth == 1 else None


def yields_text(expression: str) -> bool:
    """True when the expression is one SWITCH(TRUE(), ...) with a text literal among its results: whatever type Domo
    declares for the beast mode, SQL and the translation both give text (customer Daily Charge 'OR Cases': 'OR Case' ... else 0,
    declared LONG: a column of type int64 made Redshift cast 'OR Case' to a double, 2 cards unanswerable)."""
    arguments = _switch_arguments(expression)
    if arguments is None or len(arguments) % 2 == 0:
        return False
    return any(_CASE_TEXT_RESULT.fullmatch(arguments[i]) for i in list(range(1, len(arguments), 2)) + [len(arguments) - 1])


def _date_text_or_blank(ref: str, with_time: bool) -> str:
    """A blank date stays blank (YEAR(BLANK()) is 1899, and `&` reads a blank as ""), as the NULL the CASE gives in SQL."""
    return f"IF(ISBLANK({ref}), BLANK(), {_date_printed(ref, with_time)})"


def dates_as_text_in_case(expression: str, table: str, date_columns: dict[str, str]) -> str:
    """`CASE WHEN ... THEN 'Bad Service Date' ELSE `servicedate` END`: SQL gives the CASE the type of its text and the date
    is printed; DAX's SWITCH takes the date's type from a result and fails the row that returns the text (Emergency Admits-SW
    'Current Date < Service Date': five cards of the model unanswerable, every pass since 10-18). A date column that is a
    result of a SWITCH with a text result is printed as the text SQL gives (`date_columns`: column name -> source type)."""
    arguments = _switch_arguments(expression)
    if arguments is None or len(arguments) % 2 == 0:
        return expression
    positions = list(range(1, len(arguments), 2)) + [len(arguments) - 1]
    if not any(_CASE_TEXT_RESULT.fullmatch(arguments[i]) for i in positions):
        return expression
    for i in positions:
        for column, kind in date_columns.items():
            if arguments[i].lower() == f"{_table_ref(table)}[{column.replace(']', ']]')}]".lower():
                arguments[i] = _date_text_or_blank(arguments[i], kind.upper() != "DATE")
    return f"SWITCH(TRUE(), {', '.join(arguments)})"


def _collapse_whitespace(text: str) -> str:
    """Runs of whitespace outside string literals and backtick names become one blank.

    A literal keeps every blank it was written with: `'W/O  MCC'` and `'Revenue   '` match the data only as typed (477 field rows of the customer
    estate carry a literal with two or more blanks in a row; `" ".join(text.split())` had made them one)."""
    out: list[str] = []
    quote = ""
    blank = False
    for char in text:
        if quote:
            out.append(char)
            if char == quote:
                quote = ""
            continue
        if char.isspace():
            blank = True
            continue
        if blank and out:
            out.append(" ")
        blank = False
        out.append(char)
        if char in "'`\"":
            quote = char
    return "".join(out)


def _balanced(text: str) -> bool:
    """Parentheses balance outside string literals and backtick names: a bracket that is text (`Total )`, ')') is not one."""
    depth = 0
    quote = ""
    for char in text:
        if quote:
            if char == quote:
                quote = ""
        elif char in "'`":
            quote = char
        elif char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
            if depth < 0:
                return False
    return depth == 0


def _split_top_level(text: str, operators: str) -> tuple[str, str, str] | None:
    """Split on the last binary operator outside brackets and quotes.

    Returns (left, operator, right).

    Two subtleties, both of which produced wrong DAX before they were
    handled. Splitting on the **last** operator keeps left-associativity,
    so `a - b - c` becomes `(a - b) - c` rather than `a - (b - c)`. And a
    sign is not an operator: in `amount * -1` the minus follows another
    operator, so it belongs to the literal, not to the expression.
    """
    depth = 0
    in_quote: str | bool = False  # the quote character that is open, if any
    found: int | None = None
    for index, char in enumerate(text):
        if char in "'`":
            if not in_quote:
                in_quote = char
            elif in_quote == char:
                in_quote = False
            continue
        if in_quote:
            continue
        if char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
        elif char.isalpha() and (index == 0 or not (text[index - 1].isalnum() or text[index - 1] == "_")):
            # CASE ... END nests like brackets: an operator inside an arm is not the
            # expression's own (`CASE WHEN a THEN b - c ELSE 0 END`).
            word = re.match(r"[A-Za-z0-9_]+", text[index:]).group(0).upper()
            if word == "CASE":
                depth += 1
            elif word == "END":
                depth -= 1
        elif char in operators and depth == 0:
            previous = text[:index].rstrip()
            if not previous or previous[-1] in "+-*/(,":
                continue  # a sign, or an operator following an operator
            found = index
    if found is None:
        return None
    left, right = text[:found].strip(), text[found + 1:].strip()
    if not left or not right:
        return None
    return left, text[found], right


# The first function name no branch of `_translate_term` knew in the formula being translated, so a refusal can name it.
_REFUSED_FUNCTION: ContextVar[str | None] = ContextVar("refused_function", default=None)


def translate(formula: str, table: str) -> DaxResult:
    """Translate one beast mode. `table` is the model table it belongs to."""
    if not formula or not formula.strip():
        return DaxResult("", False, "empty formula", formula)

    source = _collapse_whitespace(formula)  # the newlines Domo allows, but not the blanks inside a text or a column name
    if not _balanced(source):
        return DaxResult("", False, "unbalanced brackets", formula)

    upper = source.upper()
    for unsupported, why in (
        ("OVER (", "window functions have no direct DAX equivalent"),
        ("PARTITION BY", "window functions have no direct DAX equivalent"),
        ("SELECT ", "embedded SQL"),
    ):
        if unsupported in upper:
            return DaxResult("", False, why, formula)

    token = _REFUSED_FUNCTION.set(None)
    try:
        expression = _translate_expression(source, table)
        refused = _REFUSED_FUNCTION.get()
    finally:
        _REFUSED_FUNCTION.reset(token)
    if expression is None:
        return DaxResult("", False, _REFUSAL_REASONS.get(refused) or (f"{refused} is not translated" if refused else "unsupported syntax"), formula)
    return DaxResult(expression, True, None, formula)


# Functions refused on purpose, with the reason worth reading in the report.
_REFUSAL_REASONS = {
    "TIMEDIFF": "TIMEDIFF is not translated: Domo's TIMEDIFF ignores the date and is not reproducible when the first time of day is earlier",
}


# DAX functions whose arguments are read row by row or over a column: a column reference inside one is not a bare one.
_ROW_CONTEXT_FUNCTIONS = {
    "SUM", "SUMX", "AVERAGE", "AVERAGEX", "MIN", "MINX", "MAX", "MAXX", "COUNT", "COUNTA", "COUNTAX", "COUNTX",
    "DISTINCTCOUNT", "COUNTROWS", "FILTER", "SELECTCOLUMNS", "ADDCOLUMNS", "DISTINCT", "VALUES", "ALL", "CALCULATE",
    "SELECTEDVALUE", "RANKX", "MEDIAN", "PERCENTILEX.INC", "PERCENTILEX.EXC", "CONCATENATEX", "TOPN",
}
_AGGREGATE_CALL = re.compile(r"\b(?:SUM|SUMX|AVERAGE|AVERAGEX|MIN|MINX|MAX|MAXX|COUNTA|COUNTAX|DISTINCTCOUNT|COUNTROWS)\(")
_DAX_TOKEN = re.compile(r"""\"(?:[^\"]|\"\")*\"|'(?:[^']|'')+'\[(?:[^\]]|\]\])+\]|\[(?:[^\]]|\]\])+\]""")


def group_columns_as_values(expression: str) -> str:
    """In a formula that aggregates, a column outside every aggregate is the group's value of it.

    Domo's `CASE WHEN servicemonthfiscalyear = Current Year THEN SUM(x) ... END` compares the columns the card groups
    by; as a measure DAX cannot read a column without a row ("A single value for column ... cannot be determined"), so
    each such reference becomes MAX(column). For a group key that is the key; for a column the card does not group by
    Domo's engine returns an arbitrary row's value, and MAX is a value of the group too (SELECTEDVALUE was blank there:
    Daily Revenue-SW 'Forecasted Charges', whose condition reads the posting date, showed the month-to-date sum where
    Domo projects the month). Applied by the caller to a beast mode that is a measure, after the type fixers (which look
    for `'T'[col] = ...`); a calculated column, where the row is there, is never passed through it."""
    if not _AGGREGATE_CALL.search(expression):
        return expression
    out: list[str] = []
    stack: list[str] = []                       # the function name of each open parenthesis ('' for a plain one)
    index = 0
    while index < len(expression):
        char = expression[index]
        token = _DAX_TOKEN.match(expression, index) if char in "\"'[" else None
        if token:
            text = token.group(0)
            bare = text[0] == "'" and not any(name in _ROW_CONTEXT_FUNCTIONS for name in stack)
            out.append(f"MAX({text})" if bare else text)
            index = token.end()
            continue
        if char == "(":
            name = re.search(r"([A-Za-z_][A-Za-z0-9_.]*)$", "".join(out))
            stack.append(name.group(1).upper() if name else "")
        elif char == ")" and stack:
            stack.pop()
        out.append(char)
        index += 1
    return "".join(out)


def _translate_expression(source: str, table: str) -> str | None:
    text = source.strip()
    while text.startswith("(") and text.endswith(")") and _balanced(text[1:-1]):
        text = text[1:-1].strip()

    # Lowest precedence splits first, so the tree binds the way arithmetic
    # does: `a - b / c` must become `a - DIVIDE(b, c)`, not the reverse.
    for operators in ("+-", "*/"):
        split = _split_top_level(text, operators)
        if split:
            left_text, operator, right_text = split
            left = _translate_expression(left_text, table)
            right = _translate_expression(right_text, table)
            if left is None or right is None:
                return None
            # A parenthesised operand lost its parentheses in the recursion: `(a + b) * -1` must not become
            # `a + b * -1`. Decided on the Domo source (column names are quoted there), not on the generated DAX,
            # whose `'T'[End Date]` the splitter would read as keywords.
            if operators == "*/" or operator == "-":
                if operators == "*/" and _is_parenthesised(left_text) and _has_top_level(left_text, "+-"):
                    left = f"({left})"
                if _is_parenthesised(right_text) and (
                        _has_top_level(right_text, "+-") or operators == "*/" and _has_top_level(right_text, "*/")):
                    right = f"({right})"
            # Domo returns null on divide-by-zero; DAX's `/` does not.
            if operator == "/":
                return f"DIVIDE({left}, {right})"
            # And the null goes on through the arithmetic around it (`1 - x / 0` is null), where DAX reads a blank
            # as 0 (`1 - DIVIDE(x, 0)` is 1): the customer's 'Historical Adj %' showed 100% for 268 rows Domo leaves empty.
            blankable = [(tag, side) for tag, side, source in (("_l", left, left_text), ("_r", right, right_text))
                         if _may_be_blank(side, operator in "+-") or operator in "+-" and _nullif_valued(source)]
            if blankable:
                # Each side once, in a variable: testing the sides and then using them wrote every nested division
                # twice per level (ten ratios added up were 72,000 characters).
                names = dict(blankable)
                bound = " ".join(f"VAR {tag} = {side}" for tag, side in blankable)
                a = "_l" if "_l" in names else left
                b = "_r" if "_r" in names else right
                checks = " || ".join(f"ISBLANK({tag})" for tag, _ in blankable)
                return f"({bound} RETURN IF({checks}, BLANK(), {a} {operator} {b}))"     # parenthesised: a RETURN runs to the end
            return f"{left} {operator} {right}"

    return _translate_term(text, table)


_BLANKABLE_AGGREGATE = re.compile(r"\b(?:SUM|AVERAGE|MIN|MAX|SUMX|AVERAGEX|MINX|MAXX)\(")
_PLAIN_COLUMN = re.compile(r"'(?:[^']|'')+'\[(?:[^\]]|\]\])+\]")


def _may_be_blank(dax_text: str, aggregates: bool = False) -> bool:
    """Whether a translated operand can be blank: a division by zero, or an aggregate over rows that hold no value (SQL's
    `SUM(a) - SUM(b)` is NULL when `a` has none, where DAX reads the blank as 0: customer Revenue Impact's Budget Variance
    of a department with budget and no charges is an empty cell in Domo, -11,505 in the model; 20 cards). An IFNULL around
    it cannot be blank, unless what it falls back on can (`IFNULL(a / b, c / d)`). The aggregate case is asked for `+` and `-`
    only: DAX's `*` already makes a blank of a blank. The same holds for a column (a row where it is NULL: Provider
    Profitability's `Sum(Case ... (Expected Reimb) - (Current Year Amt))` skips a row where either is NULL, DAX kept the other
    one: 2,619,926 against Domo's 34,405 for one provider) and for an operand already guarded by this function."""
    if dax_text.startswith("COALESCE("):
        arguments = _call_arguments(dax_text)
        if arguments is not None:
            return _may_be_blank(arguments[-1], aggregates)
    if aggregates and (_PLAIN_COLUMN.fullmatch(dax_text) or dax_text.lstrip("(").startswith("VAR _")):
        return True
    return "DIVIDE(" in dax_text or aggregates and (_BLANKABLE_AGGREGATE.search(dax_text) is not None or "BLANK()" in dax_text)


_NULLIF_CALL = re.compile(r"NULLIF\s*\(", re.IGNORECASE)


def _nullif_valued(source: str) -> bool:
    """Whether the Domo operand `source` is a NULLIF call, or a product with one (`NULLIF(a, '') * 12`): NULL when its two sides are
    equal, and `NULL + 5` is NULL in Domo where DAX reads the blank as 0 (measured 2026-10-26: `NULLIF(0,0) + 5` NULL,
    `NULLIF('','') + 0` NULL; the estate's `NULLIF(col, '') + 0` casts text to a number). Asked of the source because the DAX of a
    NULLIF is an `IF` like any other; `IFNULL(NULLIF(..), 0)` is a different call and is not matched."""
    text = source.strip()
    while text.startswith("(") and text.endswith(")") and _balanced(text[1:-1]):
        text = text[1:-1].strip()
    call = _NULLIF_CALL.match(text)
    if call and text.endswith(")") and _balanced(text[call.end():-1]):
        return True
    split = _split_top_level(text, "*")
    return split is not None and (_nullif_valued(split[0]) or _nullif_valued(split[2]))


def _call_arguments(dax_text: str) -> list[str] | None:
    """The top-level arguments of `dax_text` when it is one function call from its first character to its last
    (`COALESCE(a, b)`, not `COALESCE(a, b) + c`); None otherwise. Quotes (names, strings) and [names] are skipped."""
    start = dax_text.index("(")
    arguments: list[str] = []
    depth, current, quote = 0, "", ""
    for position in range(start, len(dax_text)):
        char = dax_text[position]
        if quote:
            current += char
            if char == quote:
                quote = ""
            continue
        if char in "'\"":
            quote = char
        elif char == "[":
            quote = "]"
        elif char == "(":
            depth += 1
            if depth == 1:
                continue
        elif char == ")":
            depth -= 1
            if depth == 0:
                arguments.append(current.strip())
                return arguments if position == len(dax_text) - 1 else None
        elif char == "," and depth == 1:
            arguments.append(current.strip())
            current = ""
            continue
        current += char
    return None


def _is_parenthesised(text: str) -> bool:
    text = text.strip()
    return text.startswith("(") and text.endswith(")") and _balanced(text[1:-1])


def _has_top_level(text: str, operators: str) -> bool:
    """Whether the Domo expression `text`, once its outer parentheses are off, has one of `operators` at its top level."""
    text = text.strip()
    while text.startswith("(") and text.endswith(")") and _balanced(text[1:-1]):
        text = text[1:-1].strip()
    return _split_top_level(text, operators) is not None


def _translate_term(text: str, table: str) -> str | None:
    upper = text.upper()

    if re.match(r"CASE\b", upper):                 # not an identifier that starts with it (`Cases`)
        # DAX's SWITCH(TRUE(), ...) is the faithful shape, but Domo's CASE
        # arms can contain anything; translate the whole thing structurally
        # only when every arm is itself translatable.
        return _translate_case(text, table)

    fixed = _translate_fixed(text, table)
    if fixed is not None:
        return fixed

    for pattern, replacement in AGGREGATES:
        match = re.match(pattern, upper)
        if match:
            inner = text[match.end():].rstrip()
            if not inner.endswith(")"):
                return None
            inner = inner[:-1].strip()
            inner_dax = _translate_expression(inner, table)
            if inner_dax is None:
                return None
            if replacement == "DISTINCTCOUNT(" and not COLUMN_REF_DAX.fullmatch(inner_dax):
                # No iterator exists for a distinct count: count the distinct non-blank
                # values of the expression evaluated row by row.
                return (f"COUNTROWS(FILTER(DISTINCT(SELECTCOLUMNS({_table_ref(table)}, \"x\", {inner_dax})), "
                        "NOT ISBLANK([x])))")
            if not COLUMN_REF_DAX.fullmatch(inner_dax):
                # DAX aggregates take a column, not an expression: SUM(CASE ...) is
                # SUMX(table, expression), evaluated row by row like Domo's.
                iterator = ITERATORS.get(replacement)
                if iterator is None:
                    return None
                return f"{iterator}({_table_ref(table)}, {inner_dax})"
            return f"{replacement}{inner_dax})"

    name_match = re.match(r"([A-Za-z_][A-Za-z0-9_]*)\s*\((.*)\)$", text, re.S)
    if name_match:
        name = name_match.group(1).upper()
        if name == "CONCAT":
            # Domo's CONCAT takes any number of arguments; DAX's
            # CONCATENATE takes exactly two, so use the & operator.
            args = _split_arguments(name_match.group(2))
            translated = [_translate_expression(a, table) for a in args]
            if any(a is None for a in translated):
                return None
            joined = "(" + " & ".join(translated) + ")"
            # MySQL's CONCAT is NULL when any argument is NULL; DAX's & reads a blank as "". Domo renders the
            # NULL as an empty cell (the customer's 'Acct ID & Name' = CONCAT(AccountID, ' - ', AccountName) is
            # '' for 5305, the model had '5305 - '), so a blank argument blanks the whole value.
            nullable = [a for a in translated if not re.fullmatch(r'"(?:[^"]|"")*"', a)]
            if not nullable:
                return joined
            return f"IF({' || '.join(f'ISBLANK({a})' for a in nullable)}, BLANK(), {joined})"
        if name == "DATE_FORMAT":
            args = _split_arguments(name_match.group(2))
            if len(args) != 2 or not re.fullmatch(r"'[^']*'", args[1]):
                return None
            pattern = _date_pattern(args[1][1:-1])
            value = _translate_expression(args[0], table)
            if pattern is None or value is None:
                return None
            return f'FORMAT({value}, "{pattern}")'
        if name in NOW_FUNCTIONS and not name_match.group(2).strip():
            return NOW_FUNCTIONS[name]
        if name == "DATE":
            return _translate_date(name_match.group(2), table)
        if name == "DAYOFWEEK":
            inner = _translate_expression(name_match.group(2), table)
            return None if inner is None else f"WEEKDAY({inner}, 1)"           # 1 = Sunday in both
        if name == "WEEKDAY":
            inner = _translate_expression(name_match.group(2), table)
            # Not MySQL's 0 = Monday: Domo's beast mode answers 1 = Sunday .. 7 = Saturday, like DAYOFWEEK (Observation - SW, 2026-10-26:
            # `WEEKDAY(d)` read 1 for a Sunday, and the estate's own formulas test `WEEKDAY(d) = 1` for 'Sunday').
            return None if inner is None else f"WEEKDAY({inner}, 1)"
        if name in ("WEEK", "WEEKOFYEAR") and len(_split_arguments(name_match.group(2))) == 1:
            # Not MySQL mode 0: Domo's beast mode WEEK(d) counts the partial first week as week 1 and begins weeks on Sunday, which is DAX's
            # WEEKNUM(d, 1) (2026-10-26: all 3,224 distinct dates of 'customer Encounter with Flags Daily', 2000-01-04 to 2026-10-04, equal;
            # 2026-01-01 is week 1, 2026-01-04 week 2). The Date Calculator tile's WEEK_OF_YEAR is the MySQL mode 0 one (#394), the beast mode is not.
            # WEEKOFYEAR(d) answers the same numbers (2026-09-27 40, 2026-01-01 1, 2026-12-31 53: function_census.py, 2026-10-26), not ISO weeks.
            inner = _translate_expression(name_match.group(2), table)
            if inner is None:
                return None
            return f"IF(ISBLANK({inner}), BLANK(), WEEKNUM({inner}, 1))"
        if name == "TO_DAYS":
            # Domo's TO_DAYS(2026-09-27) is 739886 and (2024-02-29) 738945: the day count of year 1 = 1 (Python's toordinal), 365 less than
            # MySQL's. DAX counts days from 1899-12-30, which is 693594 on that scale.
            inner = _translate_expression(name_match.group(2), table)
            return None if inner is None else f"IF(ISBLANK({inner}), BLANK(), INT({inner}) + 693594)"
        if name in ("CEILING", "FLOOR") and len(_split_arguments(name_match.group(2))) == 1:
            inner = _translate_expression(name_match.group(2), table)
            return None if inner is None else f"{name}({inner}, 1)"
        if name == "ROUND" and len(_split_arguments(name_match.group(2))) == 1:
            inner = _translate_expression(name_match.group(2), table)
            return None if inner is None else f"ROUND({inner}, 0)"                  # DAX's ROUND has no one-argument form
        if name == "NULLIF":
            return _translate_nullif(name_match.group(2), table)
        if name in ("DAYOFYEAR", "QUARTER"):
            # Domo's DAYOFYEAR(2026-09-27) is 270 and QUARTER(2026-10-03) 4 (function_census.py, 2026-10-26); a NULL date is NULL
            # (DAX reads a blank date as 1899-12-30: YEAR(BLANK()) is 1899), hence the guard. DATEDIFF counts day boundaries,
            # so the time of a timestamp does not move it.
            inner = _translate_expression(name_match.group(2), table)
            if inner is None:
                return None
            value = f"DATEDIFF(DATE(YEAR({inner}), 1, 1), {inner}, DAY) + 1" if name == "DAYOFYEAR" else f"QUARTER({inner})"
            return f"IF(ISBLANK({inner}), BLANK(), {value})"
        if name in ("DATE_SUB", "DATE_ADD"):
            return _translate_date_interval(name, name_match.group(2), table)
        if name in ("MOD", "POWER", "SQRT"):
            return _translate_numeric(name, name_match.group(2), table)
        if name == "STR_TO_DATE":
            return _translate_str_to_date(name_match.group(2), table)
        if name in ("SUBDATE", "ADDDATE"):
            # With a number of days (an INTERVAL argument is not understood); DAX adds days to a date.
            args = _split_arguments(name_match.group(2))
            if len(args) != 2 or re.match(r"\s*INTERVAL\b", args[1], re.IGNORECASE):
                return None
            value, days = (_translate_expression(a, table) for a in args)
            if value is None or days is None:
                return None
            return f"({value} {'-' if name == 'SUBDATE' else '+'} ({days}))"
        if name == "DATEDIFF":
            # MySQL DATEDIFF(a, b) is a - b in days; DAX DATEDIFF takes (start, end, unit).
            args = _split_arguments(name_match.group(2))
            if len(args) != 2:
                return None
            later, earlier = (_translate_expression(a, table) for a in args)
            if later is None or earlier is None:
                return None
            return f"DATEDIFF({earlier}, {later}, DAY)"
        if name == "LAST_DAY":
            inner = _translate_expression(name_match.group(2), table)
            return None if inner is None else f"EOMONTH({inner}, 0)"
        if name in ("SUBSTRING", "SUBSTR", "MID"):
            args = _split_arguments(name_match.group(2))
            if len(args) not in (2, 3):
                return None
            # MySQL counts from 1 like DAX; a negative start counts from the end, which MID cannot do.
            if re.match(r"\s*-", args[1]):
                return None
            translated = [_translate_expression(a, table) for a in args]
            if any(a is None for a in translated):
                return None
            translated = _text_of_date("MID", args, translated)
            length = translated[2] if len(translated) == 3 else f"LEN({translated[0]})"
            return f"MID({translated[0]}, {translated[1]}, {length})"
        if name in FORMAT_FUNCTIONS:
            inner = _translate_expression(name_match.group(2), table)
            if inner is None:
                return None
            return f'FORMAT({inner}, "{FORMAT_FUNCTIONS[name]}")'
        if name in SCALARS:
            args = _split_arguments(name_match.group(2))
            translated = [_translate_expression(a, table) for a in args]
            if any(a is None for a in translated):
                return None
            translated = _text_of_date(name, args, translated)
            return f"{SCALARS[name]}({', '.join(translated)})"
        if _REFUSED_FUNCTION.get() is None:
            _REFUSED_FUNCTION.set(name_match.group(1).upper())          # no branch above knew this name
        return None

    if COLUMN_REF.fullmatch(text):
        return _columns_to_dax(text, table)
    if upper == "CURRENT_DATE":
        return NOW_FUNCTIONS["CURRENT_DATE"]       # the SQL keyword, written without parentheses
    # Domo allows backticks to be left off a name with no spaces: sum(New).
    if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", text) and upper not in ("NULL", "TRUE", "FALSE"):
        return f"{_table_ref(table)}[{text}]"
    if re.fullmatch(r"-?(\d+(\.\d*)?|\.\d+)", text):
        return text if not text.startswith(".") and not text.startswith("-.") else text.replace(".", "0.", 1)
    if re.fullmatch(r"'[^']*'", text):
        return f'"{text[1:-1]}"'
    if COLUMN_REF.search(text):
        return None  # a column mixed into syntax we do not understand
    return None


_FIXED_CLAUSE = re.compile(r"\bFIXED\s*\(((?:[^()]|\([^()]*\))*)\)\s*$", re.IGNORECASE)
_FIXED_DIMENSIONS = re.compile(r"\s*(?:BY\s+((?:`[^`]+`\s*,?\s*)+))?(FILTER\s+NONE)?\s*$", re.IGNORECASE)
_OUTER_SUM = re.compile(r"SUM\s*\((.*)\)$", re.IGNORECASE | re.DOTALL)


def _translate_fixed(text: str, table: str) -> str | None:
    """Domo's `SUM(SUM(x) FIXED (BY d))` / `SUM(SUM(x)) FIXED (BY d)`: the inner aggregate at the level of `d`,
    whatever else the card groups by, summed over the values of `d` the card group holds. `FIXED ()` is the
    whole table; FILTER NONE ignores the filters too (otherwise the card's and the page's filters stay, ALLSELECTED).
    Only plain columns are accepted as dimensions, and the outer aggregate must be a SUM. Inferred from Domo's
    documentation, not yet measured on a render: the parity check on the Hours Per Visits cards is the test."""
    clause = _FIXED_CLAUSE.search(text)
    if clause:
        # Trailing form: the part before it is SUM(<inner aggregate expression>).
        outer = _OUTER_SUM.fullmatch(text[:clause.start()].strip())
        inner_text = outer.group(1) if outer and _balanced(outer.group(1)) else None
    else:
        # Inner form: SUM(<inner aggregate> FIXED (...)).
        outer = _OUTER_SUM.fullmatch(text)
        inner_clause = _FIXED_CLAUSE.search(outer.group(1).strip()) if outer else None
        if inner_clause is None:
            return None
        clause, inner_text = inner_clause, outer.group(1).strip()[:inner_clause.start()]
    if inner_text is None or not re.search(r"\b(SUM|AVG|AVERAGE|MIN|MAX|COUNT)\s*\(", inner_text, re.IGNORECASE):
        return None                                              # `SUM(x) FIXED (...)` alone has no outer aggregate
    dimensions = _FIXED_DIMENSIONS.fullmatch(clause.group(1))
    if dimensions is None:
        return None
    inner = _translate_expression(inner_text, table)
    if inner is None or "FIXED" in inner_text.upper():
        return None
    columns = [f"{_table_ref(table)}[{name}]" for name in COLUMN_REF.findall(dimensions.group(1) or "")]
    whole = _table_ref(table)
    # Domo keeps the card's and the page's filters unless FILTER NONE; ALLSELECTED keeps the filters set outside
    # the visual's own grouping, ALL drops them all.
    scope = f"ALL({whole})" if dimensions.group(2) else f"ALLSELECTED({whole})"
    if not columns:
        return f"CALCULATE({inner}, {scope})"
    keep = ", ".join(columns)
    pins = ", ".join(f"{c} = _{i}" for i, c in enumerate(columns))
    variables = " ".join(f"VAR _{i} = {c}" for i, c in enumerate(columns))
    return f"SUMX(SUMMARIZE({whole}, {keep}), {variables} RETURN CALCULATE({inner}, {scope}, {pins}))"


def _translate_nullif(argument_text: str, table: str) -> str | None:
    """`NULLIF(a, b)`: NULL when a = b, else a. Domo compares text case sensitively (`NULLIF('a', 'A')` is 'a', measured 2026-10-26),
    DAX's `=` does not, so a text literal on either side makes it EXACT. A blank on the right compares to nothing in SQL but equals
    0 and "" in DAX, so a right side that is not a literal is tested first."""
    args = _split_arguments(argument_text)
    if len(args) != 2:
        return None
    if args[1].strip().upper() == "NULL":
        return _translate_expression(args[0], table)          # nothing equals NULL
    if args[0].strip().upper() == "NULL":
        return "BLANK()"
    first, second = (_translate_expression(a, table) for a in args)
    if first is None or second is None:
        return None
    literal = re.fullmatch(r'-?\d+(\.\d*)?|"(?:[^"]|"")*"', second) is not None
    equal = f"EXACT({first}, {second})" if first.startswith('"') or second.startswith('"') else f"{first} = {second}"
    test = f"IF({equal}, BLANK(), {first})"
    return test if literal else f"IF(ISBLANK({second}), {first}, {test})"


_INTERVAL = re.compile(r"\s*INTERVAL\s+(.+?)\s+(DAY|WEEK|MONTH|QUARTER|YEAR)S?\s*", re.IGNORECASE | re.DOTALL)
_PLAIN_INTEGER = re.compile(r"\d+")


def _translate_date_interval(name: str, argument_text: str, table: str) -> str | None:
    """`DATE_SUB(d, INTERVAL n unit)` / `DATE_ADD`. Days and weeks are date arithmetic; months, quarters and years are EDATE, which
    like MySQL stops at the last day of a shorter month (2026-03-31 minus one month is 2026-02-28, 2024-02-29 minus a year 2023-02-28).
    A NULL date is NULL (DAX reads a blank date as 1899-12-30). Hours, minutes and seconds are not translated."""
    args = _split_arguments(argument_text)
    interval = _INTERVAL.fullmatch(args[1]) if len(args) == 2 else None
    if interval is None:
        if _REFUSED_FUNCTION.get() is None:
            _REFUSED_FUNCTION.set(name)                  # an hour or a minute, or no INTERVAL: the reason names the function
        return None
    value = _translate_expression(args[0], table)
    count = _translate_expression(interval.group(1), table)
    if value is None or count is None:
        return None
    if re.fullmatch(r"\s*'[^']*'\s*", args[0]):
        value = f"DATEVALUE({value})"                    # Domo reads a text date ('2026-03-31'); DAX would add the days to the text's number
    if re.fullmatch(r"-?\d+\.\d+", count):
        count = str(int(Decimal(count).quantize(Decimal(1), rounding=ROUND_HALF_UP)))   # Domo moves INTERVAL 1.5 DAY by 2 days (a column count is left as it is)
    unit, sign = interval.group(2).upper(), "-" if name == "DATE_SUB" else "+"
    # Only what can be NULL is tested: a column (the date or the count), not TODAY() or a number. An operand that is not a plain
    # column but can be blank (STR_TO_DATE of text that is no date, a nested DATE_SUB of a NULL, a division) is bound once, so a
    # nested call does not write it twice per level.
    binds, guarded = [], []
    for tag, operand in (("_d", value), ("_n", count)):
        if _PLAIN_COLUMN.fullmatch(operand):
            guarded.append(operand)
        elif _blankable(operand):
            binds.append(f"VAR {tag} = {operand}")
            guarded.append(tag)
            value, count = (tag, count) if tag == "_d" else (value, tag)
    per_unit = {"DAY": 1, "WEEK": 7, "MONTH": 1, "QUARTER": 3, "YEAR": 12}[unit]
    if _PLAIN_INTEGER.fullmatch(count):
        step = str(per_unit * int(count))
    else:
        step = f"({count})" if per_unit == 1 else f"({per_unit} * ({count}))"
    if unit in ("DAY", "WEEK"):
        moved = f"{value} {sign} {step}"
    else:
        moved = f"EDATE({value}, {step})" if sign == "+" else f"EDATE({value}, -{step})"
    if not guarded:
        return f"({moved})" if unit in ("DAY", "WEEK") else moved
    guard = f"IF({' || '.join(f'ISBLANK({a})' for a in guarded)}, BLANK(), {moved})"
    return f"({' '.join(binds)} RETURN {guard})" if binds else guard                  # parenthesised: a RETURN runs to the end


def _blankable(dax_text: str) -> bool:
    """An operand that can be NULL: a column, an aggregate, a division, or a NULLIF/IF that returns BLANK()."""
    return _may_be_blank(dax_text, aggregates=True) or "BLANK()" in dax_text


def _translate_numeric(name: str, argument_text: str, table: str) -> str | None:
    """`MOD(a, b)`, `POWER(a, b)`, `SQRT(x)`. Domo answers (function_census.py, 2026-10-26): MOD(-7,3) is -1 and MOD(7,-3) is 1 (the sign of
    the dividend, as in MySQL; DAX's MOD takes the divisor's), MOD(7,0) is NULL, MOD(7.5,2) is 1.5; POWER(2,-1) 0.5, POWER(-8,1) -8.0,
    SQRT(16) 4.0. A NULL operand is NULL (DAX reads a blank as 0). SQRT(-1) and POWER(0,-1) are NULL in Domo and an error in DAX: guarded.
    Known limit: MOD(7, 2.5) is 1 in Domo (an integer divisor?) and 2 here; a fractional divisor is not found in the estate."""
    args = _split_arguments(argument_text)
    if len(args) != (1 if name == "SQRT" else 2):
        return None
    operands = [_translate_expression(a, table) for a in args]
    if any(a is None for a in operands):
        return None
    if name == "MOD":
        dividend, divisor = operands
        zero = [] if re.fullmatch(r"-?\d+(\.\d+)?", divisor) and float(divisor) != 0 else ["_b = 0"]
        blank = [f"ISBLANK({v})" for v, a in (("_a", dividend), ("_b", divisor)) if _blankable(a)]
        remainder = "_a - _b * TRUNC(_a / _b)"
        if blank or zero:
            remainder = f"IF({' || '.join(blank + zero)}, BLANK(), {remainder})"
        return f"(VAR _a = {dividend} VAR _b = {divisor} RETURN {remainder})"
    number = r"-?\d+(\.\d+)?"
    if name == "SQRT":
        # Domo: SQRT(-1) is NULL; DAX raises an error that fails the whole visual.
        if re.fullmatch(number, operands[0]) and float(operands[0]) >= 0:
            return f"SQRT({operands[0]})"
        return f"(VAR _x = {operands[0]} RETURN IF(ISBLANK(_x) || _x < 0, BLANK(), SQRT(_x)))"
    # POWER: Domo gives NULL where DAX raises an error: 0 to a negative exponent, a negative base to a fractional exponent. DAX also raises
    # for POWER(0, 0) (live, 2026-10-26); MySQL says 1. A positive whole literal exponent, or a positive literal base, cannot raise.
    base, exponent = operands
    safe = (re.fullmatch(r"[1-9]\d*", exponent) is not None) or (re.fullmatch(number, base) and float(base) > 0)
    blank = [f"ISBLANK({v})" for v, a in (("_a", base), ("_b", exponent)) if _blankable(a)]
    domain = [] if safe else ["_a = 0 && _b < 0", "_a < 0 && _b <> TRUNC(_b)"]
    if not blank and not domain:
        return f"POWER({base}, {exponent})"
    if not domain:
        return f"IF({' || '.join(f'ISBLANK({a})' for a in (base, exponent) if _blankable(a))}, BLANK(), POWER({base}, {exponent}))"
    return f"(VAR _a = {base} VAR _b = {exponent} RETURN IF({' || '.join(blank + domain)}, BLANK(), IF(_a = 0 && _b = 0, 1, POWER(_a, _b))))"


# format: (separator, positions of the separators in a 10-character text, ISO date built from the text `_s`)
_STR_TO_DATE_FORMATS = {
    "%Y-%m-%d": ("-", (5, 8), "_s"),
    "%m/%d/%Y": ("/", (3, 6), 'MID(_s, 7, 4) & "-" & LEFT(_s, 2) & "-" & MID(_s, 4, 2)'),
}


def _translate_str_to_date(argument_text: str, table: str) -> str | None:
    """`STR_TO_DATE(text, '%Y-%m-%d')` and `'%m/%d/%Y'` (Domo: '09/27/2026' and '2026-09-27' are 2026-09-27, an unparseable text is NULL;
    function_census.py, 2026-10-26). Known limit: Domo is more lenient than the shape test ('9/27/2026', '2026-9-7' and a trailing time
    parse there, '' reads 2000-01-01); here they are BLANK. Only the estate's own shape (10 characters built by DATE_FORMAT) is certain. The text has to have the format's shape (DATEVALUE alone would read other layouts), and a day that does not
    exist (02-31) is NULL, as DATEVALUE's error is. Other formats stay refused. The estate's use is
    `STR_TO_DATE(DATE_FORMAT(CURRENT_DATE(), '%Y-%m-01'), '%Y-%m-%d')`."""
    args = _split_arguments(argument_text)
    if len(args) != 2 or not re.fullmatch(r"'[^']*'", args[1]) or args[1][1:-1] not in _STR_TO_DATE_FORMATS:
        return None
    text = _translate_expression(args[0], table)
    if text is None:
        return None
    separator, positions, iso = _STR_TO_DATE_FORMATS[args[1][1:-1]]
    shape = " && ".join(["LEN(_s) = 10"] + [f'MID(_s, {i}, 1) = "{separator}"' for i in positions])
    return f"(VAR _s = {text} RETURN IF(ISBLANK(_s), BLANK(), IF({shape}, IFERROR(DATEVALUE({iso}), BLANK()), BLANK())))"


def _translate_date(argument: str, table: str) -> str | None:
    """`DATE('2019-01-01')` -> `DATE(2019, 1, 1)`; `DATE(x)` (the date part of a timestamp) -> `DATE(YEAR(x), MONTH(x), DAY(x))`."""
    literal = re.fullmatch(r"\s*'(\d{4})-(\d{1,2})-(\d{1,2})'\s*", argument)
    if literal:
        year, month, day = (int(g) for g in literal.groups())
        return f"DATE({year}, {month}, {day})"
    inner = _translate_expression(argument, table)
    return None if inner is None else f"DATE(YEAR({inner}), MONTH({inner}), DAY({inner}))"


_DATE_VALUED = re.compile(r"(?:LAST_DAY|DATE|CURDATE|CURRENT_DATE|ADDDATE|SUBDATE)\b", re.IGNORECASE)
_TEXT_OF_ARGUMENT = {"LEFT", "RIGHT", "LENGTH", "SUBSTRING", "SUBSTR", "MID"}


def _date_valued(argument: str) -> bool:
    """True for a Domo argument that is a DATE value (`LAST_DAY(d)`, `DATE(d)`, `CURDATE()`, `SUBDATE(..)`), also inside
    parentheses and a `MAX` / `MIN`. MySQL prints a DATE as `2026-10-31`; DAX prints it in the model's culture."""
    text = argument.strip()
    while True:
        stripped = text
        if (stripped.startswith("(") and stripped.endswith(")") and _balanced(stripped[1:-1])
                and _split_arguments(stripped[1:-1]) == [stripped[1:-1].strip()]):
            stripped = stripped[1:-1].strip()
        wrapper = re.match(r"(?:MAX|MIN)\s*\((.*)\)$", stripped, re.IGNORECASE | re.DOTALL)
        if wrapper and _balanced(wrapper.group(1)) and len(_split_arguments(wrapper.group(1))) == 1:
            stripped = wrapper.group(1).strip()
        if stripped == text:
            break
        text = stripped
    found = _DATE_VALUED.match(text)
    if not found:
        return False
    # the whole argument is that one call: `DATE(a) + (b)` is a number in MySQL
    rest = text[found.end():].strip()
    return rest == "" or rest.startswith("(") and rest.endswith(")") and _balanced(rest[1:-1])


def _text_of_date(name: str, args: list[str], translated: list[str]) -> list[str]:
    """`RIGHT(LAST_DAY(d), 2)` is '31' in Domo (the text is 2026-10-31); the DAX text of a date is '10/31/2026', so the
    same call read '26', the year (Daily Stats - SW forecasts, 239 values, bimcontrol#397). Print the date as MySQL does."""
    if name in _TEXT_OF_ARGUMENT and args and _date_valued(args[0]):
        return [f'FORMAT({translated[0]}, "yyyy-MM-dd")', *translated[1:]]
    return translated


def _split_arguments(text: str) -> list[str]:
    """Split on top-level commas: not inside brackets, string literals or backtick names
    (`CONCAT(`last name`, ', ', `first name`)` has a comma in its second argument)."""
    parts: list[str] = []
    depth = 0
    quote = ""
    current = ""
    for char in text:
        if quote:
            if char == quote:
                quote = ""
        elif char in "'`":
            quote = char
        elif char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
        if char == "," and depth == 0 and not quote:
            parts.append(current.strip())
            current = ""
        else:
            current += char
    if current.strip():
        parts.append(current.strip())
    return parts


def _case_segments(body: str) -> list[tuple[str, str]]:
    """The WHEN / THEN / ELSE segments of a CASE body, split only at the CASE's own keywords: a nested
    `(CASE WHEN ... END)` inside a condition or a call keeps its own."""
    segments: list[tuple[str, str]] = []
    depth, quote, index, start, keyword = 0, "", 0, 0, ""
    while index < len(body):
        char = body[index]
        if quote:
            if char == quote:
                quote = ""
        elif char in "'`":
            quote = char
        elif char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
        elif char.isalpha() and (index == 0 or not (body[index - 1].isalnum() or body[index - 1] == "_")):
            word = re.match(r"[A-Za-z0-9_]+", body[index:]).group(0)
            upper = word.upper()
            if upper == "CASE":
                depth += 1
            elif upper == "END":
                depth -= 1
            elif depth == 0 and upper in ("WHEN", "THEN", "ELSE"):
                if keyword:
                    segments.append((keyword, body[start:index]))
                keyword, start = upper, index + len(word)
            index += len(word)
            continue
        index += 1
    if keyword:
        segments.append((keyword, body[start:]))
    return segments


_CASE_TEXT_RESULT = re.compile(r'"(?:[^"]|"")*"')
_CASE_NUMBER_RESULT = re.compile(r"-?\d+(?:\.\d+)?")


def _translate_case(text: str, table: str) -> str | None:
    """`CASE WHEN a THEN b ... ELSE c END` -> `SWITCH(TRUE(), a, b, ..., c)`."""
    body = re.sub(r"(?i)^CASE\s+", "", text.strip())
    body = re.sub(r"(?i)(?<=[`')\s])END$", "", body.strip())
    if not re.match(r"(?i)\s*WHEN\b", body):          # `CASE x WHEN v THEN ...` (a subject) is not handled
        return None
    segments = _case_segments(body)
    if not segments or segments[0][0] != "WHEN":
        return None

    pairs: list[str] = []
    default = "BLANK()"
    index = 0
    while index < len(segments):
        keyword, content = segments[index]
        if keyword == "ELSE":
            default = _translate_condition(content, table)
            if default is None:
                return None
            index += 1
            continue
        if (keyword != "WHEN" or index + 1 >= len(segments) or segments[index + 1][0] != "THEN"):
            return None
        condition_dax = _translate_condition(content, table, as_test=True)
        value_dax = _translate_condition(segments[index + 1][1], table)
        if condition_dax is None or value_dax is None:
            return None
        pairs.append((condition_dax, value_dax))
        index += 2

    # SQL gives a CASE whose results mix text and numbers the type of the text ('OR Case' ... else 0 is '0'); DAX's SWITCH
    # takes the first result's type and fails the row it cannot convert ("calculated column ... which does not hold any data
    # because evaluation of one of the rows caused an error": Daily Stats-SW 'Day of Week Name', Avg Stats-SW 'OR Cases').
    results = [value for _, value in pairs] + [default]
    if any(_CASE_TEXT_RESULT.fullmatch(value) for value in results):
        pairs = [(c, f'"{v}"' if _CASE_NUMBER_RESULT.fullmatch(v) else v) for c, v in pairs]
        default = f'"{default}"' if _CASE_NUMBER_RESULT.fullmatch(default) else default
    return f"SWITCH(TRUE(), {', '.join(f'{c}, {v}' for c, v in pairs)}, {default})"


def _top_level_comparison(text: str) -> tuple[str, str, str] | None:
    """The first comparison operator outside brackets, quotes and CASE ... END: (left, operator, right).

    A regex for the first `=` found one inside a nested CASE or call, so `((CASE WHEN a = 1 ...))='x'` was left
    untranslated (Forecasted Charges, Daily Revenue-SW)."""
    depth, in_quote, index = 0, "", 0
    while index < len(text):
        char = text[index]
        if char in "'`":
            if not in_quote:
                in_quote = char
            elif in_quote == char:
                in_quote = ""
        elif not in_quote:
            if char == "(":
                depth += 1
            elif char == ")":
                depth -= 1
            elif char.isalpha() and (index == 0 or not (text[index - 1].isalnum() or text[index - 1] == "_")):
                word = re.match(r"[A-Za-z0-9_]+", text[index:]).group(0)
                if word.upper() == "CASE":
                    depth += 1
                elif word.upper() == "END":
                    depth -= 1
                index += len(word)
                continue
            elif depth == 0 and char in "<>=!":
                operator = text[index:index + 2] if text[index:index + 2] in ("<=", ">=", "<>", "!=") else char
                if operator != "!":
                    return text[:index], operator, text[index + len(operator):]
        index += 1
    return None


def _translate_condition(text: str, table: str, as_test: bool = False) -> str | None:
    """A CASE arm: either a comparison or a plain expression.

    The parens come off first -- Domo writes `(x = 'y')` as often as
    `x = 'y'`, and a wrapped comparison would otherwise fall through to
    the expression translator, which cannot parse `=`.
    """
    stripped = text.strip()
    while stripped.startswith("(") and stripped.endswith(")") and _balanced(stripped[1:-1]):
        stripped = stripped[1:-1].strip()
    # OR binds loosest, then AND; `(a) || (b)` keeps each side's own grouping.
    for keyword, operator in (("OR", "||"), ("AND", "&&")):
        parts = _split_keyword(stripped, keyword)
        if len(parts) > 1:
            translated = [_translate_condition(part, table, as_test=True) for part in parts]
            if any(part is None for part in translated):
                return None
            return f" {operator} ".join(f"({part})" for part in translated)
    null_test = re.match(r"(?is)^(.*?)\s+IS\s+(NOT\s+)?NULL$", stripped)
    if null_test and _balanced(null_test.group(1)):
        subject = _translate_expression(null_test.group(1), table)
        if subject is None:
            return None
        return f"NOT ISBLANK({subject})" if null_test.group(2) else f"ISBLANK({subject})"
    like = re.match(r"(?is)^(.*?)\s+(NOT\s+)?LIKE\s+'([^']*)'$", stripped)
    if like and _balanced(like.group(1)):
        test = _translate_like(like.group(1), like.group(3), table)
        if test is None:
            return None
        return f"NOT ({test})" if like.group(2) else test
    negated = re.match(r"(?i)^NOT(?:\s+|(?=\())(.*)$", stripped, re.S)
    if negated and not re.match(r"(?i)^NOT\s+IN\b", stripped):
        inner = _translate_condition(negated.group(1), table, as_test=True)
        return None if inner is None else f"NOT ({inner})"
    membership = _translate_membership(stripped, table)
    if membership is not None:
        return membership
    comparison = _top_level_comparison(stripped)
    if comparison:
        age_test = _days_since_test(comparison, table)
        if age_test is not None:
            return age_test
        left = _translate_expression(comparison[0], table)
        right = _translate_expression(comparison[2], table)
        if left is None or right is None:
            return None
        operator = {"<>": "<>", "!=": "<>"}.get(comparison[1], comparison[1])
        left, right = _formatted_date_as_date(left, right), _formatted_date_as_date(right, left)
        return f"{left} {operator} {right}"
    literal = re.match(r"^'((?:[^'\\]|\\.)*)'$", stripped) if as_test else None
    if literal:
        # Text as a test (`... = 'INPATIENT' or 'OBSERVATION PATIENT'`, a slip in a customer beast mode): Domo reads text
        # as MySQL does, a number when it starts with one and 0 otherwise, so this one is false. DAX refuses text there
        # ("Cannot convert value 'OBSERVATION PATIENT' of type Text to type True/False": Utilization Review-SW, 2 cards).
        number = re.match(r"\s*[-+]?(\d+\.?\d*|\.\d+)", literal.group(1))
        return "TRUE()" if number and float(number.group(1)) != 0 else "FALSE()"
    plain = _translate_expression(stripped, table)
    if as_test and plain is not None and _split_top_level(stripped, "+-*/") is not None:
        # A number as a test (`WHEN `Dept No` - 17015 THEN ...`): true unless it is zero, as in SQL. DAX's SWITCH(TRUE(), ...)
        # refuses a number there ("comparing values of type True/False with values of type Number": Productivity
        # Benchmark by Year-SW, 'Fix & Flex Prod Units', 8 cards). A blank is no more true than a 0.
        return f"({plain}) <> 0"
    return plain


_DAYS_SINCE = re.compile(
    r"(?is)^DATEDIFF\(\s*(?:CURDATE\(\)|CURRENT_DATE(?:\(\))?)\s*,(?P<date>.+)\)\s*(?:(?P<sign>[-+])\s*(?P<shift>\d+))?$")


def _days_since_test(comparison: tuple[str, str, str], table: str) -> str | None:
    """`DATEDIFF(CURDATE(), d) <op> n` (also `DATEDIFF(...) - k <op> n`) as a test on the date column itself.

    DAX's DATEDIFF(d, TODAY(), DAY) cannot be folded into a DirectQuery source ("We couldn't fold the expression to the
    data source"), so every measure that held one failed in the service (Daily Stats - SW: 15 cards, 'Yesterday Stats'),
    and so does any date subtraction. A comparison of the column with TODAY() minus a number of days folds. Days are
    counted by date as in MySQL: `= 1` is the column on yesterday's date, whatever time of day it holds. A blank date
    makes the test false (MySQL: NULL), where DAX would compare it as the oldest date."""
    text = comparison[0].strip()
    while text.startswith("(") and text.endswith(")") and _balanced(text[1:-1]):
        text = text[1:-1].strip()
    found = _DAYS_SINCE.match(text)
    limit = re.fullmatch(r"\s*\(?\s*(\d+)\s*\)?\s*", comparison[2])
    if found is None or limit is None or not _balanced(found.group("date")):
        return None
    column = _translate_expression(found.group("date"), table)
    if column is None:
        return None
    shift = int(found.group("shift") or 0) * (-1 if found.group("sign") == "-" else 1)
    days = int(limit.group(1)) - shift          # DATEDIFF - k <op> n  is  DATEDIFF <op> n + k

    def day(before: int) -> str:
        return "TODAY()" if before == 0 else f"TODAY() - {before}" if before > 0 else f"TODAY() + {-before}"

    start, end = day(days), day(days - 1)       # the date `days` ago begins at `start` and ends where `end` begins
    test = {
        "=": f"{column} >= {start} && {column} < {end}",
        "<>": f"({column} < {start} || {column} >= {end})",
        "!=": f"({column} < {start} || {column} >= {end})",
        "<": f"{column} >= {end}",
        "<=": f"{column} >= {start}",
        ">": f"{column} < {start}",
        ">=": f"{column} < {end}",
    }.get(comparison[1])
    return None if test is None else f"NOT ISBLANK({column}) && {test}"


# A pattern that prints a whole date and nothing else (year, month and day, any order, any separator).
_FORMATTED_DATE = re.compile(
    r'^FORMAT\((?P<value>.+), "(?=[^"]*y)(?=[^"]*M)(?=[^"]*d)[yMd]+(?:[-/. ][yMd]+)+"\)$', re.S)


def _formatted_date_as_date(side: str, other: str) -> str:
    """`DATE_FORMAT(d, '%m-%d-%y') >= DATE('2019-01-01')`: Domo reads the text back as the date it prints, so the test
    is on the date itself. DAX refuses a comparison of the formatted text with a date (Profitability Trend PoP-SW,
    'V CFY Reimb (calc)': 13 cards; 63 beast modes in the scan)."""
    found = _FORMATTED_DATE.match(side.strip())
    if found is None or not other.strip().startswith("DATE(") or "FORMAT(" in found.group("value"):
        return side
    value = found.group("value")
    return f"DATE(YEAR({value}), MONTH({value}), DAY({value}))"


def _translate_like(subject_text: str, pattern: str, table: str) -> str | None:
    """`x LIKE 'a%'`; only the shapes that map onto a DAX test (both sides compare without regard to case)."""
    subject = _translate_expression(subject_text, table)
    if subject is None or "_" in pattern or '"' in pattern:
        return None
    core = pattern.strip("%")
    if "%" in core:
        return None
    literal = f'"{core}"'
    starts, ends = pattern.startswith("%"), pattern.endswith("%") and len(pattern) > 1
    if starts and ends:
        return f"CONTAINSSTRING({subject}, {literal})"
    if ends:
        return f"LEFT({subject}, {len(core)}) = {literal}"
    if starts:
        return f"RIGHT({subject}, {len(core)}) = {literal}"
    return f"{subject} = {literal}"


def _split_keyword(text: str, keyword: str) -> list[str]:
    """Split on a whole-word keyword (AND/OR) outside brackets, quotes and backticks."""
    parts: list[str] = []
    depth = 0
    quote = ""
    start = 0
    index = 0
    # Domo's own text has `... = 'X'AND ...` and `) and (`: the keyword needs a boundary before it (space, quote,
    # closing bracket) and a space or opening bracket after.
    pattern = re.compile(rf"(?i){keyword}(?=[\s(])")
    while index < len(text):
        char = text[index]
        if quote:
            if char == quote:
                quote = ""
        elif char in "'`":
            quote = char
        elif char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
        elif char.isalpha() and (index == 0 or not (text[index - 1].isalnum() or text[index - 1] == "_")):
            word = re.match(r"[A-Za-z0-9_]+", text[index:]).group(0)
            if word.upper() == "CASE":                # an AND inside a CASE ... END is the CASE's own
                depth += 1
            elif word.upper() == "END":
                depth -= 1
            elif depth == 0 and index > 0 and (text[index - 1].isspace() or text[index - 1] in "')`\""):
                match = pattern.match(text, index)
                if match:
                    parts.append(text[start:index])
                    start = index = match.end()
                    continue
            index += len(word)
            continue
        index += 1
    parts.append(text[start:])
    return [part.strip() for part in parts if part.strip()] if len(parts) > 1 else [text]


def _translate_membership(text: str, table: str) -> str | None:
    """`x IN ('a', 'b')` -> `x IN {"a", "b"}`; `x NOT IN (...)` -> not blank and not in."""
    match = re.match(r"(?is)^(.*?)(?:\s+|(?<=`))(NOT\s+)?IN\s*\((.*)\)$", text)     # Domo writes `x`in (...)
    if not match or not _balanced(match.group(1)):
        return None
    subject = _translate_expression(match.group(1), table)
    values = [_translate_expression(value, table) for value in _split_arguments(match.group(3))]
    if subject is None or not values or any(value is None for value in values):
        return None
    membership = f"{subject} IN {{{', '.join(values)}}}"
    # SQL's NOT IN is unknown (not true) for a null subject; DAX's NOT (blank IN {...}) is true.
    return f"(NOT ISBLANK({subject}) && NOT ({membership}))" if match.group(2) else membership

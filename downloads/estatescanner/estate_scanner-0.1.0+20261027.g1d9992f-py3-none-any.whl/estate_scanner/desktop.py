"""pywebview desktop shell: runs uvicorn in a background thread and opens a
native window pointed at it. Everything (API + frontend) is served from
127.0.0.1 -- this app never talks to anything but the target BI platform
and the local SQLite file.

pywebview must own the main thread's native GUI loop (macOS's Cocoa backend
specifically requires webview.start() to run there), so uvicorn is what
gets relegated to a background thread, not the other way around.
"""

from __future__ import annotations

import os
import socket
import sys
import threading
import time
import webbrowser
from pathlib import Path

import uvicorn

from .webapp.app import create_app


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _wait_for_socket(host: str, port: int, timeout: float = 10.0) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with socket.create_connection((host, port), timeout=0.5):
                return
        except OSError:
            time.sleep(0.1)
    raise TimeoutError(f"Server on {host}:{port} did not come up within {timeout}s")


# Set once the process has no console (pythonw.exe, as started from the Windows Start menu shortcut).
_WINDOWLESS = False

# What pywebview's Windows window needs, which it checks in the same way (webview/platforms/winforms.py):
# the Microsoft Edge WebView2 Runtime, which draws the page, and .NET Framework 4.7.2 or newer, which
# pythonnet needs to load. Without the runtime pywebview does not fail: it quietly uses the Internet
# Explorer engine, which cannot show this app (React and Babel in the page), so the window would open
# blank. Windows 10 does not always have WebView2 (Windows 11 does), hence the check, and the browser
# fallback, instead of a blank window.
_WEBVIEW2_URL = "https://developer.microsoft.com/microsoft-edge/webview2/"
_WEBVIEW2_CLIENT_IDS = (
    "{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}",  # the Evergreen Runtime, the one customers have
    "{2CD8A007-E189-409D-A2C8-9AF4EF3C72AA}",  # beta
    "{0D50BFEC-CD6A-4F9A-964C-C7416E3ACB10}",  # dev
    "{65C35B14-6C1D-4122-AC46-7148CC9D6497}",  # canary
)
_WEBVIEW2_REGISTRY_ROOTS = (
    ("HKEY_CURRENT_USER", r"SOFTWARE\Microsoft\EdgeUpdate\Clients"),  # installed for one user
    ("HKEY_LOCAL_MACHINE", r"SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients"),  # for everyone, 64-bit Windows
    ("HKEY_LOCAL_MACHINE", r"SOFTWARE\Microsoft\EdgeUpdate\Clients"),  # for everyone, 32-bit Windows
)
_WEBVIEW2_MINIMUM = (86, 0, 622, 0)  # what pywebview asks for
_DOTNET_472 = 461808  # the "Release" value of .NET Framework 4.7.2, first in Windows 10 version 1803


def _read_registry(hive: str, path: str, name: str):
    import winreg

    try:
        with winreg.OpenKey(getattr(winreg, hive), path) as key:
            return winreg.QueryValueEx(key, name)[0]
    except OSError:
        return None


def _windows_window_blocker(read=_read_registry) -> str | None:
    """Why the native window cannot work on this Windows, in words a customer can act on, or None
    when it can. `read(hive, path, name)` returns a registry value or None."""
    release = read("HKEY_LOCAL_MACHINE", r"SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full", "Release")
    if not isinstance(release, int) or release < _DOTNET_472:
        return (
            "this PC's .NET Framework is older than 4.7.2, which the app window needs "
            "(Windows 10 version 1803 and later have it; Windows Update installs it)"
        )
    for client_id in _WEBVIEW2_CLIENT_IDS:
        for hive, root in _WEBVIEW2_REGISTRY_ROOTS:
            version = read(hive, rf"{root}\{client_id}", "pv")
            try:
                parts = tuple(int(p) for p in str(version).split("."))
            except ValueError:
                continue
            if parts >= _WEBVIEW2_MINIMUM:
                return None
    return f"the Microsoft Edge WebView2 Runtime is not installed (it is free: {_WEBVIEW2_URL}). Estate Scanner's installer can add it"


def _reason(exc: Exception) -> str:
    # A RuntimeError from _native_backend is already a sentence for the customer; anything else is a repr.
    return str(exc) if isinstance(exc, RuntimeError) else repr(exc)


def _native_backend() -> str:
    """Import the GUI backend pywebview would use here and return its name.
    Raises if it is missing, which is the usual reason a window does not open
    (Windows: pythonnet or the WebView2 runtime; macOS: pyobjc)."""
    if sys.platform == "win32":
        blocker = _windows_window_blocker()
        if blocker:
            # Checked before importing pywebview's Windows backend, which on a machine without WebView2
            # would switch to the Internet Explorer engine, and edit the registry to do so.
            raise RuntimeError(blocker)
    import webview  # noqa: F401

    module = {"win32": "webview.platforms.winforms", "darwin": "webview.platforms.cocoa"}.get(sys.platform)
    if module:
        import importlib

        importlib.import_module(module)
    return module or "default"


def _brand_macos_app() -> None:
    """Give the Dock tile the app's icon and the app menu the app's name.

    Inside Estate Scanner.app (macos_app.py) the bundle already says both. Run
    as `estate-scanner ui` the process belongs to Python's own bundle, so the
    Dock would show a rocket and the menu "About Python"/"Quit Python". This
    fixes those two things: the name by editing the info dictionary the way
    pywebview itself does (it builds its app menu from CFBundleName), the icon
    directly because pywebview's `icon=` is documented as GTK/Qt only. It cannot
    rename the Dock label or the menu-bar title, which LaunchServices takes
    from the bundle: that needs the app. Purely cosmetic, so a failure is
    reported and not raised."""
    if sys.platform != "darwin":
        return
    try:
        import AppKit

        from . import macos_app

        bundle = AppKit.NSBundle.mainBundle()
        info = bundle.localizedInfoDictionary() or bundle.infoDictionary()
        if info is not None and info.get("CFBundleName") != macos_app.APP_NAME:
            info["CFBundleName"] = macos_app.APP_NAME
        icon = AppKit.NSImage.alloc().initWithContentsOfFile_(str(macos_app.icon_source()))
        if icon is not None:
            AppKit.NSApplication.sharedApplication().setApplicationIconImage_(icon)
    except Exception as exc:
        print(f"Could not set the app name and icon: {exc!r}", flush=True)


def _log_when_windowless() -> None:
    """pythonw.exe, which the Windows Start menu shortcut runs so that no console window opens,
    starts with no stdout and no stderr, so a failed start leaves nothing to read and anything
    that writes there can fail. Point both at a log file, as the Mac app's launcher does:
    %LOCALAPPDATA%\\Estate Scanner\\estate-scanner.log, the last run only."""
    global _WINDOWLESS
    if sys.platform != "win32" or (sys.stdout is not None and sys.stderr is not None):
        return
    _WINDOWLESS = True
    try:
        folder = Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData" / "Local") / "Estate Scanner"
        folder.mkdir(parents=True, exist_ok=True)
        stream = open(folder / "estate-scanner.log", "w", encoding="utf-8", buffering=1)
    except OSError:
        return  # no log is better than no app
    if sys.stdout is None:
        sys.stdout = stream
    if sys.stderr is None:
        sys.stderr = stream


def _window_icon() -> str | None:
    """On Windows the window and taskbar icon is whatever pywebview is handed (it would otherwise
    show Python's). On a Mac the bundle and _brand_macos_app supply it, so there is nothing to pass."""
    if sys.platform != "win32":
        return None
    icon = Path(__file__).parent / "assets" / "EstateScanner.ico"
    return str(icon) if icon.is_file() else None


def check(db_path: str | Path | None = None) -> int:
    """Self-test used by CI and by support: does the server answer, and can a
    native window be opened on this machine? A missing window backend is a
    failure, not a silent fallback."""
    import urllib.request

    port = _free_port()
    server = uvicorn.Server(uvicorn.Config(create_app(db_path=db_path), host="127.0.0.1", port=port, log_level="warning"))
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    try:
        _wait_for_socket("127.0.0.1", port)
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/", timeout=5) as resp:
            print(f"Server OK: GET / -> {resp.status}", flush=True)
    finally:
        server.should_exit = True
        thread.join(timeout=5)
    try:
        print(f"Native window OK: {_native_backend()}", flush=True)
    except Exception as exc:
        print(f"Native window unavailable: {_reason(exc)}", flush=True)
        return 1
    return 0


def _open_console_stream():
    """A new console window for this process, and a stream that writes to it, or None."""
    import ctypes

    if not ctypes.windll.kernel32.AllocConsole():
        return None
    return open("CONOUT$", "w", encoding="utf-8", buffering=1)


def _show_console_if_windowless() -> None:
    """In the browser there is no app window to close, and started from the Start menu there is no console
    either, so the program would run unseen with no way to stop it short of Task Manager. Give it a console
    window: closing that window stops Estate Scanner, as the message printed in it says."""
    if sys.platform != "win32" or not _WINDOWLESS:
        return
    try:
        stream = _open_console_stream()
    except Exception:
        return  # nothing to show it on; the log still has the URL
    if stream is not None:
        sys.stdout = sys.stderr = stream


def _serve_in_browser(server: uvicorn.Server, thread: threading.Thread, port: int) -> None:
    _show_console_if_windowless()
    webbrowser.open(f"http://127.0.0.1:{port}/")
    print(f"Estate Scanner is running at http://127.0.0.1:{port}/ -- close this window to stop it.", flush=True)
    try:
        while thread.is_alive():
            thread.join(timeout=1)
    except KeyboardInterrupt:
        server.should_exit = True


def main(db_path: str | Path | None = None, browser: bool = False) -> None:
    _log_when_windowless()
    port = _free_port()
    server = uvicorn.Server(uvicorn.Config(create_app(db_path=db_path), host="127.0.0.1", port=port, log_level="warning"))
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    _wait_for_socket("127.0.0.1", port)

    if not browser:
        try:
            _native_backend()
            import webview

            _brand_macos_app()
            webview.create_window("Estate Scanner", f"http://127.0.0.1:{port}/", width=1360, height=860, min_size=(1024, 700))
            webview.start(icon=_window_icon())  # blocks on the main thread until the window closes
        except Exception as exc:
            # Say why, so "it opened in my browser" is diagnosable rather than silent.
            print(f"Native window unavailable ({_reason(exc)}); opening in your browser instead.", flush=True)
            browser = True
    if browser:
        _serve_in_browser(server, thread, port)

    server.should_exit = True
    thread.join(timeout=5)


if __name__ == "__main__":
    main()

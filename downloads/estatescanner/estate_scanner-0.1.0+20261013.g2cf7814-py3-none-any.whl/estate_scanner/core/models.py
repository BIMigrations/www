"""Platform-agnostic domain model.

Every BI platform adapter maps its native payloads into these dataclasses.
Nothing here names a specific platform's vocabulary (no "Beast Mode", no
"Magic ETL", no "page") -- that translation happens entirely inside each
adapters/<platform>/client.py.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime


@dataclass(frozen=True)
class ObjectRef:
    """A pointer to some object, by its generic type tag + id, independent
    of which typed table it lives in. The universal currency for edges."""

    object_type: str
    id: str


@dataclass
class BaseObject:
    id: str
    name: str | None
    owner_id: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    raw_payload: dict = field(default_factory=dict)


@dataclass
class Dataset(BaseObject):
    provider_type: str | None = None
    stream_id: str | None = None
    row_count: int | None = None
    column_count: int | None = None
    schema_columns: list[dict] | None = None
    is_deleted: bool = False
    # A platform may precompute its own downstream-impact counts (Domo
    # does); kept generic here rather than named after Domo's "impact"
    # terminology. Re-derivable from `edges` for platforms that don't
    # provide it natively.
    downstream_card_count: int | None = None
    downstream_dataflow_count: int | None = None
    downstream_dataset_count: int | None = None
    downstream_alert_count: int | None = None
    # Row-level security policies; None means not captured (a failed call),
    # an empty list means the dataset has none.
    pdp_policies: list[dict] | None = None


@dataclass
class Dataflow(BaseObject):
    engine: str | None = None  # generalizes Domo's is_magic, e.g. "magic_etl" | "sql"
    is_deleted: bool = False
    input_dataset_ids: list[str] = field(default_factory=list)
    output_dataset_ids: list[str] = field(default_factory=list)
    last_run_state: str | None = None
    last_run_failed: bool | None = None
    last_run_at: datetime | None = None
    # The full transform-tile DAG (each tile's type, config, and dependency
    # links) -- what a migration actually needs to regenerate the ETL on
    # another platform, not just its input/output lineage.
    definition: dict | None = None


@dataclass
class Card(BaseObject):
    card_type: str | None = None
    dataset_ids: list[str] = field(default_factory=list)
    # Full chart/visualization definition (formatting, drill paths,
    # per-component overrides) -- needed to recreate the exact visual on
    # another platform, not just which dataset it reads from.
    definition: dict | None = None


@dataclass
class DashboardFilter:
    field: str | None
    label: str | None
    filter_type: str | None
    raw_payload: dict = field(default_factory=dict)


@dataclass
class Dashboard(BaseObject):  # generalizes Domo's "page"
    parent_id: str | None = None
    card_ids: list[str] = field(default_factory=list)
    filters: list[DashboardFilter] = field(default_factory=list)
    # The grid/section layout (tile positions, sizes, per-tile display
    # options) -- needed to recreate the dashboard's actual arrangement.
    layout: dict | None = None


@dataclass
class CalculatedField(BaseObject):  # generalizes Beast Mode / DAX / LookML
    formula_language: str | None = None  # e.g. "domo_beast_mode" | "dax" | "lookml"
    formula: str | None = None
    status: str | None = None
    data_type: str | None = None
    is_global: bool = False
    is_locked: bool = False
    linked_object_refs: list[ObjectRef] = field(default_factory=list)
    # Everything beyond the bare expression text: referenced functions,
    # column positions, aggregation behavior -- what a migration needs to
    # faithfully translate the formula, not just display it.
    definition: dict | None = None


@dataclass
class User(BaseObject):
    email: str | None = None
    role: str | None = None
    title: str | None = None
    group_ids: list[str] = field(default_factory=list)


@dataclass
class Group(BaseObject):
    pass


@dataclass
class Account(BaseObject):
    connector_type: str | None = None


@dataclass
class Alert(BaseObject):
    rule: str | None = None
    watched_object: ObjectRef | None = None
    disabled: bool = False


@dataclass
class AppView:
    """One screen inside an app -- in Domo, each view IS a dashboard (page)
    id in its own right, just organized under the app's navigation rather
    than the general dashboard list."""

    view_id: str
    title: str | None
    parent_view_id: str | None = None
    view_order: int | None = None
    visible: bool = True


@dataclass
class App(BaseObject):
    app_type: str | None = None
    landing_dashboard_id: str | None = None
    # Every screen in the app (see AppView), its nav menu structure, and its
    # branding/theme -- an app is not just "a thing that opens a dashboard",
    # it's a small multi-page product with its own navigation and look.
    views: list[AppView] = field(default_factory=list)
    navigations: list[dict] = field(default_factory=list)
    theme: dict | None = None


@dataclass
class Relationship:
    src: ObjectRef
    dst: ObjectRef
    edge_type: str
    weight: float = 1.0


@dataclass
class ScanProgressEvent:
    phase: str
    completed: int
    total: int | None
    elapsed_s: float
    message: str | None = None

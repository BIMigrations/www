"""Read-only access to an EstateScanner scan database."""

from .reader import EstateReader, EstateNotFoundError

__all__ = ["EstateReader", "EstateNotFoundError"]

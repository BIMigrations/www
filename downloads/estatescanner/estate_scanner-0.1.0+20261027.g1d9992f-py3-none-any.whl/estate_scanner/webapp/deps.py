"""Shared FastAPI dependencies.

Only for synchronous, request-lifetime-scoped connections (a plain GET that
reads and returns within the request). A background job (connect, scan)
outlives the HTTP request that started it and must open its own connection
inside the job's thread instead of using this -- see jobs.py callers in
routes/platforms.py and routes/scans.py.
"""

from __future__ import annotations

from fastapi import Request

from estate_scanner.storage import db


def get_conn(request: Request):
    conn = db.connect(request.app.state.db_path)
    try:
        yield conn
    finally:
        conn.close()

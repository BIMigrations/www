"""Starting migrations, in the foreground or the background.

One place that knows how to turn "migrate dashboard 2077417293" into a
project, a unit, a run and a pipeline, so the CLI and the HTTP API cannot
drift apart on it.

Background runs each get their own control-database connection, opened
inside their own thread and closed when the run ends. Nothing is shared
between a run and the request that started it except the run id.
"""

from __future__ import annotations

import threading
from pathlib import Path
from typing import Any

from bimcontrol import paths, pipelines
from bimcontrol.core import engine
from bimcontrol.estate.reader import EstateNotFoundError, EstateReader
from bimcontrol.storage import db


class UnknownRunError(Exception):
    pass


def resolve_project(
    conn, estate_db_path: str | Path, target_platform: str = "powerbi", source_platform: str = "domo"
) -> dict[str, Any]:
    """The project for this scan, created on first sight.

    The instance name comes from the scan itself rather than being asked
    for, so the common case -- one consultant, one customer, one estate --
    needs no setup at all.
    """
    # A file holding several instances is read as the one scanned last; the project then keeps that name.
    with EstateReader.newest(estate_db_path, platform=source_platform) as reader:
        scan = reader.latest_completed_scan() or (reader.scans() or [None])[0]
        instance = reader.instance or (scan["instance"] if scan else "unknown")
    return db.ensure_project(
        conn, source_platform, instance, target_platform, estate_db_path=estate_db_path
    )


def prepare_run(
    conn,
    estate_db_path: str | Path,
    dashboard_id: str,
    target_platform: str = "powerbi",
    until: str | None = None,
    pipeline_name: str | None = None,
) -> dict[str, Any]:
    """Create (or reuse) the project and unit, then open a run for them."""
    project = resolve_project(conn, estate_db_path, target_platform)
    pipeline = pipelines.get_pipeline(
        pipeline_name or f"{project['source_platform']}_to_{project['target_platform']}"
    )

    with EstateReader(estate_db_path, platform=project["source_platform"], instance=project["source_instance"]) as reader:
        dashboard = reader.find("dashboard", dashboard_id)
        if dashboard is None:
            raise EstateNotFoundError(f"No dashboard with id {dashboard_id!r} in {estate_db_path}")
        name = dashboard.name

    unit = db.ensure_unit(conn, project["id"], dashboard_id, name=name)
    if until and pipeline.find(until) is None:
        raise KeyError(f"Unknown stage {until!r}. Known: {', '.join(pipeline.stage_names())}")

    run_id = engine.start_run(
        conn, pipeline, project, unit, estate_db_path, options={"until": until}
    )
    return {"run_id": run_id, "project": project, "unit": unit, "pipeline": pipeline}


def prepare_customer_run(conn, estate_db_path: str | Path, manifest) -> dict[str, Any]:
    """Open (or resume) the convert-everything run for a customer manifest.

    One unit per customer; a run that did not finish is carried on rather than
    started again, because landing and conversion are the slow parts.
    """
    project = resolve_project(conn, estate_db_path)
    pipeline = pipelines.get_pipeline("domo_estate_sql")
    unit = db.ensure_unit(conn, project["id"], f"customer:{manifest.name}", name=manifest.name, unit_type="customer")
    latest = db.get_run(conn, unit["latest_run_id"]) if unit.get("latest_run_id") else None
    if latest is not None and latest["status"] != "succeeded":
        return {"run_id": latest["id"], "resumed": True, "project": project, "unit": unit, "pipeline": pipeline}
    run_id = engine.start_run(
        conn, pipeline, project, unit, estate_db_path, options={"manifest": manifest.to_dict()}
    )
    return {"run_id": run_id, "resumed": False, "project": project, "unit": unit, "pipeline": pipeline}


def execute_run(
    conn,
    run_id: str,
    estate_db_path: str | Path | None = None,
    until: str | None = None,
    cancel_event: threading.Event | None = None,
) -> dict[str, Any]:
    """Execute (or resume) a run to completion in the calling thread."""
    run = db.get_run(conn, run_id)
    if run is None:
        raise UnknownRunError(f"No run with id {run_id!r}")
    project = db.get_project(conn, run["project_id"])
    pipeline = pipelines.get_pipeline(run["pipeline"])
    estate_db_path = estate_db_path or project.get("estate_db_path") or paths.default_estate_db_path()
    return engine.execute(
        conn, pipeline, run_id, estate_db_path, until=until, cancel_event=cancel_event
    )


class RunManager:
    """Background runs for the HTTP API.

    Threads rather than processes: the work is IO-bound (SQLite, converter
    HTTP calls) and a thread can be told to stop through an Event, which a
    cancelled migration needs.
    """

    def __init__(self, db_path: str | Path | None = None):
        self.db_path = db_path
        self._threads: dict[str, threading.Thread] = {}
        self._cancels: dict[str, threading.Event] = {}
        self._lock = threading.Lock()

    def start(self, run_id: str, estate_db_path: str | Path, until: str | None = None) -> None:
        cancel_event = threading.Event()
        with self._lock:
            if run_id in self._threads and self._threads[run_id].is_alive():
                raise RuntimeError(f"Run {run_id} is already running")
            self._cancels[run_id] = cancel_event

        def work() -> None:
            # Its own connection, in its own thread, closed when done.
            conn = db.connect(self.db_path)
            try:
                execute_run(conn, run_id, estate_db_path, until=until, cancel_event=cancel_event)
            except Exception as exc:  # noqa: BLE001 -- nothing above this to catch it
                db.update_run(conn, run_id, status="failed", error=str(exc), finished_at=db.now())
                db.append_event(conn, run_id, "run.failed", str(exc), level="error")
            finally:
                conn.close()

        thread = threading.Thread(target=work, name=f"run-{run_id}", daemon=True)
        with self._lock:
            self._threads[run_id] = thread
        thread.start()

    def cancel(self, run_id: str) -> bool:
        """Ask a run to stop. Cooperative: it ends after the current stage,
        or sooner if that stage checks for cancellation."""
        with self._lock:
            event = self._cancels.get(run_id)
        if event is None:
            return False
        event.set()
        return True

    def is_running(self, run_id: str) -> bool:
        with self._lock:
            thread = self._threads.get(run_id)
        return bool(thread and thread.is_alive())

    def join(self, run_id: str, timeout: float | None = None) -> None:
        """Wait for a run to finish. For tests and for a clean shutdown."""
        with self._lock:
            thread = self._threads.get(run_id)
        if thread:
            thread.join(timeout)

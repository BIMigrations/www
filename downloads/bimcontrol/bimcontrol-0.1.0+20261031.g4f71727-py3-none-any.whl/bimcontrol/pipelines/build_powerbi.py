"""Building the Power BI project: model, report, then files.

Three stages, split where the interesting decisions are. `build_model`
decides what the data looks like -- tables, types, measures.
`build_report` decides what it looks like on screen -- visuals, roles,
layout. `write_pbip` is mechanical, and deliberately so: by the time it
runs, every judgement has been made and written down as an artefact
somebody can read.
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import asdict
from typing import Any

from bimcontrol.core.engine import ReviewItem, RunContext, StageResult
from bimcontrol.pipelines.convert_etl import CONVERSION_FILE, TABLE_REUSE, native_statement
from bimcontrol.warehouses import ROW_ORDER_COLUMN, WarehouseNotConfigured, get_adapter, safe_table_name
from bimcontrol.pipelines.data_plan import LANDINGS_FILE, PLAN_FILE
from bimcontrol.targets.powerbi.description import source_description
from bimcontrol.targets.powerbi import (
    calendar, chart_map, dashboard_filters, dax, daterange, directquery, prune, query, rls, writer,
)
from bimcontrol.targets.powerbi.model import (
    Column,
    DataSource,
    Drillthrough,
    Measure,
    Page,
    Projection,
    Report,
    Role,
    SemanticModel,
    Table,
    Visual,
    VisualFilter,
)

MODEL_FILE = "semantic_model.json"
REPORT_FILE = "report.json"

# Domo lays a dashboard out on a 60-unit wide grid. Power BI pages are
# sized in points, and 1280 is its own default width.
DOMO_GRID_WIDTH = 60
PAGE_WIDTH = 1280
GUTTER = 8
STATIC_TYPES = frozenset({"HEADER", "VARIABLE", "BUTTON"})
TITLE_BAND = 48


def _safe(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9 _-]", "", name).strip() or "Migrated"


# ---- build_model --------------------------------------------------------


def _unique_table_name(name: str, taken: set[str]) -> str:
    """Domo dataset names are not unique (an input upload and the dataflow output that replaces it can
    share one); two model tables of one name overwrite each other's file (DNFB - SW)."""
    candidate, n = name, 1
    while candidate.lower() in {t.lower() for t in taken}:
        n += 1
        candidate = f"{name} ({n})"
    return candidate


def build_model(ctx: RunContext) -> StageResult:
    """Turn the closure and the converted SQL into a semantic model."""
    closure = ctx.read_json("resolve_closure", "closure.json")
    plan = ctx.read_json("plan_data", PLAN_FILE)
    conversion = ctx.read_json("convert_dataflows", CONVERSION_FILE)
    warehouse = (ctx.project.get("settings") or {}).get("warehouse") or {}

    # Only the datasets the cards actually read become tables. The rest of
    # the closure exists to produce those, and belongs in the warehouse,
    # not in the report's model.
    card_datasets: list[str] = []
    for card in closure["cards"]:
        for dataset_id in card.get("dataset_ids") or []:
            if dataset_id not in card_datasets:
                card_datasets.append(dataset_id)

    by_id = {d["id"]: d for d in closure["datasets"]}
    sql_by_dataset: dict[str, str] = {}
    rejected: dict[str, str] = {}
    described: dict[str, list[dict]] = {}
    for entry in conversion.get("dataflows", []):
        for output in entry.get("outputs", []):
            if output.get("data_source_id"):
                if output.get("validated") is False:
                    # A table whose query the warehouse rejects (or that reads a dataflow that has none) makes the
                    # whole model's refresh fail, and with it every comparison of every card (Clinic AR Balance-SW:
                    # `__todo_table__` does not exist; Clinic Productivity old-SW: `_batch_id_` is ambiguous). The table stays,
                    # empty, and says why; the other tables load.
                    rejected[output["data_source_id"]] = str(output.get("validation_error") or "rejected by the warehouse")
                    if output.get("columns"):
                        described[output["data_source_id"]] = output["columns"]
                    continue
                sql_by_dataset[output["data_source_id"]] = output["artefact"]
                if output.get("columns"):
                    described[output["data_source_id"]] = output["columns"]
    landed = {l["dataset_id"]: l["table_ref"] for l in
              (ctx.read_json("land_source_data", LANDINGS_FILE).get("landings") or [])}
    # A dataset already fed from the warehouse (a Redshift connector dataset) is not landed; the
    # conversion resolved it to the table or view it reads. Without this its table had no source
    # and every visual on it was empty (Revenue Trend-SW: 28 projections on 'customer Charges Cost Redshift').
    for dataset_id, table_ref in (conversion.get("resolutions") or {}).items():
        if dataset_id not in sql_by_dataset:
            landed.setdefault(dataset_id, table_ref)

    model = SemanticModel(name=_safe(closure["dashboard"]["name"]))
    review_items: list[ReviewItem] = []
    warnings: list[str] = []

    for dataset_id in card_datasets:
        dataset = by_id.get(dataset_id)
        if dataset is None:
            review_items.append(ReviewItem(
                kind="missing_table", severity="error",
                title=f"A card reads dataset {dataset_id}, which is not in the closure",
                source_type="dataset", source_id=dataset_id,
            ))
            continue

        table = Table(name=_unique_table_name(_safe(dataset["name"]), {t.name for t in model.tables}),
                      origin=dataset_id)
        if table.name != _safe(dataset["name"]):
            review_items.append(ReviewItem(
                kind="table_renamed", severity="info",
                title=f"Another dataset is also called {dataset['name']!r}; this one is the table {table.name!r}",
                source_type="dataset", source_id=dataset_id,
            ))
        for column in _model_columns(dataset, described.get(dataset_id), review_items, warnings):
            table.columns.append(column)

        source = None if dataset_id in rejected else _source_for(
            ctx, dataset_id, sql_by_dataset, landed, warehouse,
            text_for_numbers=_text_for_numbers(dataset, described.get(dataset_id), review_items, warnings)
            + _integers_for_text(dataset, described.get(dataset_id), review_items)
            + _doubles_for_text(dataset, described.get(dataset_id), review_items))
        if source is None:
            reason = f": the dataflow that builds it was rejected ({rejected[dataset_id][:300]})" if dataset_id in rejected else ""
            review_items.append(ReviewItem(
                kind="table_without_source", severity="error",
                title=f"No query to load {dataset['name']!r} from{reason}",
                source_type="dataset", source_id=dataset_id,
            ))
        table.source = source
        model.tables.append(table)
        _add_roles(model, table, dataset.get("pdp"), review_items, warnings)

    _add_calendar_columns(closure, model, review_items, warnings)
    _add_measures(ctx, closure, model, review_items, warnings)
    _add_text_aggregations(closure, model)
    _note_unrelated_tables(model, review_items, warnings)
    _note_blank_filter_values(ctx, closure, model)

    payload = {
        "name": model.name,
        "culture": model.culture,
        "roles": [{"name": r.name, "filters": r.filters, "origin": r.origin,
                   "description": r.description} for r in model.roles],
        "card_fields": {card: {name: {"table": table, "name": model_name, "kind": kind}
                               for name, (table, model_name, kind) in fields.items()}
                        for card, fields in model.card_fields.items()},
        "tables": [
            {
                "name": t.name, "origin": t.origin,
                "columns": [{"name": c.name, "source_type": c.source_type,
                             "data_type": c.data_type, "summarize_by": c.summarize_by,
                             "expression": c.expression, "origin": c.origin,
                             "needs_review": c.needs_review, "description": c.description,
                             "sort_by": c.sort_by, "hidden": c.hidden}
                            for c in t.columns],
                "measures": [{"name": m.name, "expression": m.expression, "origin": m.origin,
                              "needs_review": m.needs_review, "description": m.description}
                             for m in t.measures],
                "source": {"kind": t.source.kind, "m": t.source.m_expression,
                           "detail": t.source.detail} if t.source else None,
                **({"blank_values": t.blank_values} if t.blank_values else {}),
            }
            for t in model.tables
        ],
    }
    ctx.write_json(MODEL_FILE, payload, kind="model", label="Semantic model")
    ctx.progress(
        f"{len(model.tables)} table(s), "
        f"{sum(len(t.columns) for t in model.tables)} column(s), "
        f"{sum(len(t.measures) for t in model.tables)} measure(s)"
    )
    return StageResult(
        summary={
            "tables": len(model.tables),
            "columns": sum(len(t.columns) for t in model.tables),
            "measures": sum(len(t.measures) for t in model.tables),
            "roles": len(model.roles),
            "measures_needing_review": sum(
                1 for t in model.tables for m in t.measures if m.needs_review),
        },
        warnings=warnings,
        review_items=review_items,
    )


# A scan of one table for a handful of values: a heavy dataflow view can take minutes. Unanswered = unknown = widened.
BLANK_VALUE_QUERY_SECONDS = 300


def _blank_value_candidates(closure: dict[str, Any], model: SemanticModel) -> dict[tuple[str, str], list[str]]:
    """(table, column) -> the text values ending in a blank that an IN / NOT IN filter of a card or of the dashboard lists on it.

    Loose on purpose (every table of the card's datasets that has the column): asking about a value nobody uses costs a
    column in a query, missing one leaves a filter widened."""
    text_columns = {t.name: {c.name.lower(): c.name for c in t.columns
                             if not c.expression and str(c.source_type).upper() in ("STRING", "TEXT")} for t in model.tables}
    by_dataset = {t.origin: t for t in model.tables}
    found: dict[tuple[str, str], list[str]] = {}

    def add(tables: list[Table], column: Any, operand: Any, values: Any) -> None:
        # Only blanks (spaces) at the end: the query compares with RTRIM, which strips nothing else.
        blanks = [str(v) for v in values or [] if str(v) != str(v).rstrip(" ") and str(v).rstrip(" ") == str(v).rstrip()]
        if not blanks or str(operand or "").upper() not in ("IN", "NOT_IN"):
            return
        for table in tables:
            name = text_columns[table.name].get(str(column).lower())
            for value in blanks if name else []:
                if value not in found.setdefault((table.name, name), []):
                    found[(table.name, name)].append(value)

    for card in closure.get("cards") or []:
        tables = [by_dataset[d] for d in card.get("dataset_ids") or [] if d in by_dataset]
        for item in card.get("filters") or []:
            add(tables, item.get("column"), item.get("operand"), item.get("values"))
    for entry in (closure.get("dashboard") or {}).get("filters") or []:
        raw = entry.get("raw") or entry
        add(model.tables, raw.get("column"), raw.get("operand"), raw.get("values"))
    return found


def _source_statement(ctx: RunContext, source: DataSource) -> str | None:
    """The query a table's source reads, as `_shape_big_tables` builds it, or None for a source that is not a query."""
    if source.kind == "redshift_sql" and (source.detail or {}).get("artefact"):
        statement = native_statement((ctx.run_dir / "convert_dataflows" / source.detail["artefact"]).read_text())
        if source.detail.get("text_for_numbers"):
            statement = _numbers_from_text(statement, [tuple(c) for c in source.detail["text_for_numbers"]])
        return statement
    if source.kind == "warehouse_table" and (source.detail or {}).get("table_ref"):
        return _warehouse_statement(source)
    return None


def _note_blank_filter_values(ctx: RunContext, closure: dict[str, Any], model: SemanticModel) -> None:
    """For each filter value that ends in a blank: which spellings does the table hold, with the blank and without? (`Table.blank_values`)

    Domo matches `'CC '` literally; the Power BI engine drops a trailing blank, so a filter is widened with the trimmed
    spelling (`with_trimmed_text`). Right where the data holds the blank ('11-30 ' in DNFB Aging Buckets), wrong where it holds
    only 'CC': the widened filter keeps the 9,391 encounters Domo's drops (Case Mix Index, #457). One pass over each table
    that has such a value. Offline (no warehouse), an adapter that cannot query, or a query that fails leaves the table
    without an answer, and a filter without an answer is widened as it was before this was asked."""
    warehouse = (ctx.project.get("settings") or {}).get("warehouse") or {}
    wanted = _blank_value_candidates(closure, model) if warehouse.get("host") else {}
    if not wanted:
        return
    by_name = {t.name: t for t in model.tables}
    quote = lambda name: '"' + name.replace('"', '""') + '"'      # noqa: E731

    def holds(column: str, text: str) -> str:
        # OCTET_LENGTH with RTRIM, not `=`: whether a trailing blank counts in a comparison depends on the column's type.
        literal = "'" + text.replace("'", "''") + "'"
        return (f"MAX(CASE WHEN OCTET_LENGTH({quote(column)}) = {len(text.encode())} AND RTRIM({quote(column)}) = RTRIM({literal}) "
                "THEN 1 ELSE 0 END)")

    try:
        adapter = get_adapter(warehouse.get("key", "redshift"), warehouse)
        with adapter:
            for table_name in dict.fromkeys(t for t, _ in wanted):
                table = by_name[table_name]
                statement = _source_statement(ctx, table.source) if table.source else None
                # A backslash is an escape in a Redshift literal: the answer would be about another value.
                asked = [(c, v) for (t, c), values in wanted.items() if t == table_name for v in values if "\\" not in v]
                if not statement or not asked:
                    continue
                tests = ", ".join(f"{holds(c, v)}, {holds(c, v.rstrip(' '))}" for c, v in asked)     # as written, then trimmed
                try:
                    row = adapter.query_row(f"SELECT {tests} FROM (\n{statement}\n) AS _model", timeout_seconds=BLANK_VALUE_QUERY_SECONDS)
                except Exception as exc:  # noqa: BLE001 -- the table keeps today's behaviour; the message is the finding
                    ctx.progress(f"{table_name!r}: could not tell which spellings of the blank-ended filter values the data holds "
                                 f"({_first_line(exc, 160)}); they stay widened")
                    continue
                if not row or len(row) != 2 * len(asked):
                    continue
                for index, (column, value) in enumerate(asked):
                    with_blank, without = row[2 * index], row[2 * index + 1]
                    if with_blank is None or without is None:           # an empty table says nothing
                        continue
                    table.blank_values.setdefault(column, {})[value] = (
                        "both" if with_blank and without else "blank" if with_blank else "trimmed" if without else "neither")
                ctx.progress(f"{table_name!r}: {len(asked)} blank-ended filter value(s) checked in the data: "
                             + ", ".join(f"{c}={v!r} {table.blank_values.get(c, {}).get(v, 'unknown')}" for c, v in asked[:4]))
    except WarehouseNotConfigured:
        return
    except Exception as exc:  # noqa: BLE001
        ctx.progress(f"could not check the blank-ended filter values ({_first_line(exc, 160)}); they stay widened")


def _with_held_blanks(flt: VisualFilter, tables: list[dict[str, Any]]) -> VisualFilter:
    """An IN filter learns from the model's table which of its blank-ended values the data holds (`Table.blank_values`)."""
    if flt.kind == "in":
        table = next((t for t in tables if t["name"] == flt.table), None)
        held = ((table or {}).get("blank_values") or {}).get(flt.column)
        if held:
            flt.blank_held = dict(held)
    return flt


def _model_columns(
    dataset: dict, described: list[dict] | None, review_items: list[ReviewItem], warnings: list[str],
) -> list[Column]:
    """The columns a table holds: the scan's, checked against what the converted SQL returns.

    A dataflow edited after the scan can stop producing a column the scan lists, and a
    model that binds it fails to refresh ("The 'Charge Code' column does not exist in
    the rowset"). The SQL is what Power BI reads, so a column it does not return is
    dropped (with a review item: cards that use it will be broken) and one it returns
    that the scan never heard of is added. Names keep the scan's case.
    """
    scanned = [Column(name=c.get("name"), source_type=c.get("type") or "STRING")
               for c in dataset.get("columns") or []]
    if not described:
        return scanned
    actual = {d["name"].lower(): d for d in described}
    kept = [c for c in scanned if c.name.lower() in actual]
    missing = [c.name for c in scanned if c.name.lower() not in actual]
    known = {c.name.lower() for c in scanned}
    known.add(ROW_ORDER_COLUMN)     # the landing's row position: carried by SQL that passes a stored dataset through, not a column of the dataset
    new = [Column(name=d["name"], source_type=d["type"]) for d in described if d["name"].lower() not in known]
    if missing:
        warnings.append(f"{dataset['name']}: the converted SQL does not return {len(missing)} column(s) "
                        f"the scan lists: {', '.join(missing[:8])}")
        review_items.append(ReviewItem(
            kind="scan_out_of_date", severity="warn",
            title=f"{dataset['name']!r}: {len(missing)} column(s) in the scan are not in what the dataflow produces now "
                  f"(edited in Domo since the scan? rescan)",
            source_type="dataset", source_id=dataset.get("id"),
            detail={"missing_from_sql": missing, "new_in_sql": [c.name for c in new]},
        ))
    return kept + new


def _add_calendar_columns(
    closure: dict, model: SemanticModel, review_items: list[ReviewItem], warnings: list[str],
) -> None:
    """A calculated column for each Domo calendar field a card groups by (CalendarMonth ...).

    The column is cut from the date column the card names, so two cards on the
    same table with different date columns each get their own.
    """
    table_by_dataset = {t.origin: t for t in model.tables}
    for card in closure["cards"]:
        wanted = calendar.calendar_columns(card)
        table = next((table_by_dataset[d] for d in card.get("dataset_ids") or [] if d in table_by_dataset), None)
        if not wanted or table is None:
            continue
        existing = {c.name.lower(): c for c in table.columns}
        for item in wanted:
            if item.name.lower() in existing:
                continue
            date_column = existing.get(item.date_column.lower())
            if date_column is None:
                warnings.append(f"{card.get('name')}: calendar field {item.field!r} is cut from "
                                f"{item.date_column!r}, which the table does not have")
                review_items.append(ReviewItem(
                    kind="calendar_column_missing", severity="error",
                    title=f"Card {card.get('name')!r} groups by {item.field}, but {item.date_column!r} is not a column of {table.name!r}",
                    source_type="card", source_id=str(card.get("id")),
                ))
                continue
            reference = query.column_ref(table.name, date_column.name)
            description = f"Migrated from Domo's {item.field} field on {date_column.name!r}"
            sort = calendar.sort_dax(item, reference)
            table.columns.append(Column(
                name=item.name, source_type=calendar.label_type(item), expression=calendar.label_dax(item, reference),
                description=description, sort_by=item.sort_name if sort else None,
            ))
            if sort:
                table.columns.append(Column(
                    name=item.sort_name, source_type="LONG", expression=sort, hidden=True,
                    description=f"Sorts {item.name!r} in time order",
                ))


def _add_roles(
    model: SemanticModel, table: Table, groups: list[dict] | None,
    review_items: list[ReviewItem], warnings: list[str],
) -> None:
    """Domo PDP on this table's dataset becomes RLS roles, without members."""
    if not groups:
        return
    result = rls.roles_for_table(table, groups)
    model.roles.extend(result.roles)
    if result.roles:
        review_items.append(ReviewItem(
            kind="rls_roles_without_members", severity="warn",
            title=f"{len(result.roles)} row-level security role(s) on {table.name!r} have no members",
            source_type="dataset", source_id=table.origin,
            detail={"roles": [{"name": r.name, "filter": r.filters[table.name],
                               "domo_user_ids": result.domo_users[r.name]} for r in result.roles]},
        ))
    for item in result.unsupported:
        review_items.append(ReviewItem(
            kind="rls_unsupported", severity="error",
            title=f"Row-level security group {item.group!r} on {table.name!r} was not translated",
            source_type="dataset", source_id=table.origin,
            detail={"group": item.group, "reason": item.reason},
        ))
    if result.unsupported:
        warnings.append(
            f"{len(result.unsupported)} PDP group(s) on {table.name!r} were not translated; "
            "until they are, users in those groups are not covered by any role."
        )


def _text_for_numbers(
    dataset: dict, described: list[dict] | None, review_items: list[ReviewItem], warnings: list[str],
) -> list[tuple[str, str]]:
    """(column, Domo type) for each column Domo declares a number and the converted SQL returns as text.

    A UnionAll the converter cannot type (a column missing from one branch) casts the column to text on every
    branch; Domo keeps the number (Customer_Charge_Claims: totalstats, wluweight... came out as VARCHAR). The model
    declares them numbers, and DirectQuery cannot fold a SUM over them (bimcontrol#227)."""
    if not described:
        return []
    domo = {str(c.get("name")).lower(): str(c.get("type") or "").upper() for c in dataset.get("columns") or []}
    found = [(d["name"], domo[d["name"].lower()]) for d in described
             if str(d.get("type") or "").upper() in ("STRING", "TEXT") and domo.get(d["name"].lower()) in _NUMBER_COLUMN_TYPES]
    if found:
        names = ", ".join(name for name, _ in found[:8])
        warnings.append(f"{dataset['name']}: {len(found)} column(s) are numbers in Domo and text in the converted SQL "
                        f"({names}); they are converted to numbers in the model's query")
        review_items.append(ReviewItem(
            kind="text_for_number_converted", severity="info",
            title=f"{dataset['name']!r}: {len(found)} column(s) Domo holds as numbers came out of the converted SQL as "
                  f"text ({names}); the model's query casts them back (text that is not a number becomes empty)",
            source_type="dataset", source_id=dataset.get("id"), detail={"columns": [n for n, _ in found]},
        ))
    return found


def _integers_for_text(
    dataset: dict, described: list[dict] | None, review_items: list[ReviewItem],
) -> list[tuple[str, str]]:
    """(column, "STRING") for each column Domo declares text and the converted SQL returns as an integer.

    The model declares the column text; over a DirectQuery table of integers Power BI cannot fold a calculated
    column or a group-by that concatenates it (Discharge YOY-SW: 'DRG Number' & ' - ' & 'DRG Name' made 18 cards
    fail with 'couldn't fold the expression', while the same expression over a real text column folds). The model's
    query casts the integer to text, which is what the column is."""
    if not described:
        return []
    domo = {str(c.get("name")).lower(): str(c.get("type") or "").upper() for c in dataset.get("columns") or []}
    found = [(d["name"], "STRING") for d in described
             if str(d.get("type") or "").upper() == "LONG" and domo.get(d["name"].lower()) in ("STRING", "TEXT")]
    if found:
        names = ", ".join(name for name, _ in found[:8])
        review_items.append(ReviewItem(
            kind="integer_for_text_converted", severity="info",
            title=f"{dataset['name']!r}: {len(found)} column(s) Domo holds as text came out of the converted SQL as "
                  f"integers ({names}); the model's query casts them to text",
            source_type="dataset", source_id=dataset.get("id"), detail={"columns": [n for n, _ in found]},
        ))
    return found


_DOUBLE_AS_TEXT = "STRING_DOUBLE"      # the second element of a `text_for_numbers` entry for `_doubles_for_text`


def _doubles_for_text(
    dataset: dict, described: list[dict] | None, review_items: list[ReviewItem],
) -> list[tuple[str, str]]:
    """(column, `_DOUBLE_AS_TEXT`) for each column Domo declares text and the converted SQL returns as a DOUBLE.

    Domo writes a DOUBLE as text with its ".0" (Java's Double.toString: 160 is '160.0'), the converted SQL keeps the
    number and Redshift would write 160 (Productivity ... with Premium, 'Hours Flag': a Value Mapper keeping a
    NumericCalculator's sum next to the text '0', bimcontrol#369). The model's query writes the text the way Domo does."""
    if not described:
        return []
    domo = {str(c.get("name")).lower(): str(c.get("type") or "").upper() for c in dataset.get("columns") or []}
    found = [(d["name"], _DOUBLE_AS_TEXT) for d in described
             if str(d.get("type") or "").upper() == "DOUBLE" and domo.get(d["name"].lower()) in ("STRING", "TEXT")]
    if found:
        names = ", ".join(name for name, _ in found[:8])
        review_items.append(ReviewItem(
            kind="double_for_text_converted", severity="info",
            title=f"{dataset['name']!r}: {len(found)} column(s) Domo holds as text came out of the converted SQL as "
                  f"numbers ({names}); the model's query writes them as text the way Domo does (160 is '160.0')",
            source_type="dataset", source_id=dataset.get("id"), detail={"columns": [n for n, _ in found]},
        ))
    return found


def double_as_text(quoted: str) -> str:
    """A DOUBLE column as the text Domo stores for it: Java's Double.toString, so a whole number keeps its ".0".
    Only the range Java prints plainly (0.001 up to 10,000,000) is rewritten; beyond it the warehouse's spelling stays.
    The converter's `SqlWriter.DoubleAsText` is the same expression for the tiles that turn a double into text mid-flow."""
    return (f"CASE WHEN {quoted} IS NULL THEN NULL WHEN {quoted} = 0 THEN '0.0' "
            f"WHEN ABS({quoted}) >= 0.001 AND ABS({quoted}) < 10000000 AND {quoted} = TRUNC({quoted}) "
            f"THEN CAST(CAST({quoted} AS BIGINT) AS VARCHAR(32)) || '.0' "
            f"ELSE CAST({quoted} AS VARCHAR(32)) END")


def _first_line(exc: Exception, limit: int) -> str:
    """The first line of an error's message (an exception with no message still says what it was)."""
    lines = str(exc).strip().splitlines()
    return (lines[0] if lines else type(exc).__name__)[:limit]


_NUMBER_COLUMN_TYPES = ("LONG", "DOUBLE", "DECIMAL")
# An exponent of up to two digits: the cast of 1e400 is an error that fails the whole table, not an empty value.
_NUMBER_PATTERN = "^[-+]?([0-9]+([.][0-9]*)?|[.][0-9]+)([eE][-+]?[0-9]{1,2})?$"
_APOSTROPHE = "'" * 4          # the SQL literal for one apostrophe, quoted: ''''


def _double_from_text(quoted: str) -> str:
    """The number a quoted text column holds (grouping commas and a leading apostrophe dropped); empty when it is not one."""
    text = f"REPLACE(LTRIM(TRIM(CAST({quoted} AS VARCHAR(65535))), {_APOSTROPHE}), ',', '')"
    return f"CASE WHEN {text} ~ '{_NUMBER_PATTERN}' THEN CAST({text} AS DOUBLE PRECISION) END"


def _with_number_columns(statement: str, columns: list[str]) -> str:
    """`statement` with, next to each of `columns`, that column read as a number (named by `directquery.number_shadow_name`)."""
    extra = ", ".join(f'{_double_from_text(chr(34) + c.replace(chr(34), chr(34) * 2) + chr(34))} AS '
                      f'"{directquery.number_shadow_name(c).replace(chr(34), chr(34) * 2)}"' for c in columns)
    return f"SELECT t.*, {extra} FROM ({statement.rstrip().rstrip(';')}) t"


def _numbers_from_text(statement: str, columns: list[tuple[str, str]]) -> str:
    """The statement with each of `columns` cast to the number Domo declares (the converter's text-to-number reading:
    grouping commas and a leading apostrophe dropped, a LONG truncated, what is not a number empty)."""
    casts = []
    for name, domo_type in columns:
        quoted = '"' + name.replace('"', '""') + '"'
        text = f"REPLACE(LTRIM(TRIM(CAST({quoted} AS VARCHAR(65535))), {_APOSTROPHE}), ',', '')"
        number = f"CAST({text} AS DOUBLE PRECISION)"
        if domo_type == _DOUBLE_AS_TEXT:
            casts.append((quoted, f"{double_as_text(quoted)} AS {quoted}"))
            continue
        if domo_type == "STRING":
            # only ever an integer column (`_integers_for_text`): 20 characters hold any BIGINT, and a 65535-wide
            # column would cost a refresh and every sort and group-by its declared width
            casts.append((quoted, f"CAST({quoted} AS VARCHAR(24)) AS {quoted}"))
            continue
        if domo_type == "LONG":
            # Digits go straight to BIGINT (a long id through a double loses its last digits); a decimal is truncated;
            # what would overflow a BIGINT is empty rather than an error that fails the whole table.
            casts.append((quoted, f"CASE WHEN {text} ~ '^[-+]?[0-9]{{1,18}}$' THEN CAST({text} AS BIGINT) "
                                  f"WHEN {text} ~ '{_NUMBER_PATTERN}' THEN "
                                  # nested, not `AND`: SQL does not promise the regex is tested before the cast
                                  f"(CASE WHEN ABS({number}) < 9e18 THEN CAST(TRUNC({number}) AS BIGINT) END) "
                                  f"END AS {quoted}"))
            continue
        casts.append((quoted, f"{_double_from_text(quoted)} AS {quoted}"))
    excluded = ", ".join(q for q, _ in casts)
    return f"SELECT {', '.join(c for _, c in casts)}, t.* EXCLUDE({excluded}) FROM ({statement.rstrip().rstrip(';')}) t"


def _source_for(
    ctx: RunContext, dataset_id: str, sql_by_dataset: dict[str, str],
    landed: dict[str, str], warehouse: dict[str, Any],
    text_for_numbers: list[tuple[str, str]] | None = None,
) -> DataSource | None:
    """Where this table's rows come from, as Power Query."""
    host = warehouse.get("host")
    database = warehouse.get("database")
    port = warehouse.get("port", 5439)

    artefact = sql_by_dataset.get(dataset_id)
    if artefact and host:
        sql = (ctx.run_dir / "convert_dataflows" / artefact).read_text()
        # The converter's script carries a leading comment; Value.NativeQuery
        # takes the statement itself.
        statement = native_statement(sql)
        if text_for_numbers:
            statement = _numbers_from_text(statement, text_for_numbers)
        return DataSource(
            kind="redshift_sql",
            m_expression=writer.redshift_m(host, port, database, statement),
            detail={"artefact": artefact, "database": database,
                    **({"text_for_numbers": [list(c) for c in text_for_numbers]} if text_for_numbers else {})},
        )

    table_ref = landed.get(dataset_id)
    if table_ref and host:
        schema, _, table = table_ref.partition(".")
        return DataSource(
            kind="warehouse_table",
            m_expression=(
                "let\n"
                f'    Source = AmazonRedshift.Database("{host}:{port}", "{database}"),\n'
                f'    Data = Source{{[Name="{schema}"]}}[Data]{{[Name="{table}"]}}[Data]\n'
                "in\n"
                "    Data"
            ),
            detail={"table_ref": table_ref},
        )
    return None


def _add_measures(
    ctx: RunContext, closure: dict, model: SemanticModel,
    review_items: list[ReviewItem], warnings: list[str],
) -> None:
    """Translate the beast modes the cards actually use.

    Only those: a shared dataset can carry hundreds of calculated fields,
    and a model cluttered with measures no visual references is worse than
    one that carries what the report needs.
    """
    if not model.tables:
        return

    # A beast mode belongs to the table of the dataset the card that uses it reads, and is built there,
    # translated against that table's name. A card whose dataset is not a table falls back to the first.
    #
    # A name is not an identity: Domo cards are copied around and carry their own beast modes, so
    # 'IP Revenue' exists in five versions (WHEN patienttype = 'IP' / 'Inpatient' / 'IN'...). Each card
    # uses the one linked to it, so the formula is taken from the card's own link, and a name used with
    # different formulas, or on different tables, becomes a field per variant (Daily Revenue-SW: the
    # first 'IP Revenue' by name summed the wrong patient type, 0 against 296,679 on every row).
    table_by_dataset = {t.origin: t for t in model.tables}
    fields_by_id = {str(f.get("id")): f for f in closure.get("calculated_fields") or []}
    fields_by_name: dict[str, dict] = {}
    for f in closure.get("calculated_fields") or []:
        fields_by_name.setdefault(f.get("name"), f)
    formulas = {fid: f.get("formula") for fid, f in fields_by_id.items()}

    def field_for(card: dict, name: str) -> dict | None:
        for fid in card.get("calculated_field_ids") or []:
            candidate = fields_by_id.get(str(fid))
            if candidate is not None and candidate.get("name") == name:
                return candidate
        return fields_by_name.get(name)

    # (Domo name) -> the distinct (table, formula) versions of it, in the order cards use them.
    variants: dict[str, list[tuple[Table, str, dict]]] = {}
    uses: list[tuple[dict, str, Table, str]] = []                  # (card, name, owner table, formula key)
    for card in closure["cards"]:
        owner = next((table_by_dataset[d] for d in card.get("dataset_ids") or []
                      if d in table_by_dataset), model.tables[0])
        for subscription in card.get("data_subscriptions") or []:
            for column in subscription.get("columns") or []:
                name = column.get("name")
                field = field_for(card, name) if column.get("formula") and name else None
                if field is None:
                    continue
                key = " ".join((field.get("formula") or "").split())
                # The model compares names without regard to case ('Direct Cost per Case' and 'Direct Cost Per Case'
                # on two tables failed to import: a measure with that name already exists).
                known = variants.setdefault(name.lower(), [])
                if not any(t is owner and k == key for t, k, _ in known):
                    known.append((owner, key, field))
                uses.append((card, name, owner, key))

    built: dict[tuple[str, str, str], tuple[str, str]] = {}      # (table, name, formula key) -> (model name, kind)
    for found in variants.values():
        name = found[0][2].get("name") or ""
        for index, (table, key, field) in enumerate(found):
            expanded, _ = dax.expand_references(field.get("formula") or "", formulas)
            kind = "column" if dax.is_row_level(expanded) else "measure"
            earlier_here = sum(1 for t, _, _ in found[:index] if t is table)
            if index == 0:
                model_name = name
            elif kind == "column":
                # A column name is unique within its table; a second formula there is "(2)".
                model_name = f"{name} ({earlier_here + 1})" if earlier_here else name
            else:
                # Measure names are unique across the model, so a later version carries its table.
                model_name = f"{name} ({table.name}" + (f", {earlier_here + 1})" if earlier_here else ")")
            taken = {c.name.lower() for c in table.columns} | {m.name.lower() for m in table.measures}
            if model_name.lower() in {c.name.lower() for c in table.columns}:
                # Fabric refuses "a measure cannot be created because a column with the same name already exists"
                # (Hospital & Clinic Provider Profitability-SW: beast mode 'Total Cost' over a dataset column 'Total Cost').
                model_name = f"{model_name} (calc)"
                while model_name.lower() in taken:
                    model_name += " (calc)"
            built[(table.name, name.lower(), key)] = (model_name, kind)
            _add_beast_mode(table, field, name, formulas, review_items, warnings, measure_name=model_name)
    for card, name, owner, key in uses:
        model_name, kind = built[(owner.name, name.lower(), key)]
        model.card_fields.setdefault(str(card.get("id")), {})[name] = (owner.name, model_name, kind)

    # `variants` is keyed by the lower-cased name (the model compares names without regard to case), so the names the
    # cards use are compared the same way: 'Avg Per Day' was built and still reported as not in the scan.
    used = {c["name"].lower(): c["name"] for card in closure["cards"] for sub in card.get("data_subscriptions") or []
            for c in sub.get("columns") or [] if c.get("formula") and c.get("name")}
    for name in sorted(name for key, name in used.items() if key not in variants):
        review_items.append(ReviewItem(
            kind="measure_not_found",
            title=f"Cards use a calculated field {name!r} that is not in the scan",
        ))


_AGGREGATION_LABELS = {"SUM": "Sum", "AVG": "Average", "AVERAGE": "Average", "MIN": "Min", "MAX": "Max"}
_ITERATORS = {"Sum": "SUMX", "Average": "AVERAGEX", "Min": "MINX", "Max": "MAXX"}


def _text_aggregation_name(table: str, column: str, aggregation: str) -> str:
    """The measure that stands in for an aggregate of a text column: "Sum of NPI (Table)"."""
    return f"{_AGGREGATION_LABELS[aggregation.upper()]} of {column} ({table})"


def _add_text_aggregations(closure: dict, model: SemanticModel) -> None:
    """A card that sums, averages, mins or maxes a text column: Domo reads the text as a number, Power BI
    shows a field error (Clinic Collections - SW, 'Sum of Service Provider NPI'). Each such aggregate becomes a
    measure that converts per row (text that is not a number counts as blank); build_report binds the card to it."""
    if not model.tables:
        return
    table_by_dataset = {t.origin: t for t in model.tables}
    have = {m.name for t in model.tables for m in t.measures}
    for card in closure["cards"]:
        owner = next((table_by_dataset[d] for d in card.get("dataset_ids") or [] if d in table_by_dataset),
                     model.tables[0])
        types = {c.name: c.source_type.upper() for c in owner.columns if c.expression is None}
        for subscription in card.get("data_subscriptions") or []:
            for column in subscription.get("columns") or []:
                aggregation = str(column.get("aggregation") or "").upper()
                name = column.get("name")
                if (str(column.get("columnType") or "").upper() != "SELECT" or column.get("formula")
                        or aggregation not in _NUMERIC_AGGREGATIONS or types.get(name) not in _TEXT_COLUMN_TYPES):
                    continue
                measure = _text_aggregation_name(owner.name, name, aggregation)
                if measure in have:
                    continue
                have.add(measure)
                iterator = _ITERATORS[_AGGREGATION_LABELS[aggregation]]
                owner.measures.append(Measure(
                    name=measure,
                    expression=(f"{iterator}({query.quote_name(owner.name)}, "
                                f"IFERROR(VALUE({query.column_ref(owner.name, name)}), BLANK()))"),
                    description=(f"{aggregation.title()} of the text column {name!r}: Domo reads the text as a number, "
                                 "Power BI cannot aggregate text, so each value is converted first."),
                ))


def _note_unrelated_tables(
    model: SemanticModel, review_items: list[ReviewItem], warnings: list[str],
) -> None:
    """Say where a relationship might be wanted, without inventing one.

    Domo records no relationship between datasets, only that a page filter
    applies to every card with a column of that name. A relationship guessed
    from names risks a many-to-many that quietly changes every figure, so
    none is created; the shared names are listed for a person to decide.
    """
    for index, left in enumerate(model.tables):
        for right in model.tables[index + 1:]:
            shared = sorted({c.name for c in left.columns} & {c.name for c in right.columns})
            if not shared:
                continue
            shown = ", ".join(shared[:5]) + (f" and {len(shared) - 5} more" if len(shared) > 5 else "")
            review_items.append(ReviewItem(
                kind="no_relationship", severity="warn",
                title=f"{left.name!r} and {right.name!r} share columns ({shown}) but no relationship "
                      "was created, so a filter on one does not reach the other",
                source_type="dataset", source_id=right.origin,
                detail={"tables": [left.name, right.name], "shared_columns": shared},
            ))
            warnings.append(f"no relationship between {left.name!r} and {right.name!r}")


_NUMERIC_RESULTS = {"DECIMAL": "DECIMAL", "DOUBLE": "DOUBLE", "NUMERIC": "DOUBLE", "FLOAT": "DOUBLE", "LONG": "LONG"}


def _calculated_type(field: dict, expression: str = "") -> str:
    """The type of a calculated column: a number when Domo says the formula yields one (a filter such as
    NOT_IN 0 compares it as a number), else text as before. Text results win over Domo's word: it declares LONG for a
    CASE of 'OR Case' and 0."""
    if dax.yields_text(expression):
        return "STRING"
    return _NUMERIC_RESULTS.get(str(field.get("data_type") or "").upper(), "STRING")


def _add_beast_mode(
    table: Table, field: dict, name: str, formulas: dict[str, str | None],
    review_items: list[ReviewItem], warnings: list[str], measure_name: str | None = None,
) -> None:
    final = measure_name or name           # what it is called in the model (see _add_measures)
    expanded, reference_error = dax.expand_references(field.get("formula") or "", formulas)
    if reference_error:
        result = dax.DaxResult("", False, reference_error, field.get("formula"))
    else:
        result = dax.translate(expanded, table.name)
        if result.ok:
            numeric = {c.name for c in table.columns if c.source_type in ("LONG", "INTEGER", "DOUBLE", "DECIMAL")}
            result.expression = dax.numbers_for_numeric_columns(result.expression, table.name, numeric)
            text = {c.name for c in table.columns if c.source_type in ("STRING", "TEXT") and c.expression is None}
            result.expression = dax.text_columns_against_numbers(result.expression, table.name, text)
            dates = {c.name: c.source_type for c in table.columns if c.source_type in _DATE_COLUMN_TYPES and c.expression is None}
            result.expression = dax.dates_as_text_in_case(result.expression, table.name, dates)
            if not dax.is_row_level(expanded):
                # A measure reads no row: a column outside its aggregates is the group's value.
                result.expression = dax.group_columns_as_values(result.expression)
    if (dax.is_row_level(expanded)
            and final not in {c.name for c in table.columns}):
        # Cards group and slice by a row-level beast mode, which only a
        # column can do. A failed translation still gets a (blank)
        # column so the visual binds to something that exists.
        if result.ok:
            table.columns.append(Column(
                name=final, source_type=_calculated_type(field, result.expression), origin=field.get("id"),
                expression=result.expression,
                description=f"Migrated from Domo beast mode: {field.get('formula')}",
            ))
            return
        table.columns.append(Column(
            name=final, source_type="STRING", origin=field.get("id"),
            expression="BLANK()", needs_review=True,
            description=(f"NOT TRANSLATED ({result.reason}). "
                         f"Original Domo formula: {field.get('formula')}"),
        ))
        review_items.append(ReviewItem(
            kind="untranslated_measure", severity="error",
            title=f"Beast mode {name!r} did not translate to DAX ({result.reason})",
            source_type="calculated_field", source_id=field.get("id"),
            detail={"formula": field.get("formula")},
        ))
        warnings.append(f"calculated column {name!r} needs writing by hand")
        return
    if result.ok:
        table.measures.append(Measure(
            name=final, expression=result.expression, origin=field.get("id"),
            description=f"Migrated from Domo beast mode: {field.get('formula')}",
        ))
    else:
        # A measure that is obviously missing beats one that is quietly
        # wrong, so the placeholder is blank and says why.
        table.measures.append(Measure(
            name=final, expression="BLANK()", origin=field.get("id"), needs_review=True,
            description=(f"NOT TRANSLATED ({result.reason}). "
                         f"Original Domo formula: {field.get('formula')}"),
        ))
        review_items.append(ReviewItem(
            kind="untranslated_measure", severity="error",
            title=f"Beast mode {name!r} did not translate to DAX ({result.reason})",
            source_type="calculated_field", source_id=field.get("id"),
            detail={"formula": field.get("formula")},
        ))
        warnings.append(f"measure {name!r} needs writing by hand")


# ---- build_report -------------------------------------------------------


def _aggregated_column(projection: Projection, column: Any, column_types: dict[str, dict[str, str]] | None = None) -> Projection:
    """A calculated column the card sums (or averages...): Domo's `Newborn Days for Productivity` is a row-level beast
    mode that the card draws as SUM(...) per pay period, so the visual aggregates the column; a plain column listed the
    values row by row (553 rows against Domo's 152 on customer Productivity Newborn). A column the model holds as
    text stays a plain column: Power BI cannot sum text, and an aggregation of it is a visual that does not draw."""
    aggregation = (column.aggregation or "").upper()
    if projection.kind != "column" or aggregation not in _NUMERIC_AGGREGATIONS + ("COUNT",):
        return projection
    if aggregation != "COUNT" and (column_types or {}).get(projection.table, {}).get(projection.name) in _TEXT_COLUMN_TYPES:
        return projection
    return Projection(projection.table, projection.name, "aggregation", aggregation=aggregation,
                      display_name=projection.display_name)


def _fit_case(columns: set[str] | dict[str, Any], name: str) -> str:
    """The table's own spelling of a column Domo names in another case ('Revenue' for the dataset's 'revenue': Domo
    matches column names without regard to case, the model does not). `name` itself when it matches exactly or
    when two columns differ only by case."""
    if name in columns:
        return name
    found = [c for c in columns if c.lower() == name.lower()]
    return found[0] if len(found) == 1 else name


def build_report(ctx: RunContext) -> StageResult:
    closure = ctx.read_json("resolve_closure", "closure.json")
    model_payload = ctx.read_json("build_model", MODEL_FILE)
    if not model_payload["tables"]:
        raise ValueError("No tables in the semantic model, so there is nothing to report on")

    tables = model_payload["tables"]
    table_by_dataset = {t.get("origin"): t["name"] for t in tables}
    card_fields = model_payload.get("card_fields") or {}
    measure_table = {m["name"]: t["name"] for t in tables for m in t["measures"]}
    measures_of = {t["name"]: {m["name"] for m in t["measures"]} for t in tables}
    columns_of = {t["name"]: {c["name"] for c in t["columns"]} for t in tables}
    column_types = {t["name"]: {c["name"]: str(c.get("source_type") or "").upper() for c in t["columns"]}
                    for t in tables}
    calculated_columns = {(t["name"], c["name"]) for t in tables for c in t["columns"]
                          if c.get("expression") is not None}

    layout_model = _layout_model(closure["dashboard"].get("layout") or {}, closure["dashboard"]["name"])
    layout_pages = [(name, boxes) for name, boxes, _ in layout_model]
    page_of_card = {card_id: index for index, (_, boxes) in enumerate(layout_pages) for card_id in boxes}
    pages = [
        Page(name="migrated-page" if index == 0 else f"migrated-page-{index + 1}",
             display_name=name, width=PAGE_WIDTH, height=_page_height(boxes))
        for index, (name, boxes) in enumerate(layout_pages)
    ]
    unplaced_page: Page | None = None

    review_items: list[ReviewItem] = []
    warnings: list[str] = []
    mapped_count = 0
    mapped_cards: list[tuple[dict, str, dict[str, list[Projection]]]] = []

    def place_card(card_id: str) -> tuple[Page, dict[str, float]]:
        """The page and box the layout gives a card."""
        nonlocal unplaced_page
        placed = page_of_card.get(card_id)
        if placed is not None:
            return pages[placed], layout_pages[placed][1][card_id]
        # The layout does not place this card. With tabs, mixing it into
        # one of them would claim it belongs there, so it gets its own page.
        if len(pages) > 1 and unplaced_page is None:
            unplaced_page = Page(name=f"migrated-page-{len(pages) + 1}", display_name="Other cards",
                                 width=PAGE_WIDTH, height=720)
            pages.append(unplaced_page)
        page = unplaced_page or pages[0]
        box = _fallback_box(len([v for v in page.visuals if v.origin not in page_of_card]))
        page.height = max(page.height, int(box["y"] + box["height"] + GUTTER))
        return page, box

    for index, card in enumerate(closure["cards"]):
        mapped = chart_map.map_card(card)
        if str(card.get("card_type") or "").lower() == "text" and not mapped.mapped and "text" in card:
            # A Notebook card is words a dashboard author put beside the charts (#443): they are carried in a text
            # box at the card's place. A blank one builds nothing and is only noted. (A closure written before the
            # text was carried has no `text` key: that card is reported as unmapped, not as blank.)
            text = card["text"] or ""
            if text.strip():
                page, box = place_card(mapped.card_id)
                page.visuals.append(Visual(visual_type="textbox", title="", x=box["x"], y=box["y"], width=box["width"],
                                           height=box["height"], text=text, origin=mapped.card_id))
                mapped_count += 1
            else:
                review_items.append(ReviewItem(
                    kind="unmapped_card", severity="info",
                    title=f"Notebook card {mapped.title!r} holds no text; nothing was built",
                    source_type="card", source_id=mapped.card_id,
                ))
            continue
        for warning in mapped.warnings:
            warnings.append(f"{mapped.title}: {warning}")
        if not mapped.mapped:
            review_items.append(ReviewItem(
                # A card that is not a chart (an image, an app) was never going to be a data visual: noted, not an error.
                kind="unmapped_card", severity="warn" if card.get("card_type") in chart_map.NON_DATA_CARD_TYPES else "error",
                title=f"Card {mapped.title!r} ({card.get('chart_type')}) has no Power BI equivalent",
                source_type="card", source_id=mapped.card_id,
            ))
            continue

        # The card's own table: the one built from the dataset it reads.
        table_name = next((table_by_dataset[d] for d in card.get("dataset_ids") or []
                           if d in table_by_dataset), tables[0]["name"])
        buckets: dict[str, list[Projection]] = {}
        own_fields = card_fields.get(str(card.get("id")), {})
        for column in mapped.columns:
            # A plain column of the card's own dataset is that column, even when another dataset's beast mode has its
            # name (Daily Stats - SW 'Cases': SUM of a column here, COUNT(DISTINCT patientid) on OR Utilization;
            # the card read the other table's measure, 43,093 on every row, bimcontrol#399).
            own_column = not column.is_formula and column.name in columns_of[table_name]
            if column.name in own_fields:
                # The beast mode this card itself uses (a name can mean different formulas on different cards).
                bound = own_fields[column.name]
                projection = Projection(bound["table"], bound["name"], bound["kind"],
                                        display_name=column.alias or column.name)
                projection = _aggregated_column(projection, column, column_types)
            elif (table_name, column.name) in calculated_columns:
                projection = Projection(table_name, column.name, "column",
                                        display_name=column.alias)
                projection = _aggregated_column(projection, column, column_types)
            elif column.is_formula or (column.name in measure_table and not own_column) or f"{column.name} ({table_name})" in measures_of[table_name]:
                # The card's own table's measure when it has one (a measure defined for several tables
                # is "<name> (<table>)" on all but the first), else whichever table defines the name.
                own = f"{column.name} ({table_name})"
                if own in measures_of[table_name]:
                    projection = Projection(table_name, own, "measure", display_name=column.alias or column.name)
                else:
                    projection = Projection(measure_table.get(column.name, table_name), column.name,
                                            "measure", display_name=column.alias)
            elif (column.aggregation and column.aggregation.upper() in _NUMERIC_AGGREGATIONS
                  and column_types.get(table_name, {}).get(column.name) in _TEXT_COLUMN_TYPES
                  and (_text_aggregation_name(table_name, column.name, column.aggregation)
                       in measures_of[table_name])):
                # The sum of a text column: the model's measure that converts it (see _add_text_aggregations).
                projection = Projection(table_name, _text_aggregation_name(table_name, column.name, column.aggregation),
                                        "measure", display_name=column.alias or f"{_AGGREGATION_LABELS[column.aggregation.upper()]} of {column.name}")
            elif column.aggregation:
                projection = Projection(table_name, _fit_case(columns_of[table_name], column.name), "aggregation",
                                        aggregation=column.aggregation,
                                        display_name=column.alias)
            else:
                projection = Projection(table_name, _fit_case(columns_of[table_name], column.name), "column",
                                        display_name=column.alias or (column.name if column.name not in columns_of[table_name] else None))
            # Domo maps the extra value columns of a multi-value chart SERIES; Power BI's Series (legend) takes
            # only a column, so a measure there is a visual error ("too many columns in the Column legend
            # bucket", Clinic Collections - SW). A measure or aggregate in that role is a value.
            role = column.role
            if role in _DIMENSION_ROLES and projection.kind in ("measure", "aggregation"):
                # The same goes for an aggregate Domo put among a pivot's rows ('Accession #' counted in ROW,
                # customer Imaging by Modality): it is a value here.
                spec = chart_map.visual_for(mapped.chart_type)
                role = (spec.roles.get("VALUE") if spec else None) or "Y"
                warnings.append(f"{mapped.title}: {projection.name!r} is an aggregate in the {column.role} role; "
                                f"placed in {role}")
            buckets.setdefault(role, []).append(projection)
        _split_combo_values(mapped.visual_type, buckets)

        visual_filters = []
        for item in mapped.card_filters:
            # A beast mode this card uses under another model name ("IP Revenue (2)": a name can mean
            # different formulas on different cards) is filtered under that name, not the Domo one.
            bound = own_fields.get(item.column)
            filter_table, filter_column = table_name, _fit_case(columns_of[table_name], item.column)
            if bound and bound["kind"] == "column":
                filter_table, filter_column = bound["table"], bound["name"]
            kind, comparison, negated = chart_map.FILTER_OPERANDS[item.operand]
            measure = None
            if kind == "compare" and ((bound and bound["kind"] == "measure") or (not bound and filter_column not in columns_of[filter_table])):
                measure = (bound["table"], bound["name"]) if bound else _measure_named(
                    item.column, table_name, measure_table, measures_of)
            if measure:
                # A filter on an aggregate (Domo: 'FTE Opportunity (Calc)' >= 0.01) keeps the rows whose measure passes,
                # a filter on the measure in Power BI (Executive Summary Productivity Benchmark: 19 rows too many).
                visual_filters.append(VisualFilter(
                    table=measure[0], column=measure[1], kind=kind, values=item.values,
                    data_type=chart_map.filter_data_type(item.data_type, None),
                    comparison=comparison, negated=negated, field_kind="measure"))
                continue
            if (bound and bound["kind"] != "column") or filter_column not in columns_of[filter_table]:
                # A filter on a card-level calculation the scan does not describe (calculation_<uuid>):
                # the model has no such column, so a visual filter on it breaks the visual.
                warnings.append(f"{mapped.title}: card filter on {item.column!r} is not applied; "
                                f"the model has no such column")
                review_items.append(ReviewItem(
                    kind="card_filter_on_unknown_column", severity="warning",
                    title=f"{mapped.title!r}: Domo filters on {item.column!r} ({item.operand}, "
                          f"{', '.join(item.values[:3])}), which is not a column of {table_name!r}; the filter "
                          "is not applied, so the visual may show more rows than Domo",
                    source_type="card", source_id=mapped.card_id,
                ))
                continue
            visual_filters.append(_with_held_blanks(VisualFilter(
                table=filter_table, column=filter_column, kind=kind, values=item.values,
                data_type=chart_map.filter_data_type(item.data_type, column_types.get(filter_table, {}).get(filter_column)),
                comparison=comparison, negated=negated), tables))

        for saved in card.get("date_ranges") or []:
            _add_date_range(saved, mapped, table_name, column_types[table_name], visual_filters,
                            review_items, warnings)

        _add_top_n(_in_model_names(card.get("top_n"), own_fields), mapped, table_name, columns_of[table_name], buckets,
                   visual_filters, review_items, warnings)
        visual_sort, sort_keys = _card_sort(_in_model_names(card.get("sort"), own_fields), buckets, columns_of[table_name])

        page, box = place_card(mapped.card_id)
        page.visuals.append(Visual(
            visual_type=mapped.visual_type, title=mapped.title,
            x=box["x"], y=box["y"], width=box["width"], height=box["height"],
            buckets=buckets, origin=mapped.card_id, filters=visual_filters,
            sort=visual_sort, sort_keys=sort_keys, row_limit=(card.get("top_n") or {}).get("limit"),
            kept_columns=_hidden_group_columns(card, mapped.visual_type, buckets, table_name, columns_of[table_name]),
            **_chart_style(mapped.visual_type, card.get("style")),
        ))
        mapped_count += 1
        mapped_cards.append((card, table_name, buckets))

    _add_static_components(pages, [statics for _, _, statics in layout_model], review_items, warnings)
    pages = [p for p in pages if p.visuals or len(pages) == 1]
    report = Report(name=_safe(closure["dashboard"]["name"]), pages=pages)
    slicer_count = _add_dashboard_filters(
        report, closure["dashboard"].get("filters"), tables, review_items, warnings)
    _add_dashboard_title(report.pages, closure["dashboard"]["name"])
    # After the slicers and title, which belong on the visible pages only.
    drill_pages = _add_drillthrough_pages(
        report, mapped_cards, tables, closure.get("calculated_fields") or [], review_items, warnings, card_fields)
    pages = report.pages
    _lint_visuals(report.pages, column_types, review_items, warnings)
    ctx.write_json(REPORT_FILE, {
        "name": report.name,
        "pages": [{
            "name": page.name, "display_name": page.display_name,
            "width": page.width, "height": page.height,
            "drillthrough": asdict(page.drillthrough) if page.drillthrough else None,
            "visuals": [{
                "origin": v.origin, "title": v.title, "visual_type": v.visual_type,
                "x": v.x, "y": v.y, "width": v.width, "height": v.height,
                "buckets": {role: [{"name": p.name, "kind": p.kind, "table": p.table,
                                    "aggregation": p.aggregation, "display_name": p.display_name} for p in fields]
                            for role, fields in v.buckets.items()},
                "filters": [asdict(f) for f in v.filters],
                "slicer_mode": v.slicer_mode, "sync_group": v.sync_group, "text": v.text, "text_size": v.text_size, "bold": v.bold,
                "data_labels": v.data_labels, "legend_position": v.legend_position,
                "sort": [{"field": {"name": p.name, "kind": p.kind, "table": p.table, "aggregation": p.aggregation},
                          "direction": direction} for p, direction in v.sort],
                "sort_keys": v.sort_keys, "row_limit": v.row_limit, "kept_columns": v.kept_columns,
            } for v in page.visuals],
        } for page in pages],
        "filters": [asdict(f) for f in report.filters],
    }, kind="report", label="Report definition")

    ctx.progress(f"{mapped_count} of {len(closure['cards'])} card(s) became visuals on {len(pages)} page(s)"
                 f", with {slicer_count} slicer(s), {len(report.filters)} report filter(s)"
                 f" and {drill_pages} drillthrough page(s)")
    return StageResult(
        summary={"visuals": mapped_count, "cards": len(closure["cards"]),
                 "pages": len(pages), "page_height": pages[0].height,
                 "slicers": slicer_count, "report_filters": len(report.filters),
                 "drillthrough_pages": drill_pages},
        warnings=warnings,
        review_items=review_items,
    )


def _box(item: dict, scale: float) -> dict[str, float]:
    return {
        "x": item.get("x", 0) * scale + GUTTER / 2,
        "y": item.get("y", 0) * scale + GUTTER / 2,
        "width": max(item.get("width", 20) * scale - GUTTER, 40),
        "height": max(item.get("height", 20) * scale - GUTTER, 40),
    }


def _layout_pages(layout: dict, title: str) -> list[tuple[str, dict[str, dict[str, float]]]]:
    """The report's pages as `(name, {card id: box})`; see `_layout_model`."""
    return [(name, boxes) for name, boxes, _ in _layout_model(layout, title)]


def _layout_model(layout: dict, title: str) -> list[tuple[str, dict[str, dict[str, float]], list[dict]]]:
    """The report's pages as `(name, {card id: box}, static items)`, scaled
    from Domo's 60-unit grid to page points.

    Domo's template holds the geometry and its content list holds the card
    ids, the header text and the tab names; they are joined on `contentKey`.
    A dashboard with tabs becomes one page per tab (cards outside every tab
    go on a first page named for the dashboard). `PAGE_BREAK` items are print
    pagination, not screens, so they do not split the page. Always returns at
    least one page.

    Static items are the layout's non-card components, each
    `{"type", "box", "text", "control_id"}`: `HEADER` (a text label),
    `VARIABLE` (a dashboard control, referenced only by `variableControlId`)
    and `BUTTON`. Separators and page breaks carry nothing and are skipped.
    """
    template = layout.get("standard", {}).get("template")
    if not isinstance(template, list):
        return [(title, {}, [])]
    content = layout.get("content") or []
    card_by_key = {c.get("contentKey"): str(c["cardId"]) for c in content if c.get("cardId") is not None}
    text_by_key = {c.get("contentKey"): c.get("text") for c in content if c.get("text")}
    control_by_key = {c.get("contentKey"): c.get("variableControlId") for c in content
                      if c.get("variableControlId") is not None}
    scale = PAGE_WIDTH / DOMO_GRID_WIDTH

    def cards_in(items: list[dict]) -> tuple[dict[str, dict[str, float]], list[dict]]:
        found: dict[str, dict[str, float]] = {}
        statics: list[dict] = []
        for item in items:
            kind = item.get("type")
            key = item.get("contentKey")
            if kind == "CARD":
                card_id = card_by_key.get(key)
                if card_id:
                    found[card_id] = _box(item, scale)
            elif kind in STATIC_TYPES:
                statics.append({"type": kind, "box": _box(item, scale), "text": text_by_key.get(key),
                                "control_id": control_by_key.get(key)})
        return found, statics

    def tab_pages(items: list[dict]) -> list[tuple[str, dict[str, dict[str, float]], list[dict]]]:
        out = []
        for item in items:
            if item.get("type") == "TABS":
                for tab in item.get("children") or []:
                    if tab.get("type") != "TAB_CONTENT":
                        continue
                    # Tab children are positioned from the tab's own top-left.
                    boxes, statics = cards_in(tab.get("children") or [])
                    out.append((text_by_key.get(tab.get("contentKey")) or "Tab", boxes, statics))
                    out.extend(tab_pages(tab.get("children") or []))  # tabs inside a tab
        return out

    tabs = tab_pages(template)
    main, main_statics = cards_in(template)
    if not tabs:
        return [(title, main, main_statics)]
    pages = ([(title, main, main_statics)] if main or main_statics else []) + tabs
    seen: dict[str, int] = {}
    named = []
    for name, boxes, statics in pages:
        seen[name] = seen.get(name, 0) + 1
        named.append((name if seen[name] == 1 else f"{name} ({seen[name]})", boxes, statics))
    return named


def _add_static_components(pages: list[Page], statics_by_page: list[list[dict]],
                           review_items: list[ReviewItem], warnings: list[str]) -> None:
    """Domo's non-card layout items. `HEADER` becomes a text box at its
    position; `VARIABLE` (a dashboard control) and `BUTTON` have no Power BI
    equivalent here, so each is named in one `layout_components_unmapped`
    review item."""
    skipped: list[dict] = []
    statics_by_page = statics_by_page + [[] for _ in pages[len(statics_by_page):]]
    for page, statics in zip(pages, statics_by_page):
        for item in statics:
            if item["type"] == "HEADER" and item["text"]:
                box = item["box"]
                page.visuals.append(Visual(
                    visual_type="textbox", title="", x=box["x"], y=box["y"],
                    width=box["width"], height=box["height"], text=item["text"],
                    origin="header"))
            else:
                skipped.append({
                    "type": item["type"], "page": page.display_name,
                    "label": item["text"], "control_id": item["control_id"]})
    if skipped:
        names = ", ".join(sorted({s["type"] for s in skipped}))
        warnings.append(f"{len(skipped)} layout component(s) not carried ({names})")
        review_items.append(ReviewItem(
            kind="layout_components_unmapped", severity="warn",
            title=f"{len(skipped)} dashboard layout component(s) have no Power BI equivalent",
            source_type="dashboard", source_id=None, detail={"components": skipped}))


def _add_dashboard_title(pages: list[Page], title: str) -> None:
    """The dashboard's title in a band above everything else on each page
    (slicers included, so call this after they are placed), unless a header
    on the page already says it. An empty tab stays out of the report."""
    for page in pages:
        if not page.visuals and len(pages) > 1:
            continue  # an empty tab stays out of the report
        has_title = any(v.text and v.text.strip().lower() == title.strip().lower()
                        for v in page.visuals)
        if not has_title:
            for visual in page.visuals:
                visual.y += TITLE_BAND
            page.height += TITLE_BAND
            page.visuals.insert(0, Visual(
                visual_type="textbox", title="", x=GUTTER / 2, y=GUTTER / 2,
                width=PAGE_WIDTH - GUTTER, height=TITLE_BAND - GUTTER, text=title,
                origin="title", text_size=20, bold=True))


def _split_combo_values(visual_type: str | None, buckets: dict[str, list[Projection]]) -> None:
    """A line-and-column chart takes its columns in Y and its line in Y2. Domo does not say which of the
    values is the line in the card definition; in the one rendered (a rate beside an amount) the first is
    the line and the others are columns, so that is the rule, and the chart_map note asks for a check."""
    values = buckets.get("Y") or []
    if visual_type in ("lineClusteredColumnComboChart", "lineStackedColumnComboChart") and len(values) >= 2:
        buckets["Y2"] = values[:1]
        buckets["Y"] = values[1:]


_DIMENSION_ROLES = ("Category", "Series", "Rows", "Columns")
_TEXT_COLUMN_TYPES = ("STRING", "TEXT")           # a column of unknown type is not flagged
_NUMERIC_AGGREGATIONS = ("SUM", "AVG", "AVERAGE", "MIN", "MAX")


def _lint_visuals(pages: list[Page], column_types: dict[str, dict[str, str]],
                  review_items: list[ReviewItem], warnings: list[str]) -> None:
    """Visuals Power BI will draw as an error, found before publishing (each was seen in the service:
    Clinic Collections - SW). A measure in a category/legend role, and a sum, average, min or max of a
    text column; the visual shows "Something's wrong with one or more fields"."""
    for page in pages:
        for visual in page.visuals:
            if visual.visual_type in ("slicer", "textbox") or not visual.origin or str(visual.origin).startswith("slicer:"):
                continue
            for role, fields in visual.buckets.items():
                for field in fields:
                    problem = None
                    if role in _DIMENSION_ROLES and field.kind in ("measure", "aggregation"):
                        problem = f"{field.name!r} is a measure in the {role} role, which takes columns only"
                    elif (field.kind == "aggregation" and (field.aggregation or "SUM").upper() in _NUMERIC_AGGREGATIONS
                          and column_types.get(field.table, {}).get(field.name) in _TEXT_COLUMN_TYPES):
                        problem = (f"{(field.aggregation or 'SUM').lower()} of the text column {field.name!r}: Power BI "
                                   "cannot aggregate text")
                    if problem:
                        warnings.append(f"{visual.title}: {problem}")
                        review_items.append(ReviewItem(
                            kind="visual_will_not_draw", severity="error",
                            title=f"{visual.title!r} will show a visual error in Power BI: {problem}",
                            source_type="card", source_id=str(visual.origin),
                            detail={"role": role, "field": field.name, "table": field.table},
                        ))


_DATE_COLUMN_TYPES = ("DATE", "DATETIME", "TIMESTAMP")

# Charts Domo draws with the value on each mark; a table, a card or a pie has its own way of showing numbers.
_LABELLED_CHARTS = {"clusteredBarChart", "clusteredColumnChart", "stackedBarChart", "stackedColumnChart",
                    "hundredPercentStackedBarChart", "hundredPercentStackedColumnChart", "lineChart"}
_LEGEND_POSITIONS = {"Bottom": "Bottom", "Right": "Right", "Top": "Top", "Left": "Left"}


def _chart_style(visual_type: str, style: dict | None) -> dict:
    """The Visual fields for how Domo draws a chart: data labels and legend position (`card_style`)."""
    style = style or {}
    cartesian = visual_type in _LABELLED_CHARTS
    legend = style.get("legend")
    return {"data_labels": bool(cartesian and style.get("data_labels", True)),
            "legend_position": "Hide" if legend == "Hide" else _LEGEND_POSITIONS.get(legend or "")}


def _measure_named(name: str, table_name: str, measure_table: dict[str, str], measures_of: dict[str, set[str]]) -> tuple[str, str] | None:
    """The model's measure a card's name stands for: the card's own table's when it has one (a measure defined for
    several tables is "<name> (<table>)" on all but the first), else whichever table defines the name."""
    own = f"{name} ({table_name})"
    if own in measures_of[table_name]:
        return table_name, own
    if name in measure_table:
        return measure_table[name], name
    return None


def _in_model_names(spec: dict | None, own_fields: dict[str, dict]) -> dict | None:
    """A card's sort or Top N with the order columns named as the model names them: a beast mode that had to be renamed
    ("Total Cost (calc)", "Rev (2)") is projected under its model name, so an order entry that says "Total Cost" found nothing."""
    if not spec or not spec.get("order_by") or not own_fields:
        return spec
    return {**spec, "order_by": [
        {**order, "column": own_fields[order["column"]]["name"]} if order.get("column") in own_fields else order
        for order in spec["order_by"]],
        # The Top N's group-by is read under Domo's name as well (a formulaId): the category it limits is projected under the model's.
        **({"group_by": [own_fields[g]["name"] if g in own_fields else g for g in spec["group_by"]]} if spec.get("group_by") else {})}


def _hidden_group_columns(card: dict, visual_type: str, buckets: dict[str, list[Projection]], table_name: str,
                          table_columns) -> list[dict]:
    """The columns a table card groups by without showing them, as the model names them ({table, column}). Domo lists one row
    per combination, so its rows are finer than the visual's; the model keeps the columns (they are not drawn) so that the
    parity check can ask for the rows at that grain. Only tables and pivots: a chart's hidden group-by is its order."""
    if visual_type not in ("tableEx", "pivotTable"):
        return []
    shown = {p.name.lower() for fields in buckets.values() for p in fields}
    found: list[dict] = []
    for name in (card.get("sort") or {}).get("group_by") or []:
        column = _fit_case(table_columns, name) if name else None
        if not column or column not in table_columns:
            return []                  # a group-by that is no column of this table (a calculation, another table): the grain cannot be reproduced
        if column.lower() not in shown and not any(k["column"] == column for k in found):
            found.append({"table": table_name, "column": column})
    return found


def _card_sort(sort: dict | None, buckets: dict[str, list[Projection]], table_columns) -> tuple[list, list[dict]]:
    """How Domo orders the card's rows, as (a visual sort, model sort keys).

    The first order entry decides. A field the visual shows is a visual sort (Power BI sorts by projected fields only).
    A column the visual does not show but groups by (a 'Day of Week Rank' beside 'Exam Day of Week') orders the category: the
    model sorts the category column by it, ascending only, for a single category column on a chart. Domo's other entries
    (a MIN of a date ordering the series) have no equivalent here and are left to Power BI's default."""
    if not sort or not sort.get("order_by"):
        return [], []
    shown = [p for fields in buckets.values() for p in fields]
    columns = {c.lower(): c for c in table_columns}
    first = sort["order_by"][0]
    direction = "Descending" if first["order"] == "DESCENDING" else "Ascending"
    for p in shown:
        if p.name.lower() != (first["column"] or "").lower():
            continue
        if p.kind == "column" and not first.get("aggregation"):
            return [(p, direction)], []
        if p.kind == "measure" or (p.kind == "aggregation" and (p.aggregation or "").upper() == (first.get("aggregation") or "").upper()):
            return [(p, direction)], []
    categories = [p for p in buckets.get("Category") or [] if p.kind == "column"]
    helper = columns.get((first["column"] or "").lower())
    if (len(categories) == 1 and len(sort.get("items") or []) == 1 and helper and not first.get("aggregation")
            and direction == "Ascending" and first["column"] in (sort.get("group_by") or [])
            and helper.lower() != categories[0].name.lower()):
        return [], [{"table": categories[0].table, "column": categories[0].name, "by": helper}]
    return [], []


def _apply_sort_keys(model: SemanticModel, report: Report) -> list[ReviewItem]:
    """Sort the model's category columns by the helper columns Domo orders them by (one helper per column)."""
    items: list[ReviewItem] = []
    tables = {t.name.lower(): t for t in model.tables}
    for page in report.pages:
        for visual in page.visuals:
            for key in visual.sort_keys:
                table = tables.get((key["table"] or "").lower())
                column = next((c for c in table.columns if c.name.lower() == key["column"].lower()), None) if table else None
                if column is None or not any(c.name.lower() == key["by"].lower() for c in table.columns):
                    continue
                if column.sort_by and column.sort_by.lower() != key["by"].lower():
                    items.append(ReviewItem(
                        kind="sort_order_conflict", severity="info",
                        title=f"{table.name}.{column.name}: cards order it by {column.sort_by!r} and by {key['by']!r}; "
                              f"the model sorts it by {column.sort_by!r} only",
                        source_type="card", source_id=str(visual.origin)))
                elif not column.sort_by:
                    column.sort_by = next(c.name for c in table.columns if c.name.lower() == key["by"].lower())
    return items


def _add_top_n(top: dict | None, mapped, table_name: str, table_columns, buckets: dict[str, list[Projection]],
               visual_filters: list[VisualFilter], review_items: list[ReviewItem], warnings: list[str]) -> None:
    """A Domo card limited to its first N rows by a sort ("Top 15 by Price Impact") as a Top N filter on the
    category. Expressible for one category column ordered by a value the visual shows (or a plain aggregate of a
    column); anything else is reported rather than silently showing every row."""
    if not top or not top.get("order_by"):
        return
    group_by = [g for g in top.get("group_by") or [] if g]
    shown = [p for role in ("Category", "Rows") for p in buckets.get(role) or [] if p.kind == "column"]
    if len(shown) > 1:
        categories = []         # (category, row) combinations are limited, not one column's values
    elif len(group_by) == 1:
        # The limit is over this column (a table card keeps every field in `Values`, a chart has a Category).
        categories = [p for fields in buckets.values() for p in fields
                      if p.kind == "column" and p.name.lower() == group_by[0].lower()][:1]
    elif not group_by:
        categories = shown
    else:
        categories = []
    order = top["order_by"][0]
    by = next((p for fields in buckets.values() for p in fields
               if p.kind in ("measure", "aggregation") and p.name.lower() == order["column"].lower()
               and (p.kind == "measure" or not order.get("aggregation")
                    or (p.aggregation or "").upper() == order["aggregation"].upper())), None)
    if by is None and order.get("aggregation") and order["column"] in table_columns:
        by = Projection(table_name, order["column"], "aggregation", aggregation=order["aggregation"])
    # The filter ranks the category's rows by a field read in the category's own table.
    foreign = by is not None and len(categories) == 1 and (by.table or table_name) != (categories[0].table or table_name)
    if len(categories) != 1 or by is None or foreign:
        why = (f"it limits {max(len(group_by), len(shown))} columns (Domo limits the combinations)"
               if len(group_by) > 1 or len(shown) > 1
               else "it limits no single column the visual shows" if len(categories) != 1
               else f"it is ordered by {order['column']!r}, which the model cannot rank by" if by is None
               else f"it is ordered by {order['column']!r} from another table than the category")
        warnings.append(f"{mapped.title}: Domo's limit of {top['limit']} rows is not applied; {why}")
        review_items.append(ReviewItem(
            kind="card_limit_not_applied", severity="warning",
            title=f"{mapped.title!r}: Domo shows the first {top['limit']} rows by {order['column']!r}; {why}, so the "
                  "visual shows every row",
            source_type="card", source_id=mapped.card_id))
        return
    category = categories[0]
    visual_filters.append(VisualFilter(
        table=category.table, column=category.name, kind="top_n", values=[],
        top_n={"limit": top["limit"], "descending": order["order"] != "ASCENDING",
               "by": {"table": by.table, "name": by.name, "kind": by.kind, "aggregation": by.aggregation}}))


def _add_date_range(saved: dict, mapped: Any, table_name: str, types: dict[str, str],
                    visual_filters: list[VisualFilter], review_items: list[ReviewItem],
                    warnings: list[str]) -> None:
    """A card's saved date range (a rolling 14 months, the current year...) as a relative date filter on the
    visual, or a review item saying why not. Without it Power BI shows every year (HCC - SW: 'Clinic
    Encounters - Current Year' counted 10x Domo's figures)."""
    spec = daterange.parse(saved)
    column = ((saved.get("column") or {}).get("column")) or ""
    if spec is not None:
        spec["column"] = _fit_case(types, spec["column"])      # Domo's 'Month Yr' is the table's 'month yr'
    if spec is None:
        reason = f"a {(saved.get('dateTimeRange') or {}).get('dateTimeRangeType') or 'unknown'} range this tool does not know"
    elif spec["column"] not in types:
        reason = f"{spec['column']!r} is not a column of {table_name!r}"
    elif types[spec["column"]] not in _DATE_COLUMN_TYPES:
        reason = f"{spec['column']!r} is {types[spec['column']] or 'text'}, not a date, in the model"
    else:
        reason = daterange.unsupported_reason(spec)
    if reason:
        what = daterange.describe(spec) if spec else column
        warnings.append(f"{mapped.title}: date range on {column!r} ({what}) is not applied: {reason}")
        review_items.append(ReviewItem(
            kind="card_date_range_not_applied", severity="warning",
            title=f"{mapped.title!r}: Domo limits it to {what} on {column!r}; not applied ({reason}), so the "
                  "visual shows more dates than Domo",
            source_type="card", source_id=mapped.card_id,
            detail={"date_range": saved},
        ))
        return
    visual_filters.append(VisualFilter(
        table=table_name, column=spec["column"], kind="date_range", values=[], date_range=spec))
    if saved.get("periods"):
        # Domo adds the previous period as a second row (`__domo_period`: "year over year" and the like);
        # the visual shows the current window only.
        review_items.append(ReviewItem(
            kind="card_period_comparison_not_migrated", severity="info",
            title=f"{mapped.title!r}: Domo compares {daterange.describe(spec)} with the period before it; the "
                  "visual shows the current period only",
            source_type="card", source_id=mapped.card_id, detail={"periods": saved["periods"]},
        ))


def _add_dashboard_filters(report: Report, raw_filters: list | None, tables: list[dict],
                           review_items: list[ReviewItem], warnings: list[str]) -> int:
    """Slicers on the pages that have visuals of the filtered table, plus
    report-level filters for saved values. Returns the number of slicers."""
    plan = dashboard_filters.plan_filters(raw_filters, tables)
    report.filters = [_with_held_blanks(f, tables) for f in plan.report_filters]
    unmapped = list(plan.unmapped)
    placed: set[tuple[str, str]] = set()
    count = 0
    for page in report.pages:
        page_tables = {p.table for v in page.visuals for fields in v.buckets.values() for p in fields}
        chosen = [s for s in plan.slicers if s.table in page_tables]
        if not chosen:
            continue
        per_row = max(1, int((PAGE_WIDTH - GUTTER) // (dashboard_filters.SLICER_WIDTH + dashboard_filters.SLICER_GAP)))
        rows = -(-len(chosen) // per_row)
        band = rows * (dashboard_filters.SLICER_HEIGHT + dashboard_filters.SLICER_GAP) + GUTTER
        for visual in page.visuals:
            visual.y += band
        page.height += band
        slicers = []
        for index, spec in enumerate(chosen):
            row, col = divmod(index, per_row)
            slicers.append(Visual(
                visual_type="slicer", title=spec.label,
                x=GUTTER / 2 + col * (dashboard_filters.SLICER_WIDTH + dashboard_filters.SLICER_GAP),
                y=GUTTER / 2 + row * (dashboard_filters.SLICER_HEIGHT + dashboard_filters.SLICER_GAP),
                width=dashboard_filters.SLICER_WIDTH, height=dashboard_filters.SLICER_HEIGHT,
                buckets={"Values": [Projection(spec.table, spec.column, "column")]},
                origin=f"slicer:{spec.sync_group}", slicer_mode=spec.mode, sync_group=spec.sync_group))
            placed.add((spec.table, spec.column))
            count += 1
        page.visuals = slicers + page.visuals
    for spec in plan.slicers:
        if (spec.table, spec.column) not in placed:
            unmapped.append((spec.label, f"no visual on any page reads table {spec.table!r}"))
    if unmapped:
        shown = "; ".join(f"{label} ({why})" for label, why in unmapped[:12])
        more = f" and {len(unmapped) - 12} more" if len(unmapped) > 12 else ""
        warnings.append(f"{len(unmapped)} dashboard filter(s) not carried: {shown}{more}")
        review_items.append(ReviewItem(
            kind="dashboard_filters_unmapped", severity="warn",
            title=f"{len(unmapped)} dashboard filter(s) have no Power BI equivalent",
            source_type="dashboard", source_id=None,
            detail={"filters": [{"label": label, "reason": why} for label, why in unmapped]}))
    return count


# Domo drill views that are tables. They become drillthrough pages; a chart
# view has no page equivalent and is a review item.
DRILL_TABLE_TYPES = frozenset({"badge_table", "badge_basic_table"})
# Roles of a parent visual whose first plain column is what a user clicks.
DRILL_PARENT_ROLES = ("Category", "Rows", "Values")


def _add_drillthrough_pages(report: Report, mapped_cards: list, tables: list[dict],
                            calculated_fields: list[dict], review_items: list[ReviewItem],
                            warnings: list[str], card_fields: dict[str, dict] | None = None) -> int:
    """Domo drill views of a card -> hidden drillthrough pages.

    A level-1 view that is a table becomes a page holding a table of the
    view's columns, filtered on the parent's category column when the user
    drills through from it. Everything else (chart views, deeper levels, a
    parent with no plain column to drill on, view columns the model lacks)
    is a review item, never dropped silently.
    """
    name_of_formula = {f.get("id"): f.get("name") for f in calculated_fields}
    card_fields = card_fields or {}
    count = 0
    for card, table_name, buckets in mapped_cards:
        views = card.get("drill_views") or []
        if not views:
            continue
        title = card.get("name") or "Untitled"
        table = next(t for t in tables if t["name"] == table_name)
        column_names = {c["name"] for c in table["columns"]}
        measure_names = {m["name"] for t in tables for m in t["measures"]}
        parent_column = next((p.name for role in DRILL_PARENT_ROLES for p in buckets.get(role, [])
                              if p.kind == "column" and p.name in column_names), None)

        def skip(view: dict, reason: str) -> None:
            warnings.append(f"{title}: drill view {view['id']} not carried: {reason}")
            review_items.append(ReviewItem(
                kind="drill_view_not_migrated", severity="warn",
                title=f"Drill view {view['title'] or view['id']!r} of card {title!r} not migrated: {reason}",
                source_type="card", source_id=str(card.get("id")),
                detail={"view": view["id"], "chart_type": view["chart_type"],
                        "level": view["level"], "reason": reason}))

        for view in views:
            if view["level"] > 1:
                skip(view, "deeper than the first drill level; a drillthrough page cannot chain from another")
            elif view["chart_type"] not in DRILL_TABLE_TYPES:
                skip(view, f"a {view['chart_type'] or 'unknown'} view has no drillthrough equivalent")
            elif parent_column is None:
                skip(view, "the card has no plain column to drill through on")
            else:
                projections, dropped = [], []
                own_fields = card_fields.get(str(card.get("id")), {})
                for column in view["columns"]:
                    name = column["name"] or name_of_formula.get(column["formula_id"])
                    if name in own_fields:
                        # The beast mode this card uses, under the name the model gave it.
                        bound = own_fields[name]
                        projections.append(Projection(bound["table"], bound["name"], bound["kind"]))
                    elif name in measure_names:
                        projections.append(Projection(table_name, name, "measure"))
                    elif name in column_names:
                        projections.append(Projection(
                            table_name, name, "aggregation" if column["aggregation"] else "column",
                            aggregation=column["aggregation"], display_name=column["alias"]))
                    else:
                        dropped.append(name or column["formula_id"] or "?")
                if not projections:
                    skip(view, "none of its columns are in the model")
                    continue
                if dropped:
                    warnings.append(f"{title}: drill view {view['id']} lost column(s) {dropped}")
                    review_items.append(ReviewItem(
                        kind="drill_view_columns_missing", severity="warn",
                        title=f"Drill table of card {title!r} lost {len(dropped)} column(s) not in the model",
                        source_type="card", source_id=str(card.get("id")),
                        detail={"view": view["id"], "columns": dropped}))
                label = view["title"] or f"{title} detail"
                page = Page(name=f"drill-{card.get('id')}-{view['id']}"[:50], display_name=f"Drill: {label}",
                            width=PAGE_WIDTH, height=720,
                            drillthrough=Drillthrough(table_name, parent_column))
                page.visuals.append(Visual(
                    visual_type="tableEx", title=label, x=GUTTER / 2, y=GUTTER / 2,
                    width=PAGE_WIDTH - GUTTER, height=720 - GUTTER,
                    buckets={"Values": projections}, origin=f"drill:{view['id']}"))
                report.pages.append(page)
                count += 1
    return count


def _page_height(positions: dict[str, dict[str, float]]) -> int:
    """Tall enough for the whole dashboard.

    A Domo dashboard scrolls and is often far taller than it is wide;
    squashing it into a 720pt page would overlap every visual, so the page
    grows instead and Power BI scrolls it.
    """
    if not positions:
        return 720
    bottom = max(box["y"] + box["height"] for box in positions.values())
    return int(max(720, bottom + GUTTER))


def _fallback_box(index: int) -> dict[str, float]:
    """Two-column grid, for cards the layout does not place."""
    column, row = index % 2, index // 2
    return {"x": column * PAGE_WIDTH / 2 + GUTTER / 2, "y": row * 320 + GUTTER / 2,
            "width": PAGE_WIDTH / 2 - GUTTER, "height": 320 - GUTTER}


# ---- write_pbip ---------------------------------------------------------


def _narrow_native_queries(ctx: RunContext, model: SemanticModel, removed: dict[str, list[str]]) -> int:
    """Re-point tables whose native query returns columns the model dropped.

    Only tables that lost columns need it, and only SQL sources: a navigation
    to a warehouse table already folds to the columns the model uses.
    """
    warehouse = (ctx.project.get("settings") or {}).get("warehouse") or {}
    host, database, port = warehouse.get("host"), warehouse.get("database"), warehouse.get("port", 5439)
    if not (host and database):
        return 0
    count = 0
    for table in model.tables:
        source = table.source
        if not (source and source.kind == "redshift_sql" and removed.get(table.name)):
            continue
        artefact = (source.detail or {}).get("artefact")
        columns = [c.name for c in table.columns if not c.expression]
        if not artefact or not columns:
            continue
        sql = (ctx.run_dir / "convert_dataflows" / artefact).read_text()
        statement = native_statement(sql)
        if (source.detail or {}).get("text_for_numbers"):
            statement = _numbers_from_text(statement, [tuple(c) for c in source.detail["text_for_numbers"]])
        source.m_expression = writer.redshift_m(host, port, database, writer.narrowed_statement(statement, columns))
        source.detail = {**source.detail, "columns": len(columns)}
        count += 1
    return count


TEXT_TYPE_CODE = 1043          # varchar in the Postgres wire protocol, which Redshift speaks
_SHAPED_KINDS = ("redshift_sql", "warehouse_table")
WIDTH_MIN_ROWS = int(os.environ.get("BIMCONTROL_WIDTH_MIN_ROWS", "1000000"))
# A table that would need several partitions to import is queried live instead: 20.7M x 77 imports in
# hours (5-12 min a partition), as DirectQuery it publishes in seconds and a total over all rows
# answers in 1-5 s (bimcontrol#144). BIMCONTROL_BIG_TABLES=import keeps the partitioned import.
BIG_TABLES_DIRECT_QUERY = os.environ.get("BIMCONTROL_BIG_TABLES", "directquery").lower() != "import"


def _measure_text_widths(ctx: RunContext, statement: str, columns: list[str]) -> dict[str, int]:
    """The longest value in each text column of `statement` (one pass over the query), or {}.

    Reads the warehouse, so a failure is not fatal: the table keeps the declared widths and the
    refresh may run out of memory, which the run reports.
    """
    warehouse = (ctx.project.get("settings") or {}).get("warehouse") or {}
    try:
        adapter = get_adapter(warehouse.get("key", "redshift"), warehouse)
        with adapter, adapter._cursor() as cursor:
            quoted = [f'"{c}"' for c in columns]
            cursor.execute(f"SELECT {', '.join(quoted)} FROM (\n{statement}\n) AS _model LIMIT 0")
            text = [c for c, d in zip(columns, cursor.description) if d.type_code == TEXT_TYPE_CODE]
            if not text:
                return {}
            longest = ", ".join(f'MAX(OCTET_LENGTH("{c}"))' for c in text)
            cursor.execute(f"SELECT {longest} FROM (\n{statement}\n) AS _model")
            row = cursor.fetchone()
    except WarehouseNotConfigured:
        raise
    except Exception as exc:  # noqa: BLE001 -- the message is the finding
        ctx.progress(f"could not measure the text columns ({_first_line(exc, 200)}); "
                     "keeping their declared widths")
        return {}
    return writer.text_widths({c: int(n or 0) for c, n in zip(text, row)})


REFRESH_ANCHOR = "_BIMControl refresh"


def _add_refresh_anchor(model: SemanticModel) -> bool:
    """A model whose tables are all queried live gets one hidden one-row imported table, when it has calculated columns.

    A calculated column of a DirectQuery table holds no data until the model has been refreshed once ("The expression
    referenced column ... which does not hold any data because it needs to be recalculated or refreshed"), and the
    service refuses to refresh a model with nothing to import (415). Published as a new item (#228) the model is born
    unrefreshed; the anchor table lets `publish_powerbi` refresh it (probe, 2026-10-19: with the anchor and a refresh
    every calculated column answers, without it none does, plain `a & b` included)."""
    live = [t for t in model.tables if t.source and t.source.direct_query]
    if not live or len(live) != len([t for t in model.tables if t.source]):
        return False
    if not any(c.expression is not None for t in live for c in t.columns):
        return False
    model.tables.append(Table(
        name=REFRESH_ANCHOR, hidden=True, columns=[Column(name="x", source_type="STRING", hidden=True)],
        source=DataSource(kind="inline", m_expression='let\n    Source = #table({"x"}, {{"a"}})\nin\n    Source'),
    ))
    return True


def _model_refers_to(model: SemanticModel, table: Table, column: str) -> bool:
    """Whether something in the model other than the visuals reads this column: a measure or calculated column
    expression, a sort key, a role's row filter (a loose test by name, as `prune` uses: a false yes only supplies a NULL column)."""
    token = f"[{column.lower()}]"
    for other in model.tables:
        if any(token in (m.expression or "").lower() for m in other.measures):
            return True
        if any(c.expression and token in c.expression.lower() for c in other.columns):
            return True
    if any((c.sort_by or "").lower() == column.lower() for c in table.columns):
        return True
    return any(token in str(f).lower() for role in model.roles for f in role.filters.values())


_NULL_TYPES = {"STRING": "VARCHAR(256)", "TEXT": "VARCHAR(256)", "LONG": "BIGINT", "DOUBLE": "DOUBLE PRECISION",
               "DECIMAL": "DOUBLE PRECISION", "DATE": "DATE", "DATETIME": "TIMESTAMP", "BOOLEAN": "BOOLEAN"}


def _warehouse_statement(source: DataSource) -> str:
    """The query a `warehouse_table` source reads: the table, with the columns the model needs and the table lacks
    supplied as NULL of Domo's type (see `_drop_columns_the_warehouse_table_lacks`)."""
    extra = source.detail.get("null_columns") or []
    ref = source.detail["table_ref"]
    if not extra:
        return f"SELECT * FROM {ref}"
    def one(name: Any, kind: Any) -> str:
        quoted = '"' + str(name).replace('"', '""') + '"'
        return f'CAST(NULL AS {_NULL_TYPES.get(str(kind).upper(), "VARCHAR(256)")}) AS {quoted}'

    supplied = ", ".join(one(name, kind) for name, kind in extra)
    return f"SELECT t.*, {supplied} FROM {ref} t"


def _drop_columns_the_warehouse_table_lacks(ctx: RunContext, model: SemanticModel, report: Report | None = None) -> list[ReviewItem]:
    """A table read straight from a warehouse table gets only the columns that table has.

    Domo's schema lists system columns of a dataflow's output (`_BATCH_LAST_RUN_`) that the table the converter resolved
    the dataset to does not carry. The model asked the warehouse for it and the refresh failed for the whole model:
    `column "_batch_last_run_" does not exist in _model` (customer - Holding, 0 of 20 cards compared, bimcontrol#335).
    A column nothing reads is left out of the model. One that a visual, measure, calculated column, sort key or role reads
    stays and is supplied as NULL by the query (a measure over it is blank, not an error that fails the model); a warning
    names it. Unknown (no credentials, the table cannot be described) leaves the table as it is."""
    warehouse = ((getattr(ctx, "project", None) or {}).get("settings") or {}).get("warehouse") or {}
    items: list[ReviewItem] = []
    tables = [t for t in model.tables if t.source and t.source.kind == "warehouse_table" and (t.source.detail or {}).get("table_ref")]
    if not tables or not warehouse.get("host"):
        return items
    in_report = prune.used_columns(model, report) if report is not None and model.tables else set()
    try:
        adapter = get_adapter(warehouse.get("key", "redshift"), warehouse)
        with adapter:
            for table in tables:
                ref = table.source.detail["table_ref"]
                described = adapter.describe_sql(f"SELECT * FROM {ref}") if hasattr(adapter, "describe_sql") else None
                if not described:
                    continue
                present = {name.lower() for name, _ in described}
                real = [c for c in table.columns if not c.expression]
                absent = [c for c in real if c.name.lower() not in present]
                if not absent or len(absent) == len(real):
                    continue                  # nothing missing, or the description does not look like this table at all
                needed = [c for c in absent if (table.name.lower(), c.name.lower()) in in_report or _model_refers_to(model, table, c.name)]
                gone = [c.name for c in absent if c not in needed]
                table.columns = [c for c in table.columns if c.name not in gone]
                if gone:
                    items.append(ReviewItem(
                        kind="column_not_in_warehouse_table", severity="warning",
                        title=f"{table.name!r}: {len(gone)} column(s) of Domo's schema are not in {ref} and nothing reads them, "
                              f"so they are left out of the model ({', '.join(gone[:6])}{', ...' if len(gone) > 6 else ''})",
                        source_type="dataset", source_id=table.origin,
                    ))
                if needed:
                    table.source.detail = {**table.source.detail, "null_columns": [[c.name, c.source_type] for c in needed]}
                    table.source.m_expression = writer.redshift_m(
                        warehouse["host"], warehouse.get("port", 5439), warehouse["database"], _warehouse_statement(table.source))
                    items.append(ReviewItem(
                        kind="column_supplied_as_null", severity="warning",
                        title=f"{table.name!r}: {', '.join(c.name for c in needed[:6])} {'is' if len(needed) == 1 else 'are'} in Domo's "
                              f"schema but not in {ref}, and the report or model reads {'it' if len(needed) == 1 else 'them'}; "
                              "supplied as NULL, so what reads it is blank",
                        source_type="dataset", source_id=table.origin, detail={"columns": [c.name for c in needed]},
                    ))
                ctx.progress(f"{table.name!r}: {len(gone)} column(s) left out and {len(needed)} supplied as NULL "
                             "(the warehouse table does not have them)")
    except WarehouseNotConfigured:
        return items
    except Exception as exc:  # noqa: BLE001 -- the model keeps its columns; the refresh will say what is wrong
        ctx.progress(f"could not check the warehouse tables' columns ({_first_line(exc, 160)})")
    return items


def _shape_big_tables(ctx: RunContext, model: SemanticModel) -> tuple[dict[str, int], list[ReviewItem]]:
    """Make the query of a big table something the service can load.

    A table of `WIDTH_MIN_ROWS` rows or more is built once in the warehouse (the model's columns
    only) and the model reads that table, not the dataflow's whole query. Loading through the
    query lost the service's connection on every partition of Revenue Trend-SW, where a
    partition of the same size read from a table loaded fine (probe models, bimcontrol#144).
    Text columns are re-declared at the width their data needs (`writer.text_widths`) and a
    table above `writer.PARTITION_CELLS` is split into hash partitions. Row counts come from the
    data plan: the dataset's own count, which for a dataflow output is what Domo last wrote.

    Returns ({table: partitions} for the tables that were split, review items).
    """
    split: dict[str, int] = {}
    items: list[ReviewItem] = []
    if not any(t.source and t.source.kind in _SHAPED_KINDS for t in model.tables):
        return split, items
    try:
        plan = ctx.read_json("plan_data", "data_plan.json")
    except FileNotFoundError:
        return split, items
    rows = {d["dataset_id"]: d.get("row_count") for d in plan.get("datasets") or []}
    warehouse = (ctx.project.get("settings") or {}).get("warehouse") or {}
    for table in model.tables:
        source = table.source
        count_rows = rows.get(table.origin) or 0
        if not (source and source.kind in _SHAPED_KINDS and warehouse.get("host")
                and count_rows >= WIDTH_MIN_ROWS):
            continue
        columns = [c.name for c in table.columns if not c.expression]
        if source.kind == "redshift_sql":
            artefact = (source.detail or {}).get("artefact")
            if not artefact:
                continue
            statement = native_statement((ctx.run_dir / "convert_dataflows" / artefact).read_text())
            if (source.detail or {}).get("text_for_numbers"):
                statement = _numbers_from_text(statement, [tuple(c) for c in source.detail["text_for_numbers"]])
        else:
            statement = _warehouse_statement(source)
        host, port, database = warehouse["host"], warehouse.get("port", 5439), warehouse["database"]

        live = BIG_TABLES_DIRECT_QUERY and writer.partition_count(count_rows, len(columns)) > 1
        shadows = []
        plain = statement                 # what the model reads if the table cannot be built (the shadow SQL is only for the build)
        if live:
            # a calculated column that reads a text column as a number cannot be computed live without a number made by the query
            shadows = directquery.number_shadows(
                dax._table_ref(table.name), [c.name for c in table.columns if c.name in columns and not c.expression
                                              and str(c.source_type).upper() in ("STRING", "TEXT")],
                [c.expression for c in table.columns if c.expression])
            taken = {c.name.lower() for c in table.columns}
            shadows = [c for c in shadows if directquery.number_shadow_name(c).lower() not in taken]   # a column of that name exists
        if shadows:
            statement = _with_number_columns(statement, shadows)
        built = _materialise_model_table(
            ctx, warehouse, table, statement, columns + [directquery.number_shadow_name(c) for c in shadows])
        if not built:
            statement = plain
        if built and live:
            schema, _, name = built.partition(".")
            source.m_expression = writer.redshift_table_m(host, port, database, schema, name)
            source.partitions = []
            source.direct_query = True
            source.detail = {**source.detail, "materialised_as": built, "direct_query": True}
            items.append(ReviewItem(
                kind="model_table_is_directquery", severity="warning",
                title=f"{table.name!r} ({count_rows:,} rows x {len(columns)} columns) is too big to import, so "
                      f"the model queries {built} in the warehouse live (DirectQuery). That table is a "
                      "snapshot built from the dataflow's SQL when this project was written; the report needs "
                      "the warehouse reachable with the stored credentials, and DAX that DirectQuery does not "
                      "support fails when a visual uses it.",
                source_type="dataset", source_id=table.origin,
            ))
            ctx.progress(f"{table.name!r}: {count_rows:,} rows x {len(columns)} columns is queried live (DirectQuery)")
            items += _make_columns_computable_live(ctx, table, shadows)
            continue
        if built:
            statement = f"SELECT * FROM {built}"
            source.detail = {**source.detail, "materialised_as": built}
            items.append(ReviewItem(
                kind="model_table_is_a_snapshot", severity="warning",
                title=f"{table.name!r} ({count_rows:,} rows) is read from {built}, built from the dataflow's "
                      "SQL when this project was written. A refresh of the model reloads that table; "
                      "rebuilding it from fresh source data means re-running the migration.",
                source_type="dataset", source_id=table.origin,
            ))
        widths = _measure_text_widths(ctx, statement, columns)
        if widths:
            ctx.progress(f"{table.name!r}: {len(widths)} text column(s) declared at the width their data needs")
        source.m_expression = writer.redshift_m(
            host, port, database, writer.narrowed_statement(statement, columns, widths))
        if widths:
            source.detail = {**source.detail, "text_columns_resized": len(widths)}
        count = writer.partition_count(count_rows, len(columns))
        if count < 2:
            continue
        source.partitions = [
            writer.redshift_m(host, port, database, sql)
            for sql in writer.partition_statements(statement, columns, count, widths)]
        source.detail = {**source.detail, "partitions": count}
        split[table.name] = count
        ctx.progress(f"{table.name!r}: {count_rows:,} rows x {len(columns)} columns "
                     f"is loaded as {count} partitions")
    return split, items


def _make_columns_computable_live(ctx: RunContext, table: Table, number_columns: list[str] = ()) -> list[ReviewItem]:
    """A calculated column of a DirectQuery table is computed by the warehouse, which cannot do
    FORMAT of a date: spell those with YEAR/MONTH/DAY/WEEKDAY. What still cannot be computed is
    reported, because every visual that uses that column fails."""
    items: list[ReviewItem] = []
    rewritten = 0
    for name in number_columns:                 # the table's query made these (see _shape_big_tables): hidden, read by the calculated columns
        table.columns.append(Column(name=directquery.number_shadow_name(name), source_type="DOUBLE", hidden=True,
                                    description=f"{name} read as a number (for the calculated columns of a DirectQuery table)"))
    for column in table.columns:
        if not column.expression:
            continue
        if number_columns:
            column.expression = directquery.use_number_shadows(column.expression, dax._table_ref(table.name), number_columns)
        folded = directquery.foldable_switch(directquery.foldable_dates(column.expression))
        if folded != column.expression:
            column.expression, rewritten = folded, rewritten + 1
        if directquery.still_needs_the_engine(column.expression):
            items.append(ReviewItem(
                kind="directquery_calculated_column", severity="warning",
                title=f"{table.name!r}: calculated column {column.name!r} uses FORMAT, which a DirectQuery "
                      "table cannot compute, so visuals that use it will fail",
                source_type="dataset", source_id=table.origin,
            ))
    if rewritten:
        ctx.progress(f"{table.name!r}: {rewritten} calculated column(s) spelled so the warehouse can compute them")
    return items


def _materialise_model_table(
    ctx: RunContext, warehouse: dict[str, Any], table: Table, statement: str, columns: list[str],
) -> str | None:
    """Build the model's columns of `statement` as a warehouse table; its reference, or None."""
    schema = warehouse.get("landing_schema") or "bimcontrol_landing"
    # One dataset is a table of several dashboards' models, each keeping the columns it reads: a name from the
    # dataset alone made the last dashboard's build replace the table under the others (Executive Summary-SW
    # failed to refresh after Accounts Payable-SW rebuilt the shared table without its columns).
    name = safe_table_name(table.name, f"{table.origin or table.name}|{','.join(sorted(columns))}", prefix="model_")
    # Domo compares and groups text without regard to case ('Lab Serology' and 'LAB SEROLOGY' are one value there, and
    # in the model's own engine). A table queried live is compared by Redshift, which is case-sensitive: Daily Revenue-
    # style filters `statname IN (..., 'LAB SEROLOGY', 'Lab Serology')` kept 4 of 44,528 rows. The text columns take the
    # warehouse's case-insensitive collation; if it refuses (a column that is not text after all) the table is built
    # without it.
    text = {c.name for c in table.columns if c.name in columns and not c.expression
            and str(c.source_type).upper() in ("STRING", "TEXT")}
    try:
        adapter = get_adapter(warehouse.get("key", "redshift"), warehouse)
        with adapter:
            if text and hasattr(adapter, "describe_sql"):
                # Domo calls a column text that the warehouse returns as a date or a number (Customer_Claims_Master v1):
                # COLLATE on it fails, and one such column cost the whole table the collation.
                described = adapter.describe_sql(statement)
                if described:
                    strings = {name.lower() for name, kind in described if kind == "STRING"}
                    text = {name for name in text if name.lower() in strings}
            try:
                ref = adapter.create_table_as(
                    schema, name, writer.narrowed_statement(statement, columns, case_insensitive=text), reuse_within=TABLE_REUSE)
            except Exception as exc:  # noqa: BLE001 -- the plain table is the fallback
                if not text:
                    raise
                ctx.progress(f"{table.name!r}: could not collate its text columns "
                             f"({_first_line(exc, 120)}); building the table as it is")
                ref = adapter.create_table_as(schema, name, writer.narrowed_statement(statement, columns), reuse_within=TABLE_REUSE)
            if ref in getattr(adapter, "reused_tables", []):
                ctx.progress(f"{table.name!r}: reusing {ref}, built from the same SQL and inputs")
            else:
                ctx.progress(f"{table.name!r}: built {ref}")
    except WarehouseNotConfigured:
        # No credentials is not a table that failed to build: publishing the dataflow's query over a model that has the
        # built table replaced three good Fabric models with unrefreshed ones (bimcontrol#296).
        raise
    except Exception as exc:  # noqa: BLE001 -- the message is the finding
        ctx.progress(f"{table.name!r}: could not build a table for the model "
                     f"({_first_line(exc, 200)}); the model keeps the dataflow's query")
        return None
    return ref


def write_pbip(ctx: RunContext) -> StageResult:
    model_payload = ctx.read_json("build_model", MODEL_FILE)
    report_payload = ctx.read_json("build_report", REPORT_FILE)

    model = SemanticModel(name=model_payload["name"], culture=model_payload["culture"])
    model.roles = [Role(name=r["name"], filters=r["filters"], origin=r.get("origin"),
                        description=r.get("description")) for r in model_payload.get("roles") or []]
    for table_payload in model_payload["tables"]:
        table = Table(name=table_payload["name"], origin=table_payload.get("origin"))
        table.columns = [Column(name=c["name"], source_type=c["source_type"],
                                origin=c.get("origin"), expression=c.get("expression"),
                                description=c.get("description"),
                                needs_review=c.get("needs_review", False),
                                sort_by=c.get("sort_by"), hidden=c.get("hidden", False))
                         for c in table_payload["columns"]]
        table.measures = [Measure(name=m["name"], expression=m["expression"],
                                  origin=m.get("origin"), description=m.get("description"),
                                  needs_review=m.get("needs_review", False))
                          for m in table_payload["measures"]]
        if table_payload.get("source"):
            table.source = DataSource(kind=table_payload["source"]["kind"],
                                      m_expression=table_payload["source"]["m"],
                                      detail=table_payload["source"].get("detail") or {})
        model.tables.append(table)

    report = Report(name=report_payload["name"])
    for page_payload in report_payload["pages"]:
        page = Page(name=page_payload["name"], display_name=page_payload["display_name"],
                    width=page_payload["width"], height=page_payload["height"],
                    drillthrough=Drillthrough(**page_payload["drillthrough"])
                    if page_payload.get("drillthrough") else None)
        for visual_payload in page_payload["visuals"]:
            page.visuals.append(Visual(
                visual_type=visual_payload["visual_type"], title=visual_payload["title"],
                x=visual_payload["x"], y=visual_payload["y"],
                width=visual_payload["width"], height=visual_payload["height"],
                buckets={
                    role: [Projection(p.get("table") or model.tables[0].name, p["name"], p["kind"],
                                      aggregation=p.get("aggregation"), display_name=p.get("display_name"))
                           for p in fields]
                    for role, fields in visual_payload["buckets"].items()
                },
                origin=visual_payload.get("origin"),
                filters=[VisualFilter(**f) for f in visual_payload.get("filters") or []],
                slicer_mode=visual_payload.get("slicer_mode"),
                sync_group=visual_payload.get("sync_group"),
                text=visual_payload.get("text"), text_size=visual_payload.get("text_size"),
                bold=visual_payload.get("bold", False),
                data_labels=visual_payload.get("data_labels", False),
                legend_position=visual_payload.get("legend_position"),
                sort=[(Projection(f.get("table") or model.tables[0].name, f["name"], f["kind"], aggregation=f.get("aggregation")),
                       entry["direction"]) for entry in visual_payload.get("sort") or [] for f in [entry["field"]]],
                sort_keys=visual_payload.get("sort_keys") or [],
                kept_columns=visual_payload.get("kept_columns") or [],
            ))
        report.pages.append(page)
    report.filters = [VisualFilter(**f) for f in report_payload.get("filters") or []]

    sort_items = _apply_sort_keys(model, report)
    removed = prune.prune_columns(model, report)
    dropped = sum(len(v) for v in removed.values())
    if dropped:
        ctx.progress(f"left {dropped} column(s) nothing reads out of the model")
        narrowed = _narrow_native_queries(ctx, model, removed)
        if narrowed:
            ctx.progress(f"narrowed {narrowed} native query(ies) to the columns the model keeps")

    absent_items = _drop_columns_the_warehouse_table_lacks(ctx, model, report)
    partitioned, shape_items = _shape_big_tables(ctx, model)
    shape_items = absent_items + shape_items
    _add_refresh_anchor(model)

    destination = ctx.stage_dir() / model.name
    files = writer.write_pbip(
        destination, model.name, model, report,
        description=source_description(ctx.source_object_id),
    )

    # Recorded as one artefact rather than several dozen: the project is
    # the deliverable, and the individual files only mean anything together.
    manifest = {
        "pbip": str((destination / f"{model.name}.pbip").relative_to(ctx.run_dir)),
        "files": [str(f.relative_to(ctx.run_dir)) for f in files],
        "open_with": "Power BI Desktop (Windows), or publish to a Fabric workspace",
        "partitioned": partitioned,
        # The service refuses to refresh a model with nothing to import (415 "Model-based dataset").
        "imported_tables": sum(1 for t in model.tables if not (t.source and t.source.direct_query)),
    }
    ctx.write_json("pbip_manifest.json", manifest, kind="pbip",
                   label=f"{model.name}.pbip ({len(files)} files)")
    ctx.progress(f"wrote {len(files)} file(s) to {destination.name}")

    return StageResult(review_items=shape_items + sort_items, summary={
        "files": len(files),
        "project": model.name,
        "visuals": sum(len(p.visuals) for p in report.pages),
        "columns_left_out": dropped,
    })


# ---- publish_powerbi ----------------------------------------------------


def publish_powerbi(ctx: RunContext) -> StageResult:
    """Publish the project into the target workspace.

    Skipped rather than failed when no workspace is configured: a PBIP on
    disk is a legitimate end state for a migration whose target is a file
    hand-off rather than a tenant.
    """
    from bimcontrol.targets.powerbi import fabric  # noqa: PLC0415 -- optional extra

    target = (ctx.project.get("settings") or {}).get("powerbi") or {}
    workspace = target.get("workspace")
    if not workspace:
        ctx.progress("no Power BI workspace configured, so the project was not published")
        return StageResult(summary={"published": False})

    manifest = ctx.read_json("write_pbip", "pbip_manifest.json")
    project_dir = (ctx.run_dir / manifest["pbip"]).parent

    published = fabric.publish_pbip(
        project_dir, workspace,
        on_progress=lambda message: ctx.progress(message),
    )
    ctx.write_json("published.json", published, kind="manifest", label="Published to Fabric")
    for item in published["items"]:
        ctx.progress(f"{item['action']} {item['type']} {item['name']!r}")
    if published.get("report_url"):
        ctx.progress(f"report: {published['report_url']}")

    summary = {
        "published": True,
        "workspace_id": published["workspace_id"],
        "report_url": published.get("report_url"),
        "items": len(published["items"]),
    }
    result = StageResult(summary=summary)
    _refresh_model(ctx, published, result)
    published["refreshed"] = result.summary.get("refreshed")
    ctx.write_json("published.json", published, kind="manifest", label="Published to Fabric")
    return result


REFRESH_PARALLELISM = int(os.environ.get("BIMCONTROL_REFRESH_PARALLELISM", "1"))


def _refresh_model(ctx: RunContext, published: dict[str, Any], result: StageResult) -> None:
    """Load the published model with data, so parity has something to read.

    An import-mode model arrives empty. Needs the warehouse user and the
    password from the environment; without them the model stays empty and
    the run says so rather than reporting numbers from nothing.
    """
    warehouse = (ctx.project.get("settings") or {}).get("warehouse") or {}
    user = warehouse.get("user")
    password = os.environ.get("REDSHIFT_PASSWORD") or warehouse.get("password")
    model_id = published.get("semantic_model_id")
    if not model_id:
        return
    if not (user and password):
        ctx.progress("no warehouse credentials in the environment, so the model was not refreshed")
        result.summary["refreshed"] = False
        return
    from bimcontrol.targets.powerbi import query  # noqa: PLC0415

    client = query.PowerBIQueryClient(allow_prompt=ctx.options.get("allow_prompt") is not False)
    ctx.progress("refreshing the published model")
    try:
        client.set_basic_credentials(published["workspace_id"], model_id, user, password)
        manifest = ctx.read_json("write_pbip", "pbip_manifest.json")
        if manifest.get("imported_tables") == 0:
            ctx.progress("every table is queried live (DirectQuery), so there is nothing to refresh")
            result.summary["refreshed"] = True
            return
        partitions = sum((manifest.get("partitioned") or {}).values())
        outcome = client.refresh(published["workspace_id"], model_id,
                                 **({"max_parallelism": REFRESH_PARALLELISM,
                                    "timeout_seconds": 2 * query.REFRESH_TIMEOUT_SECONDS} if partitions else {}))
    except query.PowerBIQueryError as exc:
        outcome = {"status": "Failed", "error": str(exc)}
    result.summary["refreshed"] = outcome["status"] == "Completed"
    if outcome["status"] == "Completed":
        ctx.progress("refresh completed")
        return
    message = f"Power BI could not refresh the model ({outcome['status']}): {outcome['error']}"
    result.warnings.append(message)
    result.review_items.append(ReviewItem(
        kind="model_refresh_failed", severity="error", title=message,
        source_type="dataset", source_id=model_id,
    ))

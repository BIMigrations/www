"""pywebview desktop shell: runs uvicorn in a background thread and opens a
native window pointed at it.

Same arrangement as EstateScanner: pywebview must own the main thread's
native GUI loop (macOS's Cocoa backend requires webview.start() to run
there), so uvicorn is what goes to a background thread. A window that cannot
open says why and falls back to the default browser.
"""

from __future__ import annotations

import socket
import sys
import threading
import time
import webbrowser
from pathlib import Path

import uvicorn

from .webapp.app import create_app


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _wait_for_socket(host: str, port: int, timeout: float = 10.0) -> None:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with socket.create_connection((host, port), timeout=0.5):
                return
        except OSError:
            time.sleep(0.1)
    raise TimeoutError(f"Server on {host}:{port} did not come up within {timeout}s")


def _native_backend() -> str:
    """Import the GUI backend pywebview would use here and return its name.
    Raises if it is missing, which is the usual reason a window does not open
    (Windows: pythonnet or the WebView2 runtime; macOS: pyobjc)."""
    try:
        import webview  # noqa: F401
    except ImportError as exc:
        raise ImportError("pywebview is not installed (pip install 'bimcontrol[ui]')") from exc

    module = {"win32": "webview.platforms.winforms", "darwin": "webview.platforms.cocoa"}.get(sys.platform)
    if module:
        import importlib

        importlib.import_module(module)
    return module or "default"


def _start_server(estate_db_path, db_path) -> tuple[uvicorn.Server, threading.Thread, int]:
    port = _free_port()
    app = create_app(estate_db_path=estate_db_path, db_path=db_path)
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning"))
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    _wait_for_socket("127.0.0.1", port)
    return server, thread, port


def check(estate_db_path: str | Path | None = None, db_path: str | Path | None = None) -> int:
    """Self-test used by CI and by support: does the server answer, and can a
    native window be opened on this machine? A missing window backend is a
    failure, not a silent fallback."""
    import urllib.request

    server, thread, port = _start_server(estate_db_path, db_path)
    try:
        # Generous: the first start after an install is slow (every new file is scanned), and a test that
        # fails on a healthy install is worse than one that waits.
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/", timeout=60) as resp:
            print(f"Server OK: GET / -> {resp.status}", flush=True)
    finally:
        server.should_exit = True
        thread.join(timeout=5)
    try:
        print(f"Native window OK: {_native_backend()}", flush=True)
    except Exception as exc:
        print(f"Native window unavailable: {exc!r}", flush=True)
        return 1
    return 0


def _serve_in_browser(server: uvicorn.Server, thread: threading.Thread, port: int) -> None:
    webbrowser.open(f"http://127.0.0.1:{port}/")
    print(f"BIMControl is running at http://127.0.0.1:{port}/ -- close this window to stop it.", flush=True)
    try:
        while thread.is_alive():
            thread.join(timeout=1)
    except KeyboardInterrupt:
        server.should_exit = True


def main(
    estate_db_path: str | Path | None = None,
    db_path: str | Path | None = None,
    browser: bool = False,
) -> None:
    server, thread, port = _start_server(estate_db_path, db_path)

    if not browser:
        try:
            _native_backend()
            import webview

            webview.create_window(
                "BIMControl", f"http://127.0.0.1:{port}/", width=1440, height=900, min_size=(1100, 720)
            )
            webview.start()  # blocks on the main thread until the window closes
        except Exception as exc:
            # Say why, so "it opened in my browser" is diagnosable rather than silent.
            print(f"Native window unavailable ({exc!r}); opening in your browser instead.", flush=True)
            browser = True
    if browser:
        _serve_in_browser(server, thread, port)

    server.should_exit = True
    thread.join(timeout=5)


if __name__ == "__main__":
    main()

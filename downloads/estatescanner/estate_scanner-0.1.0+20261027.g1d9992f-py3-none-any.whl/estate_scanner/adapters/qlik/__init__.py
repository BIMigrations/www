"""Stub registration for Qlik Sense/QlikView -- proves the plug-in pattern
works end-to-end without a real implementation yet. Registering this costs
nothing: the platform picker only shows this as "coming soon" and never
instantiates its authenticator/client.
"""

from estate_scanner.core.platform import PlatformAuthenticator, PlatformClient
from estate_scanner.core.registry import PlatformDescriptor, register_platform


class QlikAuthenticator(PlatformAuthenticator):
    platform = "qlik"


class QlikClient(PlatformClient):
    platform = "qlik"


register_platform(
    PlatformDescriptor(
        key="qlik", display_name="Qlik Sense", status="coming_soon",
        authenticator_cls=QlikAuthenticator, client_cls=QlikClient, auth_mode="unknown",
    )
)

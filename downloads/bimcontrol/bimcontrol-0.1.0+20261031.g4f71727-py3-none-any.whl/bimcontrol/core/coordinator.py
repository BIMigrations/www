"""Where a worker gets its work from.

Solo today: `LocalCoordinator` reads units out of the local control
database, and "claiming" one is just marking it. The interface exists so
the swarm version is an implementation rather than a rewrite -- a
`RemoteCoordinator` will lease units from the cloud control plane over
HTTPS and push events up, and the engine will not know the difference.

Leases are the part worth getting right early. A claimed unit carries an
owner and an expiry, so a unit held by a worker that died is reclaimable
instead of stuck. That matters even solo: a killed process leaves units
marked `running` that nothing will ever finish.
"""

from __future__ import annotations

import datetime as _dt
from typing import Any, Protocol

from bimcontrol.core.engine import worker_id
from bimcontrol.storage import db

# Long enough to outlive a slow stage's heartbeat gap, short enough that a
# dead worker's units come back within a coffee break.
DEFAULT_LEASE_SECONDS = 900


class Coordinator(Protocol):
    """How a worker gets work and reports on it."""

    def claim_next_unit(self, project_id: str) -> dict[str, Any] | None:
        """The next unit this worker should migrate, leased to it."""

    def renew_lease(self, unit_id: str) -> None:
        ...

    def release_unit(self, unit_id: str, status: str) -> None:
        ...


def _expiry(seconds: int = DEFAULT_LEASE_SECONDS) -> str:
    return (_dt.datetime.now(_dt.timezone.utc) + _dt.timedelta(seconds=seconds)).isoformat()


class LocalCoordinator:
    """Single node, local control database, no network."""

    def __init__(self, conn, lease_seconds: int = DEFAULT_LEASE_SECONDS):
        self.conn = conn
        self.lease_seconds = lease_seconds
        self.worker_id = worker_id()

    def claim_next_unit(self, project_id: str) -> dict[str, Any] | None:
        """Claim the oldest pending unit, or one whose lease has expired.

        The UPDATE ... WHERE covers the claim condition again so two workers
        racing for the same unit cannot both win: the second one updates
        zero rows and moves on.
        """
        now = db.now()
        row = self.conn.execute(
            "SELECT * FROM migration_units WHERE project_id = ?"
            "   AND (status = 'pending'"
            "        OR (status = 'running' AND (lease_expires_at IS NULL OR lease_expires_at < ?)))"
            " ORDER BY created_at LIMIT 1",
            (project_id, now),
        ).fetchone()
        if row is None:
            return None

        cursor = self.conn.execute(
            "UPDATE migration_units SET status = 'running', lease_owner = ?, lease_expires_at = ?,"
            " updated_at = ? WHERE id = ?"
            "   AND (status = 'pending'"
            "        OR (status = 'running' AND (lease_expires_at IS NULL OR lease_expires_at < ?)))",
            (self.worker_id, _expiry(self.lease_seconds), now, row["id"], now),
        )
        self.conn.commit()
        if cursor.rowcount == 0:
            return None  # somebody else took it between the select and the update
        return db.get_unit(self.conn, row["id"])

    def renew_lease(self, unit_id: str) -> None:
        self.conn.execute(
            "UPDATE migration_units SET lease_expires_at = ?, updated_at = ? WHERE id = ?",
            (_expiry(self.lease_seconds), db.now(), unit_id),
        )
        self.conn.commit()

    def release_unit(self, unit_id: str, status: str) -> None:
        self.conn.execute(
            "UPDATE migration_units SET status = ?, lease_owner = NULL, lease_expires_at = NULL,"
            " updated_at = ? WHERE id = ?",
            (status, db.now(), unit_id),
        )
        self.conn.commit()

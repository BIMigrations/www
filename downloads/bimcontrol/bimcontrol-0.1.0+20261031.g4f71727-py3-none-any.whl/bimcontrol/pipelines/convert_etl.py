"""Converting the source platform's ETL into warehouse SQL.

Hands each Magic ETL dataflow in the closure to the external converter,
having first told it where the landed tables are, and keeps the SQL it
gets back as an artefact.

Then it asks the warehouse whether the SQL is actually runnable. That
check earns its place: on the first live run the converter reported no
unsupported tiles and no unresolved sources, and the SQL it produced was
still rejected by Redshift, because a UNION of inputs with different
column sets cannot be written as `SELECT *`. A converter can only see the
tile graph; only the warehouse knows whether the result will run.

Anything the converter had an LLM translate becomes a review item rather
than passing silently. A formula that was guessed at is exactly the thing
a human should look at before a report built on it goes to a customer.
"""

from __future__ import annotations

import datetime as _dt
import os
import re
import time
from typing import Any

from bimcontrol.converters.domo_etl import ConverterError, DomoEtlConverterClient
from bimcontrol.core.engine import ReviewItem, RunContext, StageResult
from bimcontrol.pipelines import drift, repair_sql, stage_sql, unique_ties
from bimcontrol.pipelines.data_plan import LANDINGS_FILE, PLAN_FILE
from bimcontrol.storage import db
from bimcontrol.warehouses import get_adapter, safe_table_name, validation_cache

CONVERSION_FILE = "conversion.json"
PROGRESS_FILE = "conversion_progress.json"
# A table staged or published here is reused when rebuilding would produce the same table: staging
# the customer Daily Charge dataflow takes 25-45 minutes (bimcontrol#80). Older ones are snapshots
# too stale to trust, so they are rebuilt.
TABLE_REUSE = _dt.timedelta(hours=24)


def _client(ctx: RunContext) -> DomoEtlConverterClient:
    """The converter client, or a test's stand-in.

    The URL has to be configured on the project. There is deliberately no
    localhost default: a migration silently reaching whatever happens to
    be listening on 8822 is how a run ends up converted against the wrong
    Domo instance.
    """
    override = ctx.options.get("converter")
    if override is not None:
        return override
    settings = (ctx.project.get("settings") or {}).get("converters") or {}
    base_url = settings.get("domo_etl")
    if not base_url:
        raise ConverterError(
            "No Domo ETL converter configured for this project. Set one with:\n"
            "  bimcontrol converter --url http://localhost:8822"
        )
    return DomoEtlConverterClient(base_url)


def _session_lapsed(exc: Exception) -> bool:
    """Whether the converter failed for want of a Domo session. A job reports it as 'Not signed in to Domo.' (Worked RVU's
    by Posting Date: one dataflow failed that way, the table it feeds was written empty and 57,000 figures 'differed')."""
    text = str(exc).lower()
    return "session expired" in text or "session has expired" in text or "not signed in to domo" in text


def _ensure_signed_in(ctx: RunContext, client) -> dict[str, Any]:
    """Make sure the converter has a usable Domo session, lending it ours.

    The converter keeps its own session and it expires on its own
    schedule, which stopped a run mid-conversion more than once. BIMControl
    already holds a live session for the exports, so the fix is to hand it
    over rather than ask a human to sign the other tool in.
    """
    health = client.health()
    if health.get("ok"):
        return health

    status = (health.get("status") or "").lower()
    if status not in ("expired", "signedout", "failed") and not health.get("error"):
        raise ConverterError(f"The Domo ETL converter is not ready: {health.get('status')}")

    session = ctx.options.get("domo_session")
    if session is None:
        from bimcontrol.sources.domo import login  # noqa: PLC0415

        try:
            session = login.get_session(
                ctx.project.get("source_instance"),
                allow_prompt=ctx.options.get("allow_prompt"),
            )
        except Exception as exc:
            raise ConverterError(
                f"The converter's Domo session has expired ({health.get('status')}) and "
                f"BIMControl has no session to lend it: {exc}"
            ) from exc

    ctx.progress("converter session expired; handing over BIMControl's own")
    client.sign_in_with_cookies(session.cookies)
    health = client.health()
    if not health.get("ok"):
        raise ConverterError(
            f"Handed the converter a Domo session and it is still not ready: "
            f"{health.get('error') or health.get('status')}"
        )
    return health


# Magic ETL and Domo's older "etl" flows share the action JSON the converter reads.
CONVERTIBLE_ENGINES = ("magic", "etl")


def _in_dependency_order(flows: list[dict[str, Any]], producer: dict[str, Any]) -> list[dict[str, Any]]:
    """Dataflows ordered so each comes after the ones whose output it reads.

    `producer` maps a dataset id to the id of the dataflow that makes it.
    Ties keep the closure's order; a cycle (which Domo does not allow, but
    a scan could in principle describe) is broken by taking what is left in
    closure order rather than looping forever.
    """
    by_id = {str(f["id"]): f for f in flows}
    upstream = {
        fid: {str(producer[d]) for d in (f.get("input_dataset_ids") or [])
              if d in producer and str(producer[d]) in by_id and str(producer[d]) != fid}
        for fid, f in by_id.items()
    }
    ordered: list[dict[str, Any]] = []
    done: set[str] = set()
    remaining = list(by_id)
    while remaining:
        ready = [fid for fid in remaining if upstream[fid] <= done] or remaining[:1]
        fid = ready[0]
        remaining.remove(fid)
        done.add(fid)
        ordered.append(by_id[fid])
    return ordered


def _materialise_outputs(
    ctx: RunContext, flow: dict[str, Any], scripts: list[dict[str, Any]],
    wanted: set[str], schema: str, resolutions: dict[str, str],
    review_items: list[ReviewItem], warnings: list[str],
) -> None:
    """Build outputs that a later dataflow reads as tables, and say so.

    The converter can only name a table for an input; it cannot make one.
    A dataflow reading another's output therefore needs that output to
    exist in the warehouse under a name it can be told. A table, not a view:
    Redshift inlines a view into every query that reads it, and a dataflow
    reading three or four such views (each a long CTE chain) defeated the
    planner ("correlated subquery pattern is not supported", bimcontrol#69).
    The table is a snapshot from this run.
    """
    warehouse_settings = (ctx.project.get("settings") or {}).get("warehouse") or {}
    for script in scripts:
        data_source_id = script.get("data_source_id")
        if data_source_id not in wanted:
            continue
        if not warehouse_settings.get("host"):
            warnings.append(
                f"{script['destination_name']}: feeds another dataflow but no warehouse is "
                "configured to hold it, so that dataflow cannot be converted"
            )
            continue
        name = safe_table_name(script["destination_name"], data_source_id, prefix="flow_")
        sql = (ctx.stage_dir() / script["artefact"]).read_text()
        try:
            adapter = get_adapter(warehouse_settings.get("key", "redshift"), warehouse_settings)
            with adapter:
                ref = adapter.create_table_as(schema, name, sql, reuse_within=TABLE_REUSE)
                if ref in getattr(adapter, "reused_tables", []):
                    ctx.progress(f"  {script['destination_name']}: reusing {ref}, built from the same SQL and inputs")
        except Exception as exc:  # noqa: BLE001 -- the message is the finding
            message = str(exc).strip().splitlines()[0][:300]
            warnings.append(f"{script['destination_name']}: could not publish for later dataflows: {message}")
            script["materialisation_error"] = message
            review_items.append(ReviewItem(
                kind="dataflow_output_not_materialised", severity="error",
                title=f"{flow['name']}: output {script['destination_name']!r} could not be created "
                      f"in the warehouse, so dataflows reading it have no input: {message}",
                source_type="dataflow", source_id=str(flow["id"]),
            ))
            continue
        resolutions[data_source_id] = ref
        script["materialised_as"] = ref
        ctx.progress(f"  {script['destination_name']}: built as table {ref} for later dataflows")


def _run_started(ctx: RunContext) -> _dt.datetime | None:
    """When this run first started, naive UTC: a resumed run keeps its row."""
    row = db.get_run(ctx.conn, ctx.run_id)
    try:
        started = _dt.datetime.fromisoformat(row["started_at"])
    except (TypeError, KeyError, ValueError):
        return None
    if started.tzinfo is not None:
        started = started.astimezone(_dt.timezone.utc).replace(tzinfo=None)
    return started


def _fold_mixed_case_sources(
    ctx: RunContext, plan: dict[str, Any], resolutions: dict[str, str], schema: str,
    review_items: list[ReviewItem],
) -> None:
    """Give a warehouse table a copy with lower-case column names and empty text as null.

    A connector dataset can read a view with a column called "Dept Name"
    (Revenue Impact, dataflow 1951). Redshift folds the quoted name the
    converted SQL uses to "dept name", which that view does not have, so the
    dataflow is rejected and the model cannot refresh. The copy is a snapshot
    from this run, like the other tables this stage builds.

    Every such table is copied, mixed case or not: Domo reads an empty string from a
    connector as null, and the dataflows' null tests and joins on the source answer
    only on a copy that does the same (Claims Master: 648,534 empty CPT codes where
    Domo has nulls, so the self-pay rows, keyed on a null CPT code, were not found).
    """
    warehouse_settings = (ctx.project.get("settings") or {}).get("warehouse") or {}
    if not warehouse_settings.get("host"):
        return
    run_started = _run_started(ctx)
    for dataset in plan["datasets"]:
        source = resolutions.get(dataset["dataset_id"])
        if dataset["strategy"] != "warehouse_table" or not source:
            continue
        # src_, not fold_: a fold_ table from an earlier run holds the rows as the warehouse has them.
        name = safe_table_name(dataset.get("name") or source, dataset["dataset_id"], prefix="src_")
        try:
            adapter = get_adapter(warehouse_settings.get("key", "redshift"), warehouse_settings)
            with adapter:
                copy = adapter.lowercase_copy(source, schema, name, reuse_since=run_started, reuse_within=TABLE_REUSE)
        except Exception as exc:  # noqa: BLE001 -- the dataflow will fail loudly on its own
            ctx.progress(f"{dataset.get('name') or source}: could not check its columns: "
                         f"{str(exc).strip().splitlines()[0][:200]}")
            continue
        if copy:
            resolutions[dataset["dataset_id"]] = copy
            ctx.progress(f"{dataset.get('name') or source}: copied to {copy} (lower-case column names, empty text as null, as Domo reads it)")
            review_items.append(ReviewItem(
                kind="warehouse_table_snapshot", severity="info",
                title=f"{dataset.get('name') or source!r} ({source}) is read through a copy, {copy}: Domo reads an "
                      "empty string from a connector as null, and the converted SQL addresses columns in "
                      "lower case. It is a snapshot from this run and needs to be rebuilt when the source changes",
                source_type="dataset", source_id=dataset["dataset_id"],
            ))


def _empty_text_as_null(ctx: RunContext, output: Any) -> str:
    """The output's SQL with empty text as null: Domo stores no empty string, so a dataflow reading this output
    (and a card reading it) tests and groups on null where the converted SQL has ''."""
    warehouse_settings = (ctx.project.get("settings") or {}).get("warehouse") or {}
    if not warehouse_settings.get("host"):
        return output.sql
    try:
        adapter = get_adapter(warehouse_settings.get("key", "redshift"), warehouse_settings)
        with adapter:
            return adapter.empty_text_as_null(output.sql) or output.sql
    except Exception as exc:  # noqa: BLE001 -- the output is then as the converter wrote it
        ctx.progress(f"  {output.destination_name}: could not read its column types: {str(exc).strip().splitlines()[0][:200]}")
        return output.sql


def _stage_deep_sql(
    ctx: RunContext, flow: dict[str, Any], output: Any, filename: str, schema: str,
    review_items: list[ReviewItem],
) -> str:
    """Split a script too deep for the warehouse's planner into staged tables (stage_sql)."""
    warehouse_settings = (ctx.project.get("settings") or {}).get("warehouse") or {}
    if not warehouse_settings.get("host") or not stage_sql.needs_staging(output.sql):
        return output.sql
    base = safe_table_name(f"{output.destination_name}", output.data_source_id or output.cte_name, prefix="stage_")
    adapter = get_adapter(warehouse_settings.get("key", "redshift"), warehouse_settings)
    try:
        with adapter:
            staged, tables = stage_sql.stage(
                output.sql, lambda name, select: adapter.create_table_as(schema, name, select, reuse_within=TABLE_REUSE), base,
            )
    except Exception as exc:  # noqa: BLE001 -- the message is the finding
        message = str(exc).strip().splitlines()[0][:300]
        ctx.progress(f"  {output.destination_name}: could not stage the SQL: {message}")
        return output.sql
    ctx.write_text(
        filename.replace(".sql", ".full.sql"), output.sql, kind="sql",
        label=f"{output.destination_name} before staging", media_type="application/sql",
    )
    reused = [t for t in tables if t in getattr(adapter, "reused_tables", [])]
    ctx.progress(f"  {output.destination_name}: too deep for the warehouse to plan; staged through "
                 f"{len(tables)} table(s)" + (f", {len(reused)} reused from an earlier pass" if reused else ""))
    review_items.append(ReviewItem(
        kind="staged_dataflow", severity="info",
        title=f"{flow['name']}: {output.destination_name!r} has more steps than the warehouse can plan in one "
              f"statement, so {len(tables)} intermediate table(s) were built in {schema}. They are a snapshot "
              "from this run and need to be rebuilt when the sources change",
        source_type="dataflow", source_id=str(flow["id"]),
        detail={"tables": tables},
    ))
    return staged


def convert_dataflows(ctx: RunContext) -> StageResult:
    closure = ctx.read_json("resolve_closure", "closure.json")
    plan = ctx.read_json("plan_data", PLAN_FILE)
    landings = ctx.read_json("land_source_data", LANDINGS_FILE)

    magic = [f for f in closure["dataflows"] if (f.get("engine") or "").lower() in CONVERTIBLE_ENGINES]
    other = [f for f in closure["dataflows"] if f not in magic]

    review_items: list[ReviewItem] = []
    warnings: list[str] = []
    # A flow that cannot run (a loaded dataset is gone, or Domo switched the flow off) had its output landed from Domo
    # instead (plan_data), and whatever reads it already finds that table among the resolutions.
    snapshotted = {str(d["produced_by"]) for d in plan["datasets"] if d.get("snapshot_of_unrunnable_flow")}
    snapshotted |= {str(f) for f in landings.get("snapshot_flows") or []}
    for flow in [f for f in other if str(f["id"]) not in snapshotted]:
        review_items.append(
            ReviewItem(
                kind="unconvertible_dataflow",
                severity="error",
                title=f"Dataflow {flow['name']!r} is a {flow.get('engine')} flow, which the converter does not handle",
                source_type="dataflow",
                source_id=flow["id"],
            )
        )

    for flow in [f for f in magic if str(f["id"]) in snapshotted]:
        ctx.progress(f"{flow['name']!r} (dataflow {flow['id']}): not converted, its output is a landed snapshot")
    magic = [f for f in magic if str(f["id"]) not in snapshotted]

    if not magic:
        ctx.progress("No Magic ETL dataflows in this closure")
        ctx.write_json(CONVERSION_FILE, {"dataflows": []}, kind="manifest",
                       label="Conversion summary")
        return StageResult(summary={"dataflows": 0}, review_items=review_items)

    # Where every input the converter needs now lives: the tables we landed,
    # plus datasets that were already sitting in the warehouse.
    resolutions = {l["dataset_id"]: l["table_ref"] for l in landings.get("landings", [])}
    for dataset in plan["datasets"]:
        if dataset["strategy"] == "warehouse_table" and dataset.get("warehouse_table"):
            resolutions[dataset["dataset_id"]] = dataset["warehouse_table"]

    # Dataflows that read other dataflows' output go after them, and the
    # outputs they read are published to the warehouse as they appear.
    producer = {d["dataset_id"]: d["produced_by"] for d in plan["datasets"] if d.get("produced_by")}
    magic = _in_dependency_order(magic, producer)
    consumed = {d for f in magic for d in (f.get("input_dataset_ids") or []) if d in producer}
    schema = plan.get("landing_schema") or "bimcontrol_landing"

    client = _client(ctx)
    # A table landed anew has a column the converter's cached schema of it lacks (the row-order column). Every landed
    # input is sent again, also one found already landed: an earlier attempt of this run, or another lane, landed it.
    client.resend_resolutions({l["dataset_id"] for l in landings.get("landings", [])})
    health = _ensure_signed_in(ctx, client)
    ctx.progress(f"converter ready at {health['base_url']} ({health.get('instance')})")

    # A dataset fed by a warehouse connector already has a table; the scan
    # does not record which, but the converter can read it from the
    # connector's configured query.
    for dataset in plan["datasets"]:
        if dataset["strategy"] != "warehouse_table" or dataset["dataset_id"] in resolutions:
            continue
        try:
            found = client.detect_source(dataset["dataset_id"])
        except ConverterError as exc:
            found = {"detail": str(exc)}
        table = found.get("suggestedResolution")
        if table:
            resolutions[dataset["dataset_id"]] = table
            ctx.progress(f"{dataset['name']}: reads {table} in the warehouse")
        else:
            review_items.append(ReviewItem(
                kind="warehouse_table_unknown", severity="error",
                title=f"{dataset['name']!r} is fed by a warehouse connector but its table "
                      f"could not be found: {found.get('detail') or 'no detail'}",
                source_type="dataset", source_id=dataset["dataset_id"],
            ))

    _fold_mixed_case_sources(ctx, plan, resolutions, schema, review_items)

    planned = {d["dataset_id"]: d for d in plan["datasets"]}
    flow_names = {str(f["id"]): f["name"] for f in closure["dataflows"]}
    converted: list[dict[str, Any]] = []
    warehouse_settings = (ctx.project.get("settings") or {}).get("warehouse") or {}
    validator = None
    input_rows: list[dict[str, Any]] = []
    if warehouse_settings.get("host"):
        validator = get_adapter(warehouse_settings.get("key", "redshift"), warehouse_settings)
        validator.connect()
    else:
        ctx.progress("no warehouse configured, so the SQL was not checked against one")
    try:
        _convert_each(ctx, client, magic, converted, resolutions, consumed, schema, planned, flow_names,
                      validator, review_items, warnings)
        if validator is not None:
            input_rows = _warehouse_inputs(validator, plan, resolutions)
    finally:
        if validator is not None:
            validator.close()

    ctx.write_json(
        CONVERSION_FILE,
        {"dataflows": converted, "resolutions": resolutions, "validated": validator is not None,
         "input_rows": input_rows},
        kind="manifest", label="Conversion summary",
    )
    return StageResult(
        summary={
            "dataflows": len(converted),
            "outputs": sum(len(c["outputs"]) for c in converted),
            "validated": validator is not None,
        },
        warnings=warnings,
        review_items=review_items,
    )


def _warehouse_inputs(warehouse, plan: dict[str, Any], resolutions: dict[str, str]) -> list[dict[str, Any]]:
    """The row count of every warehouse table the flows read, beside the count the scan recorded for the Domo dataset.

    A dataset fed by a connector is an import: Domo's copy is as old as its last import and the converted flows read the
    live table, so every figure built on a table that gained rows after the import differs (Clinic AR Balance - SW,
    2026-10-25: 142,376 rows posted after Domo's import). Only inputs of strategy `warehouse_table` are listed (a landed
    copy is Domo's own rows). verify_parity sets these counts against what Domo holds when it compares; a count that
    cannot be read is simply not listed."""
    found = []
    for dataset in plan["datasets"]:
        table_ref = resolutions.get(dataset["dataset_id"])
        if dataset.get("strategy") != "warehouse_table" or not table_ref:
            continue
        table_schema, _, table = table_ref.rpartition(".")
        try:
            live = int(warehouse.row_count(table_schema, table))
        except Exception:  # noqa: BLE001 -- no count is not evidence
            continue
        found.append({"dataset_id": dataset["dataset_id"], "dataset": dataset.get("name"), "scan_rows": dataset.get("row_count"),
                      "warehouse_rows": live})
    return found


def _convert_each(
    ctx: RunContext, client, magic: list[dict[str, Any]], converted: list[dict[str, Any]],
    resolutions: dict[str, str], consumed: set[str], schema: str, planned: dict[str, dict[str, Any]],
    flow_names: dict[str, str], validator, review_items: list[ReviewItem], warnings: list[str],
) -> None:
    unique_deadline = time.monotonic() + UNIQUE_TIES_BUDGET
    for index, flow in enumerate(magic, start=1):
        ctx.check_cancelled()
        ctx.progress(f"[{index}/{len(magic)}] converting {flow['name']!r} (dataflow {flow['id']})")
        def convert(flow=flow):
            return client.convert(
                flow["id"], resolutions=resolutions, force=True,
                on_progress=lambda message, f=flow: ctx.progress(f"  {f['name']}: {message}"),
            )

        failure: ConverterError | None = None
        try:
            result = convert()
        except ConverterError as exc:
            failure = exc
            # A session can expire between the health check and the job,
            # on a conversion that takes minutes. Lend it ours and retry
            # once rather than losing the whole run.
            if _session_lapsed(exc):
                _ensure_signed_in(ctx, client)
                try:
                    result, failure = convert(), None
                except ConverterError as again:
                    failure = again
        if failure is not None:
            if _session_lapsed(failure):
                raise failure
            # One dataflow the converter cannot do must not lose the other 178 of a three-hour
            # run: record why and go on (bimcontrol#124). Whatever reads its output reports its own gap.
            message = str(failure).strip().splitlines()[0][:500]
            ctx.progress(f"  {flow['name']}: conversion failed: {message}")
            review_items.append(ReviewItem(
                kind="dataflow_conversion_failed", severity="error",
                title=f"{flow['name']}: the converter failed: {message}",
                source_type="dataflow", source_id=str(flow["id"]),
            ))
            converted.append({
                "dataflow_id": flow["id"], "name": flow["name"], "outputs": [],
                "unsupported_tile_types": [], "unresolved_sources": [],
                "tiles_with_warnings": 0, "repairs": [], "error": message,
            })
            _write_progress(ctx, converted, len(magic))
            continue

        _stop_if_scan_is_older_than_the_flow(ctx, flow, result.unresolved_sources, planned)

        # The converter keeps what its agent fixed, so reading it back needs no new translation (2 s, not 90).
        reread = lambda flow=flow: client.convert(flow["id"], resolutions=resolutions, force=False)  # noqa: E731
        result, repairs = _repair(ctx, client, flow, result, reread, review_items)

        scripts = []
        for output in result.outputs:
            filename = f"dataflow_{flow['id']}_{(output.data_source_id or output.cte_name)}.sql"
            output.sql = _stage_deep_sql(ctx, flow, output, filename, schema, review_items)
            output.sql = _empty_text_as_null(ctx, output)
            ctx.write_text(
                filename, output.sql, kind="sql",
                label=f"{output.destination_name} (from {flow['name']})",
                media_type="application/sql",
            )
            scripts.append({
                "data_source_id": output.data_source_id,
                "destination_name": output.destination_name,
                "artefact": filename,
                "sql_chars": len(output.sql),
            })

        _materialise_outputs(ctx, flow, scripts, consumed, schema, resolutions, review_items, warnings)

        for item in result.unresolved_sources:
            item["reason"] = _why_unresolved(item, planned, flow_names)
            review_items.append(ReviewItem(
                kind="unresolved_source", severity="error",
                title=f"{flow['name']}: {item.get('name') or item.get('cte_name')} has no table to read from",
                source_type="dataset", source_id=item.get("data_source_id"),
            ))
        for tile_type in result.unsupported_tile_types:
            review_items.append(ReviewItem(
                kind="unsupported_tile", severity="error",
                title=f"{flow['name']}: tile type {tile_type!r} is not supported by the converter",
                source_type="dataflow", source_id=str(flow["id"]),
            ))
        for cte, tile_warnings in result.tile_warnings.items():
            for warning in tile_warnings:
                # An LLM-translated expression is a guess until somebody checks it.
                kind = "llm_translated_formula" if "LLM-translated" in warning else "tile_warning"
                review_items.append(ReviewItem(
                    kind=kind, title=f"{flow['name']}: {warning[:180]}",
                    source_type="dataflow", source_id=str(flow["id"]),
                    detail={"cte": cte},
                ))

        converted.append({
            "dataflow_id": flow["id"], "name": flow["name"], "outputs": scripts,
            "unsupported_tile_types": result.unsupported_tile_types,
            "unresolved_sources": result.unresolved_sources,
            "tiles_with_warnings": len(result.tile_warnings),
            "repairs": repairs,
        })
        if validator is not None:
            _validate_entry(ctx, validator, converted[-1], review_items, warnings)
            _report_unique_ties(ctx, validator, converted[-1], review_items, unique_deadline)
            _report_run_date_reads(ctx, converted[-1], review_items)
        _write_progress(ctx, converted, len(magic))


def _write_progress(ctx: RunContext, converted: list[dict[str, Any]], total: int) -> None:
    """A convert-all run takes hours and the summary is only written at the end: keep what is
    known so far (outputs, warehouse verdicts, failures) readable while it runs (bimcontrol#124)."""
    ctx.write_json(
        PROGRESS_FILE, {"complete": False, "converted": len(converted), "of": total, "dataflows": converted},
        kind="manifest", label="Conversion so far",
    )


def _repair(
    ctx: RunContext, client: Any, flow: dict[str, Any], result: Any, regenerate: Any,
    review_items: list[ReviewItem],
) -> tuple[Any, list[dict[str, Any]]]:
    """Let the converter's agent fix the tiles the warehouse refuses (repair_sql). Off with
    BIMCONTROL_REPAIR=0, and when there is no warehouse to ask."""
    warehouse_settings = (ctx.project.get("settings") or {}).get("warehouse") or {}
    if not warehouse_settings.get("host") or os.environ.get("BIMCONTROL_REPAIR") == "0":
        return result, []
    adapter = get_adapter(warehouse_settings.get("key", "redshift"), warehouse_settings)
    with adapter:
        result, log = repair_sql.repair_rejected(
            client=client, flow_id=flow["id"], result=result, regenerate=regenerate,
            validate=lambda sql: validation_cache.validate(adapter, warehouse_settings, sql), progress=ctx.progress,
        )
    for entry in log:
        if entry["resolved"]:
            review_items.append(ReviewItem(
                kind="sql_repaired_by_agent", severity="warning",
                title=f"{flow['name']}: the converter's agent rewrote {entry['tile']} to get past "
                      f"the warehouse error: {(entry['error'] or '')[:160]}",
                source_type="dataflow", source_id=str(flow["id"]), detail=entry,
            ))
    return result, log


def _stop_if_scan_is_older_than_the_flow(
    ctx: RunContext, flow: dict[str, Any], unresolved: list[dict[str, Any]], planned: dict[str, dict[str, Any]],
) -> None:
    """An input the scan lacks but Domo has means the flow was edited after the scan (the converter reads the live
    flow). Going on would publish an empty table, so the stage stops and asks for a rescan."""
    unknown = [i for i in unresolved if i.get("data_source_id") and i["data_source_id"] not in planned]
    lookup = drift.live_dataset_lookup(ctx) if unknown else None
    for item in unknown if lookup else ():
        found = lookup(item["data_source_id"])
        if found is None:
            continue
        created = f", created {drift.when(int(found['created']))}" if found.get("created") else ""
        raise drift.ScanOutOfDate(
            f"{flow['name']!r} (dataflow {flow['id']}) reads {item.get('name') or found.get('name')!r}"
            f" ({item['data_source_id']}){created}, which exists in Domo but is not in the scan: the flow was edited "
            "after the scan, or the scanning account cannot see the dataset. Rescan with an account that can, then run again")


def _why_unresolved(item: dict[str, Any], datasets: dict[str, dict[str, Any]], names: dict[str, str]) -> str:
    """Why the converter found no table for an input, in the customer's terms."""
    dataset = datasets.get(item.get("data_source_id") or "")
    label = item.get("name") or item.get("cte_name") or "an input"
    if dataset is None:
        return f"reads {label!r}, which is not in the scan (deleted, or outside the scanning user's permissions)"
    producer = dataset.get("produced_by")
    if producer:
        flow = names.get(str(producer), "")
        return (f"reads {label!r}, the output of dataflow {producer} {flow!r}, "
                f"which has no table (that dataflow was rejected or not converted)")
    return f"reads {label!r}, which is not available in the warehouse: {dataset.get('why') or dataset.get('strategy')}"


def native_statement(script: str) -> str:
    """The converter's script as a statement Value.NativeQuery accepts: without its
    leading `-- Output` comment and trailing semicolon."""
    return "\n".join(line for line in script.splitlines() if not line.startswith("-- Output")).strip().rstrip(";")


_READS_RUN_DATE = re.compile(r"\b(?:CURRENT_DATE|CURRENT_TIMESTAMP|LOCALTIMESTAMP|SYSDATE|GETDATE\s*\(\s*\))(?![\w$])", re.IGNORECASE)
# What is no call of a function: a string, a quoted column name ("Current_Date"), a comment.
_NOT_CODE = re.compile(r"'(?:[^']|'')*'|\"[^\"]*\"|--[^\n]*")


def _report_run_date_reads(ctx: RunContext, entry: dict[str, Any], review_items: list[ReviewItem]) -> None:
    """Say that a dataflow reads the date it runs (an age, 'days since discharge', a fiscal window ending today).

    Domo's dataset holds the values of its last run; the converted dataflow reads today's date when the model builds, so
    a figure or a row key made from it differs by the days between the two (DNFB Detail's 'AR Days' 2,479 in Domo, 2,478
    in the model: every row of the card keyed differently)."""
    for script in entry["outputs"]:
        path = ctx.stage_dir() / script["artefact"]
        # A script staged through tables is written whole beside the short one that reads them.
        full = path.with_name(path.name.replace(".sql", ".full.sql"))
        text = _NOT_CODE.sub(" ", (full if full.exists() else path).read_text())
        found = sorted({re.sub(r"\s+", "", m.group(0)).upper() for m in _READS_RUN_DATE.finditer(text)})
        if found:
            review_items.append(ReviewItem(
                kind="reads_run_date", severity="info",
                title=(f"{entry['name']}: the dataflow reads the date it runs ({', '.join(found)}); Domo's dataset holds the "
                       "values of its last run, so figures that depend on the date differ by the days since"),
                source_type="dataflow", source_id=str(entry["dataflow_id"]),
                detail={"output": script["destination_name"], "functions": found},
            ))
            return


UNIQUE_TIES_BUDGET = 20 * 60     # seconds for the whole stage: each count reads the tile's whole upstream chain


def _report_unique_ties(
    ctx: RunContext, adapter, entry: dict[str, Any], review_items: list[ReviewItem], deadline: float,
) -> None:
    """Say where a Remove Duplicates tile keeps one of several different rows (bimcontrol#288)."""
    for script in entry["outputs"]:
        if not script.get("validated"):
            continue
        ties = unique_ties.ambiguous_keys(
            adapter, (ctx.stage_dir() / script["artefact"]).read_text(),
            check_cancelled=ctx.check_cancelled, out_of_time=lambda: time.monotonic() > deadline)
        script["unique_ties"] = ties
        for tie in ties:
            if not tie["checked"]:
                ctx.progress(f"{script['destination_name']}: Remove Duplicates on {tie['keys']} not checked "
                             "(the warehouse did not answer in time, or the check budget is used up)")
            elif tie["ambiguous_keys"]:
                ctx.progress(f"{script['destination_name']}: Remove Duplicates on {tie['keys']} keeps one of several "
                             f"different rows for {tie['ambiguous_keys']:,} keys")
                review_items.append(ReviewItem(
                    kind="unique_keeps_arbitrary_row",
                    title=(f"{entry['name']}: Remove Duplicates on {tie['keys']} ({script['destination_name']}) meets "
                           f"{tie['ambiguous_keys']:,} keys ({tie['rows']:,} rows) whose rows differ; Domo keeps the "
                           "first stored row of a key and the converted dataflow keeps the first by the position the "
                           "rows landed with, so figures that depend on the choice agree when the landing order is "
                           "the same and can differ from Domo's when it is not"),
                    source_type="dataflow", source_id=str(entry["dataflow_id"]),
                    detail={"output": script["destination_name"], **tie},
                ))


def _validate_entry(
    ctx: RunContext, adapter, entry: dict[str, Any], review_items: list[ReviewItem],
    warnings: list[str],
) -> None:
    """Ask the warehouse to plan each script of one dataflow."""
    # The script reads a placeholder where an input has no table, so
    # the warehouse could only answer with its own cryptic error.
    blocked = [i.get("reason") for i in entry["unresolved_sources"] if i.get("reason")]
    for script in entry["outputs"]:
        if blocked:
            script["validated"] = False
            script["validation_error"] = "not checked: " + "; ".join(blocked)
            ctx.progress(f"{script['destination_name']}: not checked, {blocked[0]}")
            continue
        sql = (ctx.stage_dir() / script["artefact"]).read_text()
        settings = (ctx.project.get("settings") or {}).get("warehouse") or {}
        ok, error = validation_cache.validate(adapter, settings, sql)
        script["validated"] = ok
        script["validation_error"] = error
        if ok:
            ctx.progress(f"{script['destination_name']}: the warehouse accepts this SQL")
            described = validation_cache.describe(adapter, settings, sql, native_statement(sql))
            if described is not None:
                script["columns"] = [{"name": name, "type": kind} for name, kind in described]
            continue
        ctx.progress(f"{script['destination_name']}: the warehouse rejects this SQL")
        warnings.append(f"{script['destination_name']}: {error}")
        review_items.append(ReviewItem(
            kind="sql_rejected_by_warehouse", severity="error",
            title=f"{entry['name']}: generated SQL for {script['destination_name']!r} "
                  f"will not run: {error}",
            source_type="dataflow", source_id=str(entry["dataflow_id"]),
            detail={"artefact": script["artefact"], "error": error},
        ))

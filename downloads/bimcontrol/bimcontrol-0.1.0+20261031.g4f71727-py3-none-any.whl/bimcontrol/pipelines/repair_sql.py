"""Repair converted SQL the warehouse rejects, one tile at a time.

The converter's transpiler is schema-blind, so some of what it writes only the warehouse can
judge: a text column used as a number, a CASE that mixes numbers and text. The converter also has
an agent for exactly that (`Fix with AI` on a single tile, driven by the warehouse's own error).
Left alone, every such dataflow stays rejected and everything reading its output cascades
(customer convert-all: 29 rejected of 179, most of them cascades).

Per rejected script: find the first CTE the warehouse refuses (bisecting the chain), ask the
converter to fix that tile, regenerate, and look again, a few rounds at most. What the agent did is
recorded so a person can check it; row parity downstream is still the real test.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from typing import Any

from bimcontrol.pipelines import stage_sql

MAX_ROUNDS = 6

# Errors that no tile edit can fix: an input with no table, the planner's own limits, the connection.
_NOT_A_TILE_PROBLEM = re.compile(
    r"does not exist.*(relation|schema)|relation .* does not exist|__todo_table__|permission denied|"
    r"correlated subquery|out of memory|connection|ssl|timeout|timed out",
    re.IGNORECASE,
)

Validate = Callable[[str], tuple[bool, str | None]]


def worth_repairing(error: str | None) -> bool:
    return bool(error) and not _NOT_A_TILE_PROBLEM.search(error or "")


def first_failing_cte(sql: str, validate: Validate) -> tuple[str | None, str | None]:
    """The first CTE the warehouse refuses (and its error), or (None, None) if it cannot be told.

    Binary search over the chain: a prefix that plans proves everything before it is fine.
    """
    chain = stage_sql.parse(sql)
    if chain is None or not chain.names:
        return None, None
    last = len(chain.names) - 1
    ok, error = validate(chain.render(chain.names[last]))
    if ok:
        return None, None
    low, high, found = 0, last, error
    while low < high:
        mid = (low + high) // 2
        ok, mid_error = validate(chain.render(chain.names[mid]))
        if ok:
            low = mid + 1
        else:
            high, found = mid, mid_error
    ok, error = validate(chain.render(chain.names[low]))
    return (chain.names[low], error) if not ok else (None, None)


def repair_rejected(
    *, client: Any, flow_id: Any, result: Any, regenerate: Callable[[], Any], validate: Validate,
    progress: Callable[[str], None] = lambda message: None, max_rounds: int = MAX_ROUNDS,
) -> tuple[Any, list[dict[str, Any]]]:
    """(the conversion to carry on with, what each round did)."""
    log: list[dict[str, Any]] = []
    if result.unresolved_sources or result.unsupported_tile_types:
        return result, log
    attempts: dict[str, int] = {}
    actions: dict[str, str] | None = None
    for round_number in range(1, max_rounds + 1):
        failing = []
        for output in result.outputs:
            if stage_sql.needs_staging(output.sql):
                continue  # too deep to plan whole; it is checked after staging
            ok, error = validate(output.sql)
            if not ok and worth_repairing(error):
                failing.append((output, error))
        if not failing:
            break
        if actions is None:
            actions = client.tile_action_ids(flow_id)
        fixed_any = False
        for output, error in failing:
            cte, cte_error = first_failing_cte(output.sql, validate)
            if cte is None or attempts.get(cte, 0) >= 2:
                continue
            attempts[cte] = attempts.get(cte, 0) + 1
            action_id = actions.get(cte.rsplit("_", 1)[-1])
            entry = {"round": round_number, "output": output.destination_name, "tile": cte,
                     "error": cte_error or error, "action_id": action_id, "resolved": False}
            log.append(entry)
            if action_id is None:
                entry["note"] = "no tile with that name in the dataflow"
                continue
            progress(f"  {output.destination_name}: asking the converter to fix {cte}: {(cte_error or error or '')[:120]}")
            try:
                outcome = client.fix_tile(flow_id, action_id)
            except Exception as exc:  # noqa: BLE001 -- a failed repair leaves the script as it was
                entry["note"] = f"fix failed: {str(exc)[:200]}"
                continue
            entry["resolved"] = bool(outcome.get("resolved"))
            entry["status"] = outcome.get("status")
            fixed_any = fixed_any or entry["resolved"]
        if not fixed_any:
            break
        result = regenerate()
    return result, log

"""Thin REST client for Tableau Server and Tableau Cloud.

Every call raises ``ApiError`` with the HTTP status on failure; deciding whether that ends the scan or
becomes a reported issue is the caller's job (a 403 on one workbook is an issue, not an abort), so
nothing here swallows an error. Sign-in problems are a different class, ``TableauAuthError``: the scan
cannot continue without a session.

**JSON, not XML.** Tableau's REST API answers XML unless asked otherwise. We send ``Accept:
application/json`` (and a JSON body for sign-in), which the API documents as an option, and parse JSON.
The shapes in this module and in tests/tableau_service.py are the documented XML tree rendered as JSON
(collections are ``{"workbooks": {"workbook": [...]}}``, numbers in ``pagination`` are strings) [U: no
JSON response was seen from a real site; 3.3 checks]. An endpoint that answers XML anyway raises an
``ApiError`` saying so rather than failing somewhere downstream.

**One session, one token.** Signing in again with the same personal access token ends the previous
session, so two threads that both see a 401 and both sign in would kill each other's fresh token. A
lock plus a generation counter makes the re-sign-in happen once per expiry however many threads race.

Nothing here was run against a Tableau site; [U] marks what is assumed from the documentation.
"""

from __future__ import annotations

import base64
import html
import json as jsonlib
import math
import random
import re
import threading
import time
import unicodedata
from collections.abc import Callable
from dataclasses import dataclass, field
from urllib.parse import quote, quote_plus, unquote, unquote_plus, urlsplit
from typing import Any

import requests

from estate_scanner.core.platform import PlatformError

from .scrub import fold_for_search
from .auth import METHOD_JWT, METHOD_PASSWORD, METHOD_PAT, TableauAuthError, TableauSession, normalise_server, read_secret, signin_body

# REST version tracks the product release (2023.1 = 3.19, 2025.1 = 3.25, 2026.2 = 3.29) [C R1].
# We use min(the server's, our ceiling). The ceiling is the newest version this adapter was written
# against; raise it only after a method that needs it has been run against a site at that version.
# The floor is 2023.1 (custom views, tasks, flows, Server subscriptions); a server below it still works
# at its own version and the caller skips what `supports()` says it lacks.
REST_VERSION_CEILING = "3.29"
REST_VERSION_FLOOR = "3.19"
# `serverinfo` is asked at a version old enough that every supported server knows it; asking at the
# ceiling would 404 on exactly the older servers whose version we want to learn. [U: that serverinfo
# exists from 2.4 is from memory of the docs, not read; if it 404s we fall back to stepping down.]
SERVERINFO_VERSION = "2.4"

# One download may take this long in all. The per-read timeout does not bound a server that dribbles a byte a minute.
DOWNLOAD_DEADLINE_S = 900.0
MAX_PAGE_SIZE = 1000  # projects, workbooks, subscriptions document 1000 as the maximum [C R7, R11, R14]
MAX_THROTTLE_RETRIES = 6
MAX_SERVER_RETRIES = 2
MAX_NETWORK_RETRIES = 3
REQUEST_TIMEOUT_S = 120
MAX_WAIT_S = 120.0
MAX_UNANCHORED_FAILURES = 3  # failed pages in a row, before any page has said how long the listing is, after which we stop asking
MAX_PAGE_FAILURES_IN_A_ROW = 3  # failed pages in a row, whether or not the total is known, after which a pass stops (a server that is down or throttling)
MAX_LIST_WAIT_S = 1000.0  # seconds one listing may spend waiting out 429s and retries (one page's six retries at Retry-After 120 is ~730 s, so one throttled page
#                           is recovered by the second pass and two are not): checked after every page, then the walk stops and no second pass is made
MAX_VIEWS = 48  # decoded views of one text that are searched for a credential: the work on a hostile text is bounded, not just its length
# An absolute bound on pages per listing. A server that claims a huge total and keeps handing out fresh rows would
# otherwise be asked for ceil(total / size) pages (a billion rows at 1000 a page is a million requests). One million rows
# in a listing is beyond any site this tool is for; reaching the bound is reported, not silent.
MAX_PAGES = 1000
EXTRA_PAGES = 2  # pages beyond ceil(total / page size) a listing may take before we conclude the server is not paging
MAX_VERSION_STEPS = 12
# Tableau's own error code for "no such REST version / resource". Assumed, not seen [U: 3.3 checks]. A 404
# without this code (an HTML page, a proxy, a wrong prefix) is NOT read as "version too new": the secret
# would be posted once per version otherwise.
UNSUPPORTED_VERSION_CODES = frozenset({"404000"})
_SENSITIVE_BODY_KEYS = ("personalAccessTokenSecret", "jwt", "password")


def _new_session() -> requests.Session:
    return requests.Session()  # a seam: tests hand in a fake backend instead


def parse_version(text: str) -> tuple[int, int]:
    major, _, minor = str(text).strip().partition(".")
    try:
        return int(major), int(minor or 0)
    except ValueError as exc:
        raise ValueError(f"Not a REST version: {text!r}") from exc


def format_version(version: tuple[int, int]) -> str:
    return f"{version[0]}.{version[1]}"


class ApiError(PlatformError):
    """A call that came back with an error status (or never came back). ``status`` is the HTTP status,
    ``code`` Tableau's own error code when the body had one."""

    def __init__(self, message: str, status: int | None = None, code: str | None = None):
        super().__init__(message)
        self.status = status
        self.code = code


def _short(text: str, limit: int = 300) -> str:
    return " ".join(text.split())[:limit]


@dataclass
class Paged:
    """A whole listing. ``missing`` is what the server said exists (``totalAvailable``) minus what came
    back after the repeat pass: the caller records an issue naming it, it does not abort."""

    items: list[dict]
    total_available: int | None
    missing: int = 0
    passes: int = 1
    # (page number, the error) for each page of the last pass that could not be read, only with
    # ``tolerate_page_errors``; otherwise the first such error is raised and nothing is returned.
    failed_pages: list[tuple[int, "ApiError"]] = field(default_factory=list)
    exceeded: int = 0  # rows received beyond ``totalAvailable``: the server under-reported its total, and all rows were kept
    truncated_at: int | None = None  # the page cap that ended a pass while rows were still arriving
    stopped: str | None = None  # why the walk gave up on the rest of the pages while the server was failing (a run of failed pages, the wait cap, a throttle)


DOWNLOAD_SLOTS = 20  # Tableau Cloud allows this many long-running requests at once [C R7]; the gate starts here and only goes down on evidence
RECOVER_AFTER = 25  # downloads in a row the server took without a 429 before the gate allows one more


class _DownloadGate:
    """How many downloads this client has in flight, lowered when the server says there are too many.

    The server's cap on concurrent downloads is shared with everything else signed in to the site, so what is left for this scan can be
    lower than its worker count. Retrying a 429 after a fixed wait is not enough then: the workers that were turned away come back
    while the others have taken the slots again, and after six tries a file is lost (and two lost files in a row stop all file
    reading). A rejected download therefore gives its place up, sets the limit to the number that were running beside it, and
    waits its turn behind that limit. The limit climbs by one after ``RECOVER_AFTER`` clean downloads, to find out whether room came back.

    A refusal lowers the limit again only after a download that started since the last lowering has gone through. A server whose cap
    is lower than the limit still lets some downloads finish, so a refusal after one is news about the room; a storm of 429 on every
    request lets none of the new ones finish (the ones already running do, and say nothing), and the same workers coming back every few
    seconds to be refused again say nothing about the room (counting each, the limit went from 20 to 13 in a 90 s storm, and then took
    25 clean downloads for every place it was given back)."""

    def __init__(self, limit: int = DOWNLOAD_SLOTS):
        self._cond = threading.Condition()
        self.maximum = self.limit = limit
        self.active = 0
        self.epoch = 0  # +1 each time the limit is lowered
        self._clean = 0
        self._news = True  # a download has gone through since the limit was last lowered (true at the start: the first refusal counts)

    def enter(self) -> int:
        """Wait for a place; returns the epoch it was given in, for ``rejected``."""
        with self._cond:
            while self.active >= self.limit:
                self._cond.wait()
            self.active += 1
            return self.epoch

    def leave(self, *, clean: bool = False, epoch: int | None = None) -> None:
        """Give the place back. ``clean``: the download went through. ``epoch``: the one it was given in (default: the current one). Only a
        download that started after the limit was last lowered says anything about the room left; one that was already running does not."""
        with self._cond:
            self.active -= 1
            if clean:
                if epoch is None or epoch == self.epoch:
                    self._news = True
                self._clean += 1
                if self._clean >= RECOVER_AFTER and self.limit < self.maximum:
                    self.limit += 1
                    self._clean = 0
            self._cond.notify_all()

    def rejected(self, epoch: int) -> None:
        """The server answered 429 to a download holding a place: give the place up and, if it was asked for after the limit last
        changed and a download has gone through since, lower the limit to the downloads running beside it. A download sent before the
        change (a burst of refusals) or refused when nothing has finished since (a storm that throttles every request) says nothing
        new, so a storm does not ratchet the limit down."""
        with self._cond:
            if epoch == self.epoch and self._news:
                self.limit = max(1, min(self.limit, self.active - 1))
                self.epoch += 1
                self._clean = 0
                self._news = False
            self.active -= 1
            self._cond.notify_all()


class _Place:
    """The place a download holds in the gate and the epoch it was given in; a download that is turned away takes a new one."""

    __slots__ = ("epoch",)

    def __init__(self, epoch: int):
        self.epoch = epoch


@dataclass(frozen=True)
class _State:
    """Replaced whole, never edited, so a thread that reads it sees a token and the generation that
    token belongs to together."""

    token: str | None = field(default=None, repr=False)
    generation: int = 0  # 0 = never signed in; +1 per sign-in
    site_id: str | None = None
    user_id: str | None = None


def _forms(secret: str) -> set[str]:
    """Every form ``secret`` takes in text about a request: as typed, JSON-escaped (with and without the
    ``\\uXXXX`` escapes), a Python repr, HTML-escaped, and each of those percent-encoded. A server that repeats the
    request body writes the JSON form; a literal replace leaves it behind (bimcontrol #577 found this in a stored error)."""
    base = {secret, jsonlib.dumps(secret)[1:-1], jsonlib.dumps(secret, ensure_ascii=False)[1:-1], repr(secret)[1:-1],
            html.escape(secret), html.escape(secret, quote=False)}
    forms = set(base)
    for form in base:
        forms |= {quote(form, safe=""), quote(form), quote_plus(form), quote_plus(form, safe="")}
    forms |= {re.sub(r"%[0-9A-F]{2}", lambda m: m.group(0).lower(), form) for form in forms}       # .NET writes percent-escapes in lower case
    raw = secret.encode("utf-8")
    forms |= {base64.b64encode(raw).decode(), base64.urlsafe_b64encode(raw).decode(), base64.b64encode(raw).decode().rstrip("="),
              base64.urlsafe_b64encode(raw).decode().rstrip("="), raw.hex(), raw.hex().upper()}                                 # `Authorization: Basic base64(name:secret)` carries it inside a longer one
    return {form for form in forms if form}


_WITHHELD = "no detail (the server's answer repeated a credential, so none of it is shown)"
_FAIL_CLOSED_MIN = 6          # a shorter secret would withhold every answer (one letter is in every sentence): it is replaced where it stands, not searched for in decoded views
_HEAD = 65536                 # only the start of an answer is ever shown; a 5 MB body is not decoded 64 ways
_JSON_ESCAPE = re.compile(r"\\(u[0-9a-fA-F]{4}|.)", re.S)


def _json_unescape(text: str) -> str:
    """JSON string escapes undone in any hex case, `\\/` and `\\u003d` included, without parsing (the text is a fragment)."""
    plain = {"n": "\n", "t": "\t", "r": "\r", "b": "\b", "f": "\f"}

    def one(match: re.Match) -> str:
        token = match.group(1)
        return chr(int(token[1:], 16)) if len(token) == 5 and token[0] == "u" else plain.get(token, token)

    return _JSON_ESCAPE.sub(one, text).encode("utf-16", "surrogatepass").decode("utf-16", "replace")


_BASE64_RUN = re.compile(r"[A-Za-z0-9+/_-]{16,}={0,2}")


def _texty(decoded: str) -> bool:
    """Whether bytes that were decoded from a run look like text (nine in ten characters printable, none a replacement): a credential echoed in base64 or hex
    decodes to text, and a uuid or a hash decodes to noise that is not worth searching (it also would multiply the views three layers deep)."""
    return len(decoded) >= 4 and sum(1 for ch in decoded if ch.isprintable() and ch != "\ufffd") >= 0.9 * len(decoded)


def _base64_runs(text: str) -> str:
    """The text with every base64-looking run of 16 or more characters decoded and appended (`Authorization: Basic base64(name:secret)` holds the secret
    at an offset no fixed encoding of the secret alone matches)."""
    found = []
    for token in _BASE64_RUN.findall(text)[:200]:
        token = token.rstrip("=")
        for offset in range(4):  # the encoded part may begin anywhere in the run (a prefix that is not a multiple of four characters)
            piece = token[offset:]
            padded = piece + "=" * (-len(piece) % 4)
            for decoder in (base64.b64decode, base64.urlsafe_b64decode):
                try:
                    text_form = decoder(padded).decode("utf-8", "replace")
                except ValueError:
                    continue
                if _texty(text_form):
                    found.append(text_form)
    return text + "\n" + "\n".join(found) if found else text


_HEX_RUN = re.compile(r"(?:(?:\\?x|0x)?[0-9A-Fa-f]{2}[ :;,.-]{0,2}){6,}")   # whole bytes, plain or with up to two separator characters after each (`70:61`, `70 61`, `70-61`) or as `\x70` / `0x70`
# One byte at a time, never by deleting "0x" from the whole token: in `x70x61` a strip of "0x" would eat the end of the first byte and the start of the next.
_HEX_BYTE = re.compile(r"(?:\\?x|0x)?([0-9A-Fa-f]{2})")
_BASE32_RUN = re.compile(r"[A-Za-z2-7]{16,}={0,6}")


def _base32_runs(text: str) -> str:
    """The text with every base32-looking run of 16 or more characters decoded and appended (any case; a prefix may shift it by up to seven characters)."""
    found = []
    for token in _BASE32_RUN.findall(text)[:100]:
        token = token.rstrip("=").upper()
        for offset in range(8):
            piece = token[offset:]
            try:
                decoded = base64.b32decode(piece + "=" * (-len(piece) % 8)).decode("utf-8", "replace")
            except ValueError:
                continue
            if _texty(decoded):
                found.append(decoded)
    return text + "\n" + "\n".join(found) if found else text


def _hex_runs(text: str) -> str:
    """The text with every run of 6 or more hex bytes (the shortest secret that is searched for, ``_FAIL_CLOSED_MIN``) decoded and appended (plain, separated by a colon, space, dash, comma, dot or semicolon, or written
    ``\\x70`` / ``x70`` (what a JSON unescape leaves) / ``0x70``): a credential echoed as a hex dump."""
    found = []
    for token in _HEX_RUN.findall(text)[:200]:
        try:
            decoded = bytes.fromhex("".join(_HEX_BYTE.findall(token))).decode("utf-8", "replace")
        except ValueError:
            continue
        if _texty(decoded):
            found.append(decoded)
    return text + "\n" + "\n".join(found) if found else text


def _views(text: str, limit: int = MAX_VIEWS) -> set[str]:
    """The text as the server's echo might have been encoded, decoded up to three layers deep (percent, `+`, HTML entities in every spelling, JSON escapes,
    base64, base32, hex): a secret that shows in any of them was in the answer. At most ``limit`` views are made: a text built to multiply them is searched
    in the first ``limit`` (breadth first: the shallow decodings, which are the ones a server's echo makes)."""
    seen, frontier = {text}, [text]
    for _ in range(3):
        following = []
        for current in frontier:
            for decode in (unquote, unquote_plus, html.unescape, _json_unescape, _base64_runs, _base32_runs, _hex_runs):
                if len(seen) >= limit:
                    return seen
                decoded = decode(current)
                if decoded not in seen:
                    seen.add(decoded)
                    following.append(decoded)
        frontier = following
    return seen


def _squash(text: str) -> str:
    """Compared as letters and digits only: without case, white space or punctuation (a secret with dots, underscores or spaces put between its characters), with
    compatibility forms folded (NFKC), invisible format characters removed and look-alike letters turned into the Latin ones (``scrub.fold_for_search``)."""
    return "".join(ch for ch in fold_for_search(text).casefold() if ch.isalnum())


class TableauHttp:
    def __init__(
        self, session: TableauSession, secret: Callable[[], str] | None = None, http: requests.Session | None = None,
        *, ceiling: str = REST_VERSION_CEILING, floor: str = REST_VERSION_FLOOR,
    ):
        self.session = session
        self._server = normalise_server(session.server)  # a restored session is checked like a typed one
        self._sensitive: set[str] = set()  # exact strings no message may carry: the secret, a minted JWT
        self._tokens: set[str] = set()     # every session token this client was ever given (not only the current one)
        self._secret = secret or (lambda: read_secret(session.method, session.secret_file))
        self._http = http or _new_session()
        self._ceiling = parse_version(ceiling)
        self._floor = parse_version(floor)
        self._version: tuple[int, int] | None = None
        self._state = _State()
        self._failure: tuple[int, TableauAuthError] | None = None  # (generation it happened at, error)
        self._auth_lock = threading.Lock()
        self._gate = _DownloadGate()
        self._sleep = time.sleep
        self._forms_for: tuple[frozenset, Any] = (frozenset(), None)
        self.view_chars_searched = 0  # characters of decoded views the secret search has looked through: a caller that has a budget for such work reads the difference
        self._napped = threading.local()  # seconds this thread has asked to wait, summed: a listing's wait cap reads the difference
        self._clock = time.monotonic
        self._jitter = random.uniform  # (a, b) -> float; tests pin it

    # -- what sign-in learnt ---------------------------------------------------------------------------

    @property
    def rest_version(self) -> str | None:
        return format_version(self._version) if self._version else None

    @property
    def site_id(self) -> str | None:
        return self._state.site_id

    @property
    def user_id(self) -> str | None:
        return self._state.user_id

    def supports(self, version: str) -> bool:
        """True when the negotiated REST version is at least ``version`` (a method newer than the URL's
        version fails [C R1], so callers check before using one)."""
        if self._version is None:
            self.sign_in()
        return self._version >= parse_version(version)

    def site_path(self, suffix: str = "") -> str:
        """``/sites/{site id}`` + suffix. The site's id (a LUID) comes from the sign-in response."""
        self.sign_in()
        return f"/sites/{self._state.site_id}{suffix}"

    # -- sign-in ---------------------------------------------------------------------------------------

    def sign_in(self) -> None:
        """Sign in if this client has no session yet. Safe to call from any thread."""
        if self._state.token is None:
            self._resign_in(0)

    def _api(self, version: tuple[int, int], path: str) -> str:
        return f"{self._server}/api/{format_version(version)}{path}"

    def _do_sign_in(self) -> None:
        """Caller holds ``_auth_lock``. The first sign-in also settles the REST version."""
        if self._version is not None:
            try:
                self._sign_in_at(self._version)
            except _VersionRejected:
                raise TableauAuthError(f"{self._server} no longer answers REST version {self.rest_version}.") from None
            return
        server_version = self._server_version()
        if server_version is not None:
            self._version = min(server_version, self._ceiling)
            try:
                self._sign_in_at(self._version)
            except _VersionRejected:
                self._version = None
                raise TableauAuthError(
                    f"POST /api/{format_version(min(server_version, self._ceiling))}/auth/signin answered 404 "
                    f"although the server reported REST version {format_version(server_version)}: is the server address right?"
                ) from None
            return
        # `serverinfo` did not answer [U: its path and shape are from the docs, not seen]. Try the
        # ceiling and step down a minor version at a time while the server says, in Tableau's own error,
        # that it does not know that version [U: code and status assumed].
        candidate = self._ceiling
        for _ in range(MAX_VERSION_STEPS):
            try:
                self._sign_in_at(candidate)
                self._version = candidate
                return
            except _VersionRejected:
                if candidate <= self._floor:
                    break
                candidate = (candidate[0], candidate[1] - 1)
        raise TableauAuthError(
            f"{self._server} does not accept the REST API at versions {format_version(self._ceiling)} "
            f"down to {format_version(candidate)}: check the server address, and that the server is Tableau 2023.1 or newer."
        )

    def _server_version(self) -> tuple[int, int] | None:
        """``GET /api/2.4/serverinfo`` (no sign-in needed) -> ``restApiVersion`` [U: unconfirmed, see
        the module note]. None when it does not answer or the answer is not what we expect."""
        resp = self._send("GET", self._api(parse_version(SERVERINFO_VERSION), "/serverinfo"), authenticated=False)
        if resp.status_code != 200:
            return None
        try:
            return parse_version(resp.json()["serverInfo"]["restApiVersion"])
        except (ValueError, KeyError, TypeError, RecursionError):  # (a body nested past the parser's limit is not an answer)
            return None

    def _remember_sensitive(self, body: dict) -> None:
        """Note every secret-bearing value of a sign-in body (and the pieces of a JWT, in case a server
        repeats only part of it) so ``_scrub`` can remove it from any text that is shown."""
        for key in _SENSITIVE_BODY_KEYS:
            value = (body.get("credentials") or {}).get(key)
            if value:
                self._sensitive.add(value)
                self._sensitive.update(part for part in value.split(".") if len(part) >= 8)

    def _sign_in_at(self, version: tuple[int, int]) -> None:
        secret = self._secret()
        self._sensitive.add(secret)
        body = signin_body(self.session, secret)
        self._remember_sensitive(body)
        url = self._api(version, "/auth/signin")
        # repeatable: signing in again is harmless, so a 5xx or a dropped connection may be retried
        resp = self._send("POST", url, authenticated=False, repeatable=True, json=body)
        status = resp.status_code
        if status == 404 and self._code(resp) in UNSUPPORTED_VERSION_CODES:
            raise _VersionRejected()
        if 300 <= status < 400:
            raise TableauAuthError(
                f"The server redirected the sign-in to {self._redirect_host(resp)}. It was not followed (the secret would "
                "have gone there); use the server's own address.", status,
            )
        if status != 200:
            raise TableauAuthError(self._sign_in_failure(resp, url), status)
        try:
            credentials = resp.json()["credentials"]
            token = credentials["token"]
            site_id = credentials["site"]["id"]
            user_id = credentials["user"]["id"]
        except (ValueError, KeyError, TypeError, RecursionError):
            raise TableauAuthError("The server's sign-in answer was not the expected JSON; is this a Tableau REST API address?", status) from None
        self._tokens.add(token)
        self._state = _State(token, self._state.generation + 1, site_id, user_id)

    def _sign_in_failure(self, resp: requests.Response, url: str) -> str:
        """Fixed wording plus Tableau's error code. The server's own text is deliberately not shown: a
        refusal that repeats the request would carry the secret, and the code says what the text would."""
        status = resp.status_code
        code = self._code(resp)
        head = f"Tableau sign-in failed ({status}{f', Tableau error {code}' if code else ''}) at {self._where(url)}."
        if status == 404:
            return head + " No such address: check the server address and its path prefix."
        if status >= 500 or status in (408, 429):
            return head + " The server is not able to answer right now; try again."
        method = self.session.method
        if method == METHOD_PAT:
            return head + (
                " Check the token name and secret, and the site name (its contentUrl, exact case). A token expires after 15 days unused "
                "(a year otherwise), and signing in with it anywhere else ends this scan's session: use one token per tool."
            )
        if method == METHOD_JWT:
            return head + (
                " Check the connected app's client id, secret id and secret, that the user exists on this site, and that this machine's "
                "clock is right: the token is valid for only a few minutes, so a clock that is off makes it look expired."
            )
        return head + " Check the user name and password, and the site name (its contentUrl, exact case). A user with MFA needs a personal access token."

    @staticmethod
    def _redirect_host(resp: requests.Response) -> str:
        """The host a redirect names and nothing else: its path and query can carry anything."""
        try:
            return urlsplit(resp.headers.get("Location") or "").hostname or "another address"
        except ValueError:
            return "another address"

    def _resign_in(self, seen_generation: int) -> None:
        """Replace an expired token -- once, however many threads got the same 401. A thread that
        arrives after another has already signed in finds the generation moved on and just retries
        with the new token. A failed attempt is remembered for its generation so the threads queued
        behind it fail the same way instead of each trying the (probably revoked) token again."""
        with self._auth_lock:
            if self._state.generation != seen_generation:
                return
            if self._failure and self._failure[0] == seen_generation:
                raise self._failure[1]
            try:
                self._do_sign_in()
            except TableauAuthError as exc:
                # Remember a refusal (bad or revoked credentials) so the threads queued behind it do not
                # each try them again. A blip (5xx, 429, timeout, no answer) is not remembered: the next
                # call tries again, because the server may be back a second later.
                if exc.status is not None and 400 <= exc.status < 500 and exc.status not in (408, 429):
                    self._failure = (seen_generation, exc)
                raise

    # -- plumbing --------------------------------------------------------------------------------------

    def _send(
        self, method: str, url: str, *, authenticated: bool = True, repeatable: bool | None = None, gate: _DownloadGate | None = None, place: _Place | None = None, **kwargs: Any,
    ) -> requests.Response:
        """The one place a request leaves. Retries 429 with jitter; retries 500/502/503/504 and network
        errors with jitter only when the request is ``repeatable`` (a GET, or sign-in), because a POST that
        died half-way may have happened. On a 401 it signs in again (once for the whole client, see
        ``_resign_in``) and repeats the request once with the new token. Redirects are never followed: a
        redirect would carry the secret or the session token to whatever host it names. Anything else,
        errors included, is returned for the caller. A caller that holds a ``place`` in a ``gate`` keeps it on return or error; while
        a 429 is waited out the place is given up and taken again after (see ``_DownloadGate``)."""
        if repeatable is None:
            repeatable = method == "GET"
        throttled = server_errors = network_errors = 0
        resigned = False
        headers = {"Accept": "application/json", **dict(kwargs.pop("headers", None) or {})}
        if "json" in kwargs:
            headers["Content-Type"] = "application/json"
        while True:
            generation = 0
            if authenticated:
                self.sign_in()
                state = self._state
                generation = state.generation
                headers["X-Tableau-Auth"] = state.token
            try:
                resp = self._http.request(method, url, headers=headers, timeout=REQUEST_TIMEOUT_S, allow_redirects=False, **kwargs)
            except (requests.exceptions.InvalidURL, requests.exceptions.InvalidSchema, requests.exceptions.MissingSchema) as exc:
                # The address itself is wrong; trying again cannot help.
                raise ApiError(f"{method} {self._where(url)} -> {type(exc).__name__}") from None       # not `from exc`: its request holds the sign-in body (the secret)
            except requests.RequestException as exc:
                # A reset, timeout or broken stream is the network, not an answer.
                network_errors += 1
                if not repeatable or network_errors > MAX_NETWORK_RETRIES:
                    raise ApiError(self._network_failure(method, url, exc)) from None
                self._nap(self._backoff(network_errors))
                continue
            if resp.status_code == 401 and authenticated:
                if resigned:
                    # A token the server issued a moment ago is refused: the session is not usable (typically the same
                    # personal access token signing in elsewhere, which ends this one). A per-object refusal is a 403, so
                    # this is not an object to skip: carrying on would leave whole phases out of a "completed" scan.
                    raise TableauAuthError(
                        f"{method} {self._where(url)} -> 401 straight after signing in again: the server does not accept the session it just issued. "
                        "Is the same personal access token in use by another process? Signing in with it anywhere else ends this session.", 401,
                    )
                resigned = True
                resp.close()
                self._resign_in(generation)
                continue
            if resp.status_code == 429 and throttled < MAX_THROTTLE_RETRIES:
                throttled += 1
                resp.close()
                if gate:
                    gate.rejected(place.epoch)
                try:
                    self._nap(self._throttle_wait(resp, throttled))
                finally:
                    if gate:
                        place.epoch = gate.enter()
                continue
            if repeatable and resp.status_code in (500, 502, 503, 504) and server_errors < MAX_SERVER_RETRIES:
                server_errors += 1
                resp.close()
                self._nap(self._backoff(server_errors + 1))
                continue
            return resp

    def _network_failure(self, method: str, url: str, exc: requests.RequestException) -> str:
        """One plain sentence for a connection that never became an answer. The library's own text (a pool, a retry
        count, a resolver error code) means nothing to the person who typed the address, so it is not shown; the
        exception's class name stays for support."""
        host = urlsplit(self._server).netloc
        if isinstance(exc, requests.exceptions.SSLError):
            reason = (f"a secure connection to {host} could not be made (its certificate was not accepted; certificates are always "
                      "checked, so ask whoever runs the server whether it needs a certificate your computer trusts)")
        elif isinstance(exc, requests.exceptions.Timeout):
            reason = f"{host} did not answer in time. Check the address, and your network or VPN"
        elif isinstance(exc, requests.ConnectionError):
            reason = f"cannot reach {host}. Check the address, your network or VPN, and that the server is running"
        else:
            reason = f"the connection to {host} failed. Check your network or VPN"
        return f"{method} {self._where(url)} -> {reason}. ({type(exc).__name__})"

    def _nap(self, seconds: float) -> None:
        self._napped.total = getattr(self._napped, "total", 0.0) + max(0.0, seconds)
        self._sleep(seconds)

    def waited(self) -> float:
        """Seconds this thread has waited (asked ``_sleep`` for) since the client was made."""
        return getattr(self._napped, "total", 0.0)

    def _backoff(self, attempt: int) -> float:
        return min(MAX_WAIT_S, 2.0 ** attempt) * self._jitter(0.5, 1.5)

    def _throttle_wait(self, resp: requests.Response, attempt: int) -> float:
        """Honour ``Retry-After`` when the 429 carries a usable one, clamped to [0, MAX_WAIT_S]. Tableau
        does not document that header [U, check on 3.3/3.10]; without one (or with one that is not a
        number) it is exponential backoff with jitter."""
        header = resp.headers.get("Retry-After")
        if header:
            try:
                seconds = float(header)
            except ValueError:
                seconds = math.nan
            if not math.isnan(seconds):
                return max(0.0, min(seconds, MAX_WAIT_S)) + self._jitter(0.0, 1.0)
        return self._backoff(attempt + 1)

    def _sensitive_values(self) -> set[str]:
        values = set(self._sensitive)
        values |= self._tokens                                      # every session token ever issued: a request in flight at a re-sign-in carries the old one
        if self._state.token:
            values.add(self._state.token)
        try:
            values |= {cookie.value for cookie in self._http.cookies if cookie.value and len(cookie.value) >= 8}   # a session cookie is a credential too
        except (AttributeError, TypeError):
            pass
        return {value for value in values if value}

    def _scrub(self, text: str) -> str:
        """Nothing secret should be in a message, but a server can repeat a body and a library a URL. In two steps:

        1. every remembered secret is replaced where it stands, in every form a server or proxy writes it (see ``_forms``), longest first, in one
           pass (a replacement is never searched again);
        2. then the text is searched DECODED (``_views``: percent, HTML entities, JSON escapes, three layers, compared without case or white space): a
           secret that survives in any view was echoed in a form step 1 does not know, so nothing of the answer is shown (fail closed).
        Called on the START of the answer, before it is shortened and before its white space is collapsed: a secret that straddles the cut, or holds a line
        break, is matched whole."""
        values = frozenset(self._sensitive_values())
        if not values:
            return text
        if self._forms_for[0] != values:  # the forms are the same for every text until a new secret or token is remembered: built once, not per call
            forms = {form for value in values for form in _forms(value)}
            pattern = re.compile("|".join(re.escape(form) for form in sorted(forms, key=len, reverse=True))) if forms else None
            self._forms_for = (values, pattern)
        pattern = self._forms_for[1]
        text = pattern.sub("***", text) if pattern else text
        needles = {needle for needle in (_squash(value) for value in values if len(value) >= _FAIL_CLOSED_MIN) if len(needle) >= _FAIL_CLOSED_MIN}  # (the length floor is on what is searched for: "........" squashes to nothing, which is in every text)
        if needles:
            views = _views(text)
            self.view_chars_searched += sum(len(view) for view in views if view is not text)
            for view in views:
                squashed = _squash(view)
                if any(needle in squashed for needle in needles):
                    return _WITHHELD
        return text

    def scrub_known(self, text: str) -> tuple[str, bool]:
        """``(text with every remembered secret replaced, False)``, or ``("", True)`` when a secret still shows in some decoded view of it (see ``_scrub``): for text
        that is stored, not only shown. The caller decides what to store in place of a withheld text."""
        scrubbed = self._scrub(text)
        return ("", True) if scrubbed == _WITHHELD else (scrubbed, False)

    def _shown(self, text: str) -> str:
        """What an error answer may put in a message: scrubbed first, then collapsed and cut."""
        return _short(self._scrub(text[:_HEAD])) or "no detail"

    @staticmethod
    def _where(url: str) -> str:
        parts = urlsplit(url)
        return parts.path or "/"

    def _error_text(self, resp: requests.Response) -> str:
        """Tableau's ``{"error": {"summary", "detail", "code"}}`` as one line, else the start of the body."""
        try:
            error = resp.json()["error"]
            parts = [str(error.get("summary") or ""), str(error.get("detail") or "")]
            return self._shown(": ".join(p for p in parts if p))
        except (ValueError, KeyError, TypeError, AttributeError, RecursionError):
            return self._shown(resp.text or "")

    @staticmethod
    def _code(resp: requests.Response) -> str | None:
        """Tableau's error code, only if it looks like one (a short token): it is shown in messages."""
        try:
            code = str(resp.json()["error"]["code"])
        except (ValueError, KeyError, TypeError, AttributeError, RecursionError):
            return None
        return code if re.fullmatch(r"[0-9A-Za-z_.-]{1,16}", code) else None

    # -- requests --------------------------------------------------------------------------------------

    def request(self, method: str, path: str, **kwargs: Any) -> Any:
        """``path`` is below ``/api/{version}``; use ``site_path`` for site-scoped ones. Returns the
        parsed JSON, or None for an empty body. Raises ``ApiError`` for any error status."""
        self.sign_in()
        resp = self._send(method, self._api(self._version, path), **kwargs)
        where = f"{method} {path}"
        if 300 <= resp.status_code < 400:
            raise ApiError(f"{where} -> {resp.status_code}: redirected to {self._redirect_host(resp)}; not followed", resp.status_code)
        if resp.status_code >= 400:
            raise ApiError(f"{where} -> {resp.status_code}: {self._error_text(resp)}", resp.status_code, self._code(resp))
        if not resp.content:
            return None
        try:
            return resp.json()
        except RecursionError:
            raise ApiError(f"{where} -> {resp.status_code}: the answer is nested too deeply to read", resp.status_code) from None
        except ValueError as exc:
            if _cut_off(exc, resp.text or ""):
                raise ApiError(f"{where} -> {resp.status_code}: the answer ends before the JSON is complete (it was cut off)", resp.status_code) from None
            kind = "XML" if (resp.text or "").lstrip().startswith("<") else "not JSON"
            raise ApiError(f"{where} -> {resp.status_code}: the answer is {kind} (Accept: application/json was not honoured)", resp.status_code) from None

    def get(self, path: str, **kwargs: Any) -> Any:
        return self.request("GET", path, **kwargs)

    def get_capped(self, path: str, *, max_bytes: int, params: dict | None = None) -> Any:
        """Like ``get`` for an answer that is not paged and so has no size of its own: the body is read in chunks and the read stops once more than ``max_bytes``
        has arrived (a declared ``Content-Length`` over it is refused unread), so the JSON of a hostile or runaway answer is never parsed. ``DownloadTooLarge``
        for the cap, ``ApiError`` as ``get`` raises it."""
        self.sign_in()
        where = f"GET {path}"
        resp = None
        try:
            resp = self._send("GET", self._api(self._version, path), params=params, stream=True)
            status = resp.status_code
            if 300 <= status < 400:
                raise ApiError(f"{where} -> {status}: redirected to {self._redirect_host(resp)}; not followed", status)
            if status >= 400:
                raw = self._error_chunk(resp)
                raise ApiError(f"{where} -> {status}: {self._stream_error_text(raw)}", status, self._code_of(raw))
            declared = resp.headers.get("Content-Length")
            if isinstance(declared, str) and re.fullmatch(r"[0-9]{1,15}", declared) and int(declared) > max_bytes:
                raise DownloadTooLarge(f"{where} -> the answer is {int(declared)} bytes, over the {max_bytes}-byte cap; not read", status)
            body = bytearray()
            for part in resp.iter_content(chunk_size=1 << 16):
                body += part
                if len(body) > max_bytes:
                    raise DownloadTooLarge(f"{where} -> the answer is over the {max_bytes}-byte cap; the read was stopped", status)
            if not body:
                return None
            try:
                return jsonlib.loads(bytes(body))
            except RecursionError:
                raise ApiError(f"{where} -> {status}: the answer is nested too deeply to read", status) from None
            except ValueError as exc:
                if _cut_off(exc, body.decode("utf-8", "replace")):
                    raise ApiError(f"{where} -> {status}: the answer ends before the JSON is complete (it was cut off)", status) from None
                raise ApiError(f"{where} -> {status}: the answer is not JSON (Accept: application/json was not honoured)", status) from None
        except requests.RequestException as exc:
            raise ApiError(f"{where} -> {type(exc).__name__} while reading the answer") from None
        finally:
            if resp is not None:
                resp.close()

    # -- downloads -------------------------------------------------------------------------------------

    def download(self, path: str, *, max_bytes: int, params: dict | None = None, chunk_size: int = 1 << 20,
                 deadline_s: float = DOWNLOAD_DEADLINE_S) -> bytearray:
        """The body of ``path`` (a workbook or data source ``/content``), streamed into memory and never to disk. The read
        stops as soon as more than ``max_bytes`` has arrived (a declared ``Content-Length`` over the cap is refused before
        any body is read), so a server that streams without end costs at most the cap plus one chunk. Raises ``ApiError``
        for an error status, a redirect (not followed) or a connection that dies mid-body, ``DownloadTooLarge`` for the cap.

        Messages name the method and the path only: ``params`` (the query) and the session token are never in one."""
        self.sign_in()
        where = f"GET {path}"
        place = _Place(self._gate.enter())
        clean = False
        resp = None
        try:
            # Accept: the file is not JSON, and a server that honours the JSON default may refuse a download with 406 [U].
            resp = self._send("GET", self._api(self._version, path), headers={"Accept": "*/*"}, params=params, stream=True, gate=self._gate, place=place)
            status = resp.status_code
            if 300 <= status < 400:
                raise ApiError(f"{where} -> {status}: redirected to {self._redirect_host(resp)}; not followed", status)
            if status >= 400:
                raw = self._error_chunk(resp)  # once: a second read would take another 64 KiB
                raise ApiError(f"{where} -> {status}: {self._stream_error_text(raw)}", status, self._code_of(raw))
            declared = resp.headers.get("Content-Length")
            # ASCII digits only and a bounded length: str.isdigit() accepts "²", and int() of 5,000 digits raises. A header that is
            # not a plain number is unknown, not an error; the cap is enforced while counting either way.
            if isinstance(declared, str) and re.fullmatch(r"[0-9]{1,15}", declared) and int(declared) > max_bytes:
                raise DownloadTooLarge(f"{where} -> the file is {int(declared)} bytes, over the {max_bytes}-byte cap; not downloaded", status)
            body = bytearray()
            started = self._clock()
            for part in resp.iter_content(chunk_size=chunk_size):
                body += part
                if len(body) > max_bytes:
                    raise DownloadTooLarge(f"{where} -> the file is over the {max_bytes}-byte cap; the download was stopped", status)
                if self._clock() - started > deadline_s:
                    raise ApiError(f"{where} -> the download took longer than {deadline_s:.0f} s and was stopped")
            clean = True
            return body  # not bytes(body): that copies, and the peak would be twice the file
        except requests.RequestException as exc:
            raise ApiError(f"{where} -> {type(exc).__name__} while reading the file") from exc
        finally:
            if resp is not None:
                resp.close()
            self._gate.leave(clean=clean, epoch=place.epoch)

    @staticmethod
    def _error_chunk(resp: requests.Response) -> bytes:
        """At most 64 KiB of an error body: a hostile server must not make a refusal as large as a download."""
        try:
            return next(iter(resp.iter_content(chunk_size=65536)), b"")[:65536]
        except requests.RequestException:
            return b""

    def _stream_error_text(self, raw: bytes) -> str:
        try:
            error = jsonlib.loads(raw)["error"]
            parts = [str(error.get("summary") or ""), str(error.get("detail") or "")]
            return self._shown(": ".join(p for p in parts if p))
        except (ValueError, KeyError, TypeError, AttributeError, RecursionError):
            return self._shown(raw[:_HEAD].decode("utf-8", "replace"))

    @staticmethod
    def _code_of(raw: bytes) -> str | None:
        try:
            code = str(jsonlib.loads(raw)["error"]["code"])
        except (ValueError, KeyError, TypeError, AttributeError, RecursionError):
            return None
        return code if re.fullmatch(r"[0-9A-Za-z_.-]{1,16}", code) else None

    # -- paging ----------------------------------------------------------------------------------------

    def list_paged(
        self, path: str, collection: str, item: str, *, page_size: int = MAX_PAGE_SIZE, params: dict | None = None,
        sort: str | None = None, tolerate_page_errors: bool = False, max_pages: int | None = None, strict: bool = False, empty_unpaged: bool = False,
    ) -> Paged:
        """Every row of a paged listing, e.g. ``list_paged(http.site_path("/workbooks"), "workbooks", "workbook")``.

        Tableau warns that an item removed between pages can make its neighbour skip [C R6], so a
        listing is reconciled: read ``totalAvailable``, compare it with the distinct ids received, and
        make **one** more pass if short, keeping the union. If it is still short, ``missing`` says by how
        many and the caller records an issue naming it (the rest is still returned: partial data is the
        normal result). ``sort`` (``name:asc``) is passed through where the endpoint supports it; whether
        it makes paging stable on every list is unconfirmed [U].

        The total is the first one any pass was told (a later pass that fails outright must not erase it). A server
        that under-reports it is not believed: paging goes on until a page comes back short, and ``exceeded`` counts the
        surplus. ``max_pages`` (default ``MAX_PAGES``) bounds a pass whatever the server claims; ``truncated_at`` says it did.

        With ``tolerate_page_errors`` a page that still fails after the transport's own retries (an ``ApiError``,
        which includes an answer that is not the documented shape; a lost sign-in is never tolerated) is skipped
        instead of ending the listing: the other pages are kept, the repeat pass asks for the missing one again, and a
        page is in ``failed_pages`` only if rows are still missing and it never answered in either pass. Without the
        option the first error is raised.

        ``strict`` is for a listing whose absence must never read as "none exist" (3.8): the answer must say how long the list is
        (``pagination.totalAvailable``) and name the collection, and a collection that holds anything must hold the item key. An
        answer that is not shaped so is the same ``ApiError`` a page that cannot be read is. Left off (the 3.5 lists), an object that
        lacks the collection is an empty page, as it always was. ``empty_unpaged`` (the task lists) also accepts a body that is exactly
        ``{collection: {}}`` as an empty list: that is what Tableau Cloud sends for a site with none (seen 2026-11-03), with no ``pagination``."""
        page_size = max(1, min(page_size, MAX_PAGE_SIZE))
        limit = max_pages or MAX_PAGES
        merged: dict[Any, dict] = {}
        anonymous: list[dict] = []  # rows with no usable id: the longest pass's, never two passes added together
        total: int | None = None
        answered: set[int] = set()
        failures: dict[int, ApiError] = {}
        truncated: int | None = None
        stopped: list[str] = []
        began = self.waited()
        passes = 0
        start = 1
        while passes < 2:
            passes += 1
            pass_total, pass_anonymous, pass_failures, pass_answered, pass_truncated = self._one_pass(
                path, collection, item, page_size, params, sort, merged, tolerate_page_errors, limit, strict, stopped, began, start, empty_unpaged)
            total = pass_total if total is None else total
            if len(pass_anonymous) > len(anonymous):
                anonymous = pass_anonymous
            answered |= pass_answered
            failures.update(pass_failures)
            truncated = truncated or pass_truncated
            if truncated or total is None or len(merged) + len(anonymous) >= total:
                break
            if self.waited() - began >= MAX_LIST_WAIT_S:
                if not stopped:
                    stopped.append(f"the waits for this listing reached {MAX_LIST_WAIT_S:.0f} s")
                break  # a server that has cost this much waiting is not asked again
            unanswered = [p for p in failures if p not in answered]
            start = min(unanswered) if unanswered else 1  # the repeat pass begins at the first page that never answered: the ones before it are read
        received = len(merged) + len(anonymous)
        missing = max(0, total - received) if total is not None else 0
        failed = sorted((p, e) for p, e in failures.items() if p not in answered) if (total is None or missing) else []
        return Paged(
            items=list(merged.values()) + anonymous, total_available=total, missing=missing, passes=passes, failed_pages=failed,
            exceeded=max(0, received - total) if total is not None else 0, truncated_at=truncated, stopped=stopped[-1] if stopped and missing else None,
        )

    @staticmethod
    def _usable_id(row_id: Any) -> bool:
        """An id we can hash and store: a non-empty string or an integer. A list or dict id (which would raise
        TypeError as a set member) and an empty one are treated as no id at all."""
        return (isinstance(row_id, str) and row_id != "") or (isinstance(row_id, int) and not isinstance(row_id, bool))

    @staticmethod
    def _page_shape(body: Any, collection: str, item: str, where: str, strict: bool = False, empty_unpaged: bool = False) -> tuple[list, dict]:
        """(rows, pagination) of one answer, or an ``ApiError`` naming what was wrong. Tableau's JSON rendering is
        unconfirmed [U], and a proxy or a broken server can answer anything: no shape is trusted."""
        if body is None:
            body = {}
        if not isinstance(body, dict):
            raise ApiError(f"{where} -> the answer is not the documented shape (a {type(body).__name__}, not an object)")
        group = body.get(collection)
        if strict:
            _strict_shape(body, group, collection, item, where, empty_unpaged)
        if group in (None, {}, [], ""):
            rows: Any = []
        elif isinstance(group, dict):
            rows = group.get(item) or []
        else:
            raise ApiError(f"{where} -> the answer is not the documented shape ('{collection}' is a {type(group).__name__}, not an object)")
        if isinstance(rows, dict):  # a one-row collection is not always rendered as a list [U]
            rows = [rows]
        if not isinstance(rows, list):
            raise ApiError(f"{where} -> the answer is not the documented shape ('{item}' is a {type(rows).__name__}, not a list)")
        pagination = body.get("pagination")
        return rows, pagination if isinstance(pagination, dict) else {}

    def _one_pass(self, path, collection, item, page_size, params, sort, merged, tolerate_page_errors=False, max_pages=MAX_PAGES, strict=False,
                  stopped=None, began=0.0, start_page=1, empty_unpaged=False):
        """One walk over the pages, adding to ``merged`` (ids seen so far, over every pass). Follows the page
        size the server says it used (it may clamp ours). Stops at an empty page, at a page that is short once
        the total is reached (a page that is full at the total is followed by one more, because a server may
        under-report ``totalAvailable``), when a page brings nothing this pass has not already seen (a server that
        ignores ``pageNumber``), when more pages than the total allows have been read while rows are still missing, or
        at ``max_pages``. A page that fails (when tolerated) is noted and the walk goes on to the next one; before any
        page has told us the total, a refusal (401/403/404: asking again will not change it) or MAX_UNANCHORED_FAILURES
        failures in a row end the walk. Returns (total, anonymous rows, {failed page: error}, answered pages, page cap hit)."""
        anonymous: list[dict] = []
        failures: dict[int, ApiError] = {}
        answered: set[int] = set()
        seen_this_pass: set[Any] = set()
        total: int | None = None
        expected: int | None = None  # pages the total implies, plus EXTRA_PAGES
        page = start_page
        in_a_row = 0  # failed pages since the last page that answered
        while True:
            if page > start_page and self.waited() - began >= MAX_LIST_WAIT_S:
                if stopped is not None:
                    stopped.append(f"the waits for this listing reached {MAX_LIST_WAIT_S:.0f} s")
                return total, anonymous, failures, answered, None
            query = {**(params or {}), "pageSize": page_size, "pageNumber": page}
            if sort:
                query["sort"] = sort
            try:
                rows, pagination = self._page_shape(self.get(path, params=query), collection, item, f"GET {path}", strict, empty_unpaged)
            except ApiError as exc:
                if not tolerate_page_errors:
                    raise
                failures[page] = exc
                in_a_row += 1
                refused = exc.status in (401, 403, 404)
                if expected is None and (refused or len(failures) >= MAX_UNANCHORED_FAILURES) and not answered:
                    return total, anonymous, failures, answered, None
                if in_a_row >= MAX_PAGE_FAILURES_IN_A_ROW:
                    if stopped is not None:
                        stopped.append(f"{in_a_row} pages in a row could not be read")
                    return total, anonymous, failures, answered, None
                if page >= (expected or page + 1) or page >= max_pages:
                    return total, anonymous, failures, answered, None
                page += 1
                continue
            answered.add(page)
            in_a_row = 0
            fresh = 0
            for row in rows:
                row_id = row.get("id") if isinstance(row, dict) else None
                if not self._usable_id(row_id):
                    anonymous.append(row)
                    fresh += 1
                else:
                    if row_id not in seen_this_pass:
                        seen_this_pass.add(row_id)
                        fresh += 1
                    merged[row_id] = row  # also drops a row served twice when the pages shifted
            try:
                total = int(pagination["totalAvailable"])
                total = total if total >= 0 else None
            except (KeyError, TypeError, ValueError):
                total = None
            try:
                served = int(pagination["pageSize"])
            except (KeyError, TypeError, ValueError):
                served = 0
            served = served if served > 0 else page_size
            if expected is None and total is not None:
                expected = -(-total // served) + EXTRA_PAGES
            if not rows or total is None or fresh == 0:
                return total, anonymous, failures, answered, None
            received = len(merged) + len(anonymous)
            if received >= total and len(rows) < served:
                return total, anonymous, failures, answered, None
            if page >= max_pages:
                return total, anonymous, failures, answered, page
            if received < total and page >= expected:
                return total, anonymous, failures, answered, None
            page += 1


def _cut_off(exc: ValueError, text: str) -> bool:
    """Whether a JSON error is the text ending too soon (a string or an object left open at the end), not text that is not JSON."""
    if text.lstrip()[:1] not in ("{", "["):
        return False
    message = str(exc)
    position = getattr(exc, "pos", None)
    return message.startswith("Unterminated string") or (message.startswith("Expecting") and isinstance(position, int) and position >= len(text.rstrip()))


def _strict_shape(body: dict, group: Any, collection: str, item: str, where: str, empty_unpaged: bool = False) -> None:
    """Raises ``ApiError`` unless ``body`` is a page of ``collection`` as documented: ``pagination`` with a ``totalAvailable`` that is a number, and
    the collection an object that is empty or holds ``item``. A collection that is absent is an empty page only when the server says the total is 0."""
    pagination = body.get("pagination")
    if empty_unpaged and group == {} and list(body) == [collection]:
        return  # exactly {"tasks": {}}: no list of tasks at all, as the live site sends it
    try:
        total = int(pagination["totalAvailable"]) if isinstance(pagination, dict) else None
    except (KeyError, TypeError, ValueError):
        total = None
    if total is None or total < 0:
        raise ApiError(f"{where} -> the answer is not the documented shape (no pagination.totalAvailable, so it does not say how long the list is)")
    if group is None:
        if total == 0:
            return
        raise ApiError(f"{where} -> the answer is not the documented shape ('{collection}' is missing, and the server says {total} exist)")
    if isinstance(group, dict) and group and item not in group:
        raise ApiError(f"{where} -> the answer is not the documented shape ('{collection}' holds no '{item}')")


class DownloadTooLarge(ApiError):
    """A download went past the size cap (declared in ``Content-Length`` or counted while streaming)."""


class _VersionRejected(Exception):
    """The server does not know the REST version in the URL."""

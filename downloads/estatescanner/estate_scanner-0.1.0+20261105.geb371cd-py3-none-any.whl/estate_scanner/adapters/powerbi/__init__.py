from estate_scanner.core.registry import PlatformDescriptor, register_platform

from .auth import PowerBiAuthenticator, PowerBiAuthError, PowerBiSession
from .client import PowerBiClient
from .http import PowerBiApiError, PowerBiHttp
from .policies import describe_policies

register_platform(
    PlatformDescriptor(
        key="powerbi",
        display_name="Power BI",
        status="available",
        authenticator_cls=PowerBiAuthenticator,
        client_cls=PowerBiClient,
        auth_mode="interactive_browser",
        instance_hint="Tenant, e.g. contoso.com",
        describe_policies=describe_policies,
    )
)

__all__ = [
    "PowerBiApiError",
    "PowerBiAuthError",
    "PowerBiAuthenticator",
    "PowerBiClient",
    "PowerBiHttp",
    "PowerBiSession",
]

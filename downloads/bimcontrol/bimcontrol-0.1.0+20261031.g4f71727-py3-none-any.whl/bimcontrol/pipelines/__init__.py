"""Pipelines: one per source-to-target pair.

A pipeline is just an ordered list of stages, so adding a pair is adding a
module here and an entry in the registry below -- the engine, the control
database and the UI stay as they are.
"""

from __future__ import annotations

from bimcontrol.core.engine import Pipeline

from . import domo_to_powerbi, estate_sql

PIPELINES: dict[str, Pipeline] = {
    domo_to_powerbi.PIPELINE.name: domo_to_powerbi.PIPELINE,
    estate_sql.PIPELINE.name: estate_sql.PIPELINE,
}

DEFAULT_PIPELINE = domo_to_powerbi.PIPELINE.name


def get_pipeline(name: str | None = None) -> Pipeline:
    pipeline = PIPELINES.get(name or DEFAULT_PIPELINE)
    if pipeline is None:
        raise KeyError(f"Unknown pipeline {name!r}. Known: {', '.join(sorted(PIPELINES))}")
    return pipeline


def pipeline_for(source_platform: str, target_platform: str) -> Pipeline:
    return get_pipeline(f"{source_platform}_to_{target_platform}")


__all__ = ["PIPELINES", "DEFAULT_PIPELINE", "get_pipeline", "pipeline_for", "Pipeline"]

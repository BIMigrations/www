"""Deciding where each dataset's data will come from, and landing what has
nowhere to come from.

Two stages, kept together because they are two halves of one idea.

`plan_data` reads the closure and labels every dataset with a strategy. It
is pure: no network, no warehouse, no credentials -- just the decision,
written down as an artefact a human can read and argue with before
anything is moved.

`land_source_data` carries out the one strategy that involves moving
bytes. This is the step that exists because of a fact about real estates:
a Domo dataflow's inputs are routinely spreadsheets somebody uploaded by
hand, which exist nowhere else. No amount of ETL translation conjures up
data that is not in the warehouse, so BIMControl puts it there.
"""

from __future__ import annotations

import datetime as _dt
from pathlib import Path
from typing import Any

from bimcontrol.core.engine import ReviewItem, RunContext, StageResult
from bimcontrol.sources.domo.export import DomoExportError
from bimcontrol.warehouses import (
    ROW_ORDER_COLUMN,
    ColumnSpec,
    TableSpec,
    WarehouseError,
    get_adapter,
    number_csv_rows,
    safe_table_name,
    scan_csv_widths,
)

PLAN_FILE = "data_plan.json"
LANDINGS_FILE = "landings.json"

# Providers whose data already lives in a warehouse the customer owns. The
# table is there; it only has to be pointed at.
WAREHOUSE_PROVIDERS = {
    "amazon-redshift": "redshift",
    "snowflake": "snowflake",
    "google-bigquery": "bigquery",
}

# Providers that mean "somebody uploaded a file into the BI tool". These
# are the ones with nowhere else to come from.
UPLOAD_PROVIDERS = {
    "large-file-upload", "file-upload", "file-upload-new", "csv3",
    "webform", "google-spreadsheets",
}

# Providers that pull from, or are pushed by, something outside Domo (a
# script posting through the DataSet API, an S3 bucket, an SFTP drop). The
# warehouse holds no copy of them either, so they are landed the same way
# as an upload; the difference is the follow-up: the real fix is to repoint
# the feed, not to re-upload a file. Added 2026-10-12 after a dashboard
# whose eleven `api` inputs left the model with no tables to read.
CONNECTOR_PROVIDERS = {"api", "amazon-s3", "amazons3-advanced", "sftp"}


def feedback_dataset_ids(flows: list[dict[str, Any]], datasets: list[dict[str, Any]]) -> set[str]:
    """Datasets a dataflow reads before (or without) its producer having run.

    Domo lets two dataflows feed each other: each reads the other's output
    from its previous run. Converted to SQL that is a cycle, and the
    consumer that has to go first finds nothing to read (the
    `__TODO_TABLE__` placeholder). Those datasets are landed from Domo as a
    snapshot so the first consumer has its input.
    """
    from bimcontrol.pipelines.convert_etl import _in_dependency_order  # noqa: PLC0415 -- avoids an import cycle

    producer = {d["id"]: d["produced_by"] for d in datasets if d.get("produced_by")}
    position = {str(f["id"]): i for i, f in enumerate(_in_dependency_order(flows, producer))}
    feedback: set[str] = set()
    for flow in flows:
        for dataset_id in flow.get("input_dataset_ids") or []:
            made_by = producer.get(dataset_id)
            if made_by is not None and str(made_by) in position \
                    and position[str(flow["id"])] <= position[str(made_by)]:
                feedback.add(dataset_id)
    return feedback


def unrunnable_flow_ids(flows: list[dict[str, Any]]) -> set[str]:
    """Dataflows that load a dataset the scan does not have (deleted, or out of the scanning user's
    reach), and dataflows Domo has switched off. They cannot run in the warehouse (or, switched off, have not
    for years: the customer's 'wRVU rules' reads a column its input lost in 2023), and Domo cannot re-run them
    either: what they last wrote is all there is."""
    return {str(f["id"]) for f in flows if f.get("missing_input_ids") or f.get("disabled_in_domo")}


def _strategy_for(
    dataset: dict[str, Any], feedback: frozenset[str] | set[str] = frozenset(),
    unrunnable: frozenset[str] | set[str] = frozenset(), disabled: frozenset[str] | set[str] = frozenset(),
) -> tuple[str, str]:
    """(strategy, why) for one dataset in the closure."""
    provider = (dataset.get("provider_type") or "").strip()

    if dataset.get("produced_by") and str(dataset["produced_by"]) in unrunnable:
        if str(dataset["produced_by"]) in disabled:
            return (
                "land_from_source",
                "produced by a dataflow that Domo has switched off; its last output is what the cards show, so "
                "it is landed as a snapshot and the flow is not converted",
            )
        return (
            "land_from_source",
            "produced by a dataflow that loads a dataset the scan does not have (deleted?); the flow "
            "cannot run, so Domo's last output is landed as a snapshot and the flow is not converted",
        )

    if dataset.get("produced_by") and dataset["id"] in feedback:
        return (
            "land_from_source",
            "produced by a dataflow that also depends on a dataflow reading it (a feedback loop in "
            "Domo); land its current rows as the starting snapshot for the first reader",
        )
    if dataset.get("produced_by"):
        return (
            "dataflow_output",
            "produced by a dataflow in this closure; the converted SQL supplies it",
        )
    if provider == "DataFlow":
        # The scan holds the dataset but no dataflow that outputs it: the flow was deleted, or is not one this
        # account can see (the customer's 'Hospital w Balance', last built 2025-04). Its rows are all Domo has, and
        # a card still reads them, so land them rather than build an empty table.
        return (
            "land_from_source",
            "a dataflow output whose dataflow is not in the scan; land Domo's last output as a snapshot",
        )
    if provider in WAREHOUSE_PROVIDERS:
        return (
            "warehouse_table",
            f"already fed from {provider}; resolve it to the existing table",
        )
    if provider in UPLOAD_PROVIDERS:
        return (
            "land_from_source",
            f"a {provider} with no warehouse copy; export it and load it",
        )
    if provider in CONNECTOR_PROVIDERS:
        return (
            "land_from_source",
            f"a {provider} feed with no warehouse copy; export a snapshot and load it",
        )
    return (
        "needs_decision",
        f"provider {provider!r} is neither a warehouse feed nor an upload",
    )


def plan_data(ctx: RunContext) -> StageResult:
    closure = ctx.read_json("resolve_closure", "closure.json")
    warehouse = (ctx.project.get("settings") or {}).get("warehouse") or {}
    warehouse_key = warehouse.get("key", "redshift")
    landing_schema = warehouse.get("landing_schema", "bimcontrol_landing")

    entries: list[dict[str, Any]] = []
    review_items: list[ReviewItem] = []

    feedback = feedback_dataset_ids(closure.get("dataflows") or [], closure["datasets"])
    unrunnable = unrunnable_flow_ids(closure.get("dataflows") or [])
    disabled = {str(f["id"]) for f in closure.get("dataflows") or [] if f.get("disabled_in_domo")} - {
        str(f["id"]) for f in closure.get("dataflows") or [] if f.get("missing_input_ids")}
    appending = {str(f["id"]): f for f in closure.get("dataflows") or [] if f.get("appends_history")}
    for dataset in closure["datasets"]:
        strategy, why = _strategy_for(dataset, feedback, unrunnable, disabled)
        entry = {
            "dataset_id": dataset["id"],
            "name": dataset["name"],
            "provider_type": dataset.get("provider_type"),
            "row_count": dataset.get("row_count"),
            "updated_at": dataset.get("updated_at"),
            "columns": dataset.get("columns") or [],
            "strategy": strategy,
            "why": why,
            "produced_by": dataset.get("produced_by"),
            "snapshot_of_unrunnable_flow": bool(dataset.get("produced_by")) and str(dataset["produced_by"]) in unrunnable,
        }
        if strategy == "land_from_source":
            entry["target_table"] = {
                "warehouse": warehouse_key,
                "schema": landing_schema,
                "table": safe_table_name(dataset["name"], dataset["id"]),
            }
            # A landed upload is a photograph of a moving thing: somebody
            # re-uploads that spreadsheet every month, and the migrated
            # report will not notice. Say so now, as migration work, rather
            # than letting it surface as a stale dashboard later.
            is_connector = (dataset.get("provider_type") or "").strip() in CONNECTOR_PROVIDERS
            review_items.append(
                ReviewItem(
                    kind="landed_upload_needs_feed",
                    title=(
                        f"{dataset['name']!r} comes from a dataflow that Domo has switched off; its last Domo rows "
                        "were landed and the dataflow was not converted"
                        if entry["snapshot_of_unrunnable_flow"] and str(dataset["produced_by"]) in disabled
                        else f"{dataset['name']!r} comes from a dataflow that loads a dataset which no longer "
                        "exists in the scan; its last Domo rows were landed and the dataflow was not converted"
                        if entry["snapshot_of_unrunnable_flow"]
                        else f"{dataset['name']!r} is part of a feedback loop between dataflows; its Domo rows "
                        "were landed as the starting snapshot for the dataflow that reads it first"
                        if dataset.get("produced_by")
                        else f"{dataset['name']!r} is a dataflow output whose dataflow is not in the scan; its Domo rows "
                        "were landed as a snapshot and nothing will refresh them"
                        if dataset.get("provider_type") == "DataFlow"
                        else f"{dataset['name']!r} is a feed from {dataset.get('provider_type')}; "
                        "the snapshot will go stale until the warehouse has the real feed"
                        if is_connector
                        else f"{dataset['name']!r} is a manual upload; the warehouse will need a real feed"
                    ),
                    source_type="dataset",
                    source_id=dataset["id"],
                    detail={"provider_type": dataset.get("provider_type"), "rows": dataset.get("row_count")},
                )
            )
        elif strategy == "dataflow_output" and _appends_to(appending.get(str(dataset["produced_by"])), dataset["id"]):
            # Domo keeps every run's rows, the converted SQL rebuilds one run: the history exists only in Domo, so a card
            # that reads it differs by construction (the parity report shows the row counts). Landing the history would
            # make the table equal, but not keep it growing: that is a design decision (an incremental load), not a conversion.
            entry["appends_history"] = True
            review_items.append(
                ReviewItem(
                    kind="append_history_not_reproduced",
                    title=(f"{dataset['name']!r} accumulates history in Domo ({dataset.get('row_count') or 0:,} rows over its runs: "
                           "the output tile's update method is APPEND); the converted dataflow rebuilds the current run only"),
                    source_type="dataset",
                    source_id=dataset["id"],
                    detail={"dataflow_id": str(dataset["produced_by"]), "domo_rows": dataset.get("row_count")},
                )
            )
        elif strategy == "needs_decision":
            review_items.append(
                ReviewItem(
                    kind="unknown_data_source",
                    severity="error",
                    title=f"Nowhere to read {dataset['name']!r} from ({dataset.get('provider_type')})",
                    source_type="dataset",
                    source_id=dataset["id"],
                    detail={"why": why},
                )
            )
        entries.append(entry)

    counts: dict[str, int] = {}
    for entry in entries:
        counts[entry["strategy"]] = counts.get(entry["strategy"], 0) + 1

    ctx.write_json(
        PLAN_FILE,
        {"warehouse": warehouse_key, "landing_schema": landing_schema, "datasets": entries},
        kind="plan",
        label="Data plan",
    )
    ctx.progress(", ".join(f"{n} {strategy}" for strategy, n in sorted(counts.items())))
    return StageResult(summary=counts, review_items=review_items)


def land_source_data(ctx: RunContext) -> StageResult:
    """Export every `land_from_source` dataset and load it into the warehouse.

    Idempotent by table: a dataset already landed with the expected row
    count is skipped, so a resumed run does not re-export gigabytes. Pass
    `relanding` in the run options to force it.
    """
    plan = ctx.read_json("plan_data", PLAN_FILE)
    to_land = [d for d in plan["datasets"] if d["strategy"] == "land_from_source"]
    closure = ctx.read_json("resolve_closure", "closure.json")

    if not to_land:
        ctx.progress("Nothing to land: no manual uploads in this closure")
        ctx.write_json(LANDINGS_FILE, {"landings": []}, kind="plan", label="Landed tables")
        return StageResult(summary={"landed": 0, "skipped": 0})

    warehouse_settings = (ctx.project.get("settings") or {}).get("warehouse") or {}
    adapter = get_adapter(plan["warehouse"], warehouse_settings)
    exporter = _exporter(ctx)
    force = bool(ctx.options.get("relanding"))

    landings: list[dict[str, Any]] = []
    warnings: list[str] = []
    review_items: list[ReviewItem] = []
    landed = skipped = 0
    unavailable: list[dict[str, Any]] = []
    snapshot_flows: set[str] = set()

    with adapter:
        adapter.ensure_schema(plan["landing_schema"])
        index = 0
        while index < len(to_land):
            dataset = to_land[index]
            index += 1
            ctx.check_cancelled()
            target = dataset["target_table"]
            schema, table = target["schema"], target["table"]
            expected = int(dataset.get("row_count") or 0)
            changed_at = _utc(dataset.get("updated_at"))
            with adapter.building(schema, table):         # one lane lands a table; the others then find it landed
                if not force and adapter.table_exists(schema, table) and adapter.table_has_column(schema, table, ROW_ORDER_COLUMN):
                    existing = adapter.row_count(schema, table)
                    if expected and _within_tolerance(existing, expected):
                        note = "" if existing == expected else f" ({existing:,} rows vs {expected:,} scanned, within tolerance)"
                        landed_at = adapter.table_data_as_of(schema, table)
                        stale = landed_at is not None and changed_at is not None and changed_at > landed_at
                        ctx.progress(f"[{index}/{len(to_land)}] {dataset['name']}: already landed{note}"
                                     + (f", but Domo changed it since ({changed_at:%Y-%m-%d %H:%M} UTC after {landed_at:%Y-%m-%d %H:%M})" if stale else ""))
                        landings.append({
                            "dataset_id": dataset["dataset_id"], "name": dataset["name"],
                            "table_ref": adapter.table_ref(schema, table), "rows": existing,
                            "method": "skipped", "already_present": True,
                            "landed_at": landed_at.isoformat(timespec="seconds") if landed_at else None,
                            "source_updated_at": changed_at.isoformat(timespec="seconds") if changed_at else None,
                            "older_than_source": stale,
                        })
                        if stale:
                            review_items.append(ReviewItem(
                                kind="landing_older_than_source", severity="warn",
                                title=f"{dataset['name']!r} was landed {landed_at:%Y-%m-%d %H:%M} UTC but Domo changed it "
                                      f"{changed_at:%Y-%m-%d %H:%M} UTC: the model reads older data than Domo's figures, so "
                                      "what differs downstream may be this. Drop the landed table and run from plan_data to land it again.",
                                source_type="dataset", source_id=dataset["dataset_id"],
                                detail={"table": adapter.table_ref(schema, table), "landed_at": landed_at.isoformat(),
                                        "domo_updated_at": changed_at.isoformat(), "rows": existing},
                            ))
                        skipped += 1
                        continue

                ctx.progress(f"[{index}/{len(to_land)}] {dataset['name']}: exporting {expected:,} rows")
                csv_path = ctx.stage_dir() / f"{table}.csv"
                read_at = _dt.datetime.now(_dt.timezone.utc).replace(tzinfo=None)   # before the export: a Domo update during it is newer than the copy
                try:
                    export = exporter.export_csv(dataset["dataset_id"], csv_path)
                except DomoExportError as exc:
                    # The output of a dataflow that cannot run, and Domo has archived it too: what the
                    # flows reading it last wrote is the data there is, so those become the snapshots.
                    archived = dataset.get("snapshot_of_unrunnable_flow") and _is_archived(exc)
                    readers, moved = _snapshot_readers(closure, plan, dataset, to_land, snapshot_flows) if archived else (0, [])
                    if not readers:
                        raise
                    csv_path.unlink(missing_ok=True)
                    unavailable.append({"dataset_id": dataset["dataset_id"], "name": dataset["name"],
                                        "why": str(exc).splitlines()[0][:300]})
                    review_items.append(ReviewItem(
                        kind="snapshot_unavailable_upstream", severity="warn",
                        title=f"{dataset['name']!r} cannot be exported from Domo (archived); the output of the "
                              f"dataflow(s) reading it ({', '.join(repr(m) for m in moved) or 'already queued'}) "
                              "was landed as a snapshot instead",
                        source_type="dataset", source_id=dataset["dataset_id"],
                    ))
                    continue

                number_csv_rows(csv_path)       # the stored order Remove Duplicates keeps its first row by (#361)
                widths, actual_rows = scan_csv_widths(csv_path)
                spec = TableSpec(
                    schema=schema,
                    table=table,
                    columns=_columns_for(dataset, widths),
                    source_id=dataset["dataset_id"],
                    source_name=dataset["name"],
                )

                ctx.progress(f"[{index}/{len(to_land)}] {dataset['name']}: loading into {spec.ref}")
                adapter.create_table(spec, replace=True)
                result = adapter.load_csv(spec, csv_path, row_count=actual_rows)
                warnings.extend(result.warnings)
                adapter.mark_data_as_of(schema, table, read_at)

                if expected and result.rows_loaded != expected:
                    warnings.append(
                        f"{dataset['name']!r}: loaded {result.rows_loaded:,} rows, "
                        f"but the scan recorded {expected:,} -- the dataset has changed since the scan"
                    )
                landings.append({
                    "dataset_id": dataset["dataset_id"], "name": dataset["name"],
                    "table_ref": result.table_ref, "rows": result.rows_loaded,
                    "method": result.method, "export_strategy": export.strategy,
                    "already_present": False, "landed_at": read_at.isoformat(timespec="seconds"),
                    "source_updated_at": changed_at.isoformat(timespec="seconds") if changed_at else None,
                })
                landed += 1

                # The CSV has served its purpose and is a copy of customer data
                # sitting in a run directory; the table is the artefact now.
                if not ctx.options.get("keep_exports"):
                    csv_path.unlink(missing_ok=True)

    ctx.write_json(
        LANDINGS_FILE,
        {"warehouse": plan["warehouse"], "landings": landings, "unavailable": unavailable,
         "snapshot_flows": sorted(snapshot_flows)},
        kind="plan",
        label="Landed tables",
    )
    return StageResult(
        summary={"landed": landed, "skipped": skipped, "tables": len(landings)},
        warnings=warnings,
        review_items=review_items,
    )


def _snapshot_readers(
    closure: dict[str, Any], plan: dict[str, Any], dataset: dict[str, Any], to_land: list[dict[str, Any]],
    snapshot_flows: set[str],
) -> tuple[int, list[str]]:
    """Queue, as snapshots, the outputs of every dataflow that reads `dataset`: (readers found, names queued).

    A reader already snapshotted for another archived input counts as found: its output is queued."""
    queued = {d["dataset_id"] for d in to_land}
    by_flow: dict[str, list[dict[str, Any]]] = {}
    for entry in closure["datasets"]:
        if entry.get("produced_by") is not None:
            by_flow.setdefault(str(entry["produced_by"]), []).append(entry)
    names: list[str] = []
    readers = 0
    for flow in closure.get("dataflows") or []:
        if dataset["dataset_id"] not in (flow.get("input_dataset_ids") or []):
            continue
        readers += 1
        snapshot_flows.add(str(flow["id"]))
        for out in by_flow.get(str(flow["id"]), []):
            if out["id"] in queued:
                continue
            to_land.append({
                "dataset_id": out["id"], "name": out["name"], "row_count": out.get("row_count"),
                "columns": out.get("columns") or [], "produced_by": out.get("produced_by"),
                "strategy": "land_from_source", "snapshot_of_unrunnable_flow": True,
                "target_table": {"warehouse": plan["warehouse"], "schema": plan["landing_schema"],
                                 "table": safe_table_name(out["name"], out["id"])},
            })
            names.append(out["name"])
    return readers, names


def _is_archived(exc: Exception) -> bool:
    """Domo's answer for an archived dataset: query API 410 'Datasource has been archived', export 404 'not found in ice'.
    A timeout or a 5xx is not that, and must not demote a runnable flow to a snapshot."""
    text = str(exc).lower()
    return "archived" in text or "not found in ice" in text or "410 client error" in text or "410 archived" in text


def _appends_to(flow: dict[str, Any] | None, dataset_id: str) -> bool:
    """Does this output tile of the flow append (the other outputs of the flow may replace). A closure written before
    the flow listed its appending outputs says only that some output does: every output of the flow then counts."""
    if not flow:
        return False
    outputs = flow.get("appending_dataset_ids")
    return str(dataset_id) in outputs if outputs is not None else True


def _utc(value: Any) -> _dt.datetime | None:
    """An ISO time from the scan as a naive UTC datetime (what the warehouse's creation times are), or None."""
    if not value:
        return None
    try:
        moment = _dt.datetime.fromisoformat(str(value))
    except ValueError:
        return None
    return moment.astimezone(_dt.timezone.utc).replace(tzinfo=None) if moment.tzinfo else moment


def _within_tolerance(existing: int, expected: int) -> bool:
    """A landed table still counts when the live dataset only drifted a little since the scan.

    Re-landing a large dataset to chase one new row cost ~10 minutes each on the Medicare
    dashboard; a drift of 0.1% (or 2 rows) is a live feed ticking, not a stale landing.
    """
    return abs(existing - expected) <= max(2, expected // 1000)


def _columns_for(dataset: dict[str, Any], widths: dict[str, int]) -> list[ColumnSpec]:
    """Column specs in the order of the CSV's header (the row-order column first), typed by the scan where it knows the column.

    COPY maps by position, so the table has to be the export's columns in the export's order. The scan only knows the
    schema of the day it was taken: customer ClaimXWalk gained two columns in the middle when its flow ran again
    (2026-10-21), and the scan's order loaded 'patientid' into a number column. A column the scan has and the export
    has not is left out; one the export has and the scan has not is text. The measured widths size the string columns.
    """
    scanned = {ROW_ORDER_COLUMN: {"type": "LONG"}} | {column.get("name"): column for column in dataset.get("columns") or []}
    if not widths:      # nothing measured (an empty export): the scan's own columns
        return [ColumnSpec(name=name, source_type=column.get("type") or "STRING") for name, column in scanned.items()]
    return [ColumnSpec(name=name, source_type=(scanned.get(name) or {}).get("type") or "STRING", max_bytes=width)
            for name, width in widths.items()]


def _exporter(ctx: RunContext):
    """The Domo exporter, or a clear explanation of what is missing.

    Injectable through the run options so a test -- and later a different
    source platform -- can substitute its own.
    """
    override = ctx.options.get("exporter")
    if override is not None:
        return override

    from bimcontrol.sources.domo import login  # noqa: PLC0415
    from bimcontrol.sources.domo.export import DomoExporter  # noqa: PLC0415

    try:
        session = login.get_session(
            ctx.project.get("source_instance"),
            allow_prompt=ctx.options.get("allow_prompt"),
        )
    except Exception as exc:
        raise WarehouseError(
            f"Landing needs a live Domo session to export from: {exc}"
        ) from exc
    return DomoExporter(session)

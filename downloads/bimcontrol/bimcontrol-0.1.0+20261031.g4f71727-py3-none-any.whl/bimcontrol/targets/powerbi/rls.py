"""Domo PDP (row-level security) as Power BI roles.

A Domo filter group says: these users see only the rows of this dataset
where `column` equals one of `values`. Several parameters in one group
all have to hold (AND across columns, OR across the values of a column).
Power BI expresses the same thing as a role with a DAX filter on the
table, and a user in several roles sees the union, which is also how
Domo combines several groups.

Only what has been seen in a real estate is translated: user-type groups
whose parameters are `COLUMN` + `EQUALS` with `not: false`. Anything else
is returned as unsupported rather than guessed, because a wrong RLS filter
shows people data they must not see (or hides data they need).

Roles are generated without members. Adding them needs a Domo user to
Entra user mapping that the estate does not hold.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from .model import Role, Table

NUMERIC_TYPES = {"LONG", "INTEGER", "DOUBLE", "DECIMAL"}


@dataclass
class Unsupported:
    group: str
    reason: str


@dataclass
class RlsResult:
    roles: list[Role] = field(default_factory=list)
    unsupported: list[Unsupported] = field(default_factory=list)
    # role name -> Domo user ids the role stands for (for the future mapping)
    domo_users: dict[str, list[str]] = field(default_factory=dict)


def _dax_literal(value: str, source_type: str) -> str | None:
    if source_type.upper() in NUMERIC_TYPES:
        try:
            float(value)
        except ValueError:
            return None
        return value
    return '"' + value.replace('"', '""') + '"'


def _role_name(table: str, group: str) -> str:
    # Role names become file names too.
    return re.sub(r'[\\/:*?"<>|]', "", f"{table} - {group}").strip()


def _group_expression(table: Table, group: dict[str, Any]) -> tuple[str | None, str | None]:
    """The DAX filter for one group, or (None, why it cannot be translated)."""
    if (group.get("type") or "user") != "user":
        return None, f"group type {group.get('type')!r} is not supported"
    parameters = group.get("parameters") or []
    if not parameters:
        return None, "no parameters"
    columns = {c.name.lower(): c for c in table.columns}
    by_column: dict[str, list[str]] = {}
    for parameter in parameters:
        if parameter.get("type") != "COLUMN" or parameter.get("operator") != "EQUALS":
            return None, f"parameter {parameter.get('name')!r}: {parameter.get('type')}/{parameter.get('operator')} is not supported"
        if parameter.get("not"):
            return None, f"parameter {parameter.get('name')!r} is negated"
        column = columns.get(str(parameter.get("name") or "").lower())
        if column is None:
            return None, f"column {parameter.get('name')!r} is not in the table"
        values = parameter.get("values") or ([parameter["value"]] if parameter.get("value") is not None else [])
        literals = [_dax_literal(str(v), column.source_type) for v in values]
        if not literals or None in literals:
            return None, f"parameter {parameter.get('name')!r} has values that do not fit {column.source_type}"
        by_column.setdefault(column.name, []).extend(literals)  # type: ignore[arg-type]
    table_ref = "'" + table.name.replace("'", "''") + "'"
    clauses = []
    for column_name, literals in by_column.items():
        unique = list(dict.fromkeys(literals))
        ref = f"{table_ref}[{column_name}]"
        clauses.append(f"{ref} = {unique[0]}" if len(unique) == 1 else f"{ref} IN {{{', '.join(unique)}}}")
    return " && ".join(clauses), None


def roles_for_table(table: Table, groups: list[dict[str, Any]] | None) -> RlsResult:
    """One role per distinct policy on this table; identical groups share one."""
    result = RlsResult()
    by_expression: dict[str, Role] = {}
    members: dict[str, list[str]] = {}
    names: dict[str, list[str]] = {}
    for group in groups or []:
        label = str(group.get("name") or group.get("filterGroupId") or "unnamed")
        expression, reason = _group_expression(table, group)
        if expression is None:
            result.unsupported.append(Unsupported(label, reason or "unsupported"))
            continue
        role = by_expression.get(expression)
        if role is None:
            name = _role_name(table.name, label)
            taken = {r.name for r in result.roles}
            n = 2
            while name in taken:
                name = f"{_role_name(table.name, label)} ({n})"
                n += 1
            role = Role(name=name, filters={table.name: expression}, origin=table.origin)
            by_expression[expression] = role
            result.roles.append(role)
            members[role.name] = []
            names[role.name] = []
        names[role.name].append(label)
        members[role.name] += [str(u) for u in group.get("userIds") or []]
    for role in result.roles:
        users = list(dict.fromkeys(members[role.name]))
        result.domo_users[role.name] = users
        role.description = (
            f"Migrated from Domo PDP filter group(s): {', '.join(names[role.name])}. "
            f"Stands for {len(users)} Domo user(s); no members assigned until a user mapping exists."
        )
    return result

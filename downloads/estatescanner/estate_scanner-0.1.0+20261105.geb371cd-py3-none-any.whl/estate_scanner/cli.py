from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

from . import adapters  # noqa: F401 -- import triggers every platform's registration
from . import bimdash, graph
from .core import registry
from .core.instances import AmbiguousInstance, normalise_instance
from .core.orchestrator import run_full_scan
from .core.platform import PlatformError
from .storage import db
from .storage.backup import NotEnoughDiskSpace
from .storage.migrate import MigrationFailed


def _get_client(conn, platform_key: str, instance: str, cookie_file: str | None):
    descriptor = registry.get_platform(platform_key)
    authenticator = descriptor.authenticator_cls()

    if cookie_file:
        session = authenticator.load_cookie_file(instance, cookie_file)
        db.persist_session(conn, session)
        return descriptor.client_cls(session)

    persisted = db.load_persisted_credentials(conn, platform_key, instance)
    if persisted is not None:
        session = authenticator.restore_session(instance, persisted)
        client = descriptor.client_cls(session)
        if client.verify_session():
            return client
        db.drop_persisted_session(conn, platform_key, instance)

    session = authenticator.login_interactive(instance)
    db.persist_session(conn, session)
    return descriptor.client_cls(session)


def cmd_platforms(args: argparse.Namespace) -> None:
    for descriptor in registry.all_platforms():
        print(f"{descriptor.key:<10} {descriptor.display_name:<15} {descriptor.status:<12} auth={descriptor.auth_mode}")


def cmd_login(args: argparse.Namespace) -> None:
    conn = db.connect(args.db_path or db.DEFAULT_DB_PATH)
    client = _get_client(conn, args.platform, args.instance, args.cookie_file)
    if not client.verify_session():
        print(f"Signed in to {args.platform}/{args.instance} but session verification failed.")
        sys.exit(1)
    print(f"Signed in to {args.platform}/{args.instance} and verified the session.")


def cmd_scan(args: argparse.Namespace) -> None:
    conn = db.connect(args.db_path or db.DEFAULT_DB_PATH)
    client = _get_client(conn, args.platform, args.instance, args.cookie_file)
    if args.skip_group_membership and hasattr(client, "fetch_group_memberships"):
        client.fetch_group_memberships = False

    def on_progress(event):
        total = f"of {event.total} " if event.total is not None else ""
        note = f" · {event.message}" if event.message else ""
        print(f"  {event.phase}: {event.completed} {total}· {event.elapsed_s:.1f}s elapsed{note}", flush=True)

    try:
        scan_id = run_full_scan(conn, client, args.platform, args.instance, on_progress=on_progress)
    except db.ScanAlreadyRunning as exc:
        print(exc, file=sys.stderr)
        sys.exit(1)
    print(f"Scan {scan_id} complete. Database: {args.db_path or db.DEFAULT_DB_PATH}")
    issues = conn.execute("SELECT phase, scope, message, http_status FROM scan_issues WHERE scan_id = ? ORDER BY id", (scan_id,)).fetchall()
    if issues:
        print(f"{len(issues)} thing(s) could not be read; the rest of the scan is complete:")
        for row in issues[:30]:
            status = f" (HTTP {row['http_status']})" if row["http_status"] else ""
            print(f"  [{row['phase']}] {row['scope']}: {row['message']}{status}")
        if len(issues) > 30:
            print(f"  ... and {len(issues) - 30} more, in the scan_issues table")


def cmd_graph_report(args: argparse.Namespace) -> None:
    conn = db.connect(args.db_path or db.DEFAULT_DB_PATH)
    g = graph.build_graph(conn, platform=args.platform, instance=args.instance)
    print(f"{g.number_of_nodes()} nodes, {g.number_of_edges()} edges")
    print()
    print("Most connected nodes:")
    for key, attrs, degree in graph.most_connected(g, top_n=args.top):
        print(f"  {degree:>4}  {attrs['platform']}/{attrs['type']:<17} {attrs['name'] or attrs['id']}")


def cmd_export(args: argparse.Namespace) -> None:
    from .export import export_scan, read_manifest

    try:
        path = export_scan(args.db_path or db.DEFAULT_DB_PATH, args.dest, platform=args.platform, instance=args.instance)
    except (FileNotFoundError, ValueError) as exc:
        print(exc)
        sys.exit(1)
    manifest = read_manifest(path)
    scope = manifest["scope"]
    print(f"Saved {path}: the {scope['platform']} estate {scope['instance']} (no sign-in session included). Attach it to an email to BI Migrations.")
    if manifest["other_estates_left_out"]:
        print(f"{manifest['other_estates_left_out']} other estate(s) in this file are not in the zip. "
              "Run again with --platform and --instance to export another.")


def cmd_delete_scan(args: argparse.Namespace) -> None:
    from pathlib import Path

    from .storage import delete

    db_path = Path(args.db_path or db.DEFAULT_DB_PATH)
    if not db_path.exists():
        print(f"There is no database at {db_path}. Nothing was deleted.", file=sys.stderr)
        sys.exit(1)
    conn = db.connect(db_path)
    try:
        # A scan row marked running is refused (a scan in another process is invisible otherwise);
        # the delete also takes the database's write lock before it copies or deletes anything.
        try:
            preview = delete.preview_delete_scan(conn, args.scan_id, abandoned=args.abandoned)
        except delete.DeleteRefused as exc:
            print(exc, file=sys.stderr)
            sys.exit(1)
        if preview.refusal:
            print("\n".join(preview.lines()), file=sys.stderr)
            sys.exit(1)
        if args.confirm is None:
            print("\n".join(preview.lines()))
            print("Nothing was deleted (no --confirm).", file=sys.stderr)
            sys.exit(1)
        try:
            result = delete.delete_scan(
                conn, args.scan_id, args.confirm, abandoned=args.abandoned, lock_wait_ms=int(args.lock_wait * 1000)
            )
        except delete.DeleteRefused as exc:
            print(exc, file=sys.stderr)
            sys.exit(1)
        print(f"Deleted scan {args.scan_id} of {preview.platform}/{preview.instance}.")
        print(f"Backup: {result.backup.path} ({result.backup.size_bytes / 1e6:.1f} MB), checked after it was written.")
        print("The backup does not hold the saved sign-in (you stay signed in). The app never deletes a backup; remove the file yourself when you no longer need it.")
        print("The database file does not shrink (no VACUUM); the freed space is reused by the next scan.")
    finally:
        conn.close()


def cmd_start_fresh(args: argparse.Namespace) -> None:
    from pathlib import Path

    from .storage import delete

    db_path = Path(args.db_path or db.DEFAULT_DB_PATH)
    if not db_path.exists():
        print(f"There is no database at {db_path}. Nothing was deleted.", file=sys.stderr)
        sys.exit(1)
    conn = db.connect(db_path)
    try:
        try:
            preview = delete.preview_start_fresh(conn, args.platform, args.instance, abandoned=args.abandoned)
        except delete.DeleteRefused as exc:
            print(exc, file=sys.stderr)
            sys.exit(1)
        if preview.refusal:
            print("\n".join(preview.lines()), file=sys.stderr)
            sys.exit(1)
        if args.confirm is None:
            print("\n".join(preview.lines()))
            print("Nothing was deleted (no --confirm).", file=sys.stderr)
            sys.exit(1)
        try:
            result = delete.start_fresh(
                conn, args.platform, args.instance, args.confirm, abandoned=args.abandoned, lock_wait_ms=int(args.lock_wait * 1000)
            )
        except delete.DeleteRefused as exc:
            print(exc, file=sys.stderr)
            sys.exit(1)
        print(f"Cleared {preview.platform}/{preview.instance}: scans, objects and edges are gone; the saved sign-in and other instances are untouched.")
        print(f"Backup: {result.backup.path} ({result.backup.size_bytes / 1e6:.1f} MB), checked after it was written.")
        print("The backup does not hold the saved sign-in (you stay signed in). The app never deletes a backup; remove the file yourself when you no longer need it.")
        print("The database file does not shrink (no VACUUM); the freed space is reused by the next scan.")
    finally:
        conn.close()


def _bimdash_dir(args: argparse.Namespace) -> Path:
    return Path(args.db_path or db.DEFAULT_DB_PATH).parent


def _org_label(shown: dict) -> str:
    # What the Connect page shows: the organisation's name, or its id when an
    # older BimDash answer names it not.
    return shown.get("org_name") or shown.get("org_id") or "BimDash"


def _print_bimdash_status(shown: dict) -> None:
    if shown.get("connected"):
        print(f"Connected to {_org_label(shown)} as '{shown['device_name']}' (paired {shown['paired_at']}).")
    else:
        print("Not connected to BimDash.")
        if shown.get("problem"):
            print(shown["problem"])


def cmd_connect(args: argparse.Namespace) -> None:
    directory = _bimdash_dir(args)
    if args.status:
        _print_bimdash_status(bimdash.status(directory))
        return
    code = args.code
    if not code:
        print("In BimDash, open the Scan your estate step: it shows a four-character code.")
        try:
            code = input("Code from BimDash: ")
        except EOFError:
            print("No code was given. Run: estate-scanner connect CODE", file=sys.stderr)
            sys.exit(1)
    shown = bimdash.connect(directory, code, args.name)
    print(f"Connected to {_org_label(shown)} as '{shown['device_name']}'. Only the pairing was done: no scan data was sent.")


def cmd_disconnect(args: argparse.Namespace) -> None:
    shown = bimdash.disconnect(_bimdash_dir(args))
    if shown.get("connected"):
        print("Could not disconnect.", file=sys.stderr)
        sys.exit(1)
    print("Disconnected: the saved BimDash code is removed from this machine. BimDash still lists the device until you remove it there (Devices).")


def cmd_ui(args: argparse.Namespace) -> None:
    try:
        from . import desktop
    except ImportError:
        print("The desktop UI needs the 'ui' extra: pip install 'estate-scanner[ui]'")
        sys.exit(1)
    if args.check:
        sys.exit(desktop.check(db_path=args.db_path))
    desktop.main(db_path=args.db_path, browser=args.browser)


def cmd_mac_app(args: argparse.Namespace) -> None:
    if sys.platform != "darwin":
        print("The Estate Scanner app is for macOS. On other systems run: estate-scanner ui")
        sys.exit(1)
    from . import macos_app

    try:
        bundle = macos_app.build_bundle(args.dest, verify=not args.no_verify)
    except macos_app.BundleError as exc:
        print(f"Could not create the Estate Scanner app: {exc}", file=sys.stderr)
        sys.exit(1)
    print(f"Created {bundle}")
    if args.open:
        subprocess.run(["open", str(bundle)], check=False)


def _delete_flags(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--abandoned", action="store_true",
        help="A scan row stuck at 'running' (the app was closed mid-scan) is refused by default, because a scan in another process looks the same. "
             "Pass this only when you know nothing is writing it",
    )
    parser.add_argument("--lock-wait", type=float, default=3.0, metavar="SECONDS", help="How long to wait for the database's write lock before refusing (default 3)")


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="estate-scanner")
    parser.add_argument("--db-path", default=None, help="SQLite database path (default: ~/.estate-scanner/estate.db)")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("platforms", help="List known BI platforms and their status").set_defaults(func=cmd_platforms)

    login = sub.add_parser("login", help="Sign in to a BI platform and persist the session")
    login.add_argument("instance", help="Platform instance/tenant name, e.g. yourcompany")
    login.add_argument("--platform", default="domo", help="Platform key (default: domo)")
    login.add_argument("--cookie-file", default=None, help="Domo only: JSON cookie file instead of interactive login")
    login.set_defaults(func=cmd_login)

    scan_cmd = sub.add_parser("scan", help="Run a full estate scan")
    scan_cmd.add_argument("instance", help="Platform instance/tenant name, e.g. yourcompany")
    scan_cmd.add_argument("--platform", default="domo", help="Platform key (default: domo)")
    scan_cmd.add_argument("--cookie-file", default=None, help="Domo only: JSON cookie file instead of interactive login")
    scan_cmd.add_argument("--skip-group-membership", action="store_true", help="Skip per-user group-membership lookups (one call per user; matters most on large orgs)")
    scan_cmd.set_defaults(func=cmd_scan)

    report = sub.add_parser("graph-report", help="Print the most-connected nodes in the estate graph")
    report.add_argument("--platform", default=None, help="Restrict to one platform (default: all)")
    report.add_argument("--instance", default=None, help="Which instance, when the database holds several of a platform")
    report.add_argument("--top", type=int, default=20)
    report.set_defaults(func=cmd_graph_report)

    export = sub.add_parser("export", help="Save the scan as a zip that is safe to email (sessions removed)")
    export.add_argument("--dest", default=None, help="Folder to save into (default: Documents)")
    export.add_argument("--platform", default=None, help="Which platform's estate to export (default: the latest completed scan's)")
    export.add_argument("--instance", default=None, help="Which instance to export (default: the latest completed scan's)")
    export.set_defaults(func=cmd_export)

    delete_scan = sub.add_parser("delete-scan", help="Delete the latest scan of an instance (preview first; --confirm to do it)")
    delete_scan.add_argument("scan_id", type=int, help="The scan's number (see the Scan screen)")
    delete_scan.add_argument("--confirm", default=None, help='Exactly the text the preview prints, e.g. "domo/acme scan 7"; without it nothing is deleted')
    _delete_flags(delete_scan)
    delete_scan.set_defaults(func=cmd_delete_scan)

    start_fresh = sub.add_parser("start-fresh", help="Clear one instance (all its scans and objects) so it can be scanned again; preview first, --confirm to do it")
    start_fresh.add_argument("instance", help="The instance as the Scan screen names it, e.g. yourcompany")
    start_fresh.add_argument("--platform", default="domo", help="Platform key (default: domo)")
    start_fresh.add_argument("--confirm", default=None, help='Exactly the text the preview prints, e.g. "domo/acme start fresh"; without it nothing is deleted')
    _delete_flags(start_fresh)
    start_fresh.set_defaults(func=cmd_start_fresh)

    connect = sub.add_parser("connect", help="Pair this machine with BimDash using the four-character code BimDash shows (for a machine without a window; the app's Connect to BimDash page does the same)")
    connect.add_argument("code", nargs="?", default=None, help="The code from BimDash (asked for when left out)")
    connect.add_argument("--name", default=None, help="How BimDash lists this machine (default: Estate Scanner on <this machine's name>)")
    connect.add_argument("--status", action="store_true", help="Show whether this machine is connected, and do nothing else")
    connect.set_defaults(func=cmd_connect)

    disconnect = sub.add_parser("disconnect", help="Remove the saved BimDash connection from this machine")
    disconnect.set_defaults(func=cmd_disconnect)

    ui = sub.add_parser("ui", help="Launch the desktop UI (pywebview + FastAPI)")
    ui.add_argument("--browser", action="store_true", help="Open in the default web browser instead of a native window")
    ui.add_argument("--check", action="store_true", help="Self-test: server answers and the native window backend imports")
    ui.set_defaults(func=cmd_ui)

    mac_app = sub.add_parser("mac-app", help="macOS: create the Estate Scanner app (own Dock icon and name) in ~/Applications")
    mac_app.add_argument("--dest", default=None, help="Folder to create it in (default: ~/Applications)")
    mac_app.add_argument("--open", action="store_true", help="Start it once it is created")
    mac_app.add_argument("--no-verify", action="store_true", help="Skip the self-test run against the new app")
    mac_app.set_defaults(func=cmd_mac_app)

    args = parser.parse_args(argv)
    if args.command in ("login", "scan"):
        args.instance = normalise_instance(args.platform, args.instance)  # one spelling, here and in the database
    try:
        args.func(args)
    except (PlatformError, AmbiguousInstance, NotEnoughDiskSpace, MigrationFailed, bimdash.BimdashError) as exc:
        print(f"{exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    sys.exit(main())

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from estate_scanner.core import registry
from estate_scanner.storage import db

from ..deps import get_conn
from ..jobs import jobs

router = APIRouter()


def _descriptor(key: str):
    try:
        return registry.get_platform(key)
    except KeyError:
        raise HTTPException(404, f"Unknown platform: {key}") from None


@router.get("")
def list_platforms():
    return [
        {"key": d.key, "display_name": d.display_name, "status": d.status, "auth_mode": d.auth_mode}
        for d in registry.all_platforms()
    ]


@router.get("/{key}/sessions")
def list_sessions(key: str, conn=Depends(get_conn)):
    _descriptor(key)
    rows = conn.execute(
        "SELECT instance, updated_at FROM platform_sessions WHERE platform = ? ORDER BY updated_at DESC", (key,)
    ).fetchall()
    return [{"instance": r["instance"], "updated_at": r["updated_at"]} for r in rows]


class ConnectRequest(BaseModel):
    instance: str
    cookie_file: str | None = None


@router.post("/{key}/connect")
def connect_platform(key: str, body: ConnectRequest, request: Request):
    """Kicks off sign-in in a background thread and returns immediately --
    for Domo this opens a real, visible browser window and can take minutes
    while a human completes SSO. Poll GET .../connect/{job_id} for status.
    """
    descriptor = _descriptor(key)
    db_path = request.app.state.db_path

    def do_connect(job):
        authenticator = descriptor.authenticator_cls()
        if body.cookie_file:
            session = authenticator.load_cookie_file(body.instance, body.cookie_file)
        else:
            session = authenticator.login_interactive(body.instance)
        conn = db.connect(db_path)
        try:
            db.persist_session(conn, session)
        finally:
            conn.close()
        return {"instance": body.instance}

    job = jobs.start("connect", do_connect)
    return {"job_id": job.id}


@router.get("/{key}/connect/{job_id}")
def connect_status(key: str, job_id: str):
    _descriptor(key)
    job = jobs.get(job_id)
    if job is None:
        raise HTTPException(404, "Unknown job")
    return {"status": job.status, "result": job.result, "error": job.error}

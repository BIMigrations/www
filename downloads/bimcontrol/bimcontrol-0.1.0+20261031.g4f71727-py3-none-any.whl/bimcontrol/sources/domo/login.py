"""Signing in to Domo, and keeping the session.

Until now BIMControl borrowed a cookie jar somebody exported by hand,
which is not a migration tool -- it is a migration tool plus a person.
This signs in properly and keeps the session under `~/.bimcontrol/auth`,
so a run picks it up, lends it to the converter when that service's own
session expires, and only asks for a human when the session is genuinely
dead.

The approach is EstateScanner's, for the same reason: Domo's private API
authenticates with the cookies its web app gets, so the only way to get
them is to let a real browser do a real sign-in -- SSO, MFA and all --
and then take what it was given. No API key, no OAuth app, nothing for
the customer to configure.

Deliberately **not** stored in the estate database. That file belongs to
EstateScanner and gets copied around; a live credential should not travel
with it. See estate/reader.py.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from bimcontrol import paths

from .session import DomoAuthError, DomoSession

# What the private API needs. Domo sets plenty more; these are the ones
# worth keeping, and keeping the set small limits what a stored file is
# worth to anybody who finds it.
WANTED_COOKIES = {
    "PLAY_SESSION", "SESSION_TOE", "_pubweb_idc", "csrf-token", "_dsidv1",
}
LOGIN_TIMEOUT_SECONDS = 600
# Any request that needs a session will do; this one is cheap.
PROBE = "/api/dataprocessing/v1/dataflows?limit=1"


def session_path(instance: str) -> Path:
    return paths.home() / "auth" / f"domo-{instance}.json"


def save(session: DomoSession) -> Path:
    path = session_path(session.instance)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"instance": session.instance, "cookies": session.cookies}))
    path.chmod(0o600)
    return path


def load(instance: str) -> DomoSession | None:
    """The stored session, if there is one. No network call."""
    path = session_path(instance)
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text())
    except ValueError:
        return None
    cookies = payload.get("cookies") or {}
    if not cookies:
        return None
    return DomoSession(instance=instance, cookies=cookies,
                       csrf_token=cookies.get("csrf-token"))


def forget(instance: str) -> bool:
    path = session_path(instance)
    if path.exists():
        path.unlink()
        return True
    return False


def is_valid(session: DomoSession, timeout: int = 30) -> bool:
    """Ask Domo whether the session still works."""
    http = session.requests_session()
    try:
        response = http.get(f"{session.base_url}{PROBE}", timeout=timeout)
    except Exception:  # noqa: BLE001 -- unreachable is not the same as invalid, but we cannot use it either
        return False
    return response.status_code == 200


def _launch_browser(playwright: Any) -> Any:
    """Prefer the machine's own Chrome or Edge so a packaged install needs no
    downloaded Chromium (`playwright install`); fall back to Playwright's own
    if someone has installed it."""
    last_error: Exception | None = None
    for channel in ("chrome", "msedge", None):
        try:
            if channel is None:
                return playwright.chromium.launch(headless=False)
            return playwright.chromium.launch(channel=channel, headless=False)
        except Exception as exc:  # noqa: BLE001 -- that browser is not installed
            last_error = exc
    raise DomoAuthError(
        "No browser found for the Domo sign-in. Install Google Chrome or Microsoft Edge and try again."
    ) from last_error


def login_interactive(instance: str, timeout_s: int = LOGIN_TIMEOUT_SECONDS) -> DomoSession:
    """Open a browser, wait for a human to sign in, keep the cookies.

    Polls an authenticated endpoint from inside the page rather than
    watching the URL, because an SSO flow can land anywhere and the only
    reliable signal that sign-in finished is that the API answers.
    """
    try:
        from playwright.sync_api import sync_playwright  # noqa: PLC0415 -- optional extra
    except ImportError as exc:
        raise DomoAuthError(
            "Signing in to Domo needs the 'domo' extra: pip install 'bimcontrol[domo]'"
        ) from exc

    base_url = f"https://{instance}.domo.com"
    with sync_playwright() as playwright:
        browser = _launch_browser(playwright)
        context = browser.new_context()
        page = context.new_page()
        page.goto(base_url, wait_until="domcontentloaded")

        deadline = timeout_s * 1000
        waited = 0
        while waited < deadline:
            page.wait_for_timeout(2000)
            waited += 2000
            try:
                status = page.evaluate(
                    "url => fetch(url, {credentials:'include'}).then(r => r.status).catch(() => 0)",
                    PROBE,
                )
            except Exception:  # noqa: BLE001 -- navigation mid-evaluate is normal during SSO
                continue
            if status == 200:
                break
        else:
            browser.close()
            raise DomoAuthError(f"No Domo sign-in completed within {timeout_s}s")

        cookies = {
            c["name"]: c["value"]
            for c in context.cookies()
            if "domo.com" in (c.get("domain") or "") and
            (c["name"] in WANTED_COOKIES or c["name"].startswith("DA-SID"))
        }
        browser.close()

    if not cookies:
        raise DomoAuthError("Signed in, but Domo set no session cookies we recognise")
    session = DomoSession(instance=instance, cookies=cookies,
                          csrf_token=cookies.get("csrf-token"))
    save(session)
    return session


def prompting_allowed(explicit: bool | None = None) -> bool:
    """Whether opening a browser is acceptable here.

    `BIMCONTROL_ALLOW_PROMPT=0` turns it off for anywhere a browser would
    be wrong -- a swarm node, CI, a test. Without this a non-interactive
    run does not fail, which would be fine; it *hangs* for ten minutes
    waiting at a window nobody can see, which is worse.
    """
    if explicit is not None:
        return explicit
    return os.environ.get("BIMCONTROL_ALLOW_PROMPT", "1") not in ("0", "false", "no")


def get_session(instance: str, allow_prompt: bool | None = None) -> DomoSession:
    """A working session: stored, from the environment, or a fresh sign-in.

    Checked against Domo before being handed out, because a stored session
    that has quietly expired fails later and further from the cause --
    inside a converter job, say, half way through a migration.
    """
    allow_prompt = prompting_allowed(allow_prompt)
    stored = load(instance)
    if stored and is_valid(stored):
        return stored

    cookie_file = os.environ.get("DOMO_COOKIE_FILE")
    if cookie_file and Path(cookie_file).expanduser().exists():
        from_file = DomoSession.from_cookie_file(instance, cookie_file)
        if is_valid(from_file):
            save(from_file)
            return from_file

    if not allow_prompt:
        raise DomoAuthError(
            f"No valid Domo session for {instance!r} and prompting is disabled. "
            f"Run `bimcontrol domo --login {instance}` on this machine."
        )
    return login_interactive(instance)

"""Row-level policies as the Estate screen shows them.

A platform stores its policies in `datasets.pdp_json` in its own shape (Domo: PDP filter groups; Power
BI: model roles). Its adapter registers a `describe_policies` that reads that shape into the common one
below; this module only decides what the stored value means and falls back for a platform with no reader.

A policy is {name, applies_to, filters, access}:
  applies_to  [{"kind": "user" | "group" | "virtual_user" | "member", "id": str} or {"kind": "member", "label": str}]
              empty when the stored policy does not say (the screen says so; it does not guess)
  filters     one readable line per filter, e.g. "Dept No = 19283"
  access      what the policy grants, where the platform says (Power BI: "read")
"""

from __future__ import annotations

import json

from .registry import get_platform


def policy_status(pdp_json: str | None) -> str:
    """'not_captured' (null, or something that is not a list), 'none' ([]), or 'policies'."""
    if pdp_json is None:
        return "not_captured"
    try:
        value = json.loads(pdp_json)
    except ValueError:
        return "not_captured"
    if not isinstance(value, list):
        return "not_captured"
    return "policies" if value else "none"


def describe(platform: str, pdp_json: str | None) -> list[dict]:
    """The dataset's policies in the common shape; [] unless policy_status is 'policies'."""
    if policy_status(pdp_json) != "policies":
        return []
    policies = json.loads(pdp_json)
    try:
        reader = get_platform(platform).describe_policies
    except KeyError:
        reader = None
    if reader is None:
        return [_unread(p) for p in policies]
    try:
        return reader(policies)
    except (KeyError, TypeError, ValueError, AttributeError):
        return [_unread(p) for p in policies]


def _unread(policy) -> dict:
    name = policy.get("name") if isinstance(policy, dict) else None
    return {"name": name, "applies_to": [], "filters": [], "access": None}

import React from 'react';

// Customer: where a whole batch stands, read from the rollup that
// `bimcontrol customer <manifest>` writes after every dashboard.
//
// The table only reads that file, so it follows a batch started from a
// terminal as well (it re-reads every 20 seconds, every 4 while a batch
// started here is running). Starting and stopping a batch from this screen is
// BatchPanel.jsx.
//
// Only `proven` is shown as success. Every other outcome reads as work
// left, and `figures_differ` leads with the differing values nothing
// explains, because those are the ones to triage: a difference on data that
// moved since Domo's figures were made is evidence, not a verdict, and
// never turns an outcome green.

// Worst first. The outcome names are the rollup's own (core/customer.py);
// the wording is what a reader sees.
const OUTCOME_ORDER = [
  'failed', 'figures_differ', 'incomplete', 'unverified', 'proven_partial',
  'pending', 'no_data', 'no_cards', 'proven',
];

const OUTCOMES = {
  proven: { label: 'Proven', tone: 'target', hint: 'Every compared figure matches Domo' },
  proven_partial: { label: 'Proven in part', tone: 'warn', hint: 'Nothing compared differs, but some visuals were not compared' },
  figures_differ: { label: 'Figures differ', tone: 'error', hint: 'Some figures are not what Domo returns' },
  unverified: { label: 'Not verified', tone: 'warn', hint: 'Ran, but no figure was compared' },
  failed: { label: 'Failed', tone: 'error', hint: 'The run stopped with an error' },
  incomplete: { label: 'Incomplete', tone: 'warn', hint: 'The run has not finished' },
  no_cards: { label: 'No cards', tone: 'neutral', hint: 'Nothing on the dashboard in the scan' },
  no_data: { label: 'No data', tone: 'neutral', hint: 'Only text cards: nothing to build' },
  pending: { label: 'Not run', tone: 'neutral', hint: 'No run yet' },
};

export function customerOutcome(key) {
  return OUTCOMES[key] || { label: String(key || '').replace(/_/g, ' '), tone: 'neutral', hint: '' };
}

// Differing values nothing explains. A figures_differ row without a cause
// split (older rollups) counts as all-unexplained: unknown is not excused.
export function unexplainedValues(row) {
  const values = row.causes && row.causes.values;
  if (!values) return row.parity ? (row.parity.error || 0) : 0;
  return values.unexplained || 0;
}

export function sortCustomerRows(rows, order) {
  const copy = (rows || []).slice();
  if (order === 'name') {
    return copy.sort(function (a, b) { return String(a.name || '').localeCompare(String(b.name || '')); });
  }
  return copy.sort(function (a, b) {
    const rank = OUTCOME_ORDER.indexOf(a.outcome) - OUTCOME_ORDER.indexOf(b.outcome);
    if (rank) return rank;
    if (a.outcome === 'figures_differ') {
      const open = unexplainedValues(b) - unexplainedValues(a);
      if (open) return open;
    }
    return String(a.name || '').localeCompare(String(b.name || ''));
  });
}

export function CustomerScreen({ onOpenRun }) {
  const [customers, setCustomers] = React.useState(null);
  const [name, setName] = React.useState(null);
  const [rollup, setRollup] = React.useState(null);
  const [filter, setFilter] = React.useState('');
  const [order, setOrder] = React.useState('worst');
  const [error, setError] = React.useState(null);
  const [batch, setBatch] = React.useState(null);        // { batch, manifest } of the selected customer
  const [reload, setReload] = React.useState(0);
  const [batchError, setBatchError] = React.useState(null);

  function loadCustomers(select) {
    fetchCustomers().then(function (body) {
      setCustomers(body.items);
      if (select) setName(select);
      else if (body.items.length) setName(function (current) { return current || body.items[0].name; });
    }, function (e) { setError(e.message); setCustomers([]); });
  }

  React.useEffect(function () { loadCustomers(null); }, []);

  const batchRunning = !!(batch && batch.batch && batch.batch.running);

  // Another customer: nothing of the last one stays on screen.
  React.useEffect(function () {
    setRollup(null);
    setBatch(null);
    setBatchError(null);
    setFilter('');
  }, [name]);

  // Reads the rollup and the batch; again every 20 s, every 4 s while a batch started here is running. Starting or
  // stopping one reads at once (`reload`) without clearing what is shown.
  React.useEffect(function () {
    if (!name) return undefined;
    let stale = false;
    function load() {
      fetchCustomer(name).then(function (body) {
        if (!stale) { setRollup(body); setError(null); }
      }, function (e) {
        // A batch that has only just started has no rollup until its first dashboard is looked at: not an error.
        if (!stale) setError(/^No rollup for customer/.test(e.message) ? null : e.message);
      });
      fetchBatch(name).then(function (body) {
        if (!stale) { setBatch(body); setBatchError(null); }
      }, function (e) { if (!stale) setBatchError(e.message); });
      // A customer that had no rollup when the batch started is in the list once its first dashboard has been looked at.
      fetchCustomers().then(function (body) { if (!stale) setCustomers(body.items); }, function () {});
    }
    load();
    const timer = setInterval(load, batchRunning ? 4000 : 20000);
    return function () { stale = true; clearInterval(timer); };
  }, [name, batchRunning, reload]);

  // A batch was started (maybe for a customer that had no rollup yet): list again and look at it.
  function started(status) {
    setBatch({ batch: status, manifest: null });
    setRollup(null);
    loadCustomers(status.key);
    setReload(function (n) { return n + 1; });
  }

  if (customers === null) {
    return <Main><div style={{ padding: 20 }}><Spinner /></div></Main>;
  }
  if (customers.length === 0 && !name && error) {
    return <Main><div style={{ padding: 20 }}><ErrorBanner error={error} title="Could not list the customer batches" /></div></Main>;
  }
  if (customers.length === 0 && !name) {
    return (
      <Main>
        <PageHeader title="No customer batch" accent="yet."
          meta="Choose the dashboards of a customer; the batch runs them one after another and the results appear here." />
        <div style={{ padding: '18px 20px 20px', overflow: 'auto' }}>
          <NewBatchForm initial={null} customer="" running={false} onStarted={started} />
        </div>
      </Main>
    );
  }

  const tally = (rollup && rollup.tally) || {};
  const rows = (rollup && rollup.rows) || [];
  const shown = sortCustomerRows(filter ? rows.filter(function (r) { return r.outcome === filter; }) : rows, order);
  const present = OUTCOME_ORDER.filter(function (key) { return tally[key]; });
  const proven = tally.proven || 0;

  const columns = [
    {
      key: 'name', header: 'Dashboard', minWidth: 240,
      render: function (r) {
        return (
          <span>
            {r.name || r.dashboard_id}
            <span className="bit-num" style={{ color: 'var(--text-tertiary)', marginLeft: 8, fontSize: 'var(--text-xs)' }}>
              {r.dashboard_id}
            </span>
          </span>
        );
      },
    },
    {
      key: 'outcome', header: 'Outcome', width: 150,
      render: function (r) {
        const o = customerOutcome(r.outcome);
        return <Badge tone={o.tone} dot title={o.hint}>{o.label}</Badge>;
      },
    },
    {
      key: 'parity', header: 'Parity', width: 170, mono: true,
      render: function (r) {
        if (!r.parity) return <span style={{ color: 'var(--text-tertiary)' }}>not compared</span>;
        return (
          <span>
            {formatCount(r.parity.ok)} ok / <span style={{ color: r.parity.error ? 'var(--status-error)' : undefined }}>
              {formatCount(r.parity.error)} differ</span>
          </span>
        );
      },
    },
    {
      key: 'elements', header: 'Elements', minWidth: 250, mono: true,
      render: function (r) {
        const e = r.elements;
        if (!e) return <span style={{ color: 'var(--text-tertiary)' }}>no status yet</span>;
        return (
          <span>
            {formatCount(e.matches)} match · <span style={{ color: e.differs ? 'var(--status-warn)' : undefined }}>{formatCount(e.differs)} differ</span>
            {' · '}{formatCount(e.not_compared)} not compared · <span style={{ color: e.not_migrated ? 'var(--status-error)' : undefined }}>
              {formatCount(e.not_migrated)} not migrated</span>
          </span>
        );
      },
    },
    {
      key: 'cards', header: 'Cards', width: 80, align: 'right', mono: true,
      render: function (r) {
        return r.cards === null || r.cards === undefined ? '--' : formatCount(r.visuals) + '/' + formatCount(r.cards);
      },
    },
    {
      key: 'causes', header: 'Differing values', minWidth: 300,
      render: function (r) { return <CauseSplit row={r} />; },
    },
    {
      key: 'open', header: '', width: 120, align: 'right',
      render: function (r) {
        return r.run_id ? (
          <Button variant="secondary" size="sm" onClick={function () { onOpenRun(r.run_id); }}>
            Open parity
          </Button>
        ) : null;
      },
    },
  ];

  return (
    <Main>
      <PageHeader
        title={(rollup && rollup.customer) || name}
        accent="batch."
        meta={rollup
          ? <span><span className="bit-num">{formatCount(rollup.dashboards)}</span> dashboards
            {' · '}<span className="bit-num">{formatCount(proven)}</span> proven
            {rollup.generated_at ? ' · rollup written ' + String(rollup.generated_at).slice(0, 19).replace('T', ' ') : ''}
            {rollup.stopped ? ' · ' + rollup.stopped : ''}</span>
          : 'Loading the rollup.'} />

      <ErrorBanner error={error} title="Could not read that rollup" />

      <div style={{ flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column', padding: '18px 20px 20px', gap: 'var(--space-7)', overflow: 'hidden' }}>
        <ErrorBanner error={batchError} title="Could not read the batch status" />
        <BatchStatus batch={batchError ? null : batch && batch.batch} name={name} onChange={function () { setReload(function (n) { return n + 1; }); }} />
        <details>
          <summary style={{ cursor: 'pointer', fontSize: 'var(--text-sm)', color: 'var(--text-secondary)' }}>
            {batchRunning ? 'The batch manifest' : 'Start a batch'}
          </summary>
          <div style={{ paddingTop: 'var(--space-5)', maxHeight: 420, overflow: 'auto' }}>
            <NewBatchForm initial={batch && batch.manifest} customer={(rollup && rollup.customer) || name} slot={name}
              running={batchRunning} onStarted={started} />
          </div>
        </details>
        <div style={{ display: 'flex', gap: 'var(--space-7)', flexWrap: 'wrap' }}>
          {present.map(function (key) {
            const o = customerOutcome(key);
            return (
              <StatTile key={key} size="sm" tone={key === 'proven' ? 'target' : 'neutral'}
                value={formatCount(tally[key])} label={o.label} />
            );
          })}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-5)' }}>
          {customers.length > 1 ? (
            <Select size="sm" value={name || ''} style={{ width: 220 }}
              options={customers.map(function (c) { return { value: c.name, label: c.customer }; })}
              onChange={function (e) { setName(e.target.value); }} />
          ) : null}
          <Select size="sm" value={filter} style={{ width: 220 }}
            options={[{ value: '', label: 'All outcomes (' + formatCount(rows.length) + ')' }].concat(
              present.map(function (key) {
                return { value: key, label: customerOutcome(key).label + ' (' + formatCount(tally[key]) + ')' };
              }))}
            onChange={function (e) { setFilter(e.target.value); }} />
          <Tabs variant="segmented" value={order} onChange={setOrder} tabs={[
            { value: 'worst', label: 'Worst first' },
            { value: 'name', label: 'By name' },
          ]} />
          <div style={{ flex: 1 }} />
          <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-secondary)', fontFamily: 'var(--font-mono)' }}>
            {formatCount(shown.length)} of {formatCount(rows.length)}
          </div>
        </div>

        <div style={{ flex: 1, minHeight: 0, overflow: 'auto', border: '1px solid var(--border-hairline)', borderRadius: 'var(--radius-card)', background: 'var(--surface-card)' }}>
          <DataTable columns={columns} rows={shown} stickyHeader zebra
            emptyLabel={rollup ? 'No dashboards with that outcome.' : 'The first dashboard has not been looked at yet.'} />
        </div>
      </div>
    </Main>
  );
}

// What the row says beyond its outcome. For figures_differ the unexplained
// values come first and in the error tone; the two causes that point at the
// data rather than the conversion follow, quieter.
export function CauseSplit({ row }) {
  const quiet = { color: 'var(--text-tertiary)', fontSize: 'var(--text-sm)' };
  if (row.outcome === 'figures_differ') {
    const values = row.causes && row.causes.values;
    if (!values) {
      return <span style={quiet}>cause not worked out; treat all {formatCount(unexplainedValues(row))} as unexplained</span>;
    }
    return (
      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
        <Badge tone={values.unexplained ? 'error' : 'neutral'} variant={values.unexplained ? 'solid' : 'soft'} mono>
          {formatCount(values.unexplained || 0)} unexplained
        </Badge>
        <span className="bit-num" style={quiet}>
          {formatCount(values.row_count || 0)} row count · {formatCount(values.stale_input || 0)} stale input · {formatCount(values.case_collapse || 0)} letter case{values.source_moved ? ' · ' + formatCount(values.source_moved) + ' source moved' : ''}{values.run_date ? ' · ' + formatCount(values.run_date) + ' run date' : ''}
        </span>
      </span>
    );
  }
  if (row.outcome === 'failed') {
    return <span style={quiet}>{(row.error_stage ? row.error_stage + ': ' : '') + String(row.error || '').slice(0, 120)}</span>;
  }
  const cov = row.coverage;
  if (row.outcome === 'proven_partial' && cov) {
    return <span style={quiet}>compared {formatCount(cov.compared)} of {formatCount(cov.data_visuals)} data visuals</span>;
  }
  if (row.outcome === 'proven') return null;
  // Anything short of proven says why in words, so a blank cell never reads as fine.
  return <span style={quiet}>{row.note || customerOutcome(row.outcome).hint}</span>;
}

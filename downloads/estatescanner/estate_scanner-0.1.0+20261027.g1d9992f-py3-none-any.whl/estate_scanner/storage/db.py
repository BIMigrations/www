"""SQLite connection, schema management, and the typed upsert layer.

Platform-agnostic: every function here takes a `platform` string and never
imports anything from estate_scanner.adapters.*. The 10 explicit
`_upsert_<type>` functions (kept explicit rather than reflection-driven --
each type has genuinely different columns) are the only place a
core.models dataclass gets turned into SQL.
"""

from __future__ import annotations

import datetime as _dt
import importlib.resources
import json
import sqlite3
from pathlib import Path

DEFAULT_DB_PATH = Path.home() / ".estate-scanner" / "estate.db"


def connect(db_path: Path | str = DEFAULT_DB_PATH) -> sqlite3.Connection:
    db_path = Path(db_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    # check_same_thread=False: FastAPI's sync dependencies and sync endpoint
    # functions each get dispatched to anyio's worker threadpool
    # independently, with no guaranteed thread affinity between a
    # generator dependency (e.g. webapp/deps.py's get_conn) and the
    # endpoint that consumes what it yields -- even within one request.
    # Safe here because each request/background job still gets its own
    # fresh connection, opened and closed within that one request/job, and
    # is never shared across concurrent requests.
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    # A scan holds write locks for as long as it takes to process a batch of
    # objects (see orchestrator.py's periodic commit) -- without this, any
    # other connection opened while that's in flight (e.g. the webapp
    # starting up to show scan progress) fails immediately with "database
    # is locked" instead of just waiting the brief moment it actually needs.
    conn.execute("PRAGMA busy_timeout = 10000")
    # Foreign keys are intentionally NOT enforced: schema.sql's REFERENCES
    # clauses are documentation of intent, not hard constraints. Real BI
    # platform data has dangling references (deleted owners, objects outside
    # the scan's permission scope, etc.) that would otherwise abort a scan.
    init_schema(conn)
    _migrate_schema(conn)
    return conn


def init_schema(conn: sqlite3.Connection) -> None:
    schema_sql = importlib.resources.files("estate_scanner.storage").joinpath("schema.sql").read_text()
    conn.executescript(schema_sql)
    conn.commit()


# Columns added to a table after its first release. "CREATE TABLE IF NOT
# EXISTS" in schema.sql is a no-op against a database file created by an
# older version, so a returning customer's db needs these added by hand,
# once, here -- otherwise the very next scan crashes on the first upsert
# into that table.
_ADDED_COLUMNS: list[tuple[str, str, str]] = [
    ("dataflows", "definition_json", "TEXT"),
    ("cards", "definition_json", "TEXT"),
    ("datasets", "pdp_json", "TEXT"),
    ("datasets", "definition_json", "TEXT"),
    ("dashboards", "layout_json", "TEXT"),
    ("calculated_fields", "definition_json", "TEXT"),
    ("apps", "views_json", "TEXT"),
    ("apps", "navigations_json", "TEXT"),
    ("apps", "theme_json", "TEXT"),
]


def _migrate_schema(conn: sqlite3.Connection) -> None:
    for table, column, coltype in _ADDED_COLUMNS:
        existing = {row[1] for row in conn.execute(f"PRAGMA table_info({table})")}
        if column not in existing:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {coltype}")
    conn.commit()


def _iso(value) -> str | None:
    if value is None:
        return None
    if isinstance(value, _dt.datetime):
        return value.isoformat()
    return str(value)


def _json(value) -> str | None:
    return None if value is None else json.dumps(value, default=str)


# -- Scan lifecycle -----------------------------------------------------------


def start_scan(conn: sqlite3.Connection, platform: str, instance: str, notes: str | None = None) -> int:
    cur = conn.execute(
        "INSERT INTO scans (platform, instance, started_at, status, notes) VALUES (?, ?, ?, 'running', ?)",
        (platform, instance, _dt.datetime.now(_dt.timezone.utc).isoformat(), notes),
    )
    conn.commit()
    return cur.lastrowid


def finish_scan(conn: sqlite3.Connection, scan_id: int, status: str = "completed") -> None:
    conn.execute(
        "UPDATE scans SET finished_at = ?, status = ? WHERE id = ?",
        (_dt.datetime.now(_dt.timezone.utc).isoformat(), status, scan_id),
    )
    conn.commit()


def record_issue(conn: sqlite3.Connection, scan_id: int, phase: str, issue) -> None:
    """One thing the scan could not read (see core.models.ScanIssue)."""
    conn.execute(
        "INSERT INTO scan_issues (scan_id, phase, scope, message, http_status, recorded_at) VALUES (?, ?, ?, ?, ?, ?)",
        (scan_id, phase, issue.scope, issue.message, issue.status, _dt.datetime.now(_dt.timezone.utc).isoformat()),
    )


# -- Session persistence -------------------------------------------------
# The platform_sessions table is platform-agnostic (a bare (platform,
# instance) -> opaque credentials_json blob); only the serialization inside
# that blob is adapter-specific, via PlatformSession.to/from_persisted_dict.


def persist_session(conn: sqlite3.Connection, session) -> None:
    conn.execute(
        """INSERT INTO platform_sessions (platform, instance, credentials_json, updated_at)
           VALUES (?, ?, ?, ?)
           ON CONFLICT(platform, instance) DO UPDATE SET
             credentials_json = excluded.credentials_json, updated_at = excluded.updated_at""",
        (session.platform, session.instance, _json(session.to_persisted_dict()), _dt.datetime.now(_dt.timezone.utc).isoformat()),
    )
    conn.commit()


def load_persisted_credentials(conn: sqlite3.Connection, platform: str, instance: str) -> dict | None:
    """Returns the raw persisted credentials dict, or None. Reconstructing
    an actual PlatformSession from it is the authenticator's job (via
    `authenticator.restore_session(instance, credentials)`) -- storage
    shouldn't need to know about any specific Session subclass."""
    row = conn.execute(
        "SELECT credentials_json FROM platform_sessions WHERE platform = ? AND instance = ?", (platform, instance)
    ).fetchone()
    return None if row is None else json.loads(row["credentials_json"])


def drop_persisted_session(conn: sqlite3.Connection, platform: str, instance: str) -> None:
    conn.execute("DELETE FROM platform_sessions WHERE platform = ? AND instance = ?", (platform, instance))
    conn.commit()


def record_raw(
    conn: sqlite3.Connection,
    scan_id: int,
    platform: str,
    object_type: str,
    object_id: str | None,
    endpoint: str,
    body_json: str,
) -> None:
    conn.execute(
        """INSERT INTO raw_objects (platform, scan_id, object_type, object_id, endpoint, fetched_at, body_json)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (platform, scan_id, object_type, object_id, endpoint, _dt.datetime.now(_dt.timezone.utc).isoformat(), body_json),
    )


def upsert_edge(
    conn: sqlite3.Connection,
    platform: str,
    src_type: str,
    src_id: str,
    dst_type: str,
    dst_id: str,
    edge_type: str,
    scan_id: int,
    weight: float = 1.0,
    raw_json: str | None = None,
) -> None:
    conn.execute(
        """INSERT INTO edges (platform, src_type, src_id, dst_type, dst_id, edge_type, weight, raw_json, scan_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(platform, src_type, src_id, dst_type, dst_id, edge_type)
           DO UPDATE SET weight = excluded.weight, raw_json = excluded.raw_json, scan_id = excluded.scan_id""",
        (platform, src_type, src_id, dst_type, dst_id, edge_type, weight, raw_json, scan_id),
    )


# -- Typed object upserts ------------------------------------------------------


def _upsert_user(conn, platform, obj, scan_id) -> None:
    conn.execute(
        """INSERT INTO users (platform, id, name, email, role, title, raw_json, first_seen_scan_id, last_seen_scan_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(platform, id) DO UPDATE SET
             name = excluded.name, email = excluded.email, role = excluded.role, title = excluded.title,
             raw_json = excluded.raw_json, last_seen_scan_id = excluded.last_seen_scan_id""",
        (platform, obj.id, obj.name, obj.email, obj.role, obj.title, _json(obj.raw_payload), scan_id, scan_id),
    )


def _upsert_group(conn, platform, obj, scan_id) -> None:
    conn.execute(
        """INSERT INTO groups_ (platform, id, name, raw_json, first_seen_scan_id, last_seen_scan_id)
           VALUES (?, ?, ?, ?, ?, ?)
           ON CONFLICT(platform, id) DO UPDATE SET
             name = excluded.name, raw_json = excluded.raw_json, last_seen_scan_id = excluded.last_seen_scan_id""",
        (platform, obj.id, obj.name, _json(obj.raw_payload), scan_id, scan_id),
    )


def _upsert_account(conn, platform, obj, scan_id) -> None:
    conn.execute(
        """INSERT INTO accounts (platform, id, name, connector_type, owner_id, raw_json, first_seen_scan_id, last_seen_scan_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(platform, id) DO UPDATE SET
             name = excluded.name, connector_type = excluded.connector_type, owner_id = excluded.owner_id,
             raw_json = excluded.raw_json, last_seen_scan_id = excluded.last_seen_scan_id""",
        (platform, obj.id, obj.name, obj.connector_type, obj.owner_id, _json(obj.raw_payload), scan_id, scan_id),
    )


def _upsert_dataset(conn, platform, obj, scan_id) -> None:
    conn.execute(
        """INSERT INTO datasets
             (platform, id, name, provider_type, stream_id, schema_columns_json, row_count, column_count,
              owner_id, created_at, updated_at, is_deleted,
              downstream_card_count, downstream_dataflow_count, downstream_dataset_count, downstream_alert_count,
              pdp_json, definition_json, raw_json, first_seen_scan_id, last_seen_scan_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(platform, id) DO UPDATE SET
             name = excluded.name, provider_type = excluded.provider_type, stream_id = excluded.stream_id,
             schema_columns_json = excluded.schema_columns_json, row_count = excluded.row_count,
             column_count = excluded.column_count, owner_id = excluded.owner_id,
             created_at = excluded.created_at, updated_at = excluded.updated_at, is_deleted = excluded.is_deleted,
             downstream_card_count = excluded.downstream_card_count,
             downstream_dataflow_count = excluded.downstream_dataflow_count,
             downstream_dataset_count = excluded.downstream_dataset_count,
             downstream_alert_count = excluded.downstream_alert_count,
             pdp_json = excluded.pdp_json, definition_json = excluded.definition_json,
             raw_json = excluded.raw_json, last_seen_scan_id = excluded.last_seen_scan_id""",
        (
            platform, obj.id, obj.name, obj.provider_type, obj.stream_id, _json(obj.schema_columns),
            obj.row_count, obj.column_count, obj.owner_id, _iso(obj.created_at), _iso(obj.updated_at),
            int(obj.is_deleted), obj.downstream_card_count, obj.downstream_dataflow_count,
            obj.downstream_dataset_count, obj.downstream_alert_count, _json(obj.pdp_policies),
            _json(obj.definition), _json(obj.raw_payload), scan_id, scan_id,
        ),
    )


def _upsert_dataflow(conn, platform, obj, scan_id) -> None:
    conn.execute(
        """INSERT INTO dataflows
             (platform, id, name, engine, is_deleted, num_inputs, num_outputs,
              last_execution_state, last_execution_failed, modified_at, owner_id, definition_json, raw_json,
              first_seen_scan_id, last_seen_scan_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(platform, id) DO UPDATE SET
             name = excluded.name, engine = excluded.engine, is_deleted = excluded.is_deleted,
             num_inputs = excluded.num_inputs, num_outputs = excluded.num_outputs,
             last_execution_state = excluded.last_execution_state,
             last_execution_failed = excluded.last_execution_failed,
             modified_at = excluded.modified_at, owner_id = excluded.owner_id,
             definition_json = excluded.definition_json, raw_json = excluded.raw_json,
             last_seen_scan_id = excluded.last_seen_scan_id""",
        (
            platform, obj.id, obj.name, obj.engine, int(obj.is_deleted),
            len(obj.input_dataset_ids), len(obj.output_dataset_ids),
            obj.last_run_state, None if obj.last_run_failed is None else int(obj.last_run_failed),
            _iso(obj.last_run_at), obj.owner_id, _json(obj.definition), _json(obj.raw_payload), scan_id, scan_id,
        ),
    )


def _upsert_card(conn, platform, obj, scan_id) -> None:
    conn.execute(
        """INSERT INTO cards (platform, id, name, type, owner_id, dataset_id, definition_json, raw_json, first_seen_scan_id, last_seen_scan_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(platform, id) DO UPDATE SET
             name = excluded.name, type = excluded.type, owner_id = excluded.owner_id,
             dataset_id = excluded.dataset_id, definition_json = excluded.definition_json, raw_json = excluded.raw_json,
             last_seen_scan_id = excluded.last_seen_scan_id""",
        (
            platform, obj.id, obj.name, obj.card_type, obj.owner_id,
            obj.dataset_ids[0] if obj.dataset_ids else None, _json(obj.definition), _json(obj.raw_payload), scan_id, scan_id,
        ),
    )


def _upsert_dashboard(conn, platform, obj, scan_id) -> None:
    filters = [
        {"field": f.field, "label": f.label, "filterType": f.filter_type, "raw": f.raw_payload}
        for f in obj.filters
    ]
    conn.execute(
        """INSERT INTO dashboards (platform, id, name, parent_dashboard_id, owner_id, filters_json, layout_json, raw_json, first_seen_scan_id, last_seen_scan_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(platform, id) DO UPDATE SET
             name = excluded.name, parent_dashboard_id = excluded.parent_dashboard_id, owner_id = excluded.owner_id,
             filters_json = excluded.filters_json, layout_json = excluded.layout_json, raw_json = excluded.raw_json,
             last_seen_scan_id = excluded.last_seen_scan_id""",
        (platform, obj.id, obj.name, obj.parent_id, obj.owner_id, _json(filters), _json(obj.layout), _json(obj.raw_payload), scan_id, scan_id),
    )


def _upsert_app(conn, platform, obj, scan_id) -> None:
    views = [
        {"viewId": v.view_id, "title": v.title, "parentViewId": v.parent_view_id, "viewOrder": v.view_order, "visible": v.visible}
        for v in obj.views
    ]
    conn.execute(
        """INSERT INTO apps (platform, id, name, type, owner_id, landing_dashboard_id, views_json, navigations_json, theme_json, raw_json, first_seen_scan_id, last_seen_scan_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(platform, id) DO UPDATE SET
             name = excluded.name, type = excluded.type, owner_id = excluded.owner_id,
             landing_dashboard_id = excluded.landing_dashboard_id, views_json = excluded.views_json,
             navigations_json = excluded.navigations_json, theme_json = excluded.theme_json, raw_json = excluded.raw_json,
             last_seen_scan_id = excluded.last_seen_scan_id""",
        (
            platform, obj.id, obj.name, obj.app_type, obj.owner_id, obj.landing_dashboard_id,
            _json(views), _json(obj.navigations), _json(obj.theme), _json(obj.raw_payload), scan_id, scan_id,
        ),
    )


def _upsert_calculated_field(conn, platform, obj, scan_id) -> None:
    conn.execute(
        """INSERT INTO calculated_fields
             (platform, id, name, owner_id, status, formula_language, formula, data_type, is_global, is_locked,
              definition_json, raw_json, first_seen_scan_id, last_seen_scan_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(platform, id) DO UPDATE SET
             name = excluded.name, owner_id = excluded.owner_id, status = excluded.status,
             formula_language = excluded.formula_language, formula = excluded.formula,
             data_type = excluded.data_type, is_global = excluded.is_global, is_locked = excluded.is_locked,
             definition_json = excluded.definition_json, raw_json = excluded.raw_json, last_seen_scan_id = excluded.last_seen_scan_id""",
        (
            platform, obj.id, obj.name, obj.owner_id, obj.status, obj.formula_language, obj.formula,
            obj.data_type, int(obj.is_global), int(obj.is_locked), _json(obj.definition), _json(obj.raw_payload), scan_id, scan_id,
        ),
    )


def _upsert_alert(conn, platform, obj, scan_id) -> None:
    resource_type = obj.watched_object.object_type if obj.watched_object else None
    resource_id = obj.watched_object.id if obj.watched_object else None
    conn.execute(
        """INSERT INTO alerts (platform, id, name, rule, owner_id, resource_id, resource_type, disabled, raw_json, first_seen_scan_id, last_seen_scan_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(platform, id) DO UPDATE SET
             name = excluded.name, rule = excluded.rule, owner_id = excluded.owner_id,
             resource_id = excluded.resource_id, resource_type = excluded.resource_type,
             disabled = excluded.disabled, raw_json = excluded.raw_json, last_seen_scan_id = excluded.last_seen_scan_id""",
        (platform, obj.id, obj.name, obj.rule, obj.owner_id, resource_id, resource_type, int(obj.disabled), _json(obj.raw_payload), scan_id, scan_id),
    )


_UPSERTERS = {
    "user": _upsert_user,
    "group": _upsert_group,
    "account": _upsert_account,
    "dataset": _upsert_dataset,
    "dataflow": _upsert_dataflow,
    "card": _upsert_card,
    "dashboard": _upsert_dashboard,
    "app": _upsert_app,
    "calculated_field": _upsert_calculated_field,
    "alert": _upsert_alert,
}


def upsert_object(conn: sqlite3.Connection, platform: str, object_type: str, obj, scan_id: int) -> None:
    try:
        upserter = _UPSERTERS[object_type]
    except KeyError:
        raise KeyError(f"No upsert function registered for object_type={object_type!r}") from None
    upserter(conn, platform, obj, scan_id)

"""The published specification (`docs/spec/`), generated from the code that enforces it.

One page per document kind, the JSON Schemas, and the format overview. Field tables come from `spec.SCHEMAS` so a
page cannot describe a field the schema does not have; examples come from a real export of a small, invented estate
(never a customer's). A test regenerates everything and fails when a committed file differs, so the docs are
current whenever the tests are green. To refresh them:

    BIMCONTROL_REGEN_SPEC_DOCS=1 python -m pytest tests/test_spec_docs.py
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .spec import SCHEMAS, SPEC_ID, SPEC_VERSION

# kind -> (page, title, where it lives in an export, what it is, example glob in the export)
PAGES: list[tuple[str, str, str, str, str, str]] = [
    ("manifest", "manifest", "manifest.json",
     "What was exported and how it was checked: counts per kind, the reconciliation with the scan, coverage per kind and the limits of the whole export.",
     "manifest.json", "manifest"),
    ("dashboard", "dashboard", "dashboards/<id>-<slug>.json",
     "A dashboard (a Domo page, a Power BI report or classic dashboard): its pages with the position of every item, its filters, its owner, and all its visuals.",
     "dashboards/*.json", "dashboard"),
    ("visual", "visual (standalone card)", "cards/<id>-<slug>.json",
     "A visual that sits on no dashboard. Inside a dashboard document a visual has the same shape. Neutral `type`/`variant` with the source's own chart type kept in `source`.",
     "cards/*.json", "visual"),
    ("metrics", "metrics", "metrics/<dataset id>-<slug>.json",
     "Calculations (Domo Beast Modes, Power BI measures and calculated columns), grouped by the dataset or model they belong to, with the expression as the source wrote it and what it depends on.",
     "metrics/*.json", "metrics"),
    ("model", "model (dataset)", "models/<id>-<slug>.json and models/<id>-<slug>.sql",
     "A dataset or semantic model: columns, row-level access policies, and where it comes from and is used. The `.sql` beside it is a CREATE TABLE in ISO types.",
     "models/*.json", "dataset"),
    ("transformation", "transformation", "transformations/<id>-<slug>.json, .sql and .portable.sql",
     "A dataflow: its inputs, outputs and steps (type, dependencies, configuration), and, where a converter run covered it, the SQL (the dialect the warehouse accepted) with a PostgreSQL-syntax rendering and the constructs outside a core ANSI set. "
     "SQL that ranks a Remove Duplicates by `_domo_row_` is written for an input table whose first column `_domo_row_` (BIGINT, 1-based) is the row's position in the dataset's export: Domo keeps the first row of a key in stored order, and a warehouse table has none. To run that SQL elsewhere, load the export with such a column.",
     "transformations/*.json", "transformation"),
    ("extract", "extract definition (Airbyte Protocol)", "extract/<unit>.json",
     "How data got into the platform, in Airbyte's vocabulary: the Airbyte source connector, a connection-specification template (placeholders, never values), an AirbyteCatalog and a ConfiguredAirbyteCatalog. Not run on Airbyte.",
     "extract/account-*.json", "extract"),
    ("extract_index", "extract index", "extract/index.json",
     "Every dataset with the extract unit it belongs to, or the category and reason it has none (manual upload, derived, pushed ...).",
     "extract/index.json", "extract_index"),
    ("app", "app", "apps/<id>-<slug>.json",
     "An app as a small product: its screens (each a dashboard), navigation menu and theme.",
     "apps/*.json", "app"),
    ("principals", "principals", "access/principals.json",
     "Users and groups. Emails are never published; for Power BI, whose only person identifier is an e-mail, ids are a stable hash.",
     "access/principals.json", "principals"),
    ("catalog", "catalog", "catalog/{apps,alerts,accounts}.json",
     "Indexes of apps, alerts and connector accounts.",
     "catalog/accounts.json", "catalog"),
    ("lineage", "lineage", "lineage/objects.json, lineage/fields.jsonl",
     "The object graph (dashboard, card, dataset, dataflow) and, in `fields.jsonl`, one field-level edge per line: column to metric to visual.",
     "lineage/objects.json", "lineage"),
]


def _squash(value: Any, depth: int = 0) -> Any:
    """A document made short enough to read: lists cut to two items, long strings cut."""
    if isinstance(value, dict):
        return {k: _squash(v, depth + 1) for k, v in list(value.items())[:40]}
    if isinstance(value, list):
        cut = [_squash(v, depth + 1) for v in value[:2]]
        return cut + (["..."] if len(value) > 2 else [])
    if isinstance(value, str) and len(value) > 140:
        return value[:137] + "..."
    return value


def _type_of(schema: dict[str, Any]) -> str:
    t = schema.get("type")
    if "enum" in schema:
        return " or ".join(f"`{e}`" for e in schema["enum"])
    if isinstance(t, list):
        return " or ".join(f"`{x}`" for x in t)
    return f"`{t}`" if t else "any"


def _rows(schema: dict[str, Any], prefix: str = "", required: bool = True, depth: int = 0) -> list[tuple[str, str, str]]:
    out: list[tuple[str, str, str]] = []
    if depth > 3:
        return out
    needed = set(schema.get("required") or [])
    for name, sub in (schema.get("properties") or {}).items():
        path = f"{prefix}{name}"
        out.append((path, _type_of(sub), "yes" if name in needed else "no"))
        if sub.get("type") == "object" or (isinstance(sub.get("type"), list) and "object" in sub["type"]):
            out += _rows(sub, path + ".", name in needed, depth + 1)
        if sub.get("type") == "array" and isinstance(sub.get("items"), dict) and sub["items"].get("properties"):
            out += _rows(sub["items"], path + "[].", name in needed, depth + 1)
    return out


def _page(slug: str, title: str, where: str, what: str, example_glob: str, schema_key: str, export_dir: Path | None) -> str:
    schema = SCHEMAS[schema_key]
    lines = [f"# {title[0].upper() + title[1:]}", "",
             f"**File:** `{where}` · **Schema:** [`schema/{schema_key}.schema.json`](schema/{schema_key}.schema.json) · **Spec:** `{SPEC_ID}`", "",
             what, "", "## Fields", "", "| Field | Type | Required |", "|---|---|---|"]
    lines += [f"| `{p}` | {t} | {r} |" for p, t, r in _rows(schema)]
    lines += [""]
    if export_dir is not None:
        matches = sorted(export_dir.glob(example_glob))
        if matches:
            doc = json.loads(matches[0].read_text(encoding="utf-8"))
            if "generated_at" in doc:  # the one value that changes between runs
                doc["generated_at"] = "2026-01-01T00:00:00+00:00"
            lines += ["## Example", "", f"From an export of an invented estate (`{matches[0].relative_to(export_dir)}`); lists are cut to two items.",
                      "", "```json", json.dumps(_squash(doc), indent=2, ensure_ascii=False), "```", ""]
    lines += ["See [the overview](README.md) for conventions that apply to every document.", ""]
    return "\n".join(lines)


OVERVIEW = f"""# bimspec: the open specification

`{SPEC_ID}` describes an estate (a BI platform's dashboards, charts, calculations, data models, data movement and
access) as plain, versioned JSON files, plus SQL, so that the work of finding out what the estate is survives any one
tool. `bimcontrol export` writes it from a scan alone: it never calls the source platform. It reads Domo scans and
Power BI scans (`--platform powerbi`) into the same vocabulary.

## Layout of an export

```
manifest.json          what was exported, counts, reconciliation, coverage, limits
COVERAGE.md            per kind: converted / total / why the rest was not
schema/*.schema.json   JSON Schema of every document kind
dashboards/            one file per dashboard, with its pages and all visuals
cards/                 visuals on no dashboard
metrics/               calculations, grouped by dataset or model
models/                datasets and semantic models (+ CREATE TABLE .sql)
transformations/       dataflows (+ SQL, + portable SQL)
extract/               Airbyte Protocol definitions + index
apps/                  apps: screens, navigation, theme
access/principals.json users and groups
catalog/               apps, alerts, accounts
lineage/               object graph + field-level edges
```

One page per kind: {", ".join(f"[{p[1]}]({p[0]}.md)" for p in PAGES)}.

## Conventions

- **Versioning.** `spec` in every document is `bimspec/<major>.<minor>`. Within a major version a change is additive
  (new optional fields, new kinds, new enum values); a breaking change bumps the major and ships its schemas under the
  new number. Current: `{SPEC_VERSION}`. 1.1 added `extract`, `extract_index`, `app` and the portable SQL. 1.2 added `sql.basis` to a transformation: `converted_run` (converted by a migration run and, per output, `checked_by_warehouse`) or `converter_only` (written from the dataflow's definition by the converter, never run against data; `checked_by_warehouse` is null and inputs are named by Domo dataset id). 1.3 added to a visual what the migration reads and the export lacked: `date_ranges` (Domo's saved range: type, interval, offset, count), `row_limit` (top N with its order and grouping), `calculations` (formulas defined on the card), `time_grains` (each date-grain column of the card, with the calendar field cut from it when there is one, and the period), `style` (legend position, data labels), and per field `mapping`/`column_type`/`component`/`metric_ref`; sort entries carry `aggregation` and `component`. These keys describe a Domo card; a Power BI visual does not carry them. A column named in `date_ranges` or `row_limit` that is a card calculation is named by its display name (`calculations[].name`). Optional keys added to 1.3 afterwards: `order` on a dashboard's visual (the position the scan lists the card in, which the migration builds in), and `grain` and `component` on a time grain (a grain with no calendar field has `calendar_field` null).
- **Platform-neutral first, source kept.** A visual has a neutral `type` and `variant` (`column`/`stacked`, `pivot`,
  `selector`/`slicer` ...); `source.chart_type` keeps the platform's own name. A type the tables do not know is `other`,
  never guessed.
- **Nothing is guessed, nothing silently dropped.** Every kind is counted against the scan and `manifest.json`
  records the reconciliation; `COVERAGE.md` says what share of each kind was converted and why the rest was not.
- **Deterministic.** Lists are sorted and object documents carry no timestamps: exporting an unchanged scan twice gives
  byte-identical files except `manifest.json`'s `generated_at`. Commit the directory and the diff is the change in the estate.
- **Nothing secret.** Raw payloads are not copied, accounts carry no credentials, connection templates hold placeholders,
  and no e-mail address is published.
- **What is not promised.** SQL beyond the converted dataflows, a translation of calculations to another language, the
  running of Airbyte definitions, and executable portable SQL are not part of the format: each document says where it
  is a reading of the scan rather than a result.

Reference: [`docs/pipeline/open-export.md`](../pipeline/open-export.md) (how the exporter works and what it checks).
"""


def render_all(export_dir: Path | None) -> dict[str, str]:
    """Relative path under docs/spec -> file text."""
    files = {"README.md": OVERVIEW}
    for slug, title, where, what, glob, schema_key in PAGES:
        files[f"{slug}.md"] = _page(slug, title, where, what, glob, schema_key, export_dir)
    for kind, schema in SCHEMAS.items():
        files[f"schema/{kind}.schema.json"] = json.dumps(
            {"$schema": "https://json-schema.org/draft/2020-12/schema", "title": f"{SPEC_ID} {kind}", **schema},
            indent=2, ensure_ascii=False) + "\n"
    return files


def write(target: Path, export_dir: Path | None) -> list[str]:
    written = []
    for rel, text in render_all(export_dir).items():
        path = target / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
        written.append(rel)
    return written

import React from 'react';

function formatElapsed(s) {
  return s < 60 ? s.toFixed(1) + 's' : Math.floor(s / 60) + 'm ' + Math.round(s % 60) + 's';
}

export function ScanScreen({ defaultPlatform, defaultInstance, onScanCompleted }) {
  const [sessions, setSessions] = React.useState([]);
  const [platform, setPlatform] = React.useState(defaultPlatform || 'domo');
  const [instance, setInstance] = React.useState(defaultInstance || '');
  const [job, setJob] = React.useState(null); // { jobId, status, progress }
  const [error, setError] = React.useState(null);
  const [runs, setRuns] = React.useState([]);
  const [platforms, setPlatforms] = React.useState([{ key: 'domo', display_name: 'Domo', status: 'available' }]);
  const [issues, setIssues] = React.useState(null); // { scanId, rows } of what the last scan could not read
  const [exported, setExported] = React.useState(null); // { path, filename, size_bytes }
  const [exporting, setExporting] = React.useState(false);

  const reloadRuns = React.useCallback(function () {
    fetchScans().then(setRuns);
  }, []);

  React.useEffect(function () {
    fetchPlatforms().then(setPlatforms);
  }, []);

  React.useEffect(function () {
    fetchPlatformSessions(platform).then(function (list) {
      setSessions(list);
      if (!instance && list.length > 0) setInstance(list[0].instance);
    });
    reloadRuns();
  }, [platform, reloadRuns]); // eslint-disable-line

  React.useEffect(function () {
    if (!job || job.status !== 'running') return undefined;
    const timer = setInterval(function () {
      fetchScanProgress(job.jobId).then(function (j) {
        setJob(function (prev) { return Object.assign({}, prev, { status: j.status, progress: j.progress, error: j.error }); });
        if (j.status === 'completed') {
          reloadRuns();
          if (j.result && j.result.scan_id) {
            fetchScan(j.result.scan_id).then(function (s) { setIssues({ scanId: s.id, status: s.status, rows: s.issues || [] }); });
          }
          if (onScanCompleted) onScanCompleted();
        } else if (j.status === 'failed') {
          setError(j.error || 'Scan failed');
          // A scan that stopped still recorded what it could not read before it did.
          if (j.result && j.result.scan_id) {
            fetchScan(j.result.scan_id).then(function (s) { setIssues({ scanId: s.id, status: s.status, rows: s.issues || [] }); });
          }
        }
      });
    }, 1000);
    return function () { clearInterval(timer); };
  }, [job, reloadRuns, onScanCompleted]);

  function start() {
    setError(null);
    setIssues(null);
    startScan(platform, instance).then(function (res) {
      setJob({ jobId: res.job_id, status: 'running', progress: {} });
    }).catch(function (e) { setError(String(e.message || e)); });
  }

  function doExport() {
    setError(null);
    setExporting(true);
    exportScan().then(setExported).catch(function (e) { setError(String(e.message || e)); }).then(function () { setExporting(false); });
  }

  const hasCompleted = runs.some(function (r) { return r.status === 'completed'; });
  const running = job && job.status === 'running';
  const progress = job && job.progress || {};

  return (
    <div style={{ padding: 24, display: 'flex', flexDirection: 'column', gap: 20, maxWidth: 900 }}>
      <div>
        <div style={{ fontSize: 'var(--text-3xl)', fontWeight: 'var(--weight-semibold)', letterSpacing: 'var(--tracking-heading)' }}>Scan</div>
        <div style={{ fontSize: 'var(--text-md)', color: 'var(--text-secondary)', marginTop: 4 }}>
          Runs the full inventory against a connected instance and stores everything locally.
        </div>
      </div>

      {error && <Banner tone="error" title="Scan failed">{error}</Banner>}

      <Card title="Run a scan">
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <Select value={platform} onChange={function (e) { setPlatform(e.target.value); setInstance(''); }} disabled={running}
            options={platforms.filter(function (p) { return p.status === 'available'; }).map(function (p) { return { value: p.key, label: p.display_name }; })} />
          <Select value={instance} onChange={function (e) { setInstance(e.target.value); }} disabled={running || sessions.length === 0}
            placeholder={sessions.length === 0 ? 'No connected instance' : 'Choose an instance'}
            options={sessions.map(function (s) { return { value: s.instance, label: s.instance }; })} />
          <Button onClick={start} disabled={running || !instance} loading={running}>
            {running ? 'Scanning…' : 'Start scan'}
          </Button>
        </div>

        {job && (
          <div style={{ marginTop: 16 }}>
            <ProgressBar
              tone={job.status === 'failed' ? 'error' : 'target'}
              value={progress.total ? progress.completed : 0}
              max={progress.total || 1}
              showValue={false}
              label={progress.phase ? 'Phase: ' + progress.phase : 'Starting…'}
              detail={
                progress.phase
                  ? progress.completed + (progress.total ? ' of ' + progress.total : '') + ' ' + progress.phase + 's' + (progress.total ? '' : ' so far (total not known)') + ' · ' + formatElapsed(progress.elapsed_s || 0) + ' elapsed'
                  : null
              }
            />
            {progress.message && (
              <div style={{ marginTop: 6, fontSize: 'var(--text-sm)', color: 'var(--text-tertiary)' }}>{progress.phase}: {progress.message}</div>
            )}
          </div>
        )}
      </Card>

      {issues && issues.rows.length > 0 && !running && (
        <Banner tone="warn" title={issues.status === 'failed'
          ? 'Scan ' + issues.scanId + ' stopped; ' + issues.rows.length + ' thing' + (issues.rows.length === 1 ? ' was' : 's were') + ' not read before it did'
          : 'Scan ' + issues.scanId + ' finished, but ' + issues.rows.length + ' thing' + (issues.rows.length === 1 ? '' : 's') + ' could not be read'}>
          <div style={{ fontSize: 'var(--text-sm)' }}>
            {issues.status === 'failed' ? 'This scan is incomplete. What was not read, and why:' : 'Everything else was scanned. What is missing, and why:'}
          </div>
          <ul style={{ margin: '6px 0 0 18px', padding: 0, fontSize: 'var(--text-sm)' }}>
            {issues.rows.slice(0, 20).map(function (i, n) {
              return <li key={n}><span style={{ fontFamily: 'var(--font-mono)' }}>{i.scope}</span>: {i.message}{i.http_status ? ' (HTTP ' + i.http_status + ')' : ''}</li>;
            })}
          </ul>
          {issues.rows.length > 20 && <div style={{ marginTop: 6, fontSize: 'var(--text-sm)' }}>… and {issues.rows.length - 20} more, recorded in the scan.</div>}
        </Banner>
      )}

      {hasCompleted && !running && (
        <Card title="Send your scan to BI Migrations">
          <div style={{ fontSize: 'var(--text-md)', color: 'var(--text-secondary)' }}>
            Save a copy of the scan as a single file, then attach it to an email to your BI Migrations contact.
            The copy contains the inventory only; your sign-in session is left out.
          </div>
          <div style={{ marginTop: 12, display: 'flex', gap: 8, alignItems: 'center' }}>
            <Button onClick={doExport} loading={exporting} disabled={exporting}>
              {exported ? 'Save again' : 'Save scan for email'}
            </Button>
            {exported && (
              <Button onClick={function () { revealExport(exported.path); }}>Show in folder</Button>
            )}
          </div>
          {exported && (
            <div style={{ marginTop: 12 }}>
              <Banner tone="ok" title="Saved">
                {exported.path} ({(exported.size_bytes / 1048576).toFixed(1)} MB). Attach this file to an email and send it to us.
                If it is too large for your mail system, tell us and we will arrange another way.
              </Banner>
            </div>
          )}
        </Card>
      )}

      <Card title="Runs" padded={false}>
        <div style={{ height: Math.max(120, Math.min(360, 60 + runs.length * 34)) }}>
          <DataGrid
            emptyLabel="No scans yet"
            columns={[
              { key: 'id', header: 'ID', mono: true, width: 60, sortable: true },
              { key: 'platform', header: 'Platform', width: 100, sortable: true, filterable: true },
              { key: 'instance', header: 'Instance', sortable: true, filterable: true },
              { key: 'started_at', header: 'Started', mono: true, sortable: true, width: 200 },
              { key: 'issue_count', header: 'Not read', mono: true, width: 90, sortable: true, render: function (r) {
                return r.issue_count ? <StatusDot status="warn" label={String(r.issue_count)} /> : <span style={{ color: 'var(--text-tertiary)' }}>0</span>;
              } },
              { key: 'status', header: 'Status', width: 130, sortable: true, filterable: true, render: function (r) {
                return <StatusDot status={r.status === 'completed' ? 'ok' : r.status === 'failed' ? 'error' : 'running'} pulse={r.status === 'running'} label={r.status} />;
              } },
            ]}
            rows={runs}
          />
        </div>
      </Card>
    </div>
  );
}

"""The marker that says which source dashboard an item in a workspace came from."""

from __future__ import annotations

PREFIX = "Migrated from Domo dashboard "


def source_description(dashboard_id: str) -> str:
    return f"{PREFIX}{dashboard_id}"


def source_of(description: str | None) -> str | None:
    """The dashboard id a description names, or None for an item we did not stamp."""
    if description and description.startswith(PREFIX):
        return description[len(PREFIX):].strip() or None
    return None

import React from 'react';

// The layout parts every screen composes, taken from the BITransition
// Console kit's shell contract: rail 56px, app bar 48px, sidebar 264px,
// main, inspector 340px. The sizes are tokens, not numbers, because a user
// moving between modules must never re-learn where the furniture is.
//
// Sidebar = what you are looking at. Main = the work. Inspector = the
// selected thing, and never load-bearing for navigation: every screen here
// is usable with the inspector empty.
//
// Loaded before the screens, because ds-preview.js only pre-declares the
// exports of files that came earlier.

export function Sidebar({ children }) {
  return (
    <aside style={{
      width: 'var(--sidebar-w)', flex: 'none', minWidth: 0,
      background: 'var(--surface-panel)', borderRight: '1px solid var(--border-hairline)',
      display: 'flex', flexDirection: 'column', overflow: 'auto',
    }}>{children}</aside>
  );
}

export function SidebarGroup({ label, action, children }) {
  return (
    <div style={{ padding: '14px 10px 6px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '0 4px 8px' }}>
        <span className="bit-eyebrow" style={{ flex: 1 }}>{label}</span>
        {action}
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>{children}</div>
    </div>
  );
}

export function SidebarRule() {
  return <div style={{ height: 1, background: 'var(--border-hairline)', margin: '8px 10px' }} />;
}

export function Inspector({ children }) {
  return (
    <aside style={{
      width: 'var(--inspector-w)', flex: 'none', minWidth: 0,
      background: 'var(--surface-panel)', borderLeft: '1px solid var(--border-hairline)',
      display: 'flex', flexDirection: 'column', overflow: 'auto',
    }}>{children}</aside>
  );
}

export function Main({ children, scroll }) {
  return (
    <main style={{
      flex: 1, minWidth: 0, minHeight: 0, display: 'flex', flexDirection: 'column',
      overflow: scroll ? 'auto' : 'hidden',
    }}>{children}</main>
  );
}

export function PageHeader({ title, accent, meta, actions, children }) {
  return (
    <div style={{ padding: '20px 20px 0', flex: 'none' }}>
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 16, flexWrap: 'wrap' }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <h1 style={{
            margin: 0, fontSize: 'var(--text-4xl)', fontWeight: 'var(--weight-bold)',
            letterSpacing: 'var(--tracking-heading)', lineHeight: 1.1, color: 'var(--text-primary)',
          }}>
            {title}
            {accent ? (
              <span style={{
                fontFamily: 'var(--font-editorial)', fontStyle: 'italic',
                fontWeight: 400, color: 'var(--provenance-target)',
              }}>{' ' + accent}</span>
            ) : null}
          </h1>
          {meta ? (
            <div style={{ fontSize: 'var(--text-md)', color: 'var(--text-tertiary)', marginTop: 5 }}>
              {meta}
            </div>
          ) : null}
        </div>
        {actions ? <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>{actions}</div> : null}
      </div>
      {children}
    </div>
  );
}

export function SectionLabel({ children }) {
  return <div className="bit-eyebrow" style={{ marginBottom: 8 }}>{children}</div>;
}

export function InspectorBody({ children }) {
  return (
    <div style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 16 }}>
      {children}
    </div>
  );
}

// ---- shared vocabulary --------------------------------------------------
//
// Named tables rather than conditionals scattered through the screens: a
// stage status means the same thing on every screen, and a reviewer can
// read the mapping in one place.

export function statusTone(status) {
  return ({
    succeeded: 'target', running: 'info', failed: 'error', cancelled: 'neutral',
    pending: 'neutral', skipped: 'neutral', not_implemented: 'neutral',
    incomplete: 'warn', needs_review: 'warn', ok: 'target', warn: 'warn', error: 'error',
  })[status] || 'neutral';
}

export function statusDot(status) {
  return ({
    succeeded: 'ok', ok: 'ok', running: 'running', failed: 'error', error: 'error',
    warn: 'warn', incomplete: 'warn', needs_review: 'warn', cancelled: 'idle',
    pending: 'idle', skipped: 'idle', not_implemented: 'idle',
  })[status] || 'idle';
}

// British English and sentence case, like every other label in the system.
export function statusLabel(status) {
  return ({
    succeeded: 'Done', running: 'Running', failed: 'Failed', cancelled: 'Cancelled',
    pending: 'Waiting', skipped: 'Skipped', not_implemented: 'Not built',
    incomplete: 'Incomplete', needs_review: 'Needs review',
  })[status] || String(status || '').replace(/_/g, ' ');
}

export function formatDuration(seconds) {
  if (seconds === null || seconds === undefined) return '--';
  if (seconds < 1) return '<1s';
  if (seconds < 60) return seconds.toFixed(1) + 's';
  return Math.floor(seconds / 60) + 'm ' + String(Math.floor(seconds % 60)).padStart(2, '0') + 's';
}

export function elapsedSeconds(from, to) {
  if (!from) return null;
  const start = Date.parse(from);
  const end = to ? Date.parse(to) : Date.now();
  if (isNaN(start) || isNaN(end)) return null;
  return (end - start) / 1000;
}

export function shortTime(timestamp) {
  if (!timestamp) return '';
  const parsed = new Date(timestamp);
  return isNaN(parsed.getTime()) ? String(timestamp).slice(11, 19)
    : parsed.toLocaleTimeString('en-GB', { hour12: false });
}

// A figure, in mono, coloured by which side of the migration it came from.
export function Figure({ value, side, muted }) {
  const colour = side === 'source' ? 'var(--provenance-source)'
    : side === 'target' ? 'var(--provenance-target)'
      : muted ? 'var(--text-tertiary)' : 'var(--text-primary)';
  return (
    <span className="bit-num" style={{ color: colour }}>
      {value === null || value === undefined || value === '' ? '--' : value}
    </span>
  );
}

export function Panel({ title, subtitle, actions, children, pad = 16 }) {
  return (
    <div style={{
      border: '1px solid var(--border-hairline)', borderRadius: 'var(--radius-card)',
      background: 'var(--surface-card)', overflow: 'hidden',
    }}>
      {title ? (
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10, padding: '11px 14px',
          borderBottom: '1px solid var(--border-hairline)',
        }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 'var(--text-lg)', fontWeight: 'var(--weight-semibold)', letterSpacing: 'var(--tracking-heading)' }}>
              {title}
            </div>
            {subtitle ? (
              <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-tertiary)', marginTop: 2 }}>
                {subtitle}
              </div>
            ) : null}
          </div>
          {actions}
        </div>
      ) : null}
      <div style={{ padding: pad }}>{children}</div>
    </div>
  );
}

export function ErrorBanner({ error, title }) {
  if (!error) return null;
  return (
    <div style={{ padding: '12px 20px 0' }}>
      <Banner tone="error" title={title || 'Something went wrong'}>{String(error)}</Banner>
    </div>
  );
}

"""Split a very deep CTE chain into tables the warehouse can plan.

Redshift's planner does not cope with a hundred nested CTEs: planning time
climbs with depth (4 s at 40, 127 s at 52 on the 278 dataflow) and then it
gives up with "correlated subquery pattern is not supported due to internal
error". Materialising a few CTEs as tables and letting the rest read them
keeps every statement shallow. The converter's output is regular (one
`name AS (` block per tile, joined by `),`), which is all this relies on.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass

STAGE_ABOVE = 45      # chains up to this many CTEs plan in seconds
STAGE_SIZE = 30       # a staged statement reads at most this many CTEs

_BLOCK_END = re.compile(r"\n\),\n")
_BLOCK_NAME = re.compile(r"(\w+) AS \(")
_TAIL = re.compile(r"(.*?\n)\)\n(SELECT .*)$", re.S)


@dataclass
class Chain:
    head: str
    names: list[str]
    bodies: dict[str, str]          # name -> text after "name AS (" up to the closing paren
    final: str                      # the closing "SELECT ..." statement

    def deps(self, name: str) -> list[str]:
        known = set(self.names) - {name}
        return [n for n in self.names if n in known and re.search(rf"\b{re.escape(n)}\b", self.bodies[name])]

    def reachable(self, target: str) -> list[str]:
        """The CTEs `target` needs, in original order, including itself."""
        seen: set[str] = set()
        stack = [target]
        while stack:
            name = stack.pop()
            if name in seen:
                continue
            seen.add(name)
            stack.extend(self.deps(name))
        return [n for n in self.names if n in seen]

    def render(self, target: str, final: str | None = None) -> str:
        parts = ",\n".join(f"{n} AS ({self.bodies[n]}\n)" for n in self.reachable(target))
        return f"{self.head}WITH\n{parts}\n{final or f'SELECT * FROM {target}'}"


def parse(sql: str) -> Chain | None:
    """None when the SQL is not in the converter's CTE shape."""
    if "WITH\n" not in sql:
        return None
    head, rest = sql.split("WITH\n", 1)
    blocks = _BLOCK_END.split(rest)
    tail = _TAIL.match(blocks[-1])
    if not tail:
        return None
    blocks[-1], final = tail.group(1).rstrip("\n"), tail.group(2).strip()
    names, bodies = [], {}
    for block in blocks:
        found = _BLOCK_NAME.match(block.strip())
        if not found:
            return None
        names.append(found.group(1))
        bodies[found.group(1)] = block.strip()[found.end():]
    return Chain(head, names, bodies, final)


def needs_staging(sql: str) -> bool:
    chain = parse(sql)
    return chain is not None and len(chain.names) > STAGE_ABOVE


def stage(sql: str, make_table: Callable[[str, str], str], base: str) -> tuple[str, list[str]]:
    """Return (shallow SQL, tables made).

    `make_table(name, select_sql)` creates the table and returns its
    reference. Walking the chain in order, a CTE whose dependency closure has
    reached STAGE_SIZE is materialised and every later CTE reads the table.
    """
    chain = parse(sql)
    if chain is None or len(chain.names) <= STAGE_ABOVE:
        return sql, []
    tables: list[str] = []
    for name in list(chain.names):
        if len(chain.reachable(name)) < STAGE_SIZE:
            continue
        ref = make_table(f"{base}_s{len(tables) + 1}", chain.render(name))
        tables.append(ref)
        chain.bodies[name] = f"\n  SELECT * FROM {ref}"
    # The final statement names one CTE; keep only what it reaches.
    target = re.search(r"FROM\s+(\w+)", chain.final)
    if not target or target.group(1) not in chain.bodies:
        return sql, tables
    return chain.render(target.group(1), final=chain.final) , tables

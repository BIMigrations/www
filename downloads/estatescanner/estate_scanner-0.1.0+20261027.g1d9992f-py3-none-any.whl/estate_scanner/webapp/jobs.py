"""In-memory background job tracking for operations that outlive an HTTP
request (Domo's interactive browser login, a full scan). Single local
user, so a plain dict + lock is enough -- no external queue/broker needed.
"""

from __future__ import annotations

import threading
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable


@dataclass
class Job:
    id: str
    kind: str  # "connect" | "scan"
    status: str = "running"  # running | completed | failed
    result: Any = None
    error: str | None = None
    progress: dict = field(default_factory=dict)


class JobManager:
    def __init__(self):
        self._jobs: dict[str, Job] = {}
        self._lock = threading.Lock()

    def start(self, kind: str, fn: Callable[[Job], Any]) -> Job:
        job = Job(id=str(uuid.uuid4()), kind=kind)
        with self._lock:
            self._jobs[job.id] = job

        def run() -> None:
            try:
                job.result = fn(job)
                job.status = "completed"
            except Exception as exc:
                job.status = "failed"
                job.error = str(exc)

        threading.Thread(target=run, daemon=True).start()
        return job

    def get(self, job_id: str) -> Job | None:
        with self._lock:
            return self._jobs.get(job_id)


jobs = JobManager()

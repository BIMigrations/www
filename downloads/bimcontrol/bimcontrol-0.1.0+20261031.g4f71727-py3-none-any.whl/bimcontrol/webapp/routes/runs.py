"""Projects, migration units, runs and everything hanging off a run.

The endpoints the Migrations screen will need: start a run, watch it, read
what it produced, and work through what it flagged.

Progress is read by long-polling `GET /runs/{id}/events?after_seq=N`,
which holds the request open until there is something new or the wait
runs out. That keeps a live log to one connection and no busy loop, and it
is the same contract the cloud control plane will sync on.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Body, Depends, HTTPException, Query, Request
from fastapi.responses import FileResponse

from bimcontrol.core import runner
from bimcontrol.estate.reader import EstateNotFoundError
from bimcontrol.pipelines import migration_report, verify_parity
from bimcontrol.storage import db

router = APIRouter()

# Long enough to be worth holding a connection open, short enough that a
# client notices a dropped server and a browser does not time out first.
MAX_WAIT_SECONDS = 30.0
POLL_INTERVAL = 0.25


def get_conn(request: Request):
    conn = db.connect(request.app.state.db_path)
    try:
        yield conn
    finally:
        conn.close()


def _run_manager(request: Request) -> runner.RunManager:
    return request.app.state.runs


def _require_run(conn, run_id: str) -> dict[str, Any]:
    run = db.get_run(conn, run_id)
    if run is None:
        raise HTTPException(status_code=404, detail=f"No run with id {run_id!r}")
    return run


# ---- projects and units -------------------------------------------------


@router.get("/projects")
def list_projects(conn=Depends(get_conn)) -> dict[str, Any]:
    return {"items": db.list_projects(conn)}


@router.get("/projects/{project_id}")
def get_project(project_id: str, conn=Depends(get_conn)) -> dict[str, Any]:
    project = db.get_project(conn, project_id)
    if project is None:
        raise HTTPException(status_code=404, detail=f"No project with id {project_id!r}")
    return project


@router.post("/projects/ensure")
def ensure_project(request: Request, conn=Depends(get_conn), body: dict[str, Any] = Body(default={})) -> dict[str, Any]:
    """The project for the loaded scan, created if this is the first sight
    of it. The UI calls this rather than making someone set a project up."""
    estate_db_path = body.get("estate_db_path") or request.app.state.estate_db_path
    try:
        return runner.resolve_project(conn, estate_db_path, body.get("target_platform", "powerbi"))
    except EstateNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.get("/units")
def list_units(
    conn=Depends(get_conn),
    project_id: str | None = None,
    status: str | None = None,
    limit: int = Query(200, le=1000),
) -> dict[str, Any]:
    return {"items": db.list_units(conn, project_id=project_id, status=status, limit=limit)}


@router.get("/units/{unit_id}")
def get_unit(unit_id: str, conn=Depends(get_conn)) -> dict[str, Any]:
    unit = db.get_unit(conn, unit_id)
    if unit is None:
        raise HTTPException(status_code=404, detail=f"No unit with id {unit_id!r}")
    return {
        **unit,
        "runs": db.list_runs(conn, unit_id=unit_id, limit=20),
        "open_reviews": db.list_review_items(conn, unit_id=unit_id, status="open"),
    }


# ---- runs ---------------------------------------------------------------


@router.post("/runs")
def start_run(
    request: Request, conn=Depends(get_conn), body: dict[str, Any] = Body(...)
) -> dict[str, Any]:
    """Start migrating one dashboard. Returns as soon as the run exists;
    the work happens in the background, watched through the events feed."""
    dashboard_id = body.get("dashboard_id")
    if not dashboard_id:
        raise HTTPException(status_code=400, detail="dashboard_id is required")

    estate_db_path = body.get("estate_db_path") or request.app.state.estate_db_path
    try:
        prepared = runner.prepare_run(
            conn,
            estate_db_path,
            str(dashboard_id),
            target_platform=body.get("target_platform", "powerbi"),
            until=body.get("until"),
        )
    except EstateNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except KeyError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    _run_manager(request).start(prepared["run_id"], estate_db_path, until=body.get("until"))
    return {
        "run": db.get_run(conn, prepared["run_id"]),
        "unit": prepared["unit"],
        "stages": db.list_stages(conn, prepared["run_id"]),
    }


@router.get("/runs")
def list_runs(
    conn=Depends(get_conn),
    project_id: str | None = None,
    unit_id: str | None = None,
    status: str | None = None,
    limit: int = Query(50, le=200),
) -> dict[str, Any]:
    return {
        "items": db.list_runs(
            conn, project_id=project_id, unit_id=unit_id, status=status, limit=limit
        )
    }


@router.get("/runs/{run_id}")
def get_run(request: Request, run_id: str, conn=Depends(get_conn)) -> dict[str, Any]:
    run = _require_run(conn, run_id)
    return {
        **run,
        "live": _run_manager(request).is_running(run_id),
        "unit": db.get_unit(conn, run["unit_id"]),
        "stages": db.list_stages(conn, run_id),
        "artefacts": db.list_artefacts(conn, run_id),
        "open_reviews": db.count_open_reviews(conn, run_id),
        "latest_seq": db.max_event_seq(conn, run_id),
    }


@router.get("/runs/{run_id}/stages")
def get_stages(run_id: str, conn=Depends(get_conn)) -> dict[str, Any]:
    _require_run(conn, run_id)
    return {"items": db.list_stages(conn, run_id)}


@router.get("/runs/{run_id}/events")
def get_events(
    request: Request,
    run_id: str,
    conn=Depends(get_conn),
    after_seq: int = 0,
    wait_seconds: float = Query(0.0, ge=0.0, le=MAX_WAIT_SECONDS),
    limit: int = Query(500, le=2000),
) -> dict[str, Any]:
    """Events after `after_seq`.

    With `wait_seconds`, hold the request until something arrives or the
    wait runs out -- a live log without a client-side busy loop. Returns
    immediately once the run is finished, so a follower does not hang on a
    run that will never emit again.
    """
    _require_run(conn, run_id)
    deadline = time.monotonic() + wait_seconds
    while True:
        events = db.list_events(conn, run_id, after_seq=after_seq, limit=limit)
        run = db.get_run(conn, run_id)
        if events or time.monotonic() >= deadline or run["status"] != "running":
            return {
                "items": events,
                "next_after_seq": events[-1]["seq"] if events else after_seq,
                "run_status": run["status"],
                "live": _run_manager(request).is_running(run_id),
            }
        time.sleep(POLL_INTERVAL)


@router.post("/runs/{run_id}/resume")
def resume_run(
    request: Request, run_id: str, conn=Depends(get_conn), body: dict[str, Any] = Body(default={})
) -> dict[str, Any]:
    """Continue a stopped run. Stages that already succeeded are skipped
    unless their inputs changed."""
    run = _require_run(conn, run_id)
    manager = _run_manager(request)
    if manager.is_running(run_id):
        raise HTTPException(status_code=409, detail="That run is already running")

    project = db.get_project(conn, run["project_id"])
    estate_db_path = (
        body.get("estate_db_path") or project.get("estate_db_path") or request.app.state.estate_db_path
    )
    manager.start(run_id, estate_db_path, until=body.get("until"))
    return {"run": db.get_run(conn, run_id)}


@router.post("/runs/{run_id}/cancel")
def cancel_run(request: Request, run_id: str, conn=Depends(get_conn)) -> dict[str, Any]:
    run = _require_run(conn, run_id)
    cancelled = _run_manager(request).cancel(run_id)
    if not cancelled and run["status"] == "running":
        # Marked running but nothing is executing it: a worker died mid-run.
        db.update_run(
            conn, run_id, status="cancelled", finished_at=db.now(),
            stopped_reason="no worker was executing this run",
        )
    return {"cancelled": cancelled, "run": db.get_run(conn, run_id)}


# ---- artefacts ----------------------------------------------------------


@router.get("/runs/{run_id}/artefacts")
def list_artefacts(run_id: str, conn=Depends(get_conn), stage: str | None = None) -> dict[str, Any]:
    _require_run(conn, run_id)
    return {"items": db.list_artefacts(conn, run_id, stage=stage)}


@router.get("/runs/{run_id}/artefacts/{artefact_id}/content")
def get_artefact_content(run_id: str, artefact_id: int, conn=Depends(get_conn)):
    """The artefact's bytes, for the inspector to show or download."""
    run = _require_run(conn, run_id)
    artefact = db.get_artefact(conn, artefact_id)
    if artefact is None or artefact["run_id"] != run_id:
        raise HTTPException(status_code=404, detail="No such artefact on this run")

    run_dir = Path(run["run_dir"]).resolve()
    path = (run_dir / artefact["path"]).resolve()
    # The stored path is ours, but resolve it against the run directory
    # anyway: an artefact row is the only thing standing between this
    # endpoint and serving an arbitrary file.
    if not path.is_relative_to(run_dir) or not path.exists():
        raise HTTPException(status_code=404, detail="Artefact file is missing from the run directory")
    return FileResponse(
        path, media_type=artefact["media_type"] or "application/octet-stream", filename=path.name
    )


# ---- the migration report ----------------------------------------------


def _report_path(run: dict[str, Any], filename: str) -> Path:
    return Path(run["run_dir"]) / "report" / filename


@router.get("/runs/{run_id}/report")
def get_report(run_id: str, conn=Depends(get_conn)) -> dict[str, Any]:
    """The migration report as data.

    Served from the artefact rather than rebuilt, so the screen and the
    file a customer was sent cannot disagree.
    """
    run = _require_run(conn, run_id)
    path = _report_path(run, migration_report.REPORT_JSON)
    if not path.exists():
        raise HTTPException(
            status_code=404,
            detail="This run has not written a migration report yet",
        )
    return json.loads(path.read_text())


@router.get("/runs/{run_id}/report.html")
def get_report_html(run_id: str, conn=Depends(get_conn), download: bool = False):
    """The sendable file itself.

    Served inline by default so the screen can show it in a frame -- naming
    a file on a `FileResponse` marks it as an attachment, and a browser
    downloads an attachment rather than rendering it, leaving the preview
    blank. `?download=1` is the save-it-to-send-it path, and only that one
    gets a filename.
    """
    run = _require_run(conn, run_id)
    path = _report_path(run, migration_report.REPORT_HTML)
    if not path.exists():
        raise HTTPException(status_code=404, detail="This run has not written a migration report yet")
    if not download:
        return FileResponse(path, media_type="text/html")
    unit = db.get_unit(conn, run["unit_id"]) or {}
    name = (unit.get("name") or run_id).replace("/", "-")
    return FileResponse(path, media_type="text/html", filename=f"{name} migration report.html")


@router.get("/runs/{run_id}/parity")
def get_parity(run_id: str, conn=Depends(get_conn), state: str | None = None) -> dict[str, Any]:
    """Parity rows, optionally only the ones that did not match.

    The Parity screen opens on the differences, because a list of several
    hundred matching figures buries the handful that matter.
    """
    run = _require_run(conn, run_id)
    path = Path(run["run_dir"]) / "verify_parity" / verify_parity.PARITY_FILE
    if not path.exists():
        return {"checked": False, "rows": [], "totals": {}}
    parity = json.loads(path.read_text())
    rows = parity.get("rows") or []
    if state:
        wanted = set(state.split(","))
        rows = [r for r in rows if r.get("state") in wanted]
    return {**parity, "rows": rows, "total_rows": len(parity.get("rows") or [])}


# ---- review items -------------------------------------------------------


@router.get("/reviews")
def list_reviews(
    conn=Depends(get_conn),
    run_id: str | None = None,
    unit_id: str | None = None,
    status: str | None = "open",
    limit: int = Query(500, le=2000),
) -> dict[str, Any]:
    # "all" is how a caller says every status; an empty string would be
    # dropped by most clients and fall back to "open".
    return {
        "items": db.list_review_items(
            conn, run_id=run_id, unit_id=unit_id,
            status=None if status == "all" else status, limit=limit,
        )
    }


@router.post("/reviews/{item_id}")
def resolve_review(
    item_id: int, conn=Depends(get_conn), body: dict[str, Any] = Body(default={})
) -> dict[str, Any]:
    status = body.get("status", "resolved")
    if status not in {"open", "resolved", "ignored"}:
        raise HTTPException(status_code=400, detail="status must be open, resolved or ignored")
    item = db.resolve_review_item(conn, item_id, status=status, note=body.get("note"))
    if item is None:
        raise HTTPException(status_code=404, detail=f"No review item with id {item_id}")
    return item

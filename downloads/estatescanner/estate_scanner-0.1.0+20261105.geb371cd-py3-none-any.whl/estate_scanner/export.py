"""Export a scan as a zip that is safe to email.

The live database holds the signed-in session in `platform_sessions`, which is
a bearer credential. The export is built from a copy with that table emptied
and the file vacuumed, so the credentials are not recoverable from free pages.
The export holds one estate: the (platform, instance) the caller chose, else that of the latest completed
scan; it names the zip. Another instance's rows, scans, issues and raw responses are removed from the copy before the
vacuum (a second customer's estate must not travel in the first one's zip). The customer's own
database is never modified.
"""

from __future__ import annotations

import json
import shutil
import sqlite3
import tempfile
import zipfile
from datetime import datetime, timezone
from importlib import metadata
from pathlib import Path

from estate_scanner.core.instances import normalise_instance
from estate_scanner.storage.migrate import instance_tables

EXPORT_DB_NAME = "estate.db"
MANIFEST_NAME = "manifest.json"
_COUNTED_TABLES = ("users", "groups_", "datasets", "dataflows", "cards", "dashboards", "apps", "calculated_fields", "alerts", "workspaces", "gateways", "edges")


def default_export_dir() -> Path:
    """Where exports go: Documents if it exists (a place people can find), else home."""
    documents = Path.home() / "Documents"
    return documents if documents.is_dir() else Path.home()


def _tool_version() -> str:
    try:
        return metadata.version("estate-scanner")
    except metadata.PackageNotFoundError:
        return "unknown"


def _latest_completed_scan(conn: sqlite3.Connection, platform: str | None = None, instance: str | None = None):
    """The newest completed scan, of the estate named when one is (an instance given without its platform matches in any)."""
    where, params = "status = 'completed'", []
    if platform:
        where += " AND platform = ?"
        params.append(platform)
    if instance is not None:
        where += " AND instance = ?"
        params.append(instance)
    return conn.execute(
        f"SELECT id, platform, instance, started_at, finished_at, status FROM scans WHERE {where} ORDER BY id DESC LIMIT 1", params  # noqa: S608 -- fixed terms, values bound
    ).fetchone()


def list_estates(db_path: str | Path) -> list[dict]:
    """The estates the file holds that have a completed scan, newest first: platform, instance, and that scan's id and finish time.
    What the export dialog offers; the first is what an export without a choice takes."""
    db_path = Path(db_path)
    if not db_path.exists():
        return []
    conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    try:
        rows = conn.execute(
            "SELECT platform, instance, MAX(id), finished_at FROM scans WHERE status = 'completed' GROUP BY platform, instance ORDER BY MAX(id) DESC"
        ).fetchall()
    except sqlite3.OperationalError:  # no scans table: not an Estate Scanner file
        return []
    finally:
        conn.close()
    return [{"platform": p, "instance": i, "scan_id": n, "finished_at": f} for p, i, n, f in rows]


def _sanitised_copy(db_path: Path, dest: Path, platform: str | None = None, instance: str | None = None) -> int:
    """Copy the database to `dest` without the saved sign-ins and without any estate but the one the export
    is of (the one named, else that of the latest completed scan: the zip is named after it). Returns how many other
    (platform, instance) estates were left out. The vacuum comes last, so nothing deleted survives in free pages."""
    src = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    try:
        out = sqlite3.connect(dest)
        try:
            src.backup(out)
            out.execute("DELETE FROM platform_sessions")
            left_out = _keep_only_one_estate(out, platform, instance)
            out.commit()
            out.execute("VACUUM")
        finally:
            out.close()
    finally:
        src.close()
    return left_out


def _keep_only_one_estate(conn: sqlite3.Connection, platform: str | None = None, instance: str | None = None) -> int:
    """Delete everything that is not the estate asked for (else that of the latest completed scan); returns how many other estates there were.
    Always runs: `scans` can list one estate while the object tables or the raw responses hold rows of another (a
    deleted scan's leftovers, a scan row never written), and those must not travel either."""
    scan = _latest_completed_scan(conn, platform, instance)
    if scan is None:
        return 0  # export_scan refuses without a completed scan
    keep = (scan[1], scan[2])
    present = {row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
    typed = [t for t in instance_tables() if t in present]
    keyed = [t for t in typed if "instance" in [c[1] for c in conn.execute(f"PRAGMA table_info({t})")]]  # noqa: S608 -- registry table names
    estates = {tuple(e) for e in conn.execute("SELECT DISTINCT platform, instance FROM scans")}
    for table in keyed:
        estates.update(tuple(e) for e in conn.execute(f"SELECT DISTINCT platform, instance FROM {table}"))  # noqa: S608
    other = estates - {keep}
    if other and len(keyed) < len(typed):
        raise ValueError(
            "This database holds more than one instance and was made by an older version, which kept no instance "
            "on its rows, so one instance cannot be separated from another. Open it once in Estate Scanner "
            "(it is brought up to date, with a copy first) and export again."
        )
    for table in keyed:
        conn.execute(f"DELETE FROM {table} WHERE NOT (platform = ? AND instance = ?)", keep)  # noqa: S608
    mine = "SELECT id FROM scans WHERE platform = ? AND instance = ?"
    if "scan_issues" in present:
        conn.execute(f"DELETE FROM scan_issues WHERE scan_id NOT IN ({mine})", keep)  # noqa: S608
    if "raw_objects" in present:
        conn.execute(f"DELETE FROM raw_objects WHERE scan_id IS NULL OR scan_id NOT IN ({mine})", keep)  # noqa: S608
    conn.execute("DELETE FROM scans WHERE NOT (platform = ? AND instance = ?)", keep)
    return len(other)


def _manifest(db_copy: Path, left_out: int) -> dict:
    conn = sqlite3.connect(db_copy)
    try:
        scan = _latest_completed_scan(conn)
        # A database last opened by an older version has no table for an object type added since.
        present = {row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
        counts = {t: conn.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] if t in present else 0 for t in _COUNTED_TABLES}
    finally:
        conn.close()
    keys = ("scan_id", "platform", "instance", "started_at", "finished_at", "status")
    return {
        "tool_version": _tool_version(),
        "exported_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "latest_completed_scan": dict(zip(keys, scan)) if scan else None,
        "scope": {"platform": scan[1], "instance": scan[2]} if scan else None,
        "other_estates_left_out": left_out,  # other (platform, instance) estates in the file: not in this zip
        "object_counts": counts,
        "contains_sessions": False,
    }


def _chosen_estate(db_path: Path, platform: str | None, instance: str | None) -> tuple[str | None, str | None]:
    """The (platform, normalised instance) to export, checked against the file; (None, None) takes the latest completed scan.
    Raises ValueError naming what the file does hold when the choice is not there or not unique."""
    if platform is None and instance is None:
        return None, None
    estates = list_estates(db_path)
    wanted = [e for e in estates
              if (platform is None or e["platform"] == platform)
              and (instance is None or e["instance"] == normalise_instance(e["platform"], instance))]
    held = ", ".join(f"{e['platform']}/{e['instance']}" for e in estates) or "none"
    if not wanted:
        raise ValueError(f"No completed scan of {platform or 'any platform'}/{instance or 'any instance'} in this file. It holds: {held}.")
    if len({(e["platform"], e["instance"]) for e in wanted}) > 1:
        matching = ", ".join(f"{e['platform']}/{e['instance']}" for e in wanted)
        raise ValueError(f"More than one estate matches ({matching}). Name the platform and the instance.")
    return wanted[0]["platform"], wanted[0]["instance"]


def read_manifest(zip_path: str | Path) -> dict:
    with zipfile.ZipFile(zip_path) as zf:
        return json.loads(zf.read(MANIFEST_NAME))


def export_scan(db_path: str | Path, dest_dir: str | Path | None = None, platform: str | None = None, instance: str | None = None) -> Path:
    """Write `EstateScan-<instance>-<timestamp>.zip` into `dest_dir` and return its path.

    One estate goes in: the (platform, instance) named, else the latest completed scan's. Naming only an instance finds its
    platform when exactly one has it; the manifest's `other_estates_left_out` says how many others the file held."""
    db_path = Path(db_path)
    if not db_path.exists():
        raise FileNotFoundError(f"No scan database at {db_path}")
    platform, instance = _chosen_estate(db_path, platform, instance)
    dest_dir = Path(dest_dir) if dest_dir else default_export_dir()
    dest_dir.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory() as tmp:
        copy = Path(tmp) / EXPORT_DB_NAME
        left_out = _sanitised_copy(db_path, copy, platform, instance)
        manifest = _manifest(copy, left_out)
        scan = manifest["latest_completed_scan"]
        if scan is None:
            raise ValueError("There is no completed scan to export yet. Run a scan first.")
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        safe_instance = "".join(c if c.isalnum() or c in "-_" else "_" for c in scan["instance"])
        zip_path = dest_dir / f"EstateScan-{safe_instance}-{stamp}.zip"
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.write(copy, EXPORT_DB_NAME)
            zf.writestr(MANIFEST_NAME, json.dumps(manifest, indent=2))
    return zip_path

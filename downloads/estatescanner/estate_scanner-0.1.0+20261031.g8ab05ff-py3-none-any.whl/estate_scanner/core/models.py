"""Platform-agnostic domain model.

Every BI platform adapter maps its native payloads into these dataclasses.
Nothing here names a specific platform's vocabulary (no "Beast Mode", no
"Magic ETL", no "page") -- that translation happens entirely inside each
adapters/<platform>/client.py.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime


@dataclass(frozen=True)
class ObjectRef:
    """A pointer to some object, by its generic type tag + id, independent
    of which typed table it lives in. The universal currency for edges."""

    object_type: str
    id: str


@dataclass
class BaseObject:
    id: str
    name: str | None
    owner_id: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    raw_payload: dict = field(default_factory=dict)
    # The workspace (object type "workspace") holding this object, for
    # platforms that group content that way; set only on the objects a
    # workspace directly contains, not on parts of them (a visual belongs to
    # its report, not to the workspace).
    workspace_id: str | None = None


@dataclass
class Refresh:
    """One run of a dataset's or dataflow's data refresh (Power BI: a refresh-history entry or a dataflow
    transaction). Stored as a row of its own, so the history outlives the platform's window on it."""

    id: str
    status: str | None = None  # the platform's word: "Completed", "Failed", "Unknown" (still running), "Success" ...
    refresh_type: str | None = None  # e.g. "Scheduled", "OnDemand", "ViaApi"
    started_at: datetime | None = None
    ended_at: datetime | None = None
    error: str | None = None  # the platform's error text, as it gave it
    raw_payload: dict = field(default_factory=dict)


@dataclass
class Dataset(BaseObject):
    provider_type: str | None = None
    stream_id: str | None = None
    row_count: int | None = None
    column_count: int | None = None
    schema_columns: list[dict] | None = None
    is_deleted: bool = False
    # A platform may precompute its own downstream-impact counts (Domo
    # does); kept generic here rather than named after Domo's "impact"
    # terminology. Re-derivable from `edges` for platforms that don't
    # provide it natively.
    downstream_card_count: int | None = None
    downstream_dataflow_count: int | None = None
    downstream_dataset_count: int | None = None
    downstream_alert_count: int | None = None
    # Row-level security policies; None means not captured (a failed call),
    # an empty list means the dataset has none.
    pdp_policies: list[dict] | None = None
    # The modelling layer a platform attaches to the dataset itself (Power BI:
    # tables, columns, measures, relationships, partitions, roles). Domo keeps
    # the equivalent on Dataflow.definition.
    definition: dict | None = None
    # Ids of the external connections (object type "account") this dataset
    # reads from, when the platform says so.
    account_ids: list[str] = field(default_factory=list)
    # The refresh history the platform returned; None means not captured (a failed call), an empty
    # list means it has never refreshed.
    refreshes: list[Refresh] | None = None


@dataclass
class Dataflow(BaseObject):
    engine: str | None = None  # generalizes Domo's is_magic, e.g. "magic_etl" | "sql"
    is_deleted: bool = False
    input_dataset_ids: list[str] = field(default_factory=list)
    output_dataset_ids: list[str] = field(default_factory=list)
    # Ids of the external connections (object type "account") this dataflow
    # reads from, and of the dataflows whose output it builds on (Power BI:
    # linked entities), when the platform says so.
    account_ids: list[str] = field(default_factory=list)
    upstream_dataflow_ids: list[str] = field(default_factory=list)
    last_run_state: str | None = None
    last_run_failed: bool | None = None
    last_run_at: datetime | None = None
    refreshes: list[Refresh] | None = None
    # The full transform-tile DAG (each tile's type, config, and dependency
    # links) -- what a migration actually needs to regenerate the ETL on
    # another platform, not just its input/output lineage.
    definition: dict | None = None


@dataclass
class Card(BaseObject):
    card_type: str | None = None
    dataset_ids: list[str] = field(default_factory=list)
    # The dashboard (Power BI: the report) a pinned tile was taken from, when
    # that is a different object from the dashboard holding the tile.
    source_dashboard_ids: list[str] = field(default_factory=list)
    # Full chart/visualization definition (formatting, drill paths,
    # per-component overrides) -- needed to recreate the exact visual on
    # another platform, not just which dataset it reads from.
    definition: dict | None = None


@dataclass
class DashboardFilter:
    field: str | None
    label: str | None
    filter_type: str | None
    raw_payload: dict = field(default_factory=dict)


@dataclass
class Dashboard(BaseObject):  # generalizes Domo's "page"
    parent_id: str | None = None
    card_ids: list[str] = field(default_factory=list)
    # Datasets the dashboard as a whole reads from (Power BI: a report is bound
    # to one semantic model), for platforms where that is stated on the
    # dashboard rather than only on each card.
    dataset_ids: list[str] = field(default_factory=list)
    filters: list[DashboardFilter] = field(default_factory=list)
    # The grid/section layout (tile positions, sizes, per-tile display
    # options) -- needed to recreate the dashboard's actual arrangement.
    layout: dict | None = None


@dataclass
class CalculatedField(BaseObject):  # generalizes Beast Mode / DAX / LookML
    formula_language: str | None = None  # e.g. "domo_beast_mode" | "dax" | "lookml"
    formula: str | None = None
    status: str | None = None
    data_type: str | None = None
    is_global: bool = False
    is_locked: bool = False
    linked_object_refs: list[ObjectRef] = field(default_factory=list)
    # Everything beyond the bare expression text: referenced functions,
    # column positions, aggregation behavior -- what a migration needs to
    # faithfully translate the formula, not just display it.
    definition: dict | None = None


@dataclass
class RoleAssignment:
    """A role a user or group holds on one object (Power BI: a workspace role or an item's
    access right). Becomes a ``has_role`` edge with the role on it."""

    target: ObjectRef
    role: str | None = None
    roles: list[str] = field(default_factory=list)  # every distinct right found, when more than one


@dataclass
class User(BaseObject):
    email: str | None = None
    role: str | None = None
    title: str | None = None
    group_ids: list[str] = field(default_factory=list)
    role_assignments: list[RoleAssignment] = field(default_factory=list)


@dataclass
class Group(BaseObject):
    role_assignments: list[RoleAssignment] = field(default_factory=list)


@dataclass
class Account(BaseObject):
    connector_type: str | None = None
    # The gateway this connection goes through (a ``hosts`` edge from it), if any.
    gateway_id: str | None = None


@dataclass
class Workspace(BaseObject):
    """A container other objects live in (Power BI / Fabric workspace)."""

    workspace_type: str | None = None  # e.g. "Workspace" | "PersonalGroup"
    state: str | None = None  # e.g. "Active" | "Deleted"
    capacity_id: str | None = None
    is_on_dedicated_capacity: bool | None = None


@dataclass
class Gateway(BaseObject):
    """An on-premises data gateway (Power BI): the machine that reaches sources the cloud cannot."""

    gateway_type: str | None = None  # e.g. "Resource" (standard) | "Personal"
    status: str | None = None
    machine: str | None = None
    version: str | None = None


@dataclass
class Alert(BaseObject):
    rule: str | None = None
    watched_object: ObjectRef | None = None
    disabled: bool = False


@dataclass
class AppView:
    """One screen inside an app -- in Domo, each view IS a dashboard (page)
    id in its own right, just organized under the app's navigation rather
    than the general dashboard list."""

    view_id: str
    title: str | None
    parent_view_id: str | None = None
    view_order: int | None = None
    visible: bool = True


@dataclass
class App(BaseObject):
    app_type: str | None = None
    landing_dashboard_id: str | None = None
    # Every screen in the app (see AppView), its nav menu structure, and its
    # branding/theme -- an app is not just "a thing that opens a dashboard",
    # it's a small multi-page product with its own navigation and look.
    views: list[AppView] = field(default_factory=list)
    navigations: list[dict] = field(default_factory=list)
    theme: dict | None = None


@dataclass
class Relationship:
    src: ObjectRef
    dst: ObjectRef
    edge_type: str
    weight: float = 1.0
    data: dict | None = None  # kept on the edge as raw_json, e.g. the role of a has_role edge


@dataclass
class ScanIssue:
    """Something a scan could not read. Recorded, never raised: the scan goes
    on, and the person reading the result sees what is missing and why."""

    scope: str  # what was being read, e.g. "workspace Sales / report Q3"
    message: str
    status: int | None = None  # HTTP status, when there was one
    phase: str | None = None  # set when the cause is not the object type being fetched, e.g. "setup"


@dataclass
class ScanProgressEvent:
    phase: str
    completed: int
    total: int | None
    elapsed_s: float
    message: str | None = None

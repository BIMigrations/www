"""COVERAGE.md: for each kind of thing in an export, how much was converted and why the rest was not.

Built from the files in the export directory (the same files a reader gets), not from the exporter's
internals, so it can be regenerated for any checked-out export (`bimcontrol export-verify` style) and
cannot say anything the files do not show.

"Converted" here means what the export can say about it: a visual is converted when it has a neutral type
(not `other`); a transformation when its SQL was written; a dataset when it has an extract stream. It does
not mean "migrated to Power BI": that is the run report's per-element status, not the export's.
"""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Any


def _docs(folder: Path) -> list[dict[str, Any]]:
    if not folder.exists():
        return []
    return [json.loads(p.read_text(encoding="utf-8")) for p in sorted(folder.glob("*.json"))]


def _row(kind: str, converted: int, total: int, reasons: dict[str, int], note: str | None = None) -> dict[str, Any]:
    return {"kind": kind, "converted": converted, "total": total,
            "reasons": {k: v for k, v in sorted(reasons.items(), key=lambda kv: (-kv[1], kv[0])) if v},
            "note": note}


def _ids(flows: list[dict[str, Any]]) -> str:
    ids = [str(f.get("id")) for f in flows]
    return ", ".join(ids[:6]) + (f", and {len(ids) - 6} more" if len(ids) > 6 else "")


# Dataset categories of the extract index that have no source to read from (the rest can have an extract definition).
_NOTHING_TO_EXTRACT = ("derived", "manual_upload", "pushed", "manual_entry", "platform_internal")
_CATEGORY_WORDS = {"derived": "outputs of dataflows", "manual_upload": "manual uploads", "pushed": "pushed", "manual_entry": "manual entry",
                   "platform_internal": "platform internal", "no_airbyte_source": "no Airbyte source", "unclassified": "unclassified"}


def _counts(by_category: dict[str, int]) -> str:
    return ", ".join(f"{n:,} {_CATEGORY_WORDS.get(c, c.replace('_', ' '))}"
                     for c, n in sorted(by_category.items(), key=lambda kv: (-kv[1], kv[0])))


def _share(converted: int, total: int) -> str:
    """Whole percent; a gap is never rounded up to `100 %` nor a converted few down to `0 %` (one decimal, within 0.1..99.9)."""
    if not total:
        return "-"
    if converted in (0, total):
        return f"{100 * converted // total} %"
    pct = 100 * converted / total
    return f"{pct:.0f} %" if 1 <= pct < 99.5 else f"{min(99.9, max(0.1, pct)):.1f} %"


def build(out: Path) -> dict[str, Any]:
    """`{rows: [...], generated_from: <platform>}` from the export directory."""
    dashboards = _docs(out / "dashboards")
    standalone = _docs(out / "cards")
    models = _docs(out / "models")
    flows = _docs(out / "transformations")
    apps = _docs(out / "apps")
    metrics_files = _docs(out / "metrics")
    index_file = out / "extract" / "index.json"
    index = json.loads(index_file.read_text(encoding="utf-8")) if index_file.exists() else None
    manifest = json.loads((out / "manifest.json").read_text(encoding="utf-8")) if (out / "manifest.json").exists() else {}
    rows: list[dict[str, Any]] = []

    placed = [v for d in dashboards for v in d["visuals"]]
    visuals = placed + standalone
    kinds = Counter(v["type"] for v in visuals)
    other = Counter((v.get("source") or {}).get("chart_type") or "unknown" for v in visuals if v["type"] == "other")
    distinct_placed = len({v["id"] for v in placed})
    distinct_all = len({v["id"] for v in visuals})
    rows.append(_row("visuals: neutral type", len(visuals) - kinds.get("other", 0), len(visuals),
                     {"chart type not in the neutral table": kinds.get("other", 0)},
                     f"{len(visuals):,} visual documents: {len(standalone):,} standalone cards and {len(placed):,} placements on dashboards "
                     f"({distinct_placed:,} distinct cards); {distinct_all:,} distinct cards in all. "
                     "A visual with type `other` keeps its source chart type; nothing is guessed. Most common: "
                     + (", ".join(f"{t} ({n})" for t, n in other.most_common(6)) or "none") + "."))
    text_boxes = [v for v in visuals if v["type"] == "text"]
    others = [v for v in visuals if v["type"] == "other"]
    data = [v for v in visuals if v["type"] not in ("text", "other")]
    no_fields = sum(1 for v in data if not v["fields"])
    rows.append(_row("visuals: fields read", len(data) - no_fields, len(data),
                     {"data visual whose saved query the scan did not hold": no_fields},
                     f"Data visuals only. Not in this count: text boxes, {len(text_boxes):,} ({sum(1 for v in text_boxes if not v['fields']):,} "
                     f"without fields), and visuals of another type, {len(others):,} ({sum(1 for v in others if not v['fields']):,} without fields)."))
    rows.append(_row("dashboards: pages and items", sum(1 for d in dashboards if d["pages"] and any(p["items"] for p in d["pages"])),
                     len(dashboards), {"no page with an item": sum(1 for d in dashboards if not any(p["items"] for p in d["pages"]))}))

    all_metrics = [m for d in metrics_files for m in d["metrics"]]
    langs = Counter(m.get("language") or "unknown" for m in all_metrics)
    rows.append(_row("metrics: expression exported", sum(1 for m in all_metrics if m.get("expression")), len(all_metrics),
                     {"no expression in the scan": sum(1 for m in all_metrics if not m.get("expression"))},
                     "Languages: " + ", ".join(f"{k} {v}" for k, v in langs.most_common())
                     + ". The export keeps the source expression; translating it to DAX is the migration's job."))

    secured = sum(1 for m in models if m["access"]["policies"])
    rows.append(_row("models: columns exported", sum(1 for m in models if m["columns"]), len(models),
                     {"the scan holds no column list": sum(1 for m in models if not m["columns"])},
                     f"{secured} model(s) carry row-level access policies."))

    with_sql = sum(1 for f in flows if f.get("sql") and any(o.get("file") for o in f["sql"]["outputs"]))
    why: Counter = Counter()
    for f in flows:
        if f.get("sql") and any(o.get("file") for o in f["sql"]["outputs"]):
            continue
        if f.get("engine") == "mysql":
            why["SQL-engine dataflow: its statements are in the steps' config, the converter reads Magic ETL only"] += 1
        elif f.get("engine") not in ("magic", "etl"):
            why[f"engine {f.get('engine')!r}: not read by the converter (Magic ETL and Domo's older ETL only)"] += 1
        else:
            why["no converter run covered this transformation" if not f.get("sql") else "converter produced no SQL file"] += 1
    unsupported: Counter = Counter()
    for f in flows:
        for step in (f.get("sql") or {}).get("unsupported_steps") or []:
            unsupported[str(step)] += 1
    written = [f for f in flows if f.get("sql") and any(o.get("file") for o in f["sql"]["outputs"])]
    checked: list = []
    converter_only: list = []
    rejected: list = []
    unchecked: list = []
    unchecked_named: list = []
    for f in written:
        outputs = [o for o in f["sql"]["outputs"] if o.get("file")]
        if all(o.get("checked_by_warehouse") for o in outputs):
            checked.append(f)
        elif f["sql"].get("basis") == "converter_only":
            converter_only.append(f)
        elif any(o.get("check_error") and not str(o["check_error"]).startswith("not checked") for o in outputs):
            rejected.append(f)
        else:
            unchecked.append(f)
            if any(str(o.get("check_error") or "").startswith("not checked") for o in outputs):
                unchecked_named.append(f)
    left_out = ""
    if rejected:
        left_out += f"; {len(rejected)} the warehouse rejected ({_ids(rejected)})"
    if unchecked:
        # Only an explicit "not checked: ..." reason names the cause; a flow with no check result at all (no warehouse
        # configured, nothing recorded) is just not checked.
        cause = ", an input is not in the scan or not available" if len(unchecked_named) == len(unchecked) else ""
        left_out += f"; {len(unchecked)} were not checked against the warehouse{cause} ({_ids(unchecked)})"
    rows.append(_row("transformations: SQL written", with_sql, len(flows), dict(why),
                     f"{len(checked)} of the {len(written)} were accepted by the warehouse when converted; {len(converter_only)} come from the "
                     f"converter alone and were not run against data{left_out}. "
                     "Steps are always exported. Steps the converter does not translate: "
                     + (", ".join(f"{k} ({v})" for k, v in unsupported.most_common(6)) or "none recorded") + "."))
    portable = (manifest.get("coverage") or {}).get("portable_sql")
    if portable:
        queries, parsed = portable["queries"], portable["rendered"]
        outside = portable["with_non_portable_constructs"]
        core_only = max(0, parsed - outside)
        names = ", ".join(c["construct"] for c in (portable.get("most_common_non_portable") or [])[:4])
        rows.append(_row("transformations: SQL rewritten for PostgreSQL", parsed, queries,
                         {"did not parse": queries - parsed},
                         f"{parsed:,} of {queries:,} queries parse after the rewrite to PostgreSQL syntax (not run on any database); "
                         f"{core_only:,} of them use only core-ANSI constructs, the other {outside:,} use constructs outside that set"
                         + (f" ({names} ...)" if names else "") + ", listed per output."))
        rows.append(_row("transformations: SQL of core-ANSI constructs only", core_only, queries,
                         {"uses a construct outside core ANSI": outside, "did not parse": queries - parsed}))

    if index is not None:
        summary = index["summary"]
        total = len(index["datasets"])
        reasons = {c: n for c, n in summary.items() if c != "extractable"}
        nothing = {c: n for c, n in summary.items() if c in _NOTHING_TO_EXTRACT}
        can = total - sum(nothing.values())
        can_not = {c: n for c, n in reasons.items() if c not in _NOTHING_TO_EXTRACT}
        rows.append(_row("datasets: extract definition", summary.get("extractable", 0), total,
                         {f"{c.replace('_', ' ')}": n for c, n in reasons.items()},
                         f"An extract definition for {summary.get('extractable', 0):,} of the {can:,} datasets that can have one"
                         + (f" (the other {sum(can_not.values()):,}: {_counts(can_not)})" if can_not else "")
                         + f"; {sum(nothing.values()):,} more have nothing to extract ({_counts(nothing)}). "
                         "Not run on Airbyte; connection templates hold placeholders, never values."))

    screens = [v for a in apps for v in a["views"]]
    rows.append(_row("apps: screens whose dashboard is exported", sum(1 for v in screens if v["dashboard_exported"]), len(screens),
                     {"screen's dashboard is not in the scan": sum(1 for v in screens if not v["dashboard_exported"])},
                     f"{len(apps)} app document(s) with navigation and theme."))
    return {"rows": rows, "platform": (manifest.get("source") or {}).get("platform")}


def markdown(cov: dict[str, Any], manifest: dict[str, Any] | None = None) -> str:
    """The table, written for a reader of the export (no tool names)."""
    lines = ["# Coverage", "",
             "What this export converted, out of how much, and why the rest was not. \"Converted\" means what the export can say about it "
             "(see each note); it does not mean migrated to Power BI.", ""]
    if manifest:
        scan = (manifest.get("source") or {}).get("scan") or {}
        lines += [f"Source platform: `{cov.get('platform')}`. Scan {scan.get('id', '?')} of {scan.get('instance', '?')}, "
                  f"finished {scan.get('finished_at', '?')}. Spec `{manifest.get('spec')}`.", ""]
    lines += ["| Kind | Converted | Total | Share | Why the rest was not converted |", "|---|---:|---:|---:|---|"]
    for r in cov["rows"]:
        share = _share(r["converted"], r["total"])
        why = "; ".join(f"{k} ({v})" for k, v in r["reasons"].items()) or "-"
        lines.append(f"| {r['kind']} | {r['converted']:,} | {r['total']:,} | {share} | {why} |")
    lines += [""]
    for r in cov["rows"]:
        if r.get("note"):
            lines.append(f"- **{r['kind']}**: {r['note']}")
    lines += ["", "Known limits of the whole export are in `manifest.json` under `limits`.", ""]
    return "\n".join(lines)

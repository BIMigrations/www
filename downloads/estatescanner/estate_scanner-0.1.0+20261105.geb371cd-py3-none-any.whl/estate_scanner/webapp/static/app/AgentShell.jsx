import React from 'react';

const NAV = [
  { key: 'connect', label: 'Connect', icon: 'link' },
  { key: 'bimdash', label: 'BimDash', icon: 'external' },
  { key: 'scan', label: 'Scan', icon: 'refresh' },
  { key: 'estate', label: 'Estate', icon: 'database' },
  { key: 'lineage', label: 'Lineage', icon: 'layers' },
];

export function AgentShell() {
  const [tab, setTab] = React.useState('estate');
  const [scope, setScope] = React.useState(null); // { platform, instance } the Estate and Lineage screens read; null = newest scan of each platform
  const [instances, setInstances] = React.useState([]);
  const [lastConnected, setLastConnected] = React.useState({ platform: null, instance: null });
  const [bimdash, setBimdash] = React.useState(null); // the BimDash pairing status for the sidebar's indicator; null until first read

  // Read again whenever the screen changes: a scan finished on the Scan screen adds or renews an instance.
  React.useEffect(function () {
    fetchEstateInstances().then(function (list) {
      setInstances(list);
      setScope(function (prev) {
        return prev && !list.some(function (i) { return i.platform === prev.platform && i.instance === prev.instance; }) ? null : prev;
      });
    });
  }, [tab]);

  // The pairing indicator reads again whenever the screen changes, and the BimDash screen calls back after a connect or a
  // disconnect, so it never says a pairing that is already gone -- or misses one just made.
  function refreshBimdash() {
    fetchBimdash().then(setBimdash).catch(function () { setBimdash({ connected: false }); });
  }
  React.useEffect(function () { refreshBimdash(); }, [tab]);

  function goToScan(platform, instance) {
    setLastConnected({ platform: platform || lastConnected.platform, instance: instance || lastConnected.instance });
    setTab('scan');
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', background: 'var(--surface-canvas)' }}>
      <div style={{ height: 3, flex: 'none', background: 'linear-gradient(90deg, var(--provenance-source) 0%, var(--provenance-source) 42%, var(--provenance-target) 58%, var(--provenance-target) 100%)' }} />
      <div style={{ display: 'flex', flex: 1, minHeight: 0, color: 'var(--text-primary)', fontFamily: 'var(--font-ui)' }}>
        <div style={{
          width: 216, flex: 'none', background: 'var(--surface-chrome)',
          borderRight: '1px solid var(--border-hairline)',
          display: 'flex', flexDirection: 'column', padding: '18px 12px',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 11, padding: '2px 8px 22px' }}>
            <Logo variant="mark" size={30} />
            <div style={{ display: 'flex', flexDirection: 'column', gap: 3, minWidth: 0 }}>
              <div style={{
                fontSize: 'var(--text-lg)', fontWeight: 'var(--weight-semibold)',
                letterSpacing: 'var(--tracking-heading)', color: 'var(--text-primary)', lineHeight: 1,
                whiteSpace: 'nowrap',
              }}>Estate Scanner</div>
              <div style={{ fontSize: 9, fontWeight: 'var(--weight-semibold)', letterSpacing: '0.14em', textTransform: 'uppercase', color: 'var(--text-tertiary)', lineHeight: 1 }}>
                BI<span style={{ opacity: 0.5 }}>/</span>Migrations
              </div>
            </div>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            {NAV.map(function (n) {
              return (
                <NavItem
                  key={n.key}
                  label={n.label}
                  icon={<Icon name={n.icon} size={16} />}
                  active={tab === n.key}
                  onClick={function () { setTab(n.key); }}
                />
              );
            })}
          </div>

          {(tab === 'estate' || tab === 'lineage') && <InstancePicker instances={instances} scope={scope} onChange={setScope} />}

          <div style={{ flex: 1 }} />

          <div style={{ padding: '10px 8px 2px', borderTop: '1px solid var(--border-hairline)' }}>
            {bimdash && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6, paddingBottom: 10 }}>
                <div style={{ fontSize: 'var(--text-2xs)', fontWeight: 'var(--weight-semibold)', letterSpacing: '0.14em', textTransform: 'uppercase', color: 'var(--text-tertiary)', lineHeight: 1 }}>
                  BimDash
                </div>
                <StatusDot status={bimdash.connected ? 'ok' : 'idle'} label={bimdash.connected ? 'Connected' : 'Not connected'} />
              </div>
            )}
            <div style={{ fontSize: 'var(--text-2xs)', color: 'var(--text-disabled)', letterSpacing: 'var(--tracking-micro)' }}>
              Runs locally &middot; scans stay on this machine
            </div>
          </div>
        </div>

        <div style={{ flex: 1, minWidth: 0, overflow: 'auto', background: 'var(--surface-canvas)' }}>
          {tab === 'connect' && <ConnectScreen onConnected={goToScan} onOpenBimdash={function () { setTab('bimdash'); }} />}
          {tab === 'bimdash' && <BimdashScreen onChanged={refreshBimdash} />}
          {tab === 'scan' && <ScanScreen defaultPlatform={lastConnected.platform} defaultInstance={lastConnected.instance} />}
          {tab === 'estate' && <EstateScreen scope={scope} onGoToScan={function () { setTab('scan'); }} />}
          {tab === 'lineage' && <LineageScreen scope={scope} />}
        </div>
      </div>
    </div>
  );
}

"""Loads the estate database into a networkx graph for connectivity analysis.

Driven by the open object-type registry (estate_scanner.core.registry)
rather than a hardcoded table map, so a new adapter introducing a new
object type doesn't require editing this file. Node keys are
"platform:type:id" so more than one platform's data can share one graph
without id collisions. A graph covers ONE instance per platform (two
instances can hold the same id for different objects, #55); which one is
decided by `db.scope`.
"""

from __future__ import annotations

import sqlite3

import networkx as nx

from .core.registry import all_object_types
from .storage import db


def _node_key(platform: str, node_type: str, node_id: str) -> str:
    return f"{platform}:{node_type}:{node_id}"


# Who may open what is not lineage: a role edge would put every person with a workspace role
# upstream of everything in the workspace, and a workspace's content downstream of each person.
ACCESS_EDGE_TYPES = ("has_role",)


def build_graph(conn: sqlite3.Connection, weighted: bool = True, platform: str | None = None,
                include_access: bool = False, instance: str | None = None, latest: bool = False) -> nx.DiGraph:
    """The graph of `platform` (all platforms when None) at `instance`. A platform holding several
    instances needs one named, else AmbiguousInstance lists them; `latest=True` takes the newest scan's."""
    graph = nx.DiGraph()
    scope_sql, scope_params = db.scope_sql(db.scope(conn, platform, instance, latest=latest))

    for descriptor in all_object_types():
        query = f"SELECT platform, instance, id, {descriptor.name_column} AS name FROM {descriptor.table} WHERE {scope_sql}"  # noqa: S608 -- registry names, scope built from ? placeholders
        for row in conn.execute(query, scope_params):
            key = _node_key(row["platform"], descriptor.object_type, row["id"])
            graph.add_node(key, platform=row["platform"], instance=row["instance"], type=descriptor.object_type, id=row["id"], name=row["name"])

    edge_query = f"SELECT platform, instance, src_type, src_id, dst_type, dst_id, edge_type, weight FROM edges WHERE {scope_sql}"  # noqa: S608
    edge_params: tuple = tuple(scope_params)
    if not include_access:
        edge_query += f" AND edge_type NOT IN ({', '.join('?' * len(ACCESS_EDGE_TYPES))})"
        edge_params += ACCESS_EDGE_TYPES
    for row in conn.execute(edge_query, edge_params):
        src = _node_key(row["platform"], row["src_type"], row["src_id"])
        dst = _node_key(row["platform"], row["dst_type"], row["dst_id"])
        graph.add_edge(src, dst, edge_type=row["edge_type"], weight=row["weight"] if weighted else 1.0)

    # An edge can reference an id the scan never captured as a typed row
    # (permission-scoped exclusions, deletions between calls, etc.) --
    # networkx auto-creates that node with no attributes. Backfill from the
    # node key so it still reports sensibly instead of showing as `{}`.
    instance_of = {platform_: instance_ for platform_, instance_ in db.scope(conn, platform, instance, latest=latest)}
    for node_key, attrs in graph.nodes(data=True):
        if "type" not in attrs:
            node_platform, _, rest = node_key.partition(":")
            node_type, _, node_id = rest.partition(":")
            attrs.update(platform=node_platform, instance=instance_of.get(node_platform, ""), type=node_type, id=node_id, name=None)

    return graph


def most_connected(graph: nx.DiGraph, top_n: int = 20) -> list[tuple[str, dict, int]]:
    """Nodes ranked by total (in+out) degree — the estate's structural hubs."""
    degrees = sorted(graph.degree(), key=lambda kv: kv[1], reverse=True)
    return [(key, graph.nodes[key], degree) for key, degree in degrees[:top_n]]


def downstream(graph: nx.DiGraph, node_key: str, max_depth: int | None = None) -> set[str]:
    """Everything that would be affected if `node_key` were retired."""
    return set(nx.descendants(graph, node_key)) if max_depth is None else _bounded_reach(graph, node_key, max_depth, reverse=False)


def upstream(graph: nx.DiGraph, node_key: str, max_depth: int | None = None) -> set[str]:
    """Everything `node_key` depends on."""
    return set(nx.ancestors(graph, node_key)) if max_depth is None else _bounded_reach(graph, node_key, max_depth, reverse=True)


def _bounded_reach(graph: nx.DiGraph, node_key: str, max_depth: int, reverse: bool) -> set[str]:
    g = graph.reverse(copy=False) if reverse else graph
    seen: set[str] = set()
    frontier = {node_key}
    for _ in range(max_depth):
        frontier = {nbr for n in frontier for nbr in g.successors(n)} - seen - {node_key}
        if not frontier:
            break
        seen |= frontier
    return seen

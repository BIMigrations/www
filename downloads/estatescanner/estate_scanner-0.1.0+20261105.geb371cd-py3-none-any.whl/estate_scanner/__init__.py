"""Estate Scanner: inventories a customer's BI estate into a local SQLite graph."""

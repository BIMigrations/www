from __future__ import annotations

import json

from fastapi import APIRouter, Depends, HTTPException

from estate_scanner import graph as graph_module
from estate_scanner.core.registry import all_object_types, get_object_type

from ..deps import get_conn
from ..graph_cache import get_graph

router = APIRouter()

# Allow-listed sortable columns per object type -- never accept a raw
# column name from the request straight into SQL.
_SORTABLE = {
    "dataset": ["name", "provider_type", "row_count", "column_count", "updated_at", "downstream_card_count"],
    "dataflow": ["name", "engine", "num_inputs", "num_outputs", "last_execution_state", "modified_at"],
    "card": ["name", "type", "dataset_id"],
    "dashboard": ["name", "parent_dashboard_id"],
    "user": ["name", "email", "role"],
    "group": ["name"],
    "account": ["name", "connector_type"],
    "calculated_field": ["name", "formula_language", "status"],
    "alert": ["name", "resource_type", "disabled"],
    "app": ["name", "type"],
    "workspace": ["name", "type", "state", "capacity_id"],
    "gateway": ["name", "type", "status", "machine", "version"],
}


@router.get("/summary")
def summary(conn=Depends(get_conn), platform: str | None = None):
    counts = {}
    for descriptor in all_object_types():
        query = f"SELECT COUNT(*) FROM {descriptor.table}"
        params: tuple = ()
        if platform:
            query += " WHERE platform = ?"
            params = (platform,)
        counts[descriptor.object_type] = conn.execute(query, params).fetchone()[0]

    edge_query = "SELECT COUNT(*) FROM edges" + (" WHERE platform = ?" if platform else "")
    edge_count = conn.execute(edge_query, (platform,) if platform else ()).fetchone()[0]
    last_scan = conn.execute(
        "SELECT id, platform, instance, started_at, finished_at, status FROM scans ORDER BY id DESC LIMIT 1"
    ).fetchone()
    return {"counts": counts, "edge_count": edge_count, "last_scan": dict(last_scan) if last_scan else None}


@router.get("/{object_type}")
def list_objects(
    object_type: str,
    conn=Depends(get_conn),
    page: int = 1,
    page_size: int = 100,
    sort: str | None = None,
    dir: str = "asc",
    q: str | None = None,
    owner: str | None = None,
    platform: str | None = None,
):
    try:
        descriptor = get_object_type(object_type)
    except KeyError:
        raise HTTPException(404, f"Unknown object type: {object_type}") from None

    allowed_sorts = _SORTABLE.get(object_type, ["name"])
    sort_col = sort if sort in allowed_sorts else allowed_sorts[0]
    sort_dir = "DESC" if dir.lower() == "desc" else "ASC"

    where: list[str] = []
    params: list = []
    if platform:
        where.append("platform = ?")
        params.append(platform)
    if owner:
        where.append("owner_id = ?")
        params.append(owner)
    if q:
        where.append(f"{descriptor.name_column} LIKE ?")
        params.append(f"%{q}%")
    where_sql = f"WHERE {' AND '.join(where)}" if where else ""

    total = conn.execute(f"SELECT COUNT(*) FROM {descriptor.table} {where_sql}", params).fetchone()[0]  # noqa: S608 -- table/column names are allow-listed above, never request-supplied raw
    page = max(1, page)
    page_size = max(1, min(page_size, 500))
    offset = (page - 1) * page_size
    rows = conn.execute(
        f"SELECT * FROM {descriptor.table} {where_sql} ORDER BY {sort_col} {sort_dir} LIMIT ? OFFSET ?",  # noqa: S608
        [*params, page_size, offset],
    ).fetchall()
    return {"rows": [dict(r) for r in rows], "total": total, "page": page, "page_size": page_size}


@router.get("/{object_type}/{object_id}")
def get_object(object_type: str, object_id: str, conn=Depends(get_conn), platform: str | None = None):
    try:
        descriptor = get_object_type(object_type)
    except KeyError:
        raise HTTPException(404, f"Unknown object type: {object_type}") from None

    if platform:
        row = conn.execute(f"SELECT * FROM {descriptor.table} WHERE platform = ? AND id = ?", (platform, object_id)).fetchone()  # noqa: S608
    else:
        row = conn.execute(f"SELECT * FROM {descriptor.table} WHERE id = ? ORDER BY platform LIMIT 1", (object_id,)).fetchone()  # noqa: S608
    if row is None:
        raise HTTPException(404, "Object not found")
    platform = row["platform"]

    g = get_graph(conn, platform)
    node_key = f"{platform}:{object_type}:{object_id}"

    result = dict(row)
    result["upstream"] = [_node_summary(g, k) for k in _neighbors(g, node_key, upstream=True)]
    result["downstream"] = [_node_summary(g, k) for k in _neighbors(g, node_key, upstream=False)]
    # Role edges are not lineage (the graph leaves them out); read them from the table.
    result["access"] = _role_edges(conn, platform, object_type, object_id, holders=True)
    result["holds"] = _role_edges(conn, platform, object_type, object_id, holders=False)
    if object_type in ("dataset", "dataflow"):
        result["refreshes"] = [dict(r) for r in conn.execute(
            "SELECT id, refresh_type, status, started_at, ended_at, error FROM refreshes "
            "WHERE platform = ? AND object_type = ? AND object_id = ? ORDER BY started_at DESC, id LIMIT 200",
            (platform, object_type, object_id))]
    return result


def _role_edges(conn, platform: str, object_type: str, object_id: str, holders: bool) -> list[dict]:
    """The has_role edges into this object (who holds a role on it: `holders`) or out of it (what
    it holds a role on), with the other end's name and the role."""
    here, there = ("dst", "src") if holders else ("src", "dst")
    rows = conn.execute(
        f"SELECT {there}_type AS type, {there}_id AS id, raw_json FROM edges "  # noqa: S608
        f"WHERE platform = ? AND edge_type = 'has_role' AND {here}_type = ? AND {here}_id = ? ORDER BY {there}_type, {there}_id",
        (platform, object_type, object_id),
    ).fetchall()
    names: dict[tuple[str, str], str | None] = {}
    by_type: dict[str, list[str]] = {}
    for row in rows:
        by_type.setdefault(row["type"], []).append(row["id"])
    for t, ids in by_type.items():
        try:
            d = get_object_type(t)
        except KeyError:
            continue
        for i in range(0, len(ids), 500):
            chunk = ids[i:i + 500]
            for r in conn.execute(
                f"SELECT id, {d.name_column} AS name FROM {d.table} WHERE platform = ? AND id IN ({','.join('?' * len(chunk))})",  # noqa: S608
                (platform, *chunk),
            ):
                names[(t, r["id"])] = r["name"]
    out = []
    for row in rows:
        try:
            role = json.loads(row["raw_json"]).get("role") if row["raw_json"] else None
        except ValueError:
            role = None
        out.append({"type": row["type"], "id": row["id"], "name": names.get((row["type"], row["id"])), "role": role})
    return out


def _neighbors(g, node_key: str, upstream: bool) -> list[str]:
    if node_key not in g.nodes:
        return []
    reach = graph_module.upstream(g, node_key) if upstream else graph_module.downstream(g, node_key)
    return sorted(reach)


def _node_summary(g, node_key: str) -> dict:
    attrs = g.nodes[node_key]
    return {"platform": attrs["platform"], "type": attrs["type"], "id": attrs["id"], "name": attrs["name"]}

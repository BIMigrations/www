import React from 'react';

// The one grid used everywhere in this app (Estate, Scan runs, Lineage
// rankings). Column-resize drags a <col> width via mouse listeners bound to
// window rather than the header cell, so the drag keeps tracking even if the
// pointer slips past the resize handle. Sort is "controlled" (server-side)
// when the caller passes onSort; otherwise the grid sorts the rows it was
// given itself. Filtering always happens client-side, against whatever rows
// are currently in view -- for the server-paginated screens that means
// filtering within the current page, which is a fine trade for a local
// desktop tool with a 50-row page size.
const MIN_COL_WIDTH = 64;
const HEADER_ROW_H = 30;
const FILTER_ROW_H = 28;

export function DataGrid({
  columns = [],
  rows = [],
  density = 'dense',
  onRowClick,
  selectedId,
  sort,
  onSort,
  stickyHeader = true,
  zebra = false,
  emptyLabel = 'Nothing here yet',
}) {
  const rowH = density === 'comfortable' ? 'var(--row-h-comfy)' : 'var(--row-h)';
  const [hoverRow, setHoverRow] = React.useState(null);
  const [widths, setWidths] = React.useState({});
  const [uncontrolledSort, setUncontrolledSort] = React.useState(null);
  const [filters, setFilters] = React.useState({});
  const [openFilter, setOpenFilter] = React.useState(null);
  const dragState = React.useRef(null);

  React.useEffect(function () {
    setWidths(function (prev) {
      let changed = false;
      const next = Object.assign({}, prev);
      columns.forEach(function (c) {
        if (next[c.key] == null) { next[c.key] = c.width || 180; changed = true; }
      });
      return changed ? next : prev;
    });
  }, [columns]);

  const controlled = !!onSort;
  const effectiveSort = controlled ? sort : uncontrolledSort;
  const hasFilterRow = openFilter != null && columns.some(function (c) { return c.key === openFilter && c.filterable; });

  function toggleSort(col) {
    if (!col.sortable) return;
    if (controlled) { onSort(col.key); return; }
    setUncontrolledSort(function (prev) {
      if (!prev || prev.key !== col.key) return { key: col.key, dir: 'asc' };
      if (prev.dir === 'asc') return { key: col.key, dir: 'desc' };
      return null;
    });
  }

  function startResize(e, key) {
    e.stopPropagation();
    e.preventDefault();
    dragState.current = { key, startX: e.clientX, startWidth: widths[key] || 180 };
    function onMove(ev) {
      const d = dragState.current;
      if (!d) return;
      const w = Math.max(MIN_COL_WIDTH, d.startWidth + (ev.clientX - d.startX));
      setWidths(function (prev) { return Object.assign({}, prev, { [d.key]: w }); });
    }
    function onUp() {
      dragState.current = null;
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    }
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  }

  let visible = rows;
  Object.keys(filters).forEach(function (key) {
    const needle = (filters[key] || '').trim().toLowerCase();
    if (!needle) return;
    const col = columns.find(function (c) { return c.key === key; });
    visible = visible.filter(function (r) {
      const raw = col && col.render ? col.render(r) : r[key];
      return String(raw == null ? '' : raw).toLowerCase().includes(needle);
    });
  });
  if (effectiveSort && !controlled) {
    const key = effectiveSort.key, dir = effectiveSort.dir;
    visible = visible.slice().sort(function (a, b) {
      const av = a[key], bv = b[key];
      if (av == null && bv == null) return 0;
      if (av == null) return 1;
      if (bv == null) return -1;
      const cmp = typeof av === 'number' && typeof bv === 'number' ? av - bv : String(av).localeCompare(String(bv));
      return dir === 'desc' ? -cmp : cmp;
    });
  }

  function cellStyle(col) {
    return {
      padding: '0 var(--pad-cell-x)',
      textAlign: col.align || 'left',
      fontFamily: col.mono ? 'var(--font-mono)' : 'var(--font-ui)',
      fontVariantNumeric: col.mono ? 'tabular-nums' : undefined,
      fontSize: col.mono ? 'var(--text-sm)' : 'var(--text-md)',
      color: col.muted ? 'var(--text-secondary)' : 'var(--text-primary)',
      whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
    };
  }

  return (
    <div style={{ width: '100%', height: '100%', overflow: 'auto', background: 'var(--surface-card)' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', tableLayout: 'fixed' }}>
        <colgroup>
          {columns.map(function (col) { return <col key={col.key} style={{ width: widths[col.key] || col.width || 180 }} />; })}
        </colgroup>
        <thead>
          <tr style={{ position: stickyHeader ? 'sticky' : undefined, top: 0, zIndex: 2, background: 'var(--surface-panel)' }}>
            {columns.map(function (col) {
              const active = effectiveSort && effectiveSort.key === col.key;
              return (
                <th key={col.key}
                  onClick={function () { toggleSort(col); }}
                  style={{
                    ...cellStyle(col), height: HEADER_ROW_H, position: 'relative',
                    fontFamily: 'var(--font-ui)', fontSize: 'var(--text-xs)', fontWeight: 'var(--weight-semibold)',
                    letterSpacing: 'var(--tracking-micro)', textTransform: 'uppercase',
                    color: active ? 'var(--text-primary)' : 'var(--text-tertiary)',
                    borderBottom: '1px solid var(--border-default)',
                    cursor: col.sortable ? 'pointer' : 'default', userSelect: 'none',
                  }}>
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, maxWidth: '100%' }}>
                    <span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{col.header}</span>
                    {active && <span style={{ color: 'var(--provenance-target)', flex: 'none' }}>{effectiveSort.dir === 'desc' ? '↓' : '↑'}</span>}
                    {col.filterable && (
                      <span
                        onClick={function (e) { e.stopPropagation(); setOpenFilter(openFilter === col.key ? null : col.key); }}
                        style={{ display: 'inline-flex', flex: 'none', color: filters[col.key] ? 'var(--provenance-target)' : 'var(--text-disabled)' }}>
                        <Icon name="filter" size={11} />
                      </span>
                    )}
                  </span>
                  <span
                    onMouseDown={function (e) { startResize(e, col.key); }}
                    onClick={function (e) { e.stopPropagation(); }}
                    style={{ position: 'absolute', right: -3, top: 0, bottom: 0, width: 7, cursor: 'col-resize', zIndex: 3 }} />
                </th>
              );
            })}
          </tr>
          {hasFilterRow && (
            <tr style={{ position: stickyHeader ? 'sticky' : undefined, top: HEADER_ROW_H, zIndex: 1, background: 'var(--surface-panel)' }}>
              {columns.map(function (col) {
                return (
                  <th key={col.key} style={{ padding: '0 6px', height: FILTER_ROW_H, borderBottom: '1px solid var(--border-default)' }}>
                    {col.filterable && openFilter === col.key && (
                      <input
                        autoFocus
                        value={filters[col.key] || ''}
                        onChange={function (e) { setFilters(function (prev) { return Object.assign({}, prev, { [col.key]: e.target.value }); }); }}
                        onClick={function (e) { e.stopPropagation(); }}
                        placeholder="Filter…"
                        style={{
                          width: '100%', height: 22, boxSizing: 'border-box',
                          border: '1px solid var(--border-control)', borderRadius: 'var(--radius-xs)',
                          padding: '0 6px', fontSize: 'var(--text-xs)', fontFamily: 'var(--font-ui)',
                          background: 'var(--surface-card)', color: 'var(--text-primary)', outline: 'none',
                        }}
                      />
                    )}
                  </th>
                );
              })}
            </tr>
          )}
        </thead>
        <tbody>
          {visible.length === 0 && (
            <tr><td colSpan={columns.length} style={{ padding: '28px 12px', textAlign: 'center', fontSize: 'var(--text-md)', color: 'var(--text-tertiary)' }}>{emptyLabel}</td></tr>
          )}
          {visible.map(function (row, i) {
            const id = row.id ?? i;
            const isSelected = selectedId != null && id === selectedId;
            return (
              <tr key={id}
                onMouseEnter={function () { setHoverRow(id); }} onMouseLeave={function () { setHoverRow(null); }}
                onClick={function () { onRowClick && onRowClick(row); }}
                style={{
                  height: rowH,
                  background: isSelected ? 'var(--surface-selected)' : hoverRow === id ? 'var(--surface-hover)' : zebra && i % 2 ? 'var(--surface-panel)' : 'transparent',
                  borderBottom: '1px solid var(--border-hairline)',
                  borderLeft: isSelected ? '2px solid var(--border-accent)' : '2px solid transparent',
                  cursor: onRowClick ? 'pointer' : 'default',
                  transition: 'background-color var(--dur-instant) var(--ease-instrument)',
                }}>
                {columns.map(function (col) {
                  return <td key={col.key} style={cellStyle(col)}>{col.render ? col.render(row) : row[col.key]}</td>;
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

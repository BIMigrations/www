"""Stub registration for Power BI -- see adapters/qlik/__init__.py for why
this is deliberately this small."""

from estate_scanner.core.platform import PlatformAuthenticator, PlatformClient
from estate_scanner.core.registry import PlatformDescriptor, register_platform


class PowerBiAuthenticator(PlatformAuthenticator):
    platform = "powerbi"


class PowerBiClient(PlatformClient):
    platform = "powerbi"


register_platform(
    PlatformDescriptor(
        key="powerbi", display_name="Power BI", status="coming_soon",
        authenticator_cls=PowerBiAuthenticator, client_cls=PowerBiClient, auth_mode="unknown",
    )
)

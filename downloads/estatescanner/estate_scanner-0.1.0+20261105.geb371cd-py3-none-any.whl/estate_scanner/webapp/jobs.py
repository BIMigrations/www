"""In-memory background job tracking for operations that outlive an HTTP
request (Domo's interactive browser login, a full scan). Single local
user, so a plain dict + lock is enough -- no external queue/broker needed.
"""

from __future__ import annotations

import threading
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable


@dataclass
class Job:
    id: str
    kind: str  # "connect" | "scan"
    status: str = "running"  # running | completed | failed
    result: Any = None
    error: str | None = None
    progress: dict = field(default_factory=dict)


class JobAlreadyRunning(RuntimeError):
    """`start(..., exclusive=True)` found a job of the same kind still running."""


class JobManager:
    def __init__(self):
        self._jobs: dict[str, Job] = {}
        self._lock = threading.Lock()

    def start(self, kind: str, fn: Callable[[Job], Any], exclusive: bool = False) -> Job:
        """`exclusive`: refuse (JobAlreadyRunning) while another job of this kind runs; the check and the registration are one step."""
        job = Job(id=str(uuid.uuid4()), kind=kind)
        with self._lock:
            if exclusive and any(j.kind == kind and j.status == "running" for j in self._jobs.values()):
                raise JobAlreadyRunning(kind)
            self._jobs[job.id] = job

        def run() -> None:
            try:
                result = fn(job)
                if result is not None:
                    job.result = result
                job.status = "completed"
            except Exception as exc:
                job.status = "failed"
                job.error = str(exc)

        threading.Thread(target=run, daemon=True).start()
        return job

    def scan_running(self) -> bool:
        """True while a scan job is still writing (or about to: it has no scan row until the sign-in checks pass)."""
        with self._lock:
            return any(j.kind == "scan" and j.status == "running" for j in self._jobs.values())

    def get(self, job_id: str) -> Job | None:
        with self._lock:
            return self._jobs.get(job_id)


jobs = JobManager()

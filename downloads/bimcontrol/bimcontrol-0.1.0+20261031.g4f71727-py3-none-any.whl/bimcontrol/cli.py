"""BIMControl's command line.

The UI is the main way in, but every step a migration takes is reachable
here too -- a swarm node runs headless, and so does CI.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

from . import paths
from .estate.closure import resolve_dashboard
from .estate.reader import EstateNotFoundError, EstateReader


def _reader(args: argparse.Namespace) -> EstateReader:
    try:
        return EstateReader(
            args.estate or paths.default_estate_db_path(), platform=args.platform, instance=args.instance
        )
    except EstateNotFoundError as exc:
        print(exc, file=sys.stderr)
        print("Run an EstateScanner scan first, or pass --estate.", file=sys.stderr)
        raise SystemExit(1) from exc


def cmd_estate(args: argparse.Namespace) -> None:
    with _reader(args) as reader:
        scan = reader.latest_completed_scan()
        print(f"Estate: {reader.db_path}")
        if scan:
            print(f"Latest completed scan: #{scan['id']} {scan['instance']} finished {scan['finished_at']}")
        else:
            print("No completed scan in this database.")
        for object_type, count in sorted(reader.counts().items(), key=lambda kv: -kv[1]):
            print(f"  {count:>7}  {object_type}")


def cmd_dashboards(args: argparse.Namespace) -> None:
    with _reader(args) as reader:
        rows = reader.list_dashboards(search=args.search, limit=args.limit, order=args.order)
        for row in rows:
            print(f"{row['id']:<14} {row['card_count']:>4} cards  {row['name']}")


def cmd_closure(args: argparse.Namespace) -> None:
    with _reader(args) as reader:
        try:
            closure = resolve_dashboard(reader, args.dashboard)
        except EstateNotFoundError as exc:
            print(exc, file=sys.stderr)
            raise SystemExit(1) from exc

        if args.json:
            print(json.dumps(closure.summary(), indent=2))
            return

        summary = closure.summary()
        print(f"Dashboard {closure.dashboard.id}: {closure.dashboard.name}")
        print(f"  cards             {summary['cards']}")
        print(f"  datasets          {summary['datasets']} ({summary['root_datasets']} raw inputs)")
        print(f"  dataflows         {summary['dataflows']}")
        print(f"  calculated fields {summary['calculated_fields']}")
        if summary["chart_types"]:
            print("  chart types:")
            for chart_type, n in summary["chart_types"].items():
                print(f"    {n:>3}  {chart_type}")
        for warning in summary["warnings"]:
            print(f"  warning: {warning}")


def cmd_run(args: argparse.Namespace) -> None:
    from .core import runner
    from .storage import db

    estate_db_path = args.estate or paths.default_estate_db_path()
    conn = db.connect(args.db_path)
    try:
        try:
            prepared = runner.prepare_run(
                conn, estate_db_path, args.dashboard, until=args.until
            )
        except (EstateNotFoundError, KeyError) as exc:
            print(exc, file=sys.stderr)
            raise SystemExit(1) from exc

        run_id = prepared["run_id"]
        print(f"Run {run_id}: {prepared['unit']['name'] or args.dashboard}")
        _follow(conn, run_id, runner.execute_run(conn, run_id, estate_db_path, until=args.until))
    finally:
        conn.close()


def _reset_stages(conn, run_id: str, from_stage: str | None, force: bool) -> None:
    """Make a resume re-run work it would otherwise skip.

    Without this, correcting a bug in a later stage means editing the
    control database by hand, which is no way to iterate.
    """
    from .storage import db

    if force:
        db.reset_stages_from(conn, run_id)
    elif from_stage:
        db.reset_stages_from(conn, run_id, from_stage)


def cmd_resume(args: argparse.Namespace) -> None:
    from .core import runner
    from .storage import db

    conn = db.connect(args.db_path)
    try:
        try:
            _reset_stages(conn, args.run, getattr(args, "from_stage", None), args.force)
            run = runner.execute_run(conn, args.run, args.estate, until=args.until)
        except runner.UnknownRunError as exc:
            print(exc, file=sys.stderr)
            raise SystemExit(1) from exc
        _follow(conn, args.run, run)
    finally:
        conn.close()


def _follow(conn, run_id: str, run: dict) -> None:
    """Print what a finished run did. Runs are synchronous on the command
    line, so this is a summary rather than a live feed -- the events are all
    in the database either way."""
    from .storage import db

    markers = {"stage.started": ">", "stage.succeeded": "+", "stage.skipped": "=",
               "stage.progress": " ", "run.started": " ", "run.finished": " "}
    for event in db.list_events(conn, run_id):
        marker = {"warn": "!", "error": "x"}.get(event["level"]) or markers.get(event["type"], " ")
        stage = f"{event['stage']}: " if event["stage"] else ""
        print(f"  {marker} {stage}{event['message'] or event['type']}")

    reviews = db.list_review_items(conn, run_id=run_id, status="open")
    print(f"\nRun {run['status']}" + (f": {run['stopped_reason']}" if run.get("stopped_reason") else ""))
    if run.get("error"):
        print(f"  error in {run['error_stage']}: {run['error']}")
    if reviews:
        print(f"  {len(reviews)} item(s) need review:")
        for item in reviews[:10]:
            print(f"    - [{item['kind']}] {item['title']}")
        if len(reviews) > 10:
            print(f"    ... and {len(reviews) - 10} more")
    print(f"  artefacts: {run['run_dir']}")


def _runs_with_conversions() -> list[Path]:
    """Every run's convert_dataflows folder that has a conversion.json, oldest first by when it was last written (a
    resumed run converts again later than its id says)."""
    from . import paths  # noqa: PLC0415

    written = []
    for f in paths.runs_dir().glob("*/convert_dataflows/conversion.json"):
        try:
            written.append((f.stat().st_mtime, str(f), f.parent))
        except OSError:                          # a run folder removed while the export was listing them
            continue
    return [folder for _, _, folder in sorted(written)]


def cmd_export(args: argparse.Namespace) -> None:
    from .export import export_estate

    with _reader(args) as reader:
        try:
            sql_from = list(args.sql_from or [])
            if args.sql_from_runs:
                sql_from = _runs_with_conversions() + sql_from
            result = export_estate(reader, args.out, dashboard_ids=args.dashboard or None, sql_from=sql_from or None)
        except EstateNotFoundError as exc:
            print(exc, file=sys.stderr)
            raise SystemExit(1) from exc
    print(f"Exported to {result.out_dir} ({result.files} files)")
    for note in result.notes:
        print(f"  note: {note}", file=sys.stderr)
    for key, value in result.counts.items():
        print(f"  {value:>8}  {key}")
    failed = [c for c in result.reconciliation["checks"] if not c["ok"]]
    for check in result.reconciliation["checks"]:
        mark = "ok  " if check["ok"] else "FAIL"
        print(f"  [{mark}] {check['name']}: expected {check['expected']}, found {check['actual']}")
    if failed:
        raise SystemExit(1)
    print("Reconciled with the scan.")


def cmd_export_sql(args: argparse.Namespace) -> None:
    from .converters import DomoEtlConverterClient
    from .export import converter_sql

    client = DomoEtlConverterClient(args.converter) if args.converter else DomoEtlConverterClient()
    health = client.health()
    if not health.get("ok"):
        print(f"The converter at {health.get('base_url')} is not ready: {health.get('status')} ({health.get('error')})",
              file=sys.stderr)
        raise SystemExit(1)
    with _reader(args) as reader:
        # The converter reads Magic ETL and Domo's older ETL (the engines the pipeline hands it); a SQL-engine dataflow
        # (MySQL) already is SQL, its statements are in the steps.
        flows = [(f.id, f.name) for f in reader.iter_objects("dataflow")
                 if f.row.get("engine") in ("magic", "etl") and (not args.dataflow or f.id in {str(d) for d in args.dataflow})]
    skip = converter_sql.covered_flows(args.skip_covered_by or []) if args.skip_covered_by else set()
    if args.skip_covered_by_runs:
        skip |= converter_sql.covered_flows(_runs_with_conversions())
    result = converter_sql.convert_flows(client, flows, args.out, skip=skip, progress=print)
    print(f"{result['converted']} of {result['flows']} dataflows have SQL in {args.out} "
          f"({result['asked']} asked of the converter, {result['kept']} kept from an earlier run, {len(skip)} skipped as covered)")
    print(f"  {result['failed']} failed; {result['with_unsupported_tiles']} contain steps the converter does not translate; "
          f"{result['unnamed_inputs']} input(s) it could not name")
    print(f"  export with: bimcontrol export --out DIR --sql-from {args.out} --sql-from-runs")


def cmd_export_verify(args: argparse.Namespace) -> None:
    from .export import verify_export

    checks = verify_export(Path(args.directory).expanduser())
    for check in checks:
        print(f"  [{'ok  ' if check['ok'] else 'FAIL'}] {check['name']}: found {check['actual']}")
        for problem in check["problems"][:5]:
            print(f"         {problem}")
    if not all(c["ok"] for c in checks):
        raise SystemExit(1)


def cmd_export_build(args: argparse.Namespace) -> None:
    from .export import rebuild

    spec, out = Path(args.directory).expanduser(), Path(args.out).expanduser()
    scan = None
    try:
        if args.check:
            from .pipelines.domo_to_powerbi import closure_payload

            with _reader(args) as reader:
                scan = closure_payload(reader, resolve_dashboard(reader, args.dashboard))
        # Checking against the scan puts the cards in the scan's order: the export does not keep it, and a few choices of
        # the build depend on it.
        closure = rebuild.closure_from_spec(spec, args.dashboard, like_scan=args.like_scan,
                                            card_order=[c["id"] for c in scan["cards"]] if scan else None)
    except (rebuild.SpecNotFound, EstateNotFoundError) as exc:
        print(exc, file=sys.stderr)
        raise SystemExit(1) from exc
    built = rebuild.build_project_offline(closure, out / "from-spec")
    summary = built["write_pbip"].summary
    print(f"Built {summary['project']!r} from the specification: {summary['files']} files, {summary['visuals']} visuals "
          f"in {out / 'from-spec' / 'write_pbip'}")
    if scan is None:
        return
    from_scan = rebuild.build_project_offline(scan, out / "from-scan")
    differences = rebuild.compare_projects(out / "from-scan" / "write_pbip", out / "from-spec" / "write_pbip")
    differences += rebuild.compare_results(from_scan, built)
    if not differences:
        print("Identical to the project built from the scan.")
        return
    print(f"{len(differences)} difference(s) from the project built from the scan:")
    for item in differences[:20]:
        print(f"  {item['path']}\n      scan: {str(item['scan'])[:160]}\n      spec: {str(item['spec'])[:160]}")
    raise SystemExit(1)


def cmd_customer(args: argparse.Namespace) -> None:
    from .core import customer
    from .storage import db

    try:
        manifest = customer.Manifest.load(args.manifest)
    except (OSError, ValueError) as exc:
        print(exc, file=sys.stderr)
        raise SystemExit(1) from exc
    try:
        pass_began = customer._parse_time(args.pass_start)
    except ValueError as exc:
        print(f"--pass-start {args.pass_start!r}: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
    if pass_began is not None and pass_began > datetime.now(timezone.utc) + timedelta(minutes=5):
        # a local time east of UTC, read as UTC, lands in the future: no run would ever count as handled in the pass
        print(f"--pass-start {args.pass_start} is in the future ({pass_began.isoformat()}): "
              "the time is UTC unless it carries an offset (e.g. 2026-10-20T09:50:00+05:30)", file=sys.stderr)
        raise SystemExit(1)
    if manifest.rerun_proven and not args.pass_start and not (args.dry_run or args.status):
        print(f"{args.manifest}: \"rerun_proven\" needs --pass-start (a proven dashboard is run again once per pass; without a pass "
              "a loop that starts one dashboard per call would start the same one every time)", file=sys.stderr)
        raise SystemExit(1)
    estate_db_path = args.estate or paths.default_estate_db_path()
    with _reader(args) as reader:
        selected = customer.select_dashboards(reader, manifest)
    if not selected:
        print(f"{args.manifest}: no dashboard in the scan matches this manifest.", file=sys.stderr)
        raise SystemExit(1)

    conn = db.connect(args.db_path)
    try:
        if args.dry_run or args.status:
            if args.dry_run and not args.status:
                print(f"{manifest.name}: {len(selected)} dashboard(s), cheapest first")
                for s in selected:
                    print(f"  {s.id:<12} {s.cards:>4} cards {s.dataflows:>4} dataflows {s.source_rows:>12,} rows  {s.name}")
                return
            rollup = customer.build_rollup(conn, estate_db_path, manifest, selected)
            customer.write_rollup(rollup)
            print(customer.format_rollup(rollup))
            return
        if args.convert_all:
            _convert_all(conn, estate_db_path, manifest)
            return
        rollup = customer.run_batch(
            conn, estate_db_path, manifest, selected, limit=args.limit, force=args.force,
            retry_failed=not args.no_retry, rerun_unproven=args.rerun_unproven, session_command=args.session_cmd,
            session_max_age_minutes=args.session_max_age, max_minutes=args.max_minutes, pass_start=args.pass_start,
            restart_from_change=args.restart_from_change, converter_redeployed=args.converter_redeployed)
        print()
        print(customer.format_rollup(rollup))
        if rollup.get("stopped"):
            print(f"\n{rollup['stopped']}")
        print(f"\nRollup: {customer.rollup_path(manifest.name)}")
    finally:
        conn.close()


def _convert_all(conn, estate_db_path, manifest) -> None:
    """Convert every dataflow in the customer's closure, then say what the warehouse made of them."""
    import json

    from .core import runner

    prepared = runner.prepare_customer_run(conn, estate_db_path, manifest)
    run_id = prepared["run_id"]
    print(f"{'resuming' if prepared['resumed'] else 'new run'} {run_id}")
    finished = runner.execute_run(conn, run_id, estate_db_path)
    print(f"-> {finished['status']}")
    path = Path(finished["run_dir"]) / "convert_dataflows" / "conversion.json"
    if not path.exists():
        return
    flows = json.loads(path.read_text()).get("dataflows") or []
    print(format_conversion_tally(flows))


def format_conversion_tally(flows: list[dict]) -> str:
    """What the warehouse made of each dataflow: planned (CREATE TEMP TABLE ... LIMIT 0) and, for outputs that later
    dataflows read, actually built. A dataflow whose output could not be built counts as rejected:
    its readers have no input (bimcontrol#123)."""
    import collections

    accepted, rejected, repaired = 0, collections.Counter(), 0
    for flow in flows:
        outputs = flow.get("outputs") or []
        errors = [o.get("validation_error") for o in outputs if o.get("validated") is False]
        errors += [f"could not be built: {o.get('materialisation_error')}" for o in outputs if o.get("materialisation_error")]
        if errors:
            rejected[(errors[0] or "")[:90]] += 1
        else:
            accepted += 1
            repaired += any(r.get("resolved") for r in flow.get("repairs") or [])
    lines = [f"{len(flows)} dataflows converted: {accepted} accepted by the warehouse, {sum(rejected.values())} rejected"
             + (f" ({repaired} of the accepted after the converter's agent rewrote a tile)" if repaired else "")]
    lines += [f"  {count:>3}  {reason}" for reason, count in rejected.most_common()]
    return "\n".join(lines)


def cmd_runs(args: argparse.Namespace) -> None:
    from .storage import db

    conn = db.connect(args.db_path)
    try:
        rows = db.list_runs(conn, limit=args.limit)
        if not rows:
            print("No runs yet.")
            return
        for row in rows:
            unit = db.get_unit(conn, row["unit_id"])
            stages = db.list_stages(conn, row["id"])
            done = sum(1 for s in stages if s["status"] in ("succeeded", "skipped"))
            print(
                f"{row['id']}  {row['status']:<10} {done}/{len(stages)} stages  "
                f"{unit['name'] if unit else row['unit_id']}"
            )
    finally:
        conn.close()


def cmd_report(args: argparse.Namespace) -> None:
    """Show, or open, a run's migration report."""
    import webbrowser
    from pathlib import Path

    from .pipelines.migration_report import REPORT_HTML, REPORT_JSON
    from .storage import db

    conn = db.connect(args.db_path)
    try:
        run_id = args.run_id
        if run_id is None:
            rows = db.list_runs(conn, limit=1)
            if not rows:
                print("No runs yet.", file=sys.stderr)
                raise SystemExit(1)
            run_id = rows[0]["id"]
        run = db.get_run(conn, run_id)
        if run is None:
            print(f"No run with id {run_id!r}.", file=sys.stderr)
            raise SystemExit(1)

        report_dir = Path(run["run_dir"]) / "report"
        page, data = report_dir / REPORT_HTML, report_dir / REPORT_JSON
        if not data.exists():
            print(f"Run {run_id} has not written a migration report.", file=sys.stderr)
            print(f"Its last status was {run['status']}; "
                  f"`bimcontrol resume {run_id}` carries it on.", file=sys.stderr)
            raise SystemExit(1)

        payload = json.loads(data.read_text())
        verdict, counts = payload["verdict"], payload["counts"]
        print(f"{payload['migration']['name']}  ({run_id})")
        print(f"  {verdict['title']}: {verdict['statement']}")
        print(f"  {counts['visuals']}/{counts['cards']} cards migrated, "
              f"{counts['measures']} measures, {counts['open_reviews']} to review")
        if payload["parity"]["checked"]:
            totals = payload["parity"]["totals"]
            print(f"  parity: {totals.get('ok', 0)} match, {totals.get('warn', 0)} close, "
                  f"{totals.get('error', 0)} differ")
        print(f"  {page}")
        if args.open:
            webbrowser.open(page.as_uri())
    finally:
        conn.close()


def cmd_warehouse(args: argparse.Namespace) -> None:
    from . import warehouses
    from .core import runner
    from .storage import db

    conn = db.connect(args.db_path)
    try:
        if args.list:
            for entry in warehouses.list_warehouses():
                mark = "  " if entry["implemented"] else "* "
                print(f"{mark}{entry['key']:<12} {entry['display_name']}")
            print("\n* not built yet")
            return

        project = runner.resolve_project(conn, args.estate or paths.default_estate_db_path())
        settings = dict((project.get("settings") or {}).get("warehouse") or {})

        if args.set:
            for pair in args.set:
                key, _, value = pair.partition("=")
                if key.lower() in ("password", "secret", "aws_secret_access_key"):
                    print(f"Refusing to store {key!r}. Put secrets in the environment "
                          "(REDSHIFT_PASSWORD, AWS_SECRET_ACCESS_KEY).", file=sys.stderr)
                    raise SystemExit(1)
                settings[key] = value
            settings.setdefault("key", "redshift")
            settings.setdefault("landing_schema", "bimcontrol_landing")
            project_settings = dict(project.get("settings") or {})
            project_settings["warehouse"] = settings
            db.update_project(conn, project["id"], settings=project_settings)
            print(f"Saved warehouse settings for project {project['name']!r}.")

        if not settings:
            print("No warehouse configured. Set one, e.g.:")
            print("  bimcontrol warehouse --set key=redshift --set host=... --set database=... --set user=...")
            return

        print(f"Project {project['name']!r} -> {settings.get('key')}")
        for key, value in sorted(settings.items()):
            print(f"  {key:<16} {value}")
        print(f"  {'staging':<16} {'s3://' + settings['s3_bucket'] if settings.get('s3_bucket') else 'none (inserts only)'}")

        if args.check:
            result = warehouses.get_adapter(settings.get("key", "redshift"), settings).check()
            print()
            if result.get("ok"):
                print("Connection ok: " + ", ".join(
                    f"{k}={v}" for k, v in result.items() if k not in ("ok", "warehouse")))
            else:
                print(f"Connection failed: {result.get('error')}")
                raise SystemExit(1)
    finally:
        conn.close()


def cmd_converter(args: argparse.Namespace) -> None:
    from .converters import DomoEtlConverterClient
    from .core import runner
    from .storage import db

    conn = db.connect(args.db_path)
    try:
        project = runner.resolve_project(conn, args.estate or paths.default_estate_db_path())
        settings = dict(project.get("settings") or {})
        converters = dict(settings.get("converters") or {})

        if args.url:
            converters["domo_etl"] = args.url.rstrip("/")
            settings["converters"] = converters
            db.update_project(conn, project["id"], settings=settings)
            print(f"Saved converter URL for project {project['name']!r}.")

        url = converters.get("domo_etl")
        if not url:
            print("No converter configured. Set one with:")
            print("  bimcontrol converter --url http://localhost:8822")
            return
        print(f"Domo ETL converter: {url}")

        if args.check:
            health = DomoEtlConverterClient(url).health()
            if health.get("ok"):
                print(f"  ready, signed in to {health.get('instance')}")
            else:
                print(f"  not ready: {health.get('error') or health.get('status')}")
                raise SystemExit(1)
    finally:
        conn.close()


def cmd_domo(args: argparse.Namespace) -> None:
    from .core import runner
    from .sources.domo import login
    from .storage import db

    conn = db.connect(args.db_path)
    try:
        instance = args.instance
        if not instance:
            project = runner.resolve_project(conn, args.estate or paths.default_estate_db_path())
            instance = project["source_instance"]
    finally:
        conn.close()

    if args.logout:
        print(f"Forgot the saved session for {instance!r}." if login.forget(instance)
              else f"No saved session for {instance!r}.")
        return

    if args.login:
        print(f"Opening a browser for {instance}.domo.com -- sign in there.")
        login.login_interactive(instance)
        print("Signed in, and the session is saved.")

    stored = login.load(instance)
    if not stored:
        print(f"No saved Domo session for {instance!r}. Run `bimcontrol domo --login`.")
        raise SystemExit(1)
    ok = login.is_valid(stored)
    print(f"Domo {instance}: session {'valid' if ok else 'EXPIRED'} "
          f"({len(stored.cookies)} cookies)")
    if not ok:
        raise SystemExit(1)


def cmd_fabric(args: argparse.Namespace) -> None:
    from .core import runner
    from .storage import db
    from .targets.powerbi import auth

    if args.logout:
        print("Signed out." if auth.sign_out() else "No saved sign-in to forget.")
        return

    conn = db.connect(args.db_path)
    try:
        project = runner.resolve_project(conn, args.estate or paths.default_estate_db_path())
        settings = dict(project.get("settings") or {})
        powerbi = dict(settings.get("powerbi") or {})

        if args.workspace:
            powerbi["workspace"] = args.workspace
            settings["powerbi"] = powerbi
            db.update_project(conn, project["id"], settings=settings)
            print(f"Target workspace for {project['name']!r}: {args.workspace}")

        if args.login:
            auth.credential()           # prompts once, then caches
        account = auth.signed_in_account()
        if account:
            print(f"Signed in as {account.get('username')} (tenant {account.get('tenant_id')})")
        else:
            print("Not signed in. Run `bimcontrol fabric --login` once.")
        if powerbi.get("workspace"):
            print(f"Workspace: {powerbi['workspace']}")
    finally:
        conn.close()


def cmd_ui(args: argparse.Namespace) -> None:
    try:
        from . import desktop
    except ImportError:
        print("The desktop UI needs the 'ui' extra: pip install 'bimcontrol[ui]'")
        raise SystemExit(1)
    if args.check:
        raise SystemExit(desktop.check(estate_db_path=args.estate, db_path=args.db_path))
    desktop.main(estate_db_path=args.estate, db_path=args.db_path, browser=args.browser)


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="bimcontrol")
    parser.add_argument(
        "--estate",
        default=None,
        help=f"EstateScanner database to read (default: {paths.default_estate_db_path()})",
    )
    parser.add_argument(
        "--db-path",
        default=None,
        help=f"BIMControl's own database (default: {paths.default_db_path()})",
    )
    parser.add_argument("--platform", default="domo", help="Source platform key (default: domo)")
    parser.add_argument(
        "--instance",
        default=None,
        help="Which instance of the platform to read, when the estate database holds several "
             "(default: the only one)",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("estate", help="Summarise the loaded estate scan").set_defaults(func=cmd_estate)

    dashboards = sub.add_parser("dashboards", help="List dashboards, smallest first")
    dashboards.add_argument("--search", default=None, help="Filter by name")
    dashboards.add_argument("--limit", type=int, default=30)
    dashboards.add_argument("--order", default="cards", choices=["cards", "cards_desc", "name"])
    dashboards.set_defaults(func=cmd_dashboards)

    closure = sub.add_parser("closure", help="Resolve a dashboard's migration closure")
    closure.add_argument("dashboard", help="Dashboard id")
    closure.add_argument("--json", action="store_true", help="Print the summary as JSON")
    closure.set_defaults(func=cmd_closure)

    run = sub.add_parser("run", help="Migrate one dashboard")
    run.add_argument("--dashboard", required=True, help="Source dashboard id")
    run.add_argument("--until", default=None, help="Stop after this stage")
    run.set_defaults(func=cmd_run)

    resume = sub.add_parser("resume", help="Continue a stopped run")
    resume.add_argument("run", help="Run id")
    resume.add_argument("--until", default=None, help="Stop after this stage")
    resume.add_argument("--from", dest="from_stage", default=None,
                        help="Re-run from this stage, discarding its result and everything after")
    resume.add_argument("--force", action="store_true",
                        help="Re-run every stage, even ones that already succeeded")
    resume.set_defaults(func=cmd_resume)

    export = sub.add_parser("export", help="Write the estate as open specification files")
    export.add_argument("--out", required=True, help="Directory to write (created if missing)")
    export.add_argument("--dashboard", action="append", metavar="ID",
                        help="Only this dashboard and everything it needs (repeatable); default: the whole estate")
    export.add_argument("--sql-from", action="append", metavar="DIR",
                        help="A converter run's convert_dataflows folder (conversion.json and the .sql files): "
                             "adds each dataflow's Redshift SQL to its transformation (repeatable, oldest first)")
    export.add_argument("--sql-from-runs", action="store_true",
                        help="Take the SQL from every run of this machine (the best conversion of each dataflow: "
                             "accepted by the warehouse, then the latest)")
    export.set_defaults(func=cmd_export)

    export_sql = sub.add_parser(
        "export-sql", help="Write every dataflow's SQL from the converter alone (not run against data), for `export --sql-from`")
    export_sql.add_argument("--out", required=True, help="Folder to write (conversion.json and the .sql files); a rerun continues it")
    export_sql.add_argument("--converter", default=None, metavar="URL", help="The converter's base URL (default: its usual one)")
    export_sql.add_argument("--dataflow", action="append", metavar="ID", help="Only this dataflow (repeatable)")
    export_sql.add_argument("--skip-covered-by", action="append", metavar="DIR",
                            help="Leave out the dataflows this convert_dataflows folder already converted (repeatable)")
    export_sql.add_argument("--skip-covered-by-runs", action="store_true",
                            help="Leave out the dataflows any run of this machine already converted")
    export_sql.set_defaults(func=cmd_export_sql)

    export_verify = sub.add_parser("export-verify", help="Check an export directory against its schemas")
    export_verify.add_argument("directory")
    export_verify.set_defaults(func=cmd_export_verify)

    export_build = sub.add_parser(
        "export-build", help="Build one dashboard's Power BI project from an export alone (no scan, no source, no warehouse)")
    export_build.add_argument("directory", help="A `bimcontrol export` folder")
    export_build.add_argument("--dashboard", required=True, metavar="ID")
    export_build.add_argument("--out", required=True, help="Folder to build in")
    export_build.add_argument("--check", action="store_true",
                              help="Also build from the scan (--estate) and compare the two projects; exits 1 if they differ")
    export_build.add_argument("--like-scan", action="store_true",
                              help="Read a card's sort and calculations the way the scan path does (to isolate what the "
                                   "export knows beyond it)")
    export_build.set_defaults(func=cmd_export_build)

    customer = sub.add_parser("customer", help="Migrate every dashboard in a customer manifest")
    customer.add_argument("manifest", help="JSON manifest naming the customer's dashboards")
    customer.add_argument("--dry-run", action="store_true", help="List the selected dashboards, cheapest first")
    customer.add_argument("--status", action="store_true", help="Show the rollup from earlier runs; run nothing")
    customer.add_argument("--limit", type=int, default=None, help="Start at most this many dashboards")
    customer.add_argument("--max-minutes", type=float, default=None,
                          help="Do not start another dashboard after this many minutes")
    customer.add_argument("--force", action="store_true", help="Run proven dashboards again too")
    customer.add_argument("--convert-all", action="store_true",
                          help="Land the sources and convert every dataflow in the customer's dashboards (no models or reports)")
    customer.add_argument("--no-retry", action="store_true", help="Leave dashboards whose last run failed alone")
    customer.add_argument("--rerun-unproven", action="store_true",
                          help="Start a fresh run for dashboards that finished unverified or with differing figures")
    customer.add_argument("--pass-start", default=None, metavar="ISO-TIME",
                          help="A pass began at this time (UTC, e.g. 2026-10-20T04:22:00): a dashboard whose latest run "
                               "started at or after it is not started again, whatever its outcome. With --limit 1 in a "
                               "loop this runs a pass one dashboard per process, so each picks up the code merged meanwhile "
                               "(scripts in the brain repo: batch_loop.sh)")
    customer.add_argument("--restart-from-change", action="store_true",
                          help="With --pass-start: resume a run from before the pass at the earliest stage that the code "
                               "changed since it ran can affect (a DAX or parity fix does not redo the conversion) instead of "
                               "starting it over. A run with no record of its code is dated by its start")
    customer.add_argument("--converter-redeployed", default=None, metavar="ISO-TIME",
                          help="With --restart-from-change: the converter changed at this time (UTC), so a conversion "
                               "that finished before it is redone")
    customer.add_argument("--session-cmd", default=None,
                          help="Shell command that renews the source sign-in, run before the first "
                               "dashboard and whenever the session is older than --session-max-age")
    customer.add_argument("--session-max-age", type=float, default=120,
                          help="Minutes before the session command runs again (default 120)")
    customer.set_defaults(func=cmd_customer)

    runs = sub.add_parser("runs", help="List migration runs")
    runs.add_argument("--limit", type=int, default=20)
    runs.set_defaults(func=cmd_runs)

    report = sub.add_parser("report", help="Show a run's migration report")
    report.add_argument("run_id", nargs="?", help="defaults to the most recent run")
    report.add_argument("--open", action="store_true", help="open the report in a browser")
    report.set_defaults(func=cmd_report)

    warehouse = sub.add_parser("warehouse", help="Show, set or test the target warehouse")
    warehouse.add_argument("--list", action="store_true", help="List supported warehouses")
    warehouse.add_argument("--set", action="append", metavar="KEY=VALUE",
                           help="Set a setting (repeatable). Secrets belong in the environment.")
    warehouse.add_argument("--check", action="store_true", help="Test the connection")
    warehouse.set_defaults(func=cmd_warehouse)

    converter = sub.add_parser("converter", help="Show, set or test the ETL converter service")
    converter.add_argument("--url", default=None, help="Base URL, e.g. http://localhost:8822")
    converter.add_argument("--check", action="store_true", help="Test that it is ready")
    converter.set_defaults(func=cmd_converter)

    domo = sub.add_parser("domo", help="Domo sign-in for live calls (exports, converter handoff)")
    domo.add_argument("instance", nargs="?", default=None, help="Instance name (default: the project's)")
    domo.add_argument("--login", action="store_true", help="Open a browser and sign in")
    domo.add_argument("--logout", action="store_true", help="Forget the saved session")
    domo.set_defaults(func=cmd_domo)

    fabric = sub.add_parser("fabric", help="Power BI / Fabric sign-in and target workspace")
    fabric.add_argument("--login", action="store_true", help="Sign in once and cache it")
    fabric.add_argument("--logout", action="store_true", help="Forget the saved sign-in")
    fabric.add_argument("--workspace", default=None, help="Target workspace name or id")
    fabric.set_defaults(func=cmd_fabric)

    ui = sub.add_parser("ui", help="Launch the desktop UI")
    ui.add_argument("--browser", action="store_true", help="Open in the default web browser instead of a native window")
    ui.add_argument("--check", action="store_true", help="Self-test: server answers and the native window backend imports")
    ui.set_defaults(func=cmd_ui)

    args = parser.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()

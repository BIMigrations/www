"""Remove Duplicates tiles whose duplicates are not identical.

Domo's Remove Duplicates keeps one row per key and does not define which. Where the rows of a key are the same the
pick is irrelevant; where they differ (a provider listed under two service lines) Domo's pick cannot be reproduced
(bimcontrol#288: no first/last/min/max rule matched more than 68 % of the keys), and the converted dataflow keeps one
too. The figures that depend on it differ from Domo's, and the parity report cannot say why: this says so, from the data.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Callable

# The shape the converter's UniqueTranspiler writes: the CTE, its key, and the CTE it reads.
_UNIQUE_TILE = re.compile(
    r"(?P<name>tile_unique_\w+) AS \(\n  SELECT \* EXCLUDE\(__domo_etl_dedup_rn\)\n  FROM \(\n"
    r"    SELECT \*, ROW_NUMBER\(\) OVER \(PARTITION BY (?P<keys>.+?) ORDER BY [^\n]+\) AS __domo_etl_dedup_rn\n"
    r"    FROM (?P<source>\w+)\n"
)


@dataclass(frozen=True)
class UniqueTile:
    name: str
    keys: str
    query: str      # keys with rows that differ, and the rows behind them


def unique_tiles(sql: str) -> list[UniqueTile]:
    """Every Remove Duplicates tile of a converted script, each with the query that counts its ambiguous keys."""
    opening = re.search(r"^WITH$", sql, re.MULTILINE)
    found = []
    for match in _UNIQUE_TILE.finditer(sql):
        if opening is None or match.start() < opening.start():
            continue
        # Everything the tile reads is defined before it, so the script cut there is a complete statement.
        defined_before = sql[opening.start():match.start()].rstrip().rstrip(",")
        keys, source = match["keys"], match["source"]
        found.append(UniqueTile(match["name"], keys, (
            f"{defined_before}\nSELECT COUNT(*), COALESCE(SUM(__rows), 0) FROM ("
            f"SELECT {keys}, COUNT(*) AS __rows FROM (SELECT DISTINCT * FROM {source}) AS __distinct "
            f"GROUP BY {keys} HAVING COUNT(*) > 1) AS __ties"
        )))
    return found


def ambiguous_keys(
    adapter: Any, sql: str, timeout_seconds: int = 120, check_cancelled: Callable[[], None] | None = None,
    out_of_time: Callable[[], bool] | None = None,
) -> list[dict[str, Any]]:
    """One entry per Remove Duplicates tile: {"tile", "keys", "checked", "ambiguous_keys", "rows"}.

    `checked` is False (counts None) for a tile the warehouse could not answer for (timeout, a column type DISTINCT
    cannot compare) or that was left unasked because `out_of_time()` said so: unknown is not "no ambiguous keys".
    This is a check on top of a conversion that already worked, and must never fail the run.
    """
    out = []
    for tile in unique_tiles(sql):
        if check_cancelled is not None:
            check_cancelled()
        entry = {"tile": tile.name, "keys": tile.keys, "checked": False, "ambiguous_keys": None, "rows": None}
        out.append(entry)
        if out_of_time is not None and out_of_time():
            continue
        try:
            row = adapter.query_row(tile.query, timeout_seconds)
        except Exception:  # noqa: BLE001 -- unknown is an answer; the conversion itself is reported elsewhere
            continue
        if row:
            entry.update(checked=True, ambiguous_keys=int(row[0]), rows=int(row[1]))
    return out

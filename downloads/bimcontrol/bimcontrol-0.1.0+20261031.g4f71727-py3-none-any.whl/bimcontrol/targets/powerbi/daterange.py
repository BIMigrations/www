"""A Domo card's date range filter, as Power BI shows it (bimcontrol#169).

Domo saves a card's range as `dateRangeFilter.dateTimeRange`: `ROLLING_PERIOD` (the last `count`
calendar intervals, ending with the current one, shifted back by `offset`), `INTERVAL_OFFSET` (the one
interval `offset` intervals ago; 0 is the current one: "Current Year"), `PERIOD_TO_DATE` (from the start
of the interval to today) and `FIXED_RANGE` (`beginDate`..`endDate`). All of them are evaluated when the
card is viewed, so the Power BI side has to be relative to the day it is viewed too: a PBIR relative
date filter on the report, and the same window as DAX for the parity query.
"""

from __future__ import annotations

import datetime as _dt
from typing import Any

INTERVALS = ("DAY", "WEEK", "MONTH", "QUARTER", "YEAR")
# PBIR query TimeUnit codes, measured on published probe reports (2026-10-18; a wrong code shows an empty or
# too wide window: Year 5 showed nothing, 3 showed a year). There is no quarter unit (codes 4-7 gave all rows,
# nothing, nothing and one day), and a quarter boundary depends on today's month, so a quarter range cannot be
# written as a relative filter: `unsupported_reason` says so and the report builder lists the card.
TIME_UNIT = {"DAY": 0, "WEEK": 1, "MONTH": 2, "YEAR": 3}


def parse(entry: dict[str, Any]) -> dict[str, Any] | None:
    """The saved `dateRangeFilter` as a plain dict, or None when it is not one we can reproduce."""
    rng = (entry or {}).get("dateTimeRange") or {}
    kind = rng.get("dateTimeRangeType")
    column = ((entry or {}).get("column") or {}).get("column")
    if not column:
        return None
    offset = int(rng.get("offset") or 0)
    if kind == "FIXED_RANGE":
        try:        # a date, possibly with a time part: "2025-12-01" or "2025-12-01T00:00:00"
            begin = _dt.date.fromisoformat(str(rng.get("beginDate"))[:10]).isoformat()
            end = _dt.date.fromisoformat(str(rng.get("endDate"))[:10]).isoformat()
        except ValueError:
            return None
        return {"type": kind, "column": column, "begin": begin, "end": end}
    interval = str(rng.get("interval") or "").upper()
    if interval not in INTERVALS:
        return None
    if kind == "ROLLING_PERIOD" and int(rng.get("count") or 0) >= 1:
        return {"type": kind, "column": column, "interval": interval, "offset": offset, "count": int(rng["count"])}
    if kind == "INTERVAL_OFFSET":
        return {"type": kind, "column": column, "interval": interval, "offset": offset, "count": 1}
    if kind == "PERIOD_TO_DATE":
        return {"type": kind, "column": column, "interval": interval, "offset": 0, "count": 1}
    return None


def unsupported_reason(spec: dict[str, Any]) -> str | None:
    if spec.get("interval") == "QUARTER":
        return "Power BI's relative date filter has no quarter unit"
    return None


def describe(spec: dict[str, Any]) -> str:
    if spec["type"] == "FIXED_RANGE":
        return f"{spec['begin']} to {spec['end']}"
    if spec["type"] == "PERIOD_TO_DATE":
        return f"{spec['interval'].lower()} to date"
    if spec["type"] == "INTERVAL_OFFSET":
        return f"{spec['interval'].lower()} {'-' + str(spec['offset']) if spec['offset'] else '(current)'}"
    return f"last {spec['count']} {spec['interval'].lower()}s" + (f" ending {spec['offset']} back" if spec["offset"] else "")


def _periods_back(spec: dict[str, Any]) -> tuple[int, int]:
    """(how many intervals back the first one starts, how many back the last one is)."""
    if spec["type"] == "ROLLING_PERIOD":
        return spec["offset"] + spec["count"] - 1, spec["offset"]
    if spec["type"] == "PERIOD_TO_DATE":
        return 0, 0
    return spec["offset"], spec["offset"]


# ---- the window as dates, for the parity query ---------------------------------------------------------


def _start_of(interval: str, today: _dt.date, back: int) -> _dt.date:
    """The first day of the interval containing `today`, `back` intervals ago (negative: ahead)."""
    if interval == "DAY":
        return today - _dt.timedelta(days=back)
    if interval == "WEEK":                                   # weeks begin on Sunday, as in Domo and Power BI
        return today - _dt.timedelta(days=(today.weekday() + 1) % 7 + 7 * back)
    if interval == "YEAR":
        return _dt.date(today.year - back, 1, 1)
    months_per = 3 if interval == "QUARTER" else 1
    first = today.month - 1 - (today.month - 1) % months_per
    index = today.year * 12 + first - months_per * back
    return _dt.date(index // 12, index % 12 + 1, 1)


def window(spec: dict[str, Any], today: _dt.date) -> tuple[_dt.date, _dt.date]:
    """(start, end): a date `v` is in the range when `start <= v < end`."""
    if spec["type"] == "FIXED_RANGE":
        return (_dt.date.fromisoformat(spec["begin"]), _dt.date.fromisoformat(spec["end"]) + _dt.timedelta(days=1))
    first, last = _periods_back(spec)
    end = today + _dt.timedelta(days=1) if spec["type"] == "PERIOD_TO_DATE" else _start_of(spec["interval"], today, last - 1)
    return _start_of(spec["interval"], today, first), end


def dax_filter(spec: dict[str, Any], column_ref: str, today: _dt.date | None = None) -> str:
    """A `FILTER(ALL(column), ...)` argument for SUMMARIZECOLUMNS that repeats the window.

    The bounds are literal dates computed here: a DirectQuery table cannot fold `EDATE(TODAY(), ...)` to
    the warehouse ("couldn't fold the expression", HCC - SW). Works for dates and datetimes."""
    start, end = window(spec, today or _dt.date.today())
    lower, upper = (f"DATE({d.year}, {d.month}, {d.day})" for d in (start, end))
    return f"FILTER(ALL({column_ref}), {column_ref} >= {lower} && {column_ref} < {upper})"


# ---- PBIR ---------------------------------------------------------------------------------------------


def _now_back(unit: int, back: int) -> dict:
    now: dict = {"Now": {}}
    if back == 0:
        return now
    return {"DateAdd": {"Expression": now, "Amount": -back, "TimeUnit": unit}}


def pbir_condition(spec: dict[str, Any], column: dict) -> dict:
    """The `Where` condition of a PBIR relative-date filter (or a plain range for a fixed one)."""
    if spec["type"] == "FIXED_RANGE":
        return {"Between": {
            "Expression": column,
            "LowerBound": {"Literal": {"Value": f"datetime'{spec['begin']}T00:00:00'"}},
            "UpperBound": {"Literal": {"Value": f"datetime'{spec['end']}T23:59:59'"}},
        }}
    unit = spec.get("_unit", TIME_UNIT[spec["interval"]])        # `_unit`: probe hook
    first, last = _periods_back(spec)
    if spec["type"] == "PERIOD_TO_DATE":
        lower = {"DateSpan": {"Expression": _now_back(unit, 0), "TimeUnit": unit}}
        upper = {"DateSpan": {"Expression": _now_back(TIME_UNIT["DAY"], 0), "TimeUnit": TIME_UNIT["DAY"]}}
    else:
        lower = {"DateSpan": {"Expression": _now_back(unit, first), "TimeUnit": unit}}
        upper = {"DateSpan": {"Expression": _now_back(unit, last), "TimeUnit": unit}}
    return {"Between": {"Expression": column, "LowerBound": lower, "UpperBound": upper}}

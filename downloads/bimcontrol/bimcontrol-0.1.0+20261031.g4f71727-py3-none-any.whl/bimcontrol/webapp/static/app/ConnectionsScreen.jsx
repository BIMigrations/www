import React from 'react';

// The four things a migration needs to reach, and the one action that
// fixes each. A run that stops on an expired cookie should be fixed here
// in two clicks, not by reading an error message and finding the right
// CLI command.
//
// Every credential is obtained once and kept: a migration that stops to
// ask for a password is not a factory. Domo needs a real browser sign-in
// because its private API only accepts the cookies a genuine SSO flow
// produces; Power BI uses an MSAL token cache plus a saved authentication
// record, so a token can be refreshed without asking again.
//
// Opening this screen never prompts for anything. Only the buttons do.

const ORDER = [
  {
    key: 'domo', title: 'Domo', side: 'source',
    needed: 'Exporting datasets, reading card figures, and lending the converter a session.',
  },
  {
    key: 'powerbi', title: 'Power BI and Fabric', side: 'target',
    needed: 'Publishing the generated project, and running the parity queries against it.',
  },
  {
    key: 'warehouse', title: 'Warehouse', side: 'target',
    needed: 'Landing manual uploads, and proving the converted SQL will actually run.',
  },
  {
    key: 'converter', title: 'Magic ETL converter', side: 'service',
    needed: 'Rewriting Domo dataflows as warehouse SQL. Runs as a separate service.',
  },
];

export function ConnectionsScreen() {
  const [state, setState] = React.useState(null);
  const [busy, setBusy] = React.useState(null);
  const [error, setError] = React.useState(null);
  const [converterUrl, setConverterUrlValue] = React.useState('');

  function reload() {
    return fetchConnections().then(function (body) {
      setState(body);
      setConverterUrlValue((body.converter && body.converter.url) || '');
    }, function (e) { setError(e.message); });
  }

  React.useEffect(function () { reload(); }, []);

  function act(key, promise) {
    setBusy(key);
    setError(null);
    promise.then(function () { setBusy(null); reload(); },
      function (e) { setBusy(null); setError(e.message); reload(); });
  }

  const connected = ORDER.filter(function (c) {
    return state && state[c.key] && state[c.key].connected;
  }).length;

  return (
    <React.Fragment>
      <Sidebar>
        <SidebarGroup label="This node">
          <NavItem label="Connections" active icon={<Icon name="link" size={13} />}
            meta={state ? connected + ' of ' + ORDER.length : ''} />
        </SidebarGroup>
        <div style={{ padding: '14px 14px 20px', marginTop: 'auto' }}>
          <Card title="Worker node" subtitle="Runs on this machine">
            <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-secondary)', lineHeight: 1.6 }}>
              BIMControl runs inside the customer's network because that is the only thing with
              access to their BI platform. Nothing here is sent anywhere: sessions are kept on
              this machine, and passwords are read from the environment, never stored.
            </div>
          </Card>
        </div>
      </Sidebar>

      <Main scroll>
        <PageHeader
          title="Connections"
          meta="What this node can currently reach. Checked live, every time this screen opens."
          actions={
            <Button variant="secondary" size="md" iconLeft={<Icon name="refresh" size={14} />}
              onClick={reload}>Check again</Button>
          } />

        <ErrorBanner error={error} title="That did not work" />

        <div style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 14 }}>
          {!state ? <Spinner /> : ORDER.map(function (entry) {
            const status = state[entry.key] || {};
            return (
              <ConnectionCard
                key={entry.key}
                entry={entry}
                status={status}
                projectId={state.project_id}
                busy={busy === entry.key}
                converterUrl={converterUrl}
                onConverterUrl={setConverterUrlValue}
                onAction={function (promise) { act(entry.key, promise); }}
              />
            );
          })}
        </div>
      </Main>
    </React.Fragment>
  );
}

export function ConnectionCard({ entry, status, projectId, busy, converterUrl, onConverterUrl, onAction }) {
  const side = entry.side === 'source' ? 'var(--provenance-source)'
    : entry.side === 'target' ? 'var(--provenance-target)' : 'var(--border-strong)';

  return (
    <div style={{
      border: '1px solid var(--border-hairline)', borderLeft: '3px solid ' + side,
      borderRadius: 'var(--radius-card)', background: 'var(--surface-card)', padding: 16,
      display: 'flex', gap: 16, alignItems: 'flex-start',
    }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <StatusDot status={status.connected ? 'ok' : 'idle'} />
          <span style={{ fontSize: 'var(--text-xl)', fontWeight: 'var(--weight-semibold)', letterSpacing: 'var(--tracking-heading)' }}>
            {entry.title}
          </span>
          {status.connected
            ? <Badge tone={entry.side === 'source' ? 'source' : 'target'} variant="soft">Connected</Badge>
            : <Badge tone="neutral" variant="soft">Not connected</Badge>}
        </div>

        <div style={{ fontSize: 'var(--text-md)', color: 'var(--text-secondary)', marginTop: 8 }}>
          {status.detail}
        </div>
        <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-tertiary)', marginTop: 6 }}>
          Needed for: {entry.needed}
        </div>

        {status.account || status.instance || status.host ? (
          <div className="bit-num" style={{ fontSize: 'var(--text-xs)', color: 'var(--text-tertiary)', marginTop: 8 }}>
            {[status.account, status.instance, status.host && status.host + '/' + (status.database || ''), status.url]
              .filter(Boolean).join(' · ')}
          </div>
        ) : null}

        {entry.key === 'converter' ? (
          <div style={{ display: 'flex', gap: 8, marginTop: 12, maxWidth: 460 }}>
            <Input size="sm" mono placeholder="http://localhost:8822" value={converterUrl}
              onChange={function (e) { onConverterUrl(e.target.value); }} style={{ flex: 1 }} />
            <Button size="sm" variant="secondary" disabled={busy}
              onClick={function () { onAction(setConverterUrl(converterUrl)); }}>Save</Button>
          </div>
        ) : null}

        {entry.key === 'warehouse' ? (
          <WarehouseForm status={status} projectId={projectId} busy={busy} onAction={onAction} />
        ) : null}
      </div>

      <div style={{ flex: 'none', display: 'flex', flexDirection: 'column', gap: 8, width: 150 }}>
        {entry.key === 'domo' ? (
          <React.Fragment>
            <Button size="sm" variant={status.connected ? 'secondary' : 'accent'} fullWidth disabled={busy}
              onClick={function () { onAction(signInToDomo()); }}>
              {busy ? 'In the browser…' : status.connected ? 'Sign in again' : 'Sign in'}
            </Button>
            {status.connected ? (
              <Button size="sm" variant="secondary" fullWidth disabled={busy}
                onClick={function () { onAction(forgetDomo()); }}>Forget</Button>
            ) : null}
          </React.Fragment>
        ) : null}

        {entry.key === 'powerbi' ? (
          <React.Fragment>
            <Button size="sm" variant={status.connected ? 'secondary' : 'accent'} fullWidth disabled={busy}
              onClick={function () { onAction(signInToPowerBI()); }}>
              {busy ? 'In the browser…' : status.connected ? 'Sign in again' : 'Sign in'}
            </Button>
            {status.connected ? (
              <Button size="sm" variant="secondary" fullWidth disabled={busy}
                onClick={function () { onAction(signOutOfPowerBI()); }}>Sign out</Button>
            ) : null}
          </React.Fragment>
        ) : null}
      </div>
    </div>
  );
}

// The non-secret half of a warehouse. The password is not a field on
// purpose: it lives in the environment, so the form says which variable to
// set and whether this process can see it. Saving re-checks the connection
// (the screen reloads and every status is live).
const WAREHOUSE_FIELDS = [
  { key: 'host', label: 'Host', placeholder: 'cluster.eu-west-1.redshift.amazonaws.com' },
  { key: 'port', label: 'Port', placeholder: '5439' },
  { key: 'database', label: 'Database', placeholder: 'analytics' },
  { key: 'user', label: 'User', placeholder: 'bimcontrol' },
  { key: 'landing_schema', label: 'Landing schema', placeholder: 'bimcontrol_landing' },
];

export function WarehouseForm({ status, projectId, busy, onAction }) {
  const saved = status.settings || {};
  const [open, setOpen] = React.useState(false);
  const [values, setValues] = React.useState({});

  function valueOf(key) {
    return values[key] !== undefined ? values[key] : (saved[key] === undefined ? '' : String(saved[key]));
  }

  function save() {
    const body = { key: 'redshift' };
    WAREHOUSE_FIELDS.forEach(function (f) {
      const v = valueOf(f.key).trim();
      if (v) body[f.key] = f.key === 'port' ? Number(v) : v;
    });
    // Staging settings are not on this form; keep what the CLI set.
    ['s3_bucket', 's3_prefix', 'aws_region', 'iam_role', 'keep_staged_files'].forEach(function (k) {
      if (saved[k] !== undefined) body[k] = saved[k];
    });
    onAction(saveWarehouse(projectId, body).then(function (r) { setOpen(false); setValues({}); return r; }));
  }

  const canSave = valueOf('host').trim() && valueOf('database').trim() && valueOf('user').trim();

  return (
    <div style={{ marginTop: 10 }}>
      <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-tertiary)' }}>
        Password: set <span className="bit-num">{status.password_env || 'REDSHIFT_PASSWORD'}</span> in
        the environment BIMControl starts in, so it never goes near the control database.
        {' '}{status.password_set
          ? <Badge tone="neutral" variant="soft">Found</Badge>
          : <Badge tone="warn" variant="soft">Not set</Badge>}
      </div>
      {open ? (
        <div style={{ marginTop: 12, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, maxWidth: 560 }}>
          {WAREHOUSE_FIELDS.map(function (f) {
            return (
              <label key={f.key} style={{ display: 'flex', flexDirection: 'column', gap: 4,
                fontSize: 'var(--text-xs)', color: 'var(--text-secondary)',
                gridColumn: f.key === 'host' ? '1 / span 2' : undefined }}>
                {f.label}
                <Input size="sm" mono placeholder={f.placeholder} value={valueOf(f.key)}
                  onChange={function (e) {
                    const next = Object.assign({}, values); next[f.key] = e.target.value; setValues(next);
                  }} />
              </label>
            );
          })}
          <div style={{ gridColumn: '1 / span 2', display: 'flex', gap: 8 }}>
            <Button size="sm" variant="accent" disabled={busy || !canSave} onClick={save}>Save and check</Button>
            <Button size="sm" variant="secondary" disabled={busy} onClick={function () { setOpen(false); }}>Cancel</Button>
          </div>
        </div>
      ) : (
        <div style={{ marginTop: 10 }}>
          <Button size="sm" variant={status.connected ? 'secondary' : 'accent'} disabled={busy || !projectId}
            onClick={function () { setOpen(true); }}>
            {saved.host ? 'Edit settings' : 'Set up Redshift'}
          </Button>
        </div>
      )}
    </div>
  );
}

import React from 'react';

// The migration unit picker: every dashboard in the loaded scan, smallest
// first, with its dependency closure in the inspector. Card count is the
// default sort because the smallest dashboards are the ones to migrate
// first, and because a dashboard of three cards is a believable first
// end-to-end run in a way a forty-card one is not.

// Pick an EstateScanner export zip (EstateScan-*.zip). The server validates
// it and keeps any earlier scan; on success the screen reloads onto it.
export function ImportScan({ label }) {
  const input = React.useRef(null);
  const [busy, setBusy] = React.useState(false);
  const [message, setMessage] = React.useState(null);

  function onPick(e) {
    const file = e.target.files && e.target.files[0];
    e.target.value = '';
    if (!file) return;
    setBusy(true);
    setMessage(null);
    uploadEstateZip(file).then(function () {
      window.location.reload();
    }, function (err) {
      setBusy(false);
      setMessage(err.message);
    });
  }

  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 'var(--space-5)' }}>
      <input ref={input} type="file" accept=".zip" style={{ display: 'none' }} onChange={onPick} />
      <Button variant="secondary" size="sm" disabled={busy}
        onClick={function () { input.current.click(); }}>
        {busy ? 'Importing...' : (label || 'Import a scan')}
      </Button>
      {message ? <span style={{ color: 'var(--text-error, #b42318)', fontSize: 'var(--text-sm)' }}>{message}</span> : null}
    </span>
  );
}

export function EstateScreen({ onSelectDashboard, starting }) {
  const [status, setStatus] = React.useState(null);
  const [error, setError] = React.useState(null);
  const [rows, setRows] = React.useState([]);
  const [total, setTotal] = React.useState(0);
  const [query, setQuery] = React.useState('');
  const [order, setOrder] = React.useState('cards');
  const [selected, setSelected] = React.useState(null);

  React.useEffect(function () {
    fetchEstateStatus().then(setStatus, function (e) { setError(e.message); });
  }, []);

  React.useEffect(function () {
    let stale = false;
    const handle = setTimeout(function () {
      fetchDashboards({ q: query, order: order, page_size: 200 }).then(function (body) {
        if (stale) return;
        setRows(body.items);
        setTotal(body.total);
      }, function (e) { if (!stale) setError(e.message); });
    }, query ? 180 : 0);  // debounce typing, but load the first page at once
    return function () { stale = true; clearTimeout(handle); };
  }, [query, order]);

  if (error) {
    return (
      <div style={{ padding: 'var(--space-10)' }}>
        <Banner tone="error" title="No estate scan loaded">
          {error}
          <div style={{ marginTop: 8 }}>
            Run an EstateScanner scan first, then start BIMControl with
            <span style={{ fontFamily: 'var(--font-mono)' }}> --estate &lt;path to estate.db&gt;</span>,
            or import the zip EstateScanner exported:
          </div>
          <div style={{ marginTop: 8 }}><ImportScan label="Import a scan (zip)" /></div>
        </Banner>
      </div>
    );
  }

  const scan = status && status.latest_completed_scan;
  const counts = (status && status.counts) || {};

  const columns = [
    { key: 'name', header: 'Dashboard', minWidth: 260 },
    { key: 'id', header: 'Id', width: 120, mono: true, muted: true },
    {
      key: 'card_count', header: 'Cards', width: 80, align: 'right', mono: true,
      render: function (row) { return formatCount(row.card_count); },
    },
  ];

  return (
    <React.Fragment>
      <Main>
        <PageHeader
          title="Estate"
          accent="as found."
          meta={scan
            ? <span>Scan <span className="bit-num">#{scan.id}</span> of <ProvenanceChip side="source" platform={'Domo · ' + scan.instance} size="sm" /> finished {String(scan.finished_at || '').slice(0, 10)}</span>
            : 'No completed scan in this database.'} />

        <div style={{ flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column', padding: '18px 20px 20px', gap: 'var(--space-7)', overflow: 'hidden' }}>
        <div style={{ display: 'flex', gap: 'var(--space-7)' }}>
          <StatTile size="sm" tone="source" value={formatCount(counts.dashboard)} label="Dashboards" />
          <StatTile size="sm" tone="source" value={formatCount(counts.card)} label="Cards" />
          <StatTile size="sm" tone="source" value={formatCount(counts.dataset)} label="Datasets" />
          <StatTile size="sm" tone="source" value={formatCount(counts.dataflow)} label="Dataflows" />
          <StatTile size="sm" tone="source" value={formatCount(counts.calculated_field)} label="Beast modes" />
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-5)' }}>
          <Input
            size="sm"
            placeholder="Search dashboards"
            iconLeft={<Icon name="search" size={14} />}
            value={query}
            onChange={function (e) { setQuery(e.target.value); }}
            style={{ width: 280 }}
          />
          <Tabs
            variant="segmented"
            value={order}
            onChange={setOrder}
            tabs={[
              { value: 'cards', label: 'Smallest first' },
              { value: 'cards_desc', label: 'Largest first' },
              { value: 'name', label: 'By name' },
            ]}
          />
          <div style={{ flex: 1 }} />
          <ImportScan />
          <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-secondary)', fontFamily: 'var(--font-mono)' }}>
            {formatCount(rows.length)} of {formatCount(total)}
          </div>
        </div>

        <div style={{ flex: 1, minHeight: 0, overflow: 'auto', border: '1px solid var(--border-hairline)', borderRadius: 'var(--radius-card)', background: 'var(--surface-card)' }}>
          <DataTable
            columns={columns}
            rows={rows}
            stickyHeader
            zebra
            onRowClick={function (row) { setSelected(row); }}
            emptyLabel="No dashboards match."
          />
        </div>
        </div>
      </Main>

      <Inspector>
        <ClosurePanel dashboard={selected} onMigrate={onSelectDashboard} starting={starting} />
      </Inspector>
    </React.Fragment>
  );
}

// The inspector: what a migration of the selected dashboard would have to
// carry. Everything here is source-side, so it is amber throughout; the
// target column stays empty until a run produces something.
export function ClosurePanel({ dashboard, onMigrate, starting }) {
  const [closure, setClosure] = React.useState(null);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState(null);

  React.useEffect(function () {
    if (!dashboard) { setClosure(null); return undefined; }
    let stale = false;
    setLoading(true);
    setError(null);
    fetchClosure(dashboard.id).then(function (body) {
      if (!stale) { setClosure(body); setLoading(false); }
    }, function (e) {
      if (!stale) { setError(e.message); setLoading(false); }
    });
    return function () { stale = true; };
  }, [dashboard && dashboard.id]);

  const panelStyle = { padding: 'var(--pad-panel)' };

  if (!dashboard) {
    return (
      <div style={panelStyle}>
        <EmptyState
          compact
          tone="source"
          headline="Pick a dashboard"
          accent="to migrate"
          body="Its dependency closure -- cards, datasets, dataflows and beast modes -- appears here."
        />
      </div>
    );
  }

  const summary = closure && closure.summary;

  return (
    <div style={panelStyle}>
      <div style={{ fontSize: 'var(--text-xl)', fontWeight: 'var(--weight-semibold)', lineHeight: 1.25 }}>
        {dashboard.name}
      </div>
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-xs)', color: 'var(--text-tertiary)', marginTop: 2 }}>
        {dashboard.id}
      </div>

      {loading && <div style={{ padding: '20px 0' }}><Spinner /></div>}
      {error && <div style={{ marginTop: 12 }}><Banner tone="error" title="Could not resolve closure">{error}</Banner></div>}

      {summary && (
        <div style={{ marginTop: 'var(--space-7)', display: 'flex', flexDirection: 'column', gap: 'var(--space-7)' }}>
          <KeyValueList
            dense
            dividers
            items={[
              { label: 'Cards', value: formatCount(summary.cards) },
              { label: 'Datasets', value: formatCount(summary.datasets) + ' (' + formatCount(summary.root_datasets) + ' raw)' },
              { label: 'Dataflows', value: formatCount(summary.dataflows) },
              { label: 'Beast modes', value: formatCount(summary.calculated_fields) },
            ]}
          />

          <div>
            <SectionLabel>Chart types</SectionLabel>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
              {Object.entries(summary.chart_types || {}).map(function ([chartType, n]) {
                return (
                  <Badge key={chartType} tone={chartType === 'unknown' ? 'warn' : 'source'} variant="soft">
                    {chartTypeLabel(chartType)} <span style={{ fontFamily: 'var(--font-mono)', opacity: 0.7 }}>{n}</span>
                  </Badge>
                );
              })}
            </div>
          </div>

          <div>
            <SectionLabel>Closure</SectionLabel>
            <TreeNode label={dashboard.name} depth={0} hasChildren expanded provenance="source" icon={<Icon name="grid" size={14} />} meta={String(summary.cards)} />
            {(closure.cards || []).map(function (card) {
              return (
                <TreeNode
                  key={card.id}
                  depth={1}
                  label={card.name || card.id}
                  provenance="source"
                  icon={<Icon name="chart" size={14} />}
                  status={card.chart_type ? undefined : 'warn'}
                  meta={chartTypeLabel(card.chart_type)}
                />
              );
            })}
            {(closure.datasets || []).map(function (ds) {
              return (
                <TreeNode
                  key={ds.id}
                  depth={1}
                  label={ds.name || ds.id}
                  provenance="source"
                  icon={<Icon name="database" size={14} />}
                  meta={ds.is_root ? 'raw input' : 'from dataflow'}
                />
              );
            })}
            {(closure.dataflows || []).map(function (flow) {
              return (
                <TreeNode
                  key={flow.id}
                  depth={1}
                  label={flow.name || flow.id}
                  provenance="source"
                  icon={<Icon name="branch" size={14} />}
                  meta={flow.engine}
                />
              );
            })}
          </div>

          {(summary.warnings || []).length > 0 && (
            <Banner tone="warn" title={summary.warnings.length + ' thing(s) to check'}>
              <ul style={{ margin: '4px 0 0', paddingLeft: 16 }}>
                {summary.warnings.map(function (w, i) { return <li key={i} style={{ marginBottom: 2 }}>{w}</li>; })}
              </ul>
            </Banner>
          )}

          <Button
            variant="accent"
            fullWidth
            iconLeft={<Icon name="play" size={14} />}
            disabled={Boolean(starting)}
            onClick={function () { if (onMigrate) onMigrate(dashboard); }}
          >
            {starting === dashboard.id ? 'Starting…' : 'Migrate this dashboard'}
          </Button>
        </div>
      )}
    </div>
  );
}

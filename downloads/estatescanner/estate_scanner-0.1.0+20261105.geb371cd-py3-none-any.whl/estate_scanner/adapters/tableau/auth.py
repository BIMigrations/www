"""Tableau sign-in: the PlatformAuthenticator implementation.

Every Tableau REST sign-in is the same call -- ``POST /api/{version}/auth/signin`` -- that returns a
token sent back as ``X-Tableau-Auth``; none of them needs a browser. Three credentials, in the order
we prefer them:

- **Personal access token (PAT).** Created by the person, not on their behalf; the session has that
  person's permissions. Required when the user has MFA, and the only way in for SSO users (the REST
  sign-in does not go through the IdP). Signing in again with the same PAT *ends the previous session*,
  so exactly one process may hold it; ``http.py`` serialises re-sign-in for that reason.
- **Connected-app JWT (direct trust).** A site admin creates the connected app. We mint the JWT here
  with the standard library (HS256 is HMAC-SHA256; a JOSE dependency for 20 lines is not worth it on a
  customer's machine). Its shared secret can mint a session for *any* user, which is more dangerous to
  hold than a PAT, so this is for scheduled/enterprise use, not the default.
- **Username and password.** Works only for a Tableau-authentication user without MFA.

**The secret is never stored in ``platform_sessions``.** That table is effectively a bearer token and
is documented as strippable before a database is handed over; a secret in it would make "strip it" a
hole. The secret comes from an environment variable (unattended runs) or from a mode-600 file beside
the database (what the Connect screen writes), like Power BI's MSAL cache. The persisted session holds
only the server, the site ``contentUrl`` (exact case), the token name and the REST version.
See docs/tableau-scan-decisions.md.

Nothing in this module was run against a Tableau site. Claims below tagged [U] are assumed from the
documentation (or from memory of it) and are checked by task 3.3.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import ipaddress
import json
import os
import re
import secrets
import time
import urllib.parse
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from estate_scanner import fsutil
from estate_scanner.core.platform import PlatformAuthenticator, PlatformError, PlatformSession

METHOD_PAT = "pat"
METHOD_JWT = "jwt"
METHOD_PASSWORD = "password"
METHODS = (METHOD_PAT, METHOD_JWT, METHOD_PASSWORD)

# Where an unattended run finds each method's secret. The environment wins over the file, so a
# scheduled job can override what the Connect screen saved.
SECRET_ENV = {METHOD_PAT: "TABLEAU_PAT_SECRET", METHOD_JWT: "TABLEAU_JWT_SECRET", METHOD_PASSWORD: "TABLEAU_PASSWORD"}
PAT_NAME_ENV = "TABLEAU_PAT_NAME"

DEFAULT_SITE_LABEL = "~default"  # the instance key's spelling of a Server's default site (contentUrl "")

# Tableau documents "exp within 10 minutes" for connected-app JWTs. We stay well inside it: the token
# is used once, at sign-in.
JWT_MAX_LIFETIME_S = 600
JWT_DEFAULT_LIFETIME_S = 300
JWT_DEFAULT_SCOPES = ("tableau:content:read",)  # list/GET of workbooks, views, data sources, projects, sites [C R5].
# Users, groups and tasks have their own scopes (tableau:users:read, tableau:groups:read,
# tableau:tasks:read); a read scope for permissions and flows was not found [U]. The caller adds them.


class TableauAuthError(PlatformError):
    """Sign-in failed or is impossible. Fatal to a scan, unlike an ApiError on one object."""

    def __init__(self, message: str, status: int | None = None):
        super().__init__(message)
        self.status = status


# -- names -------------------------------------------------------------------------------------------


ALLOW_HTTP_ENV = "TABLEAU_ALLOW_HTTP"
SERVER_URL_ENV = "TABLEAU_SERVER_URL"


def _is_loopback(host: str) -> bool:
    if host == "localhost":
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


_SITE_IN_PATH = re.compile(r"^(?P<prefix>.*?)/t/(?P<site>[^/]+)(?:/.*)?$")  # .../t/<site>/views/<wb>/<view>
_SITE_IN_FRAGMENT = re.compile(r"^/?site/(?P<site>[^/?]+)")  # #/site/<site>/home


def _address_parts(value: str) -> tuple[urllib.parse.SplitResult, str | None]:
    """The address split, with a site that the address itself names taken out of it: a Tableau page URL is
    ``https://host/#/site/<site>/...`` (Cloud, and Server for a non-default site) or ``https://host/t/<site>/views/...``
    (an embed or a shared link), neither of which is a server prefix. The site, if the address names one, comes back
    separately (percent-decoding is left alone: a contentUrl is letters, digits, ``-`` and ``_``)."""
    parts = urllib.parse.urlsplit(value)
    site = None
    path = parts.path
    in_path = _SITE_IN_PATH.match(path)
    if in_path:
        path, site = in_path.group("prefix"), in_path.group("site")
    in_fragment = _SITE_IN_FRAGMENT.match(parts.fragment)
    if in_fragment and site is None:
        site = in_fragment.group("site")
    return parts._replace(path=path), site


def site_in_address(server: str) -> str | None:
    """The site a pasted browser address names, or None. Never raises: a bad address is ``normalise_server``'s to refuse."""
    value = (server or "").strip()
    if not value:
        return None
    try:
        return _address_parts(value if "://" in value else "https://" + value)[1]
    except ValueError:
        return None


def normalise_server(server: str) -> str:
    """``https://host[:port][/prefix]``: scheme added when missing, query, fragment and a trailing slash
    dropped, and a site the address names (``/t/<site>/...``, ``#/site/<site>/...``) taken out of it: people paste a
    browser URL such as ``https://x.online.tableau.com/#/site/y/home`` (``site_in_address`` gives them the site).

    Refused, without echoing the input (it may hold a password): a user name or password in the address
    (it would end up in the database, the session and a file name), and any scheme but https. Plain http is
    accepted for loopback (a local test server) and when ``TABLEAU_ALLOW_HTTP`` is set, because a secret
    sent over http is readable on the way. TLS certificates are always verified: nothing here turns that off."""
    value = (server or "").strip()
    if not value:
        raise TableauAuthError("Enter the Tableau server address, e.g. https://10ax.online.tableau.com")
    if "://" not in value:
        value = "https://" + value
    try:
        parts, _site = _address_parts(value)
        host, _port = parts.hostname, parts.port
    except ValueError:
        raise TableauAuthError("That is not a server address (for example https://10ax.online.tableau.com).") from None
    if not host:
        raise TableauAuthError("That is not a server address (for example https://10ax.online.tableau.com).")
    if "@" in parts.netloc:
        raise TableauAuthError("The server address must not contain a user name or password; enter those as the sign-in details.")
    scheme = parts.scheme.lower()
    if scheme != "https" and not (scheme == "http" and (_is_loopback(host) or os.environ.get(ALLOW_HTTP_ENV))):
        raise TableauAuthError(
            "The server address must start with https:// (a token sent over http can be read on the way). "
            f"For a test server on this machine http is accepted; otherwise set {ALLOW_HTTP_ENV}=1."
        )
    return f"{scheme}://{parts.netloc}{parts.path.rstrip('/')}"


def instance_key(server: str, site: str | None) -> str:
    """``<host>[/prefix]/<contentUrl>``: one site, one instance, so two sites never mix (#55). The path
    prefix of a server mounted below the root is part of the key, so two servers on one host do not share
    a key. The database lower-cases it (``normalise_instance``); the session keeps the site's exact case.
    ``~`` is not a character a site URL name can hold [U, check on 3.3], so it cannot collide with a real site."""
    parts = urllib.parse.urlsplit(normalise_server(server))
    return f"{parts.netloc}{parts.path}/{site or DEFAULT_SITE_LABEL}"


def split_instance(instance: str) -> tuple[str, str]:
    """The inverse, for an unattended run that has only the instance name: (server, site). The name does
    not say whether the server is http or https, so https is assumed; a server with a path prefix cannot be
    split reliably at all and is refused: give the full address in ``TABLEAU_SERVER_URL``."""
    host, _, site = instance.strip().partition("/")
    if "/" in site:
        raise TableauAuthError(
            f"{instance!r} has a path prefix, which the instance name alone cannot tell apart from the site: "
            f"set {SERVER_URL_ENV} to the full server address (for example https://host/prefix)."
        )
    return normalise_server(host), "" if site in ("", DEFAULT_SITE_LABEL) else site


# -- the secret: environment or a mode-600 file, never the database --------------------------------


def default_secret_dir() -> Path:
    from estate_scanner.storage import db  # noqa: PLC0415 -- a module attribute so tests can move it

    return db.DEFAULT_DB_PATH.parent


def secret_path(instance: str, directory: Path | str | None = None) -> Path:
    """One file per instance. The name is the percent-encoded instance (so ``a_b`` and ``a~b`` stay two
    names and a ``/`` or ``:`` never reaches the file system) plus a short hash of the whole instance, which
    also bounds the length. Lower-case, like the database key."""
    key = instance.strip().lower()
    readable = urllib.parse.quote(key, safe="")[:100]
    digest = hashlib.sha256(key.encode()).hexdigest()[:10]
    return (Path(directory) if directory else default_secret_dir()) / f"tableau-{readable}-{digest}.secret"


def write_secret_file(path: Path, secret: str) -> None:
    """Replace the file whole, owner-only from the first byte (``fsutil.write_private``: a random exclusive temp name, no symlink followed, the
    mode or ACL set on the empty file). Refused, with the reason and no secret in it, when it cannot be made private and others can read it."""
    try:
        fsutil.write_private(path, secret)
    except fsutil.PrivateFileError as exc:
        raise TableauAuthError(str(exc)) from exc


def read_secret(method: str, secret_file: str | os.PathLike | None) -> str:
    """The secret for an unattended call. Never logged, never put in an error message."""
    env_name = SECRET_ENV[method]
    from_env = os.environ.get(env_name)
    if from_env:
        return from_env.strip()
    if secret_file and Path(secret_file).exists():
        path = Path(secret_file)
        try:
            if fsutil.readable_by_others(path):
                # Like ssh with a private key: a secret others can read is refused, not used quietly.
                raise TableauAuthError(f"{path} is readable by other users; {fsutil.fix_hint(path)}")
            value = path.read_text().strip()
        except OSError as exc:
            raise TableauAuthError(f"Cannot read the Tableau secret file {path}: {exc.strerror or type(exc).__name__}") from exc
        if value:
            return value
    raise TableauAuthError(f"No Tableau secret: set {env_name}, or connect again so it is saved beside the database.")


# -- the session ---------------------------------------------------------------------------------------


@dataclass
class TableauSession(PlatformSession):
    """What survives in ``platform_sessions``. No token, no secret: only names and a path to look the
    secret up. ``token_name`` is the PAT's name; ``username`` is the JWT's ``sub`` (the user's email) or
    the password sign-in's name."""

    instance: str
    server: str
    site: str = ""  # contentUrl, exact case ("" is a Server's default site)
    method: str = METHOD_PAT
    token_name: str | None = None
    username: str | None = None
    jwt_client_id: str | None = None
    jwt_secret_id: str | None = None
    jwt_scopes: tuple[str, ...] = JWT_DEFAULT_SCOPES
    rest_version: str | None = None  # what the last sign-in negotiated; informational, negotiated again each run
    secret_file: str | None = None
    platform: str = "tableau"

    def to_persisted_dict(self) -> dict:
        return {
            "server": self.server, "site": self.site, "method": self.method, "token_name": self.token_name,
            "username": self.username, "jwt_client_id": self.jwt_client_id, "jwt_secret_id": self.jwt_secret_id,
            "jwt_scopes": list(self.jwt_scopes), "rest_version": self.rest_version, "secret_file": self.secret_file,
        }

    @classmethod
    def from_persisted_dict(cls, instance: str, data: dict) -> "TableauSession":
        return cls(
            instance=instance, server=data["server"], site=data.get("site") or "", method=data.get("method") or METHOD_PAT,
            token_name=data.get("token_name"), username=data.get("username"), jwt_client_id=data.get("jwt_client_id"),
            jwt_secret_id=data.get("jwt_secret_id"), jwt_scopes=tuple(data.get("jwt_scopes") or JWT_DEFAULT_SCOPES),
            rest_version=data.get("rest_version"), secret_file=data.get("secret_file"),
        )


# -- credentials -> the sign-in body ------------------------------------------------------------------


def _b64url(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def hs256(signing_input: bytes, key: bytes) -> str:
    """JWS HS256: HMAC-SHA256 over ``header.payload``, base64url without padding (RFC 7515)."""
    return _b64url(hmac.new(key, signing_input, hashlib.sha256).digest())


def mint_jwt(
    *, client_id: str, secret_id: str, secret: str, username: str, scopes: tuple[str, ...] | list[str] = JWT_DEFAULT_SCOPES,
    lifetime_s: int = JWT_DEFAULT_LIFETIME_S, now: float | None = None, jti: str | None = None,
) -> str:
    """A connected-app (direct trust) token. Claims ``sub`` (the user's email), ``aud`` "tableau", ``exp``
    (at most 10 minutes out), ``jti`` (unique per token) and ``scp`` [C R4]. ``iss`` (the connected
    app's client id) in the claims and in the header with ``kid`` (the secret's id) is from memory of
    the connected-apps page, not from the plan's notes [U; checked on 3.3]."""
    if not 0 < lifetime_s <= JWT_MAX_LIFETIME_S:
        raise ValueError(f"A connected-app token may live at most {JWT_MAX_LIFETIME_S} s, asked for {lifetime_s}")
    issued = int(time.time() if now is None else now)
    header = {"alg": "HS256", "typ": "JWT", "kid": secret_id, "iss": client_id}
    claims = {
        "iss": client_id, "sub": username, "aud": "tableau", "exp": issued + lifetime_s,
        "jti": jti or secrets.token_hex(16), "scp": list(scopes),
    }
    signing_input = f"{_b64url(json.dumps(header, separators=(',', ':')).encode())}.{_b64url(json.dumps(claims, separators=(',', ':')).encode())}"
    return f"{signing_input}.{hs256(signing_input.encode('ascii'), secret.encode())}"


def signin_body(session: TableauSession, secret: str) -> dict:
    """The JSON sign-in document. The docs show XML (``<tsRequest><credentials ...>``); the JSON form
    below is the same tree, accepted when ``Content-Type: application/json`` is sent [U on 3.3]."""
    site = {"contentUrl": session.site}
    if session.method == METHOD_PAT:
        if not session.token_name:
            raise TableauAuthError("A personal access token needs its name (the token name shown when it was created).")
        return {"credentials": {"personalAccessTokenName": session.token_name, "personalAccessTokenSecret": secret, "site": site}}
    if session.method == METHOD_JWT:
        if not (session.jwt_client_id and session.jwt_secret_id and session.username):
            raise TableauAuthError("A connected-app sign-in needs the app's client id, the secret id and the user's email.")
        token = mint_jwt(
            client_id=session.jwt_client_id, secret_id=session.jwt_secret_id, secret=secret, username=session.username,
            scopes=session.jwt_scopes,
        )
        return {"credentials": {"jwt": token, "site": site}}
    if session.method == METHOD_PASSWORD:
        if not session.username:
            raise TableauAuthError("A password sign-in needs the user name.")
        return {"credentials": {"name": session.username, "password": secret, "site": site}}
    raise TableauAuthError(f"Unknown Tableau sign-in method {session.method!r}; use one of {', '.join(METHODS)}.")


# -- the authenticator ---------------------------------------------------------------------------------


class TableauAuthenticator(PlatformAuthenticator):
    platform = "tableau"
    case_sensitive_instance = True  # the site's contentUrl is part of the instance name and keeps its case

    def instance_for(self, *, server: str | None = None, site: str | None = None, **_: Any) -> str | None:
        if not server:
            return None
        return instance_key(server, site or site_in_address(server))

    def login_interactive(
        self, instance: str, *, server: str | None = None, site: str | None = None, token_name: str | None = None,
        secret: str | None = None, method: str = METHOD_PAT, username: str | None = None, jwt_client_id: str | None = None,
        jwt_secret_id: str | None = None, secret_dir: Path | str | None = None, **_: Any,
    ) -> TableauSession:
        """Sign in once to prove the credentials and learn the REST version, then save the secret to a
        mode-600 file. Despite the name there is no window: a PAT is typed (or set in the environment)
        by the person, which is why this never opens a browser. With only ``instance`` given (the CLI)
        the server and site come from it and the secret from the environment."""
        from .http import TableauHttp  # noqa: PLC0415 -- http imports this module

        if server is None:
            full_address = os.environ.get(SERVER_URL_ENV)
            if full_address:
                server, site = full_address, instance.strip().rpartition("/")[2] if site is None else site
                site = "" if site == DEFAULT_SITE_LABEL else site
            else:
                server, derived_site = split_instance(instance)
                site = derived_site if site is None else site
        site = site or site_in_address(server) or ""
        server = normalise_server(server)
        if method not in METHODS:
            raise TableauAuthError(f"Unknown Tableau sign-in method {method!r}; use one of {', '.join(METHODS)}.")
        key = instance_key(server, site)
        session = TableauSession(
            instance=key, server=server, site=site, method=method,
            token_name=(token_name or os.environ.get(PAT_NAME_ENV)) if method == METHOD_PAT else None,
            username=username if method != METHOD_PAT else None,
            jwt_client_id=jwt_client_id, jwt_secret_id=jwt_secret_id,
        )
        typed = (secret or "").strip() or None
        path = secret_path(key, secret_dir)
        http = TableauHttp(session, secret=(lambda: typed) if typed else (lambda: read_secret(method, path)))
        http.sign_in()  # raises TableauAuthError with the server's reason; nothing is saved before it works
        session.rest_version = http.rest_version
        if typed:
            write_secret_file(path, typed)
        # An unattended run supplies the secret through the environment on every run; a file is
        # pointed to only if one exists.
        session.secret_file = str(path) if path.exists() else None
        return session

    def restore_session(self, instance: str, persisted: dict) -> TableauSession:
        return TableauSession.from_persisted_dict(instance, persisted)

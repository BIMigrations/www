"""Drop model columns that nothing in the report or the model reads.

A Domo dataset often carries hundreds of columns while its cards read a
handful. Importing all of them made a 1.7M-row model run out of memory on
refresh (AR Aging-SW: 263 columns). Columns are kept when a visual, slicer,
filter or drillthrough page uses them, or when a measure, a calculated
column or a role filter mentions them by name.
"""

from __future__ import annotations

from bimcontrol.targets.powerbi.model import Report, SemanticModel


def used_columns(model: SemanticModel, report: Report) -> set[tuple[str, str]]:
    """(table, column) pairs read by the report, lower-cased."""
    used: set[tuple[str, str]] = set()
    default_table = model.tables[0].name if model.tables else ""

    def add(table: str | None, column: str | None) -> None:
        if column:
            used.add(((table or default_table).lower(), column.lower()))

    for page in report.pages:
        if page.drillthrough:
            add(page.drillthrough.table, page.drillthrough.column)
        for visual in page.visuals:
            for fields in visual.buckets.values():
                for projection in fields:
                    add(projection.table, projection.name)
            for kept in visual.kept_columns:
                add(kept.get("table"), kept.get("column"))
            for flt in visual.filters:
                if flt.field_kind != "measure":
                    add(flt.table, flt.column)
                by = (flt.top_n or {}).get("by") if flt.kind == "top_n" else None
                if by and by.get("kind") != "measure":
                    add(by.get("table"), by.get("name"))      # a Top N ranks by a column no bucket may show
    for flt in report.filters:
        add(flt.table, flt.column)
    for table in model.tables:
        for column in table.columns:
            if column.sort_by:
                add(table.name, column.sort_by)       # a column another is sorted by must stay
    return used


def prune_columns(model: SemanticModel, report: Report) -> dict[str, list[str]]:
    """Remove unused source columns in place; returns what was removed per table."""
    used = used_columns(model, report)
    expressions = [m.expression or "" for t in model.tables for m in t.measures]
    expressions += [c.expression or "" for t in model.tables for c in t.columns]
    expressions += [dax for r in model.roles for dax in r.filters.values()]
    text = "\n".join(expressions).lower()

    removed: dict[str, list[str]] = {}
    for table in model.tables:
        keep = []
        for column in table.columns:
            name = column.name.lower()
            if (column.expression or (table.name.lower(), name) in used
                    or f"[{name}]" in text):
                keep.append(column)
            else:
                removed.setdefault(table.name, []).append(column.name)
        if keep:
            table.columns = keep
        else:  # never leave a table with no columns
            removed.pop(table.name, None)
    return removed

"""Platform-agnostic core: domain models, abstract platform interfaces, the
platform/object-type registries, generic pagination, and the scan orchestrator.

Nothing under estate_scanner.core may import from estate_scanner.adapters.*.
"""

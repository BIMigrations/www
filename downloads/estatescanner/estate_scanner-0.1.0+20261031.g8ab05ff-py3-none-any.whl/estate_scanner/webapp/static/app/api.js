// Thin fetch() wrappers for the FastAPI backend. Loaded through the same
// zero-build ds-preview.js mechanism as the JSX files (Babel's react preset
// passes plain JS through unchanged), so every exported function here is
// available as a plain call inside any component via window.BITDS.

export function apiGet(path) {
  return fetch(path).then((r) => {
    if (!r.ok) throw new Error('GET ' + path + ' -> ' + r.status);
    return r.json();
  });
}

export function apiPost(path, body) {
  return fetch(path, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body || {}),
  }).then((r) => {
    if (!r.ok) return r.json().then((b) => { throw new Error(b.detail || ('POST ' + path + ' -> ' + r.status)); });
    return r.json();
  });
}

export function fetchPlatforms() {
  return apiGet('/api/platforms');
}

export function fetchPlatformSessions(key) {
  return apiGet('/api/platforms/' + key + '/sessions');
}

export function connectPlatform(key, instance) {
  return apiPost('/api/platforms/' + key + '/connect', { instance });
}

export function fetchConnectStatus(key, jobId) {
  return apiGet('/api/platforms/' + key + '/connect/' + jobId);
}

export function startScan(platform, instance, skipGroupMembership) {
  return apiPost('/api/scans', { platform, instance, skip_group_membership: !!skipGroupMembership });
}

export function fetchScanProgress(jobId) {
  return apiGet('/api/scans/jobs/' + jobId + '/progress');
}

export function fetchScan(scanId) {
  return apiGet('/api/scans/' + scanId);
}

export function fetchScans() {
  return apiGet('/api/scans');
}

export function fetchEstateSummary(platform) {
  return apiGet('/api/estate/summary' + (platform ? '?platform=' + encodeURIComponent(platform) : ''));
}

export function fetchEstateObjects(objectType, params) {
  const qs = new URLSearchParams(
    Object.fromEntries(Object.entries(params || {}).filter(([, v]) => v !== undefined && v !== null && v !== ''))
  ).toString();
  return apiGet('/api/estate/' + objectType + (qs ? '?' + qs : ''));
}

export function fetchEstateObject(objectType, id, platform) {
  return apiGet('/api/estate/' + objectType + '/' + encodeURIComponent(id) + (platform ? '?platform=' + encodeURIComponent(platform) : ''));
}

export function fetchGraphStats(platform) {
  return apiGet('/api/graph/stats' + (platform ? '?platform=' + encodeURIComponent(platform) : ''));
}

export function fetchMostConnected(platform, top) {
  const params = new URLSearchParams();
  if (platform) params.set('platform', platform);
  if (top) params.set('top', String(top));
  const qs = params.toString();
  return apiGet('/api/graph/most-connected' + (qs ? '?' + qs : ''));
}

// Every "*_json" column in schema.sql (dataflows.definition_json,
// dashboards.layout_json, apps.views_json, ...) comes back from
// /api/estate/{type}/{id} as a JSON-encoded string, not a parsed object --
// pretty-print it for display, falling back to the raw string if a value
// somehow isn't valid JSON.
export function prettyJson(raw) {
  if (raw == null) return '';
  try {
    return JSON.stringify(JSON.parse(raw), null, 2);
  } catch (e) {
    return String(raw);
  }
}

// Turns a raw snake_case column name into an Inspector-friendly label, e.g.
// "definition_json" -> "Definition", "downstream_dataflow_count" ->
// "Downstream dataflow count". Stripping the "_json" suffix specifically
// covers the dedicated blob-section titles; every other column just gets
// spaces where a fixed-width KeyValueList label needs a wrap point that an
// unbroken snake_case string wouldn't otherwise get.
export function humanizeFieldKey(key) {
  const base = key.replace(/_json$/, '').replace(/_/g, ' ');
  return base.charAt(0).toUpperCase() + base.slice(1);
}

// ds-preview.js's loader only recognizes a named function export (it
// regexes the source text for that exact shape, comments included, to know
// what to merge into window.BITDS) -- a const array export is never used
// anywhere in this design system for that reason, so this stays a
// function rather than a const array.
export function getObjectTypes() {
  return [
    { value: 'dataset', label: 'Datasets' },
    { value: 'dataflow', label: 'Dataflows' },
    { value: 'card', label: 'Cards' },
    { value: 'dashboard', label: 'Dashboards' },
    { value: 'calculated_field', label: 'Calculated fields' },
    { value: 'user', label: 'Users' },
    { value: 'group', label: 'Groups' },
    { value: 'account', label: 'Accounts' },
    { value: 'alert', label: 'Alerts' },
    { value: 'app', label: 'Apps' },
    { value: 'workspace', label: 'Workspaces' },
    { value: 'gateway', label: 'Gateways' },
  ];
}

export function exportScan() {
  return apiPost('/api/export');
}

export function revealExport(path) {
  return apiPost('/api/export/reveal', { path });
}

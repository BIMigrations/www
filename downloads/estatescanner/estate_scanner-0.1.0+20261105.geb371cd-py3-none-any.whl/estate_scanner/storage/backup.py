"""A consistent copy of the database file, taken before anything rewrites it.

One function for every operation that changes data in place: the instance migration (#55) and,
when #57 lands, deleting a scan or starting fresh. The name says why the copy exists:
`estate.db.pre-instance-20261030T130500Z.bak`, `estate.db.pre-delete-scan-12-<stamp>.bak`.
"""

from __future__ import annotations

import datetime as _dt
import os
import shutil
import sqlite3
from pathlib import Path

# The copy, plus room for the rewrite itself (a rebuilt table exists twice for a while).
FREE_SPACE_FACTOR = 2.5


class NotEnoughDiskSpace(RuntimeError):
    """The disk holds less than the copy and the rewrite need. Nothing was written."""


def backup_path(db_path: Path | str, reason: str, now: _dt.datetime | None = None) -> Path:
    db_path = Path(db_path)
    stamp = (now or _dt.datetime.now(_dt.timezone.utc)).strftime("%Y%m%dT%H%M%SZ")
    return db_path.with_name(f"{db_path.name}.pre-{reason}-{stamp}.bak")


def backup_database(
    db_path: Path | str,
    reason: str,
    *,
    free_space_factor: float = FREE_SPACE_FACTOR,
    exclude_tables: tuple[str, ...] = (),
) -> Path:
    """Copy `db_path` with SQLite's backup API (consistent even while another connection writes) and
    return the path of the copy. Refuses, writing nothing, when free disk is below
    `free_space_factor` x the file's size. The copy is complete or absent: it is written under a
    temporary name and renamed.

    `exclude_tables` are emptied in the copy (never in `db_path`), with `secure_delete` on so their
    old content is zeroed in the free pages too, not just unlinked: the saved sign-in does not need
    to sit in plain text in a file that is kept for good."""
    db_path = Path(db_path)
    size = db_path.stat().st_size
    free = shutil.disk_usage(db_path.parent).free
    if free < size * free_space_factor:
        raise NotEnoughDiskSpace(
            f"{db_path} is {size / 1e6:,.0f} MB and the disk has {free / 1e6:,.0f} MB free; "
            f"{size * free_space_factor / 1e6:,.0f} MB are needed to copy it first. Free some space and open it again."
        )
    target = backup_path(db_path, reason)
    # Two processes opening the same old file in one second must not share a name (found by starting three at once).
    taken = 1
    while target.exists():
        taken += 1
        target = backup_path(db_path, f"{reason}-{taken}")
    partial = target.with_name(f"{target.name}.{os.getpid()}.partial")
    src = sqlite3.connect(db_path, timeout=60)
    try:
        dst = sqlite3.connect(partial)
        try:
            src.backup(dst)
            if exclude_tables:
                dst.execute("PRAGMA secure_delete = ON")
                for table in exclude_tables:
                    if dst.execute("SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?", (table,)).fetchone():
                        dst.execute(f'DELETE FROM "{table}"')
                dst.commit()
        finally:
            dst.close()
    except BaseException:
        partial.unlink(missing_ok=True)
        raise
    finally:
        src.close()
    os.replace(partial, target)
    return target

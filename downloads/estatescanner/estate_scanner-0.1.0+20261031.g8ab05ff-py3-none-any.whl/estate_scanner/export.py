"""Export a scan as a zip that is safe to email.

The live database holds the signed-in session in `platform_sessions`, which is
a bearer credential. The export is built from a copy with that table emptied
and the file vacuumed, so the credentials are not recoverable from free pages.
The customer's own database is never modified.
"""

from __future__ import annotations

import json
import shutil
import sqlite3
import tempfile
import zipfile
from datetime import datetime, timezone
from importlib import metadata
from pathlib import Path

EXPORT_DB_NAME = "estate.db"
MANIFEST_NAME = "manifest.json"
_COUNTED_TABLES = ("users", "groups_", "datasets", "dataflows", "cards", "dashboards", "apps", "calculated_fields", "alerts", "workspaces", "gateways", "edges")


def default_export_dir() -> Path:
    """Where exports go: Documents if it exists (a place people can find), else home."""
    documents = Path.home() / "Documents"
    return documents if documents.is_dir() else Path.home()


def _tool_version() -> str:
    try:
        return metadata.version("estate-scanner")
    except metadata.PackageNotFoundError:
        return "unknown"


def _sanitised_copy(db_path: Path, dest: Path) -> None:
    src = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    try:
        out = sqlite3.connect(dest)
        try:
            src.backup(out)
            out.execute("DELETE FROM platform_sessions")
            out.commit()
            out.execute("VACUUM")
        finally:
            out.close()
    finally:
        src.close()


def _manifest(db_copy: Path) -> dict:
    conn = sqlite3.connect(db_copy)
    try:
        scan = conn.execute(
            "SELECT id, platform, instance, started_at, finished_at, status FROM scans "
            "WHERE status = 'completed' ORDER BY id DESC LIMIT 1"
        ).fetchone()
        # A database last opened by an older version has no table for an object type added since.
        present = {row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}
        counts = {t: conn.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] if t in present else 0 for t in _COUNTED_TABLES}
    finally:
        conn.close()
    keys = ("scan_id", "platform", "instance", "started_at", "finished_at", "status")
    return {
        "tool_version": _tool_version(),
        "exported_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "latest_completed_scan": dict(zip(keys, scan)) if scan else None,
        "object_counts": counts,
        "contains_sessions": False,
    }


def export_scan(db_path: str | Path, dest_dir: str | Path | None = None) -> Path:
    """Write `EstateScan-<instance>-<timestamp>.zip` into `dest_dir` and return its path."""
    db_path = Path(db_path)
    if not db_path.exists():
        raise FileNotFoundError(f"No scan database at {db_path}")
    dest_dir = Path(dest_dir) if dest_dir else default_export_dir()
    dest_dir.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory() as tmp:
        copy = Path(tmp) / EXPORT_DB_NAME
        _sanitised_copy(db_path, copy)
        manifest = _manifest(copy)
        scan = manifest["latest_completed_scan"]
        if scan is None:
            raise ValueError("There is no completed scan to export yet. Run a scan first.")
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        safe_instance = "".join(c if c.isalnum() or c in "-_" else "_" for c in scan["instance"])
        zip_path = dest_dir / f"EstateScan-{safe_instance}-{stamp}.zip"
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.write(copy, EXPORT_DB_NAME)
            zf.writestr(MANIFEST_NAME, json.dumps(manifest, indent=2))
    return zip_path

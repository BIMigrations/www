import React from 'react';

export function ConnectScreen({ onConnected }) {
  const [platforms, setPlatforms] = React.useState(null);
  const [sessionsByKey, setSessionsByKey] = React.useState({});
  const [instanceByKey, setInstanceByKey] = React.useState({});
  const [connecting, setConnecting] = React.useState(null); // { key, jobId, status }
  const [error, setError] = React.useState(null);

  const reload = React.useCallback(function () {
    fetchPlatforms().then(function (list) {
      setPlatforms(list);
      list.filter(function (p) { return p.status === 'available'; }).forEach(function (p) {
        fetchPlatformSessions(p.key).then(function (sessions) {
          setSessionsByKey(function (prev) { return Object.assign({}, prev, { [p.key]: sessions }); });
        });
      });
    });
  }, []);

  React.useEffect(function () { reload(); }, [reload]);

  React.useEffect(function () {
    if (!connecting || connecting.status !== 'running') return undefined;
    const timer = setInterval(function () {
      fetchConnectStatus(connecting.key, connecting.jobId).then(function (job) {
        if (job.status === 'completed') {
          setConnecting(null);
          setError(null);
          reload();
          if (onConnected) onConnected(connecting.key, job.result && job.result.instance);
        } else if (job.status === 'failed') {
          setConnecting(null);
          setError(job.error || 'Connection failed');
        }
      });
    }, 2000);
    return function () { clearInterval(timer); };
  }, [connecting, reload, onConnected]);

  function connect(key) {
    const instance = (instanceByKey[key] || '').trim();
    if (!instance) return;
    setError(null);
    connectPlatform(key, instance).then(function (res) {
      setConnecting({ key, jobId: res.job_id, status: 'running' });
    }).catch(function (e) { setError(String(e.message || e)); });
  }

  if (!platforms) return <Spinner />;

  return (
    <div style={{ padding: 24, display: 'flex', flexDirection: 'column', gap: 16, maxWidth: 720 }}>
      <div>
        <div style={{ fontSize: 'var(--text-3xl)', fontWeight: 'var(--weight-semibold)', letterSpacing: 'var(--tracking-heading)' }}>
          Connect a <span style={{ fontFamily: 'var(--font-editorial)', fontStyle: 'italic', fontWeight: 400, color: 'var(--provenance-target)' }}>BI platform</span>
        </div>
        <div style={{ fontSize: 'var(--text-md)', color: 'var(--text-secondary)', marginTop: 4 }}>
          Signing in opens a real browser window for that platform's own login (SSO/MFA all supported) --
          nothing is sent anywhere but the platform itself and this machine's local database.
        </div>
      </div>

      {error && <Banner tone="error" title="Connection failed">{error}</Banner>}

      {platforms.map(function (p) {
        const sessions = sessionsByKey[p.key] || [];
        const isConnecting = connecting && connecting.key === p.key;
        return (
          <Card key={p.key} title={p.display_name} actions={
            p.status === 'coming_soon' ? <Tag>Coming soon</Tag> : <StatusDot status={sessions.length ? 'ok' : 'idle'} label={sessions.length ? 'Connected' : 'Not connected'} />
          }>
            {p.status === 'coming_soon' ? (
              <div style={{ color: 'var(--text-tertiary)', fontSize: 'var(--text-sm)' }}>Support for {p.display_name} is planned but not built yet.</div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {sessions.length > 0 && (
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                    {sessions.map(function (s) { return <Tag key={s.instance} tone="source">{s.instance}</Tag>; })}
                  </div>
                )}
                <div style={{ display: 'flex', gap: 8 }}>
                  <Input
                    placeholder="Instance name, e.g. 6intelligence"
                    value={instanceByKey[p.key] || ''}
                    onChange={function (e) { setInstanceByKey(Object.assign({}, instanceByKey, { [p.key]: e.target.value })); }}
                    disabled={!!isConnecting}
                  />
                  <Button onClick={function () { connect(p.key); }} disabled={!!isConnecting} loading={!!isConnecting}>
                    {isConnecting ? 'Waiting for sign-in…' : 'Connect'}
                  </Button>
                </div>
                {isConnecting && (
                  <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-tertiary)' }}>
                    Complete sign-in in the browser window that just opened.
                  </div>
                )}
              </div>
            )}
          </Card>
        );
      })}
    </div>
  );
}

import React from 'react';

// Watching a migration run: the ten stages of the line, what each one
// reported, and the live log underneath.
//
// Progress is never a bare spinner or a percentage. A run that says
// "landing 940 rows of customer JULY 22 US" tells you whether it is
// stuck; one that says "52%" does not. The stage list is the progress bar.
//
// The log follows by long-polling `GET /runs/{id}/events?wait_seconds=N`,
// which holds one connection open until something happens. The alternative
// -- polling every second -- costs a request per second per open screen and
// still shows events late.

const FOLLOW_WAIT_SECONDS = 25;

export function MigrateScreen({ runId, onSelectRun, onOpenParity }) {
  const [runs, setRuns] = React.useState([]);
  const [run, setRun] = React.useState(null);
  const [events, setEvents] = React.useState([]);
  const [error, setError] = React.useState(null);
  const [busy, setBusy] = React.useState(false);
  const [artefact, setArtefact] = React.useState(null);
  const [panel, setPanel] = React.useState('artefacts');

  function reloadRuns() {
    return fetchRuns({ limit: 50 }).then(function (body) { setRuns(body.items); }, function (e) { setError(e.message); });
  }

  React.useEffect(function () { reloadRuns(); }, []);

  React.useEffect(function () {
    if (!runId) { setRun(null); setEvents([]); return undefined; }
    let stale = false;
    setEvents([]);
    setArtefact(null);
    fetchRun(runId).then(function (body) { if (!stale) setRun(body); },
      function (e) { if (!stale) setError(e.message); });
    return function () { stale = true; };
  }, [runId]);

  // Follow the event stream for as long as this run is on screen. Each
  // reply carries the run's status, so the stage list refreshes from the
  // same round trip rather than a second poll.
  React.useEffect(function () {
    if (!runId) return undefined;
    let stale = false;
    let seq = 0;

    function follow() {
      if (stale) return;
      fetchEvents(runId, seq, FOLLOW_WAIT_SECONDS).then(function (page) {
        if (stale) return;
        if (page.items.length) {
          seq = page.next_after_seq;
          setEvents(function (previous) { return previous.concat(page.items); });
        }
        if (page.live || page.run_status === 'running') {
          fetchRun(runId).then(function (body) { if (!stale) setRun(body); }, function () {});
          follow();
        } else {
          // One last read, so the final stage statuses are not left behind
          // by the event that ended the run.
          fetchRun(runId).then(function (body) { if (!stale) setRun(body); }, function () {});
          reloadRuns();
        }
      }, function () { /* a dropped connection stops the follow, not the screen */ });
    }
    follow();
    return function () { stale = true; };
  }, [runId]);

  function act(promise) {
    setBusy(true);
    setError(null);
    return promise.then(function (body) {
      setBusy(false);
      reloadRuns();
      return body;
    }, function (e) { setBusy(false); setError(e.message); });
  }

  const stages = (run && run.stages) || [];
  const live = run && (run.live || run.status === 'running');

  return (
    <React.Fragment>
      <Sidebar>
        <SidebarGroup label="Runs" action={
          <IconButton size="sm" icon={<Icon name="refresh" size={13} />} label="Refresh"
            onClick={reloadRuns} />
        }>
          {runs.length === 0
            ? <div style={{ padding: '6px 6px 2px', fontSize: 'var(--text-sm)', color: 'var(--text-tertiary)' }}>
                No runs yet. Pick a dashboard on the Estate screen.
              </div>
            : runs.map(function (r) {
              return (
                <NavItem
                  key={r.id}
                  label={r.unit_name || r.unit_id}
                  meta={statusLabel(r.status)}
                  active={r.id === runId}
                  icon={<StatusDot status={statusDot(r.status)} />}
                  onClick={function () { onSelectRun(r.id); }}
                />
              );
            })}
        </SidebarGroup>
      </Sidebar>

      <Main>
        {!run ? (
          <div style={{ flex: 1, display: 'grid', placeItems: 'center', padding: 'var(--space-10)' }}>
            <EmptyState
              headline="No run"
              accent="selected."
              body="Pick a run on the left, or start one from the Estate screen."
            />
          </div>
        ) : (
          <React.Fragment>
            <PageHeader
              title={(run.unit && run.unit.name) || run.unit_id}
              meta={
                <span>
                  <span className="bit-num">{run.id}</span>
                  {' · '}<ProvenanceChip side="source" platform="Domo" size="sm" />
                  {' → '}<ProvenanceChip side="target" platform="Power BI" size="sm" />
                  {' · started '}{shortTime(run.started_at)}
                  {' · '}<span className="bit-num">{formatDuration(elapsedSeconds(run.started_at, run.finished_at))}</span>
                </span>
              }
              actions={
                <React.Fragment>
                  {live
                    ? <Button variant="secondary" size="md" disabled={busy}
                        iconLeft={<Icon name="stop" size={13} />}
                        onClick={function () { act(cancelRun(run.id)); }}>Stop</Button>
                    : <Button variant="accent" size="md" disabled={busy}
                        iconLeft={<Icon name="play" size={13} />}
                        onClick={function () {
                          act(resumeRun(run.id)).then(function () { onSelectRun(run.id); });
                        }}>{run.status === 'succeeded' ? 'Run again' : 'Carry on'}</Button>}
                </React.Fragment>
              }>
              <div style={{ margin: '18px 0 6px' }}>
                <RunStatusLine run={run} onOpenParity={onOpenParity}
                  onOpenReview={function () { setPanel('review'); }} />
              </div>
            </PageHeader>

            <ErrorBanner error={error} title="That did not work" />
            {run.error ? (
              <div style={{ padding: '12px 20px 0' }}>
                <Banner tone="error" title={'Stopped in ' + (run.error_stage || 'an early stage')}>
                  {run.error}
                </Banner>
              </div>
            ) : null}
            {run.stopped_reason && !run.error ? (
              <div style={{ padding: '12px 20px 0' }}>
                <Banner tone="warn" title="The run did not finish">{run.stopped_reason}</Banner>
              </div>
            ) : null}

            <div style={{ flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column', padding: '16px 20px 20px', gap: 16, overflow: 'hidden' }}>
              <StageList stages={stages} />
              <EventLog events={events} live={live} />
            </div>
          </React.Fragment>
        )}
      </Main>

      <Inspector>
        {run ? (
          <div style={{ padding: '0 12px' }}>
            <Tabs value={panel} onChange={setPanel} tabs={[
              { value: 'artefacts', label: 'Artefacts' },
              { value: 'review', label: 'Review', count: run.open_reviews || 0 },
            ]} />
          </div>
        ) : null}
        {run && panel === 'review'
          ? <ReviewPanel run={run} onChanged={function () {
              fetchRun(run.id).then(setRun, function () {});
            }} />
          : <ArtefactPanel run={run} artefact={artefact} onOpen={setArtefact} />}
      </Inspector>
    </React.Fragment>
  );
}

// The headline every run gets: how far down the line it reached, in
// stations rather than in percent.
export function RunStatusLine({ run, onOpenParity, onOpenReview }) {
  const stages = run.stages || [];
  const done = stages.filter(function (s) { return s.status === 'succeeded' || s.status === 'skipped'; }).length;
  const failed = stages.filter(function (s) { return s.status === 'failed'; }).length;
  const parity = (stages.find(function (s) { return s.name === 'verify_parity'; }) || {}).result;
  const elements = ((stages.find(function (s) { return s.name === 'report'; }) || {}).result || {}).elements;
  const publishedUrl = ((stages.find(function (s) { return s.name === 'publish_powerbi'; }) || {}).result || {}).report_url;

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 20, flexWrap: 'wrap' }}>
      <div style={{ minWidth: 260, flex: '1 1 260px' }}>
        <ProgressBar
          max={stages.length}
          showValue={false}
          segments={[
            { value: done, tone: 'target', label: 'Done' },
            { value: failed, tone: 'retired', label: 'Failed' },
          ]}
          detail={done + ' of ' + stages.length + ' stages'}
        />
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <StatusDot status={statusDot(run.status)} pulse={run.status === 'running'} />
        <span style={{ fontSize: 'var(--text-md)' }}>{statusLabel(run.status)}</span>
      </div>
      {run.open_reviews ? (
        <span style={{ cursor: onOpenReview ? 'pointer' : 'default' }} onClick={onOpenReview}>
          <Badge tone="warn" dot>{formatCount(run.open_reviews)} to review</Badge>
        </span>
      ) : null}
      {publishedUrl ? (
        <a href={publishedUrl} target="_blank" rel="noopener noreferrer">
          <Button size="sm" variant="secondary">Open in Power BI</Button>
        </a>
      ) : null}
      {elements ? (
        <Button size="sm" variant="secondary" onClick={function () { onOpenParity(run.id); }}>
          {formatCount(elements.matches)} match, {formatCount(elements.differs)} differ, {formatCount(elements.not_compared)} not compared, {formatCount(elements.not_migrated)} not migrated
        </Button>
      ) : parity && parity.checked ? (
        <Button size="sm" variant="secondary" onClick={function () { onOpenParity(run.id); }}>
          Parity: {formatCount(parity.ok)} match, {formatCount(parity.error)} differ
        </Button>
      ) : null}
    </div>
  );
}

// A stage result value is a number, a string or a {name: count} map (chart types): a map printed
// with String() reads "[object Object]".
function stageValue(value) {
  if (value && typeof value === 'object' && !Array.isArray(value)) {
    return Object.keys(value).map(function (k) { return k + ' ' + value[k]; }).join(', ');
  }
  return String(value);
}

export function StageList({ stages }) {
  return (
    <Panel pad={0}>
      <div>
        {stages.map(function (stage, index) {
          const result = stage.result || {};
          const summary = Object.keys(result)
            .filter(function (k) { return result[k] !== null && result[k] !== false; })
            .map(function (k) { return k.replace(/_/g, ' ') + ' ' + stageValue(result[k]); })
            .join(' · ');
          return (
            <div key={stage.name} style={{
              display: 'flex', alignItems: 'center', gap: 12, padding: '8px 14px',
              borderTop: index ? '1px solid var(--border-hairline)' : 'none',
              background: stage.status === 'running' ? 'var(--surface-selected)' : 'transparent',
            }}>
              <StatusDot status={statusDot(stage.status)} pulse={stage.status === 'running'} />
              <span style={{ width: 210, flex: 'none', fontSize: 'var(--text-md)' }}>{stage.title}</span>
              <span style={{ width: 92, flex: 'none' }}>
                <Badge tone={statusTone(stage.status)} variant="soft">{statusLabel(stage.status)}</Badge>
              </span>
              <span style={{ flex: 1, minWidth: 0, fontSize: 'var(--text-sm)', color: 'var(--text-tertiary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {stage.error || summary}
              </span>
              <span style={{ flex: 'none' }}>
                <Figure muted value={formatDuration(elapsedSeconds(stage.started_at, stage.finished_at))} />
              </span>
            </div>
          );
        })}
      </div>
    </Panel>
  );
}

export function EventLog({ events, live }) {
  const scroller = React.useRef(null);

  // Follow the tail only while the reader is already at the bottom: yanking
  // the view back down while somebody is reading an earlier error is the
  // fastest way to make a log useless.
  React.useEffect(function () {
    const node = scroller.current;
    if (!node) return;
    const atBottom = node.scrollHeight - node.scrollTop - node.clientHeight < 60;
    if (atBottom) node.scrollTop = node.scrollHeight;
  }, [events.length]);

  return (
    <div style={{ flex: 1, minHeight: 120, display: 'flex', flexDirection: 'column' }}>
      <SectionLabel>{live ? 'Log · following' : 'Log'}</SectionLabel>
      <div ref={scroller} style={{
        flex: 1, minHeight: 0, overflow: 'auto', padding: '8px 12px',
        border: '1px solid var(--border-hairline)', borderRadius: 'var(--radius-card)',
        background: 'var(--surface-sunken)', fontFamily: 'var(--font-mono)',
        fontSize: 'var(--text-xs)', lineHeight: 1.65,
      }}>
        {events.length === 0
          ? <span style={{ color: 'var(--text-tertiary)' }}>Nothing logged yet.</span>
          : events.map(function (event) {
            return (
              <div key={event.seq} style={{
                display: 'flex', gap: 10,
                color: event.level === 'error' ? 'var(--status-error)'
                  : event.level === 'warn' ? 'var(--status-warn)' : 'var(--text-secondary)',
              }}>
                <span style={{ color: 'var(--text-disabled)', flex: 'none' }}>{shortTime(event.created_at)}</span>
                <span style={{ color: 'var(--text-disabled)', flex: 'none', width: 130 }}>{event.stage || ''}</span>
                <span style={{ minWidth: 0, wordBreak: 'break-word' }}>{event.message || event.type}</span>
              </div>
            );
          })}
      </div>
    </div>
  );
}

// What the run produced, and a preview of whichever one is open. Text
// artefacts -- SQL, TMDL, JSON -- are the ones worth reading in place; the
// rest are a download.
export function ArtefactPanel({ run, artefact, onOpen }) {
  const [text, setText] = React.useState(null);
  const [error, setError] = React.useState(null);

  React.useEffect(function () {
    if (!artefact || !run) { setText(null); return undefined; }
    let stale = false;
    setText(null);
    setError(null);
    fetchArtefactText(run.id, artefact.id).then(function (body) {
      if (!stale) setText(body.slice(0, 40000));
    }, function (e) { if (!stale) setError(e.message); });
    return function () { stale = true; };
  }, [artefact && artefact.id]);

  if (!run) {
    return (
      <InspectorBody>
        <EmptyState compact headline="Artefacts" body="What a run wrote appears here." />
      </InspectorBody>
    );
  }

  const artefacts = run.artefacts || [];
  if (artefact) {
    return (
      <InspectorBody>
        <div>
          <Button size="sm" variant="secondary" iconLeft={<Icon name="chevronLeft" size={13} />}
            onClick={function () { onOpen(null); }}>All artefacts</Button>
        </div>
        <div>
          <div style={{ fontSize: 'var(--text-lg)', fontWeight: 'var(--weight-semibold)' }}>
            {artefact.label || artefact.path}
          </div>
          <div className="bit-num" style={{ fontSize: 'var(--text-xs)', color: 'var(--text-tertiary)', marginTop: 2 }}>
            {artefact.path} · {formatCount(artefact.bytes)} bytes
          </div>
        </div>
        {error ? <Banner tone="error" title="Could not read it">{error}</Banner> : null}
        {text !== null ? <CodeBlock code={text} language={artefact.kind === 'sql' ? 'sql' : 'json'} maxHeight={420} /> : <Spinner />}
        <a href={artefactUrl(run.id, artefact.id)} download>
          <Button size="sm" variant="secondary" fullWidth iconLeft={<Icon name="download" size={13} />}>
            Download
          </Button>
        </a>
      </InspectorBody>
    );
  }

  return (
    <InspectorBody>
      <div>
        <SectionLabel>Artefacts</SectionLabel>
        <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-tertiary)' }}>
          Every stage writes what it produced to disk. These are the files, in the order they were made.
        </div>
      </div>
      {artefacts.length === 0
        ? <EmptyState compact headline="Nothing written" body="This run has not produced an artefact yet." />
        : artefacts.map(function (a) {
          return (
            <div key={a.id} onClick={function () { onOpen(a); }} style={{
              cursor: 'pointer', padding: '8px 10px', borderRadius: 'var(--radius-sm)',
              border: '1px solid var(--border-hairline)', background: 'var(--surface-card)',
            }}>
              <div style={{ fontSize: 'var(--text-md)' }}>{a.label || a.path}</div>
              <div className="bit-num" style={{ fontSize: 'var(--text-2xs)', color: 'var(--text-tertiary)', marginTop: 2 }}>
                {a.stage} · {formatCount(a.bytes)} bytes
              </div>
            </div>
          );
        })}
    </InspectorBody>
  );
}

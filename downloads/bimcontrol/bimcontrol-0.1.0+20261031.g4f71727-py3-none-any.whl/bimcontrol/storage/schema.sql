-- BIMControl's control database: what is being migrated, how far each
-- attempt got, and what it produced.
--
-- Separate from the estate database, which belongs to EstateScanner and is
-- only ever read (see estate/reader.py). Nothing here duplicates estate
-- content; a unit points at a source object id and the estate is consulted
-- for the rest.
--
-- Designed so a swarm is a configuration change rather than a rewrite:
-- every run is stamped with the worker that owns it, units carry a lease,
-- and `events` is an append-only log with a per-run sequence number -- the
-- same shape that will sync to the cloud control plane.
--
-- Artefacts live on disk under ~/.bimcontrol/runs/<run-id>/, with only
-- their metadata here. A generated Power BI project is a folder tree, and
-- SQLite is the wrong place for it.

CREATE TABLE IF NOT EXISTS schema_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

-- One migration engagement. A consultant's machine may hold more than one.
CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    source_platform TEXT NOT NULL,          -- domo
    source_instance TEXT NOT NULL,          -- the source Domo instance
    target_platform TEXT NOT NULL,          -- powerbi
    estate_db_path TEXT,                    -- the scan this project reads
    settings_json TEXT,                     -- target warehouse, converter urls, ...
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

-- One thing to migrate: today a dashboard, later a whole app or a dataflow
-- on its own. This is the unit a swarm node leases.
CREATE TABLE IF NOT EXISTS migration_units (
    id TEXT PRIMARY KEY,
    project_id TEXT NOT NULL REFERENCES projects(id),
    unit_type TEXT NOT NULL DEFAULT 'dashboard',
    source_object_id TEXT NOT NULL,
    name TEXT,
    status TEXT NOT NULL DEFAULT 'pending',  -- pending|running|succeeded|failed|incomplete|needs_review
    -- Hash of the closure's object ids and the scan that last saw them: a
    -- fresh scan that changes the closure must invalidate completed work
    -- rather than silently reuse it.
    closure_fingerprint TEXT,
    summary_json TEXT,
    latest_run_id TEXT,
    -- Swarm leasing. Unused while solo, but a unit claimed by a dead worker
    -- has to be reclaimable, which needs the expiry to exist from the start.
    lease_owner TEXT,
    lease_expires_at TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE (project_id, unit_type, source_object_id)
);

-- One attempt at a unit. Re-running is routine, so history is kept: this
-- table is the audit trail of what was tried and what came of it.
CREATE TABLE IF NOT EXISTS runs (
    id TEXT PRIMARY KEY,                     -- run_20260921T084500_ab12cd
    project_id TEXT NOT NULL REFERENCES projects(id),
    unit_id TEXT NOT NULL REFERENCES migration_units(id),
    pipeline TEXT NOT NULL,                  -- domo_to_powerbi
    status TEXT NOT NULL,                    -- running|succeeded|failed|cancelled|incomplete
    worker_id TEXT NOT NULL,
    stopped_reason TEXT,                     -- why an incomplete run stopped
    error TEXT,
    error_stage TEXT,
    run_dir TEXT NOT NULL,                   -- absolute, so a moved home is visible
    options_json TEXT,
    started_at TEXT NOT NULL,
    finished_at TEXT,
    heartbeat_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_runs_unit ON runs(unit_id, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_runs_project ON runs(project_id, started_at DESC);

-- One row per stage per run: where resume reads from.
CREATE TABLE IF NOT EXISTS stages (
    run_id TEXT NOT NULL REFERENCES runs(id),
    name TEXT NOT NULL,
    ordinal INTEGER NOT NULL,
    title TEXT,
    status TEXT NOT NULL DEFAULT 'pending',  -- pending|running|succeeded|failed|skipped|not_implemented|cancelled
    -- Inputs hashed at the moment the stage ran. A resume re-runs the stage
    -- when this no longer matches, and skips it when it does.
    fingerprint TEXT,
    attempt INTEGER NOT NULL DEFAULT 0,
    warning_count INTEGER NOT NULL DEFAULT 0,
    result_json TEXT,                        -- the stage's own summary, for the UI
    error TEXT,
    started_at TEXT,
    finished_at TEXT,
    PRIMARY KEY (run_id, name)
);

-- Files a stage produced. `path` is relative to the run directory so a run
-- folder stays portable.
CREATE TABLE IF NOT EXISTS artefacts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT NOT NULL REFERENCES runs(id),
    stage TEXT NOT NULL,
    kind TEXT NOT NULL,                      -- closure|sql|tmdl|pbip|manifest|log
    label TEXT,
    path TEXT NOT NULL,
    media_type TEXT,
    bytes INTEGER,
    sha256 TEXT,
    created_at TEXT NOT NULL,
    UNIQUE (run_id, path)
);

CREATE INDEX IF NOT EXISTS idx_artefacts_run ON artefacts(run_id, stage);

-- Append-only progress log. `seq` is per run so a client can long-poll for
-- "everything after N" -- the same contract the cloud sync will use.
CREATE TABLE IF NOT EXISTS events (
    run_id TEXT NOT NULL REFERENCES runs(id),
    seq INTEGER NOT NULL,
    created_at TEXT NOT NULL,
    stage TEXT,
    level TEXT NOT NULL DEFAULT 'info',      -- debug|info|warn|error
    type TEXT NOT NULL,                      -- run.started|stage.started|stage.progress|...
    message TEXT,
    payload_json TEXT,
    PRIMARY KEY (run_id, seq)
);

-- Work for a human: an unmapped chart type, a formula that would not parse,
-- a dataset with nowhere to read from. A queue, not a log line -- these are
-- worked through and closed, and they gate a unit being called done.
CREATE TABLE IF NOT EXISTS review_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id TEXT NOT NULL REFERENCES runs(id),
    unit_id TEXT NOT NULL REFERENCES migration_units(id),
    stage TEXT,
    kind TEXT NOT NULL,                      -- unmapped_chart|unparsed_formula|unresolved_source|...
    severity TEXT NOT NULL DEFAULT 'warn',   -- warn|error
    source_type TEXT,                        -- card|dataset|dataflow|calculated_field
    source_id TEXT,
    title TEXT NOT NULL,
    detail_json TEXT,
    status TEXT NOT NULL DEFAULT 'open',     -- open|resolved|ignored
    created_at TEXT NOT NULL,
    resolved_at TEXT,
    resolution_note TEXT
);

CREATE INDEX IF NOT EXISTS idx_review_run ON review_items(run_id, status);
CREATE INDEX IF NOT EXISTS idx_review_unit ON review_items(unit_id, status);

"""Files only their owner may read: the Tableau secret files and the Power BI token cache.

On Linux and macOS that is mode 0600, set with ``chmod``. Windows has no such mode (``os.chmod`` only touches the read-only bit), so the file gets an
ACL that names the signed-in user (by SID) and nothing else (``icacls``). Callers set it on the empty temp file *before* the secret is written, so
the ACL travels with ``os.replace`` and no moment exists in which the secret sits under the folder's inherited ACL. Setting it is best effort
only while it does not matter: if ``icacls`` is missing or fails and the empty file is private anyway (the usual private ``~/.estate-scanner``),
the sign-in goes on and one line in the log says so, never the file's contents; if it fails and others can read the empty file, ``write_private``
refuses (``PrivateFileError``) before a secret is written, the same rule as the read (a secret others can read is not used quietly).

``readable_by_others`` is the check a secret read makes before it trusts a file: POSIX looks at the mode; Windows saves the ACL as SDDL
(``icacls /save``), which holds SIDs and rights masks, so it reads the same on a localised Windows and needs no echoed path. The text of
``icacls <file>`` is the fallback when ``/save`` fails. Known and left as they are: an inherit-only entry (``IO``) counts as a grant (an
over-refusal), and ``icacls /save`` is trusted to name the file on its first line without a drive letter and a colon in front of ``D:``.
"""

from __future__ import annotations

import getpass
import logging
import os
import re
import secrets
import stat
import subprocess
import sys
import tempfile
from pathlib import Path

log = logging.getLogger(__name__)

# Patchable: the Windows branches are tested on every platform with canned ``icacls`` output.
_IS_WINDOWS = sys.platform == "win32"

# The principals whose read right makes a file "readable by other users", as ``icacls <file>`` prints them (English names only: the fallback).
BROAD_PRINCIPALS = frozenset({
    "everyone", "builtin\\users", "nt authority\\authenticated users", "builtin\\guests",
    "s-1-1-0", "s-1-5-32-545", "s-1-5-11", "s-1-5-32-546",
})
# The same, as SDDL writes a trustee: Everyone, Users, Authenticated Users, Guests, Interactive, Network, Power Users, Domain Users, Domain Guests,
# Anonymous, the pre-Windows 2000 compatible group; and the SID spellings (the domain's own Users and Guests end in -513 and -514).
BROAD_SDDL_TRUSTEES = frozenset({"WD", "BU", "AU", "BG", "IU", "NU", "PU", "DU", "DG", "AN", "RU"})
_BROAD_SID = re.compile(r"^S-1-(1-0|5-(11|4|2|7)|5-32-(545|546|547|554)|5-21-\d+-\d+-\d+-(513|514))$", re.IGNORECASE)
# The rights letters of an ACE that let a principal read the file's content (``F`` full, ``M`` modify, ``RX``/``R`` read, ``GR``/``GA`` generic
# read/all, ``RD`` read data).
READ_RIGHTS = frozenset({"F", "M", "RX", "R", "GR", "GA", "RD"})
# SDDL access masks: FILE_READ_DATA (0x1), GENERIC_READ and GENERIC_ALL make a file's content readable. A mask is a hex number or runs of two-letter
# rights; every letter is a bit, so the answer is the same bit test (an unknown letter reads as a read right: the check errs towards refusing).
_READ_BITS = 0x1 | 0x80000000 | 0x10000000
_RIGHT_BITS = {
    "GA": 0x10000000, "GR": 0x80000000, "GW": 0x40000000, "GX": 0x20000000, "FA": 0x1F01FF, "FR": 0x120089, "FW": 0x120116, "FX": 0x1200A0,
    "CC": 0x1, "DC": 0x2, "LC": 0x4, "SW": 0x8, "RP": 0x10, "WP": 0x20, "DT": 0x40, "LO": 0x80, "CR": 0x100,
    "SD": 0x10000, "RC": 0x20000, "WD": 0x40000, "WO": 0x80000,
}

_ACE = re.compile(r"^\s*(?P<who>.+?):(?P<rights>(?:\([^()]*\))+)\s*$")
_DACL = re.compile(r"(?m)^D:(?P<flags>[A-Z_]*)")
_warned: set[str] = set()
_me: tuple[str, str | None] | None = None        # (DOMAIN\user, SID) of the signed-in user, once known


def _creation_flags() -> int:
    return getattr(subprocess, "CREATE_NO_WINDOW", 0)       # no console window flashing up in the desktop app


def _run(args: list[str]) -> subprocess.CompletedProcess:
    # ``errors="replace"``: icacls and whoami write the console's code page and Python decodes with the ANSI one, so a name like Jürgen holds bytes
    # (0x81...) that strict decoding rejects; nothing here needs the exact text of a name, and a log line must never cost a sign-in.
    return subprocess.run(args, capture_output=True, text=True, errors="replace", timeout=10, creationflags=_creation_flags(), check=False)


def _icacls(*args: str) -> subprocess.CompletedProcess:
    return _run(["icacls", *args])


def _whoami() -> tuple[str, str | None]:
    """``(DOMAIN\\user, SID)`` of the process's user from ``whoami /user``: the SID does not depend on the language of Windows or on what
    ``getpass.getuser()`` reads (``LOGNAME``/``USER`` first), and names an account (Entra ID) that has no ``DOMAIN\\name`` icacls can resolve."""
    global _me
    if _me is None:
        try:
            done = _run(["whoami", "/user", "/fo", "csv", "/nh"])
            fields = [f.strip().strip('"') for f in done.stdout.strip().splitlines()[0].split('","')] if done.returncode == 0 else []
        except (OSError, subprocess.SubprocessError, IndexError):
            fields = []
        if len(fields) == 2 and fields[1].upper().startswith("S-1-"):
            _me = (fields[0], fields[1])
        else:
            domain = os.environ.get("USERDOMAIN", "").strip()
            user = getpass.getuser()
            _me = (f"{domain}\\{user}" if domain else user), None       # kept: a whoami that fails is not run again for every file
    return _me


def _warn_once(reason: str, checking: bool = False) -> None:
    key = ("check:" if checking else "set:") + reason
    if key not in _warned:
        _warned.add(key)
        if checking:
            log.warning("who can read a sign-in file could not be checked (%s); the file is used as it is", reason)
        elif _IS_WINDOWS:
            log.warning("the owner-only ACL of a sign-in file could not be set (%s); other users of this machine may be able to read it unless "
                        "its folder keeps them out", reason)
        else:
            log.warning("the mode of a sign-in file could not be set to 0600 (%s); other users of this machine may be able to read it", reason)


def private_file(path: str | os.PathLike) -> bool:
    """Make ``path`` private to the signed-in user. Call it on the empty temp file before the secret is written (an ACL travels with
    ``os.replace``). On Windows it replaces the user's own entry and strips the *inherited* ones; an explicit entry already on the file (say
    ``Users:(R)``) stays, so it is for a file this process just created, not a promise about any file. True when both steps are done. A failure is
    not an error here: it is logged once per reason, with the reason and never the path's contents (``write_private`` decides what a failure
    means for the secret)."""
    path = Path(path)
    if not _IS_WINDOWS:
        try:
            os.chmod(path, 0o600)
        except OSError as exc:
            _warn_once(type(exc).__name__)
            return False
        return True
    name, sid = _whoami()
    principal = f"*{sid}" if sid else name
    try:
        # The grant first, then the end of inheritance: a grant that fails leaves the ACL as it was, not an empty one that nobody can read.
        for args in (("/grant:r", f"{principal}:(R,W,D)"), ("/inheritance:r",)):
            done = _icacls(str(path), *args)
            if done.returncode != 0:
                _warn_once(f"icacls exit {done.returncode}")
                return False
    except (OSError, subprocess.SubprocessError) as exc:      # icacls missing, or it hung
        _warn_once(type(exc).__name__)
        return False
    return True


def fix_hint(path: str | os.PathLike, folder: bool = False) -> str:
    """The command that makes ``path`` private, for the error a refusal shows. On Windows the grant comes first (a grant that fails leaves the ACL
    as it was) and names the user by SID when known (``DOMAIN\\name`` does not resolve for an Entra ID account; ``%USERNAME%`` is only cmd.exe's).
    ``folder``: the grant is inherited by what is created in it."""
    if _IS_WINDOWS:
        name, sid = _whoami()
        who = f"*{sid}" if sid else name
        inherit = "(OI)(CI)" if folder else ""
        return f'run these two commands, in this order: icacls "{path}" /grant:r "{who}:{inherit}(R,W,D)"   and then   icacls "{path}" /inheritance:r'
    return f"run: chmod {700 if folder else 600} {path}"


def _mask(rights: str) -> int | None:
    """The access mask of an SDDL rights field: ``0x1200a9``, or runs of two-letter rights (``FA``, ``CCDC``...). None when a letter is unknown."""
    rights = rights.strip()
    if rights.lower().startswith("0x"):
        try:
            return int(rights, 16)
        except ValueError:
            return None
    mask = 0
    for k in range(0, len(rights), 2):
        bit = _RIGHT_BITS.get(rights[k:k + 2].upper())
        if bit is None or len(rights) % 2:
            return None
        mask |= bit
    return mask


def _aces(text: str) -> list[str]:
    """The ``(...)`` groups at the start of ``text``, balanced: a conditional ACE holds parentheses of its own (``(XA;;GR;;;WD;(Member_of{SID(BA)}))``).
    It ends at the first character outside a group (the ``S:`` of a SACL, the end of the line)."""
    groups, depth, start = [], 0, 0
    for k, ch in enumerate(text):
        if ch == "(":
            if depth == 0:
                start = k + 1
            depth += 1
        elif ch == ")" and depth:
            depth -= 1
            if depth == 0:
                groups.append(text[start:k])
        elif depth == 0:
            break
    return groups


def sddl_lets_others_read(saved: str) -> bool | None:
    """True when the DACL in ``icacls /save`` output has an allow entry that reads the content for a broad trustee (``BROAD_SDDL_TRUSTEES``, the
    SIDs of Everyone, Users, Authenticated Users, Guests, Interactive, Network and the domain's Users and Guests). Deny entries are not grants. A null
    DACL (no access control) lets everyone. None when the text holds no DACL."""
    found = _DACL.search(saved)
    if found is None:
        return None
    if "NO_ACCESS_CONTROL" in found["flags"]:
        return True
    for ace in _aces(saved[found.end():]):
        fields = ace.split(";")
        if len(fields) < 6 or fields[0].upper() not in ("A", "OA", "XA"):
            continue
        trustee = fields[5].strip()
        if trustee.upper() not in BROAD_SDDL_TRUSTEES and not _BROAD_SID.match(trustee):
            continue
        mask = _mask(fields[2])
        if mask is None or mask & _READ_BITS:
            return True
    return False


def acl_lets_others_read(icacls_output: str, path: str | os.PathLike | None = None) -> bool:
    """The fallback of ``readable_by_others``, from the text of ``icacls <file>``: True when it shows a read right for ``Everyone``,
    ``BUILTIN\\Users``, ``NT AUTHORITY\\Authenticated Users`` or ``BUILTIN\\Guests`` (English names; ``sddl_lets_others_read`` is the one that is
    not). A deny entry is not a grant. ``path`` is the text ``icacls`` echoes in front of the first entry (removed first: a path holds ``:``;
    matched without regard to case or the kind of slash, but not to the code page the echo was written in: when the decoder had to replace a
    character of the path, it is not found and the entry on the first line is not read; ``sddl_lets_others_read`` has no names to lose)."""
    text = icacls_output
    if path is not None:
        shown = str(path)
        flat = text.replace("/", "\\").lower()
        at = flat.find(shown.replace("/", "\\").lower()) if len(flat) == len(text) else -1      # same length: the offsets are the text's own
        if at >= 0:
            text = text[:at] + text[at + len(shown):]
    for line in text.splitlines():
        found = _ACE.match(line)
        if not found:
            continue
        groups = re.findall(r"\(([^()]*)\)", found["rights"])
        if any(g.upper() == "DENY" for g in groups):
            continue
        rights = {r.strip().upper() for g in groups for r in g.split(",")}
        if found["who"].strip().lower() in BROAD_PRINCIPALS and rights & READ_RIGHTS:
            return True
    return False


def _saved_acl(path: Path) -> str | None:
    """``icacls <file> /save``: the file's ACL as SDDL (UTF-16, the file's name on the first line), or None when it cannot be had."""
    with tempfile.TemporaryDirectory() as folder:
        out = Path(folder) / "acl.txt"
        done = _icacls(str(path), "/save", str(out))
        if done.returncode != 0 or not out.is_file():
            return None
        raw = out.read_bytes()
    try:
        return raw.decode("utf-16")             # with or without a byte order mark (none: the machine's own, little-endian on every Windows)
    except UnicodeDecodeError:
        return None


def readable_by_others(path: str | os.PathLike) -> bool:
    """True when the file can be read by someone other than its owner. POSIX: any group or other permission bit. Windows: a broad trustee in the
    ACL (``sddl_lets_others_read`` over ``icacls /save``, else ``acl_lets_others_read`` over ``icacls``); when ``icacls`` cannot be asked, False
    (the file is used, as when the ACL could not be set) and one line in the log says the check did not run."""
    path = Path(path)
    if not _IS_WINDOWS:
        return bool(stat.S_IMODE(path.stat().st_mode) & 0o077)
    try:
        saved = _saved_acl(path)
        verdict = sddl_lets_others_read(saved) if saved is not None else None
        if verdict is not None:
            return verdict
        shown = _icacls(str(path))
    except (OSError, subprocess.SubprocessError) as exc:      # icacls missing, or it hung
        _warn_once(type(exc).__name__, checking=True)
        return False
    if shown.returncode != 0:
        _warn_once(f"icacls exit {shown.returncode}", checking=True)
        return False
    return acl_lets_others_read(shown.stdout, path)


class PrivateFileError(Exception):
    """A private file could not be written: no temp file could be created, or it could not be made private and others can read it. The text
    carries no secret; callers turn it into their own sign-in error."""


def write_private(path: str | os.PathLike, text: str) -> None:
    """Replace ``path`` whole (a reader never sees half a secret), readable by its owner only from the first byte. The temp file has a name nobody
    can predict, is created exclusively and without following a symlink, and its mode is set explicitly: a stale or planted file at a guessable
    name can neither keep a looser mode nor redirect the write somewhere else. ``private_file`` runs on the *empty* temp file; if it fails and
    others can still read that file, nothing is written and ``PrivateFileError`` says how to fix the folder (the usual private
    ``~/.estate-scanner`` is private anyway, so a failed ``icacls`` there only goes to the log)."""
    path = Path(path)
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
    for _ in range(5):
        tmp = path.with_name(f"{path.name}.{secrets.token_hex(8)}.tmp")
        try:
            fd = os.open(tmp, flags, 0o600)
            break
        except FileExistsError:
            continue
    else:
        raise PrivateFileError(f"Cannot create a private file beside {path}.")
    try:
        with os.fdopen(fd, "w") as fh:
            if os.name != "nt":
                os.fchmod(fh.fileno(), 0o600)
            if not private_file(tmp) and readable_by_others(tmp):
                raise PrivateFileError(
                    f"{path} cannot be made private to your account here and its folder lets other users read it, so nothing was written; "
                    f"keep it in a private folder, or {fix_hint(path.parent, folder=True)}"
                )
            fh.write(text)
        os.replace(tmp, path)               # (the ACL travels with the file)
    except BaseException:
        tmp.unlink(missing_ok=True)
        raise

import React from 'react';

// The review queue for one run: things a stage could not decide and a person
// has to. Grouped by kind, because the same finding repeats (every baseline
// dashboard raised "manual upload needs a feed") and a flat list of forty
// near-identical lines hides the one that is different.
//
// Each kind says what it means and what to do about it. Kinds we have no
// words for still show, under their raw name, rather than disappearing.

const GUIDE = {
  landed_upload_needs_feed: {
    label: 'Uploads and feeds need a real feed',
    meaning: 'A Domo dataset someone uploads by hand (a spreadsheet), or a feed pushed from outside Domo (API, S3, SFTP). A copy was landed in the warehouse, but nothing will refresh it, so the migrated report goes stale when the spreadsheet changes.',
    action: 'Decide where the file will live and how it reaches the warehouse, or accept a one-time copy and mark this done.',
  },
  unique_keeps_arbitrary_row: {
    label: 'Remove Duplicates keeps one of several different rows',
    meaning: 'A Remove Duplicates step meets keys whose rows are not identical (a provider listed under two service lines). Domo keeps the first stored row of a key, and the converted dataflow keeps the first by the position the rows landed with, so the figures agree when the data lands in the same order. A different landing order is a possible cause of a difference, not a confirmed one.',
    action: 'Fix the data (one row per key) or decide which row should win, and say so in the hand-over.',
  },
  reads_run_date: {
    label: 'Dataflow reads the date it runs',
    meaning: 'The dataflow computes something from today\'s date (an age in days, a window ending today). Domo\'s dataset holds the values of its last run; the migrated dataflow reads the date when the model is built, so those figures differ from Domo\'s by the days in between. They agree again when Domo reruns the flow.',
    action: 'Nothing is wrong with the conversion. Compare after Domo\'s next run if exact agreement matters, or accept the day-count difference.',
  },
  staged_dataflow: {
    label: 'Dataflows built in stages',
    meaning: 'A dataflow with too many steps for Redshift to plan as one query. Its middle steps were built as tables in the landing schema, and the report reads the short query on top of them. Those tables are a snapshot from this run.',
    action: 'Schedule a rebuild of the staging tables whenever the source data changes, or accept the snapshot.',
  },
  card_without_dataset: {
    label: 'Cards with no dataset',
    meaning: 'A card the scan found no dataset for (a text or notebook-style card, or one whose dataset is not in the scan). It cannot become a data visual.',
    action: 'Recreate it by hand in Power BI if it matters, or ignore it if it is decoration.',
  },
  unknown_data_source: {
    label: 'No source decided',
    meaning: 'A dataset comes from a connector BIMControl does not know how to read from (not a Redshift table, a dataflow output or an upload). Nothing was landed for it.',
    action: 'Choose where its data will come from, then run again.',
  },
  unresolved_source: {
    label: 'Source not resolved',
    meaning: 'The dataset has no producer in the scan, so there is no query to rebuild it from.',
    action: 'Rescan the estate, or decide the source by hand.',
  },
  unconvertible_dataflow: {
    label: 'Dataflows that did not convert',
    meaning: 'The converter could not turn this Magic ETL dataflow into SQL. Datasets it produces are empty or missing.',
    action: 'Check the converter message in the log, fix the dataflow\'s unsupported step, or rebuild its logic by hand.',
  },
  sql_rejected_by_warehouse: {
    label: 'SQL the warehouse rejected',
    meaning: 'The converted SQL was refused by Redshift when it was run.',
    action: 'Open the SQL artefact and the error in the log. Usually a converter fix; report it with the dataflow id.',
  },
  sql_repaired_by_agent: {
    label: 'SQL the converter\'s agent rewrote',
    meaning: 'The warehouse refused a step of the converted SQL, so the converter\'s AI agent rewrote that step until the warehouse accepted it. The warehouse accepts it; nobody has read it.',
    action: 'Compare the step with the Domo tile (the item details name the tile and the error). The dashboard comparison checks the numbers.',
  },
  dataflow_output_not_materialised: {
    label: 'Dataflow output not built',
    meaning: 'A dataflow ran but one of its outputs was not created in the warehouse.',
    action: 'Run again once the conversion errors are fixed.',
  },
  warehouse_table_unknown: {
    label: 'Warehouse table not found',
    meaning: 'A table the plan expects is not in the warehouse.',
    action: 'Check the landing schema and run the landing stage again.',
  },
  table_without_source: {
    label: 'Tables with no query',
    meaning: 'A model table has no source query, so it will be empty after publishing.',
    action: 'Fix the source (see the related items) and rebuild the model.',
  },
  rls_roles_without_members: {
    label: 'Row-level security roles with no members',
    meaning: 'Domo restricted who sees which rows (PDP). The model has an equivalent role for each distinct policy, but nobody is assigned to it yet, so published as is, only workspace admins see data.',
    action: 'Add the right people to each role in the Power BI service (Security on the semantic model). The Domo user ids behind each role are in the item details.',
  },
  rls_unsupported: {
    label: 'Row-level security not translated',
    meaning: 'A Domo row-level security group uses a rule this tool does not translate yet, so no role was created for it.',
    action: 'Recreate the rule as a role by hand before sharing the report with the people in that group.',
  },
  dashboard_filters_unmapped: {
    label: 'Dashboard filters not carried over',
    meaning: 'Some Domo dashboard filters name a column that no table in the model has, or sit on a table no visual uses, so they have no slicer in the report.',
    action: 'The item details list each filter and why. Add the column to the model or a slicer by hand if the viewers need it.',
  },
  layout_components_unmapped: {
    label: 'Dashboard controls and buttons not carried over',
    meaning: 'The Domo page has variable controls or buttons. Headers became text boxes, but these have no equivalent in the report, so they are missing from it.',
    action: 'The item details name each one and its page. Add a parameter or slicer for a variable control, or a button, by hand if viewers need it.',
  },
  missing_table: {
    label: 'Card reads a missing dataset',
    meaning: 'A card reads a dataset that is not in the closure, so its visual has no table.',
    action: 'Rescan the estate so the dataset is included.',
  },
  missing_object: {
    label: 'Objects not in the scan',
    meaning: 'Something the dashboard depends on was not found in the estate scan.',
    action: 'Rescan the estate, then run again.',
  },
  untranslated_measure: {
    label: 'Calculations that did not translate',
    meaning: 'A Domo calculation (beast mode) has no DAX equivalent yet. The model has a blank placeholder with the original formula in its description.',
    action: 'Write the DAX by hand in the placeholder, or leave it blank and ignore the visuals that use it.',
  },
  measure_not_found: {
    label: 'Calculations not in the scan',
    meaning: 'A card uses a calculation the scan did not capture.',
    action: 'Rescan the estate, or define the measure by hand.',
  },
  unmapped_card: {
    label: 'Chart types with no Power BI equivalent',
    meaning: 'No Power BI visual is mapped for this Domo chart type, so the card was left out of the report.',
    action: 'Rebuild it with the closest Power BI visual, or ignore it.',
  },
  unsupported_tile: {
    label: 'Unsupported tiles',
    meaning: 'A dashboard element that is not a data card (for example a variable control).',
    action: 'Recreate it in Power BI if needed.',
  },
  no_relationship: {
    label: 'Tables with shared columns but no relationship',
    meaning: 'Two tables share column names, so a filter on one may be expected to reach the other. No relationship was created, because a guessed one can change every figure.',
    action: 'Add a relationship in Power BI Desktop if the columns are keys, then check the figures.',
  },
  model_refresh_failed: {
    label: 'Model refresh failed',
    meaning: 'The published model could not load its data.',
    action: 'Read the error in the log (often credentials or a table the warehouse does not have), fix it, and run again.',
  },
  parity_mismatch: {
    label: 'Figures that differ from Domo',
    meaning: 'The Power BI visual and the Domo card returned different numbers.',
    action: 'Open Parity for the differing rows.',
  },
  parity_partial: {
    label: 'Figures only partly compared',
    meaning: 'Domo renders at most 2,000 rows of a table, so only those rows could be compared. The rest of the Power BI table has no Domo figure to check against.',
    action: 'The compared rows are in Parity. Spot-check the rest in the report if it matters.',
  },
  parity_unavailable: {
    label: 'Figures not compared',
    meaning: 'A card could not be compared: Domo would not render it, or the published model could not answer.',
    action: 'Check the sign-ins on Connections and the model refresh, then run the parity stage again.',
  },
};

function guideFor(kind) {
  return GUIDE[kind] || { label: kind.replace(/_/g, ' '), meaning: null, action: null };
}

// Errors first, then the biggest groups.
function groupItems(items) {
  const groups = {};
  items.forEach(function (item) {
    (groups[item.kind] = groups[item.kind] || []).push(item);
  });
  return Object.keys(groups).map(function (kind) {
    const list = groups[kind];
    return { kind: kind, items: list, errors: list.filter(function (i) { return i.severity === 'error'; }).length };
  }).sort(function (a, b) {
    return (b.errors > 0) - (a.errors > 0) || b.items.length - a.items.length;
  });
}

export function ReviewPanel({ run, onChanged }) {
  const [items, setItems] = React.useState(null);
  const [showClosed, setShowClosed] = React.useState(false);
  const [error, setError] = React.useState(null);
  const [open, setOpen] = React.useState({});
  const runId = run && run.id;
  const settled = run && !run.live && run.status !== 'running';

  function load() {
    return fetchReviews({ run_id: runId, status: 'all', limit: 2000 }).then(
      function (body) { setItems(body.items); }, function (e) { setError(e.message); });
  }

  // Stages raise items while the run is going, so reload when the stage list changes.
  const finishedStages = ((run && run.stages) || []).filter(function (s) { return s.finished_at; }).length;
  React.useEffect(function () {
    if (!runId) { setItems(null); return; }
    load();
  }, [runId, finishedStages, settled]);

  function close(item, status) {
    setError(null);
    resolveReview(item.id, status).then(function () {
      return load();
    }).then(function () { if (onChanged) onChanged(); }, function (e) { setError(e.message); });
  }

  if (!items) return <InspectorBody>{error ? <Banner tone="error" title="Could not load">{error}</Banner> : <Spinner />}</InspectorBody>;

  const openItems = items.filter(function (i) { return i.status === 'open'; });
  const shown = showClosed ? items : openItems;
  const groups = groupItems(shown);

  return (
    <InspectorBody>
      <div>
        <SectionLabel>Needs a decision</SectionLabel>
        <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-tertiary)' }}>
          {openItems.length
            ? formatCount(openItems.length) + ' open across ' + formatCount(groupItems(openItems).length) + ' kinds. Work through them, then mark each done or ignore it.'
            : 'Nothing open. Everything the run raised has been closed.'}
        </div>
      </div>
      {error ? <Banner tone="error" title="That did not work">{error}</Banner> : null}
      {items.length !== openItems.length ? (
        <div>
          <Button size="sm" variant="secondary" onClick={function () { setShowClosed(!showClosed); }}>
            {showClosed ? 'Hide closed' : 'Show ' + formatCount(items.length - openItems.length) + ' closed'}
          </Button>
        </div>
      ) : null}
      {groups.length === 0 && items.length === 0
        ? <EmptyState compact headline="Nothing to review" body="This run raised no review items." />
        : groups.map(function (group) {
          const guide = guideFor(group.kind);
          const expanded = open[group.kind] !== undefined ? open[group.kind] : group.items.length <= 3;
          return (
            <div key={group.kind} style={{
              border: '1px solid var(--border-hairline)', borderRadius: 'var(--radius-sm)',
              background: 'var(--surface-card)',
            }}>
              <div onClick={function () { const next = Object.assign({}, open); next[group.kind] = !expanded; setOpen(next); }}
                style={{ cursor: 'pointer', padding: '8px 10px', display: 'flex', alignItems: 'center', gap: 8 }}>
                <Icon name={expanded ? 'chevronDown' : 'chevronRight'} size={13} />
                <span style={{ flex: 1, fontSize: 'var(--text-md)', fontWeight: 'var(--weight-semibold)' }}>{guide.label}</span>
                <Badge tone={group.errors ? 'error' : 'warn'} variant="soft">{formatCount(group.items.length)}</Badge>
              </div>
              {guide.meaning ? (
                <div style={{ padding: '0 10px 8px 31px', fontSize: 'var(--text-sm)', color: 'var(--text-secondary)' }}>
                  {guide.meaning}
                  <div style={{ marginTop: 4, color: 'var(--text-primary)' }}>
                    <strong style={{ fontWeight: 'var(--weight-semibold)' }}>What to do: </strong>{guide.action}
                  </div>
                </div>
              ) : null}
              {expanded ? group.items.map(function (item) {
                const closed = item.status !== 'open';
                return (
                  <div key={item.id} style={{ padding: '8px 10px', borderTop: '1px solid var(--border-hairline)', opacity: closed ? 0.6 : 1 }}>
                    <div style={{ fontSize: 'var(--text-sm)', wordBreak: 'break-word' }}>{item.title}</div>
                    <div className="bit-num" style={{ fontSize: 'var(--text-2xs)', color: 'var(--text-tertiary)', marginTop: 2 }}>
                      {[item.stage, item.source_type && item.source_id ? item.source_type + ' ' + item.source_id : null,
                        closed ? item.status : null].filter(Boolean).join(' · ')}
                    </div>
                    <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
                      {closed
                        ? <Button size="sm" variant="secondary" onClick={function () { close(item, 'open'); }}>Reopen</Button>
                        : <React.Fragment>
                            <Button size="sm" variant="secondary" onClick={function () { close(item, 'resolved'); }}>Mark done</Button>
                            <Button size="sm" variant="secondary" onClick={function () { close(item, 'ignored'); }}>Ignore</Button>
                          </React.Fragment>}
                    </div>
                  </div>
                );
              }) : null}
            </div>
          );
        })}
    </InspectorBody>
  );
}

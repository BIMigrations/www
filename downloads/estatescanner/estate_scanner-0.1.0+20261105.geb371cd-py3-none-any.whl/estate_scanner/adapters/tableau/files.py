"""Opening a Tableau file that came from outside: bytes in, a bounded element tree out.

A downloaded ``.twb``/``.tds`` is XML and a ``.twbx``/``.tdsx`` is a zip of one, written by whoever
published it. Both are treated as hostile. This module is the only place bytes are interpreted; the
summary code (``workbook.py``) only ever sees the tree built here.

**XML.** ``defusedxml`` (optional extra ``tableau``) with every document type declaration refused.
Entities can only be declared inside a DOCTYPE, so refusing it refuses entity expansion (billion
laughs, quadratic blow-up), external entities and external DTDs in one rule; Tableau never writes one
[unconfirmed: from the XSDs, which allow none, and from memory of real files]. If ``defusedxml`` is
not installed this module refuses to read rather than falling back to the standard parser. The tree
is built by our own parser target so that depth and element count are capped *while* parsing: an
attacker's file cannot first grow into memory and then be measured. The attribute count is checked when
expat hands over an element, which is after expat has built that element's attribute list (the handler
cannot see it earlier). So ``max_attributes`` stops the tree keeping an absurd element and stops it being
summarised, but the memory one element's attribute list can take at that moment is bounded by the XML
size cap, not by ``max_attributes``.

**Zip.** Only the one top-level ``.twb`` or ``.tds`` member is opened, in memory. Nothing is extracted
to disk and no path is built from a member name, so a traversal name cannot write anywhere; it is
refused anyway, with the whole archive, because an archive that carries one is not one we want to
guess about. The central directory is bounded before ``zipfile`` parses it (``zipfile`` builds one
object per entry up front). Every other member (``.hyper`` extracts, images, nested archives) is
never decompressed.

Errors are typed (:class:`TableauFileError` and subclasses), carry a fixed ``code`` and a message
that never quotes the file: a workbook holds customer data and connection details, and a message
ends up in an issue row and a log.

Provenance: written from Tableau's published XSD and the M3 plan; never run against a file saved by
Tableau. Every limit below is a judgement, not a measured fact about real workbooks.
"""

from __future__ import annotations

import io
import stat
import struct
import zipfile
from dataclasses import dataclass

KIB = 1024
MIB = 1024 * KIB
GIB = 1024 * MIB

# -- limits -------------------------------------------------------------------------------------------
# One value each, with the reason it is that value. All are arguments of ``Limits`` so a test (or a
# caller who knows better after 3.4(b)) can change one without monkeypatching.

# The whole file as downloaded. The scan downloads with ``includeExtract=False`` (plan, "Download
# safely"), so a real file is small; a ``.twbx`` that carries a local data file can be large, and we
# never read that part. Refuses a file that is plainly not a workbook before anything else happens.
MAX_FILE_BYTES = 1 * GIB

# The XML itself, as a bare file or as the one member of an archive. Workbooks with thousands of
# sheets and calculations are tens of MB [unconfirmed: no real file was available]; 64 MiB is
# several times that, and the tree we build is roughly ten times the XML (see MAX_ELEMENTS).
MAX_XML_BYTES = 64 * MIB

# Entries in the archive. A packaged workbook is the .twb, a few images, shapes and extracts: tens.
# 5,000 leaves room for a workbook with a large custom shape palette.
MAX_ZIP_MEMBERS = 5_000

# What the central directory may occupy. 5,000 entries at about 100 bytes of name and header is
# 0.5 MiB; 8 MiB allows long names but stops a directory that is itself the attack, checked from the
# end-of-directory record *before* ``zipfile`` allocates an object per entry.
MAX_ZIP_DIRECTORY_BYTES = 8 * MIB

# Sum of the sizes the directory *claims* for all members. We open one member and bound that read
# ourselves, so this is not what protects memory; it refuses a directory that claims the absurd (a
# 100 GiB entry list) and anything the .twbx format has no reason to hold. A genuine extract-carrying
# archive is a few GiB at most.
MAX_ZIP_TOTAL_BYTES = 8 * GIB

# How much the .twb member may expand: XML of this kind deflates 10x to 30x, highly repetitive
# generated files perhaps 80x; 200x is far past that and far below a bomb (1000x and up). Only
# applied when the member is over RATIO_FLOOR_BYTES: a tiny member that deflates 300x cannot hurt.
MAX_COMPRESSION_RATIO = 200
RATIO_FLOOR_BYTES = 1 * MIB

# Element nesting. Dashboard zones nest to a few dozen levels, group filters a few more. The
# summary code recurses over the tree, so this also keeps it far from Python's recursion limit.
MAX_XML_DEPTH = 200

# Elements in the document. The tree costs roughly 500 bytes an element, so 2,000,000 is about
# 1 GB in the worst case: well above a very large real workbook, and it stops "<a/>" repeated to
# the byte limit (16 million elements) from being built.
MAX_ELEMENTS = 2_000_000

# Attributes on one element. Real elements have a dozen; a million would only be an attack. Checked after
# expat has built the list, so what bounds the transient memory is MAX_XML_BYTES (about 240 MB per million
# attributes at the byte cap), bounded by the XML size cap rather than by this number.
MAX_ATTRIBUTES = 1_000

MAX_NAME_BYTES = 1024  # an archive member name; real ones are short


@dataclass(frozen=True)
class Limits:
    max_file_bytes: int = MAX_FILE_BYTES
    max_xml_bytes: int = MAX_XML_BYTES
    max_zip_members: int = MAX_ZIP_MEMBERS
    max_zip_directory_bytes: int = MAX_ZIP_DIRECTORY_BYTES
    max_zip_total_bytes: int = MAX_ZIP_TOTAL_BYTES
    max_compression_ratio: int = MAX_COMPRESSION_RATIO
    ratio_floor_bytes: int = RATIO_FLOOR_BYTES
    max_xml_depth: int = MAX_XML_DEPTH
    max_elements: int = MAX_ELEMENTS
    max_attributes: int = MAX_ATTRIBUTES


DEFAULT_LIMITS = Limits()


# -- errors -------------------------------------------------------------------------------------------


class TableauFileError(Exception):
    """The bytes are not a Tableau file this reader will read. The message says what kind of refusal and
    never quotes the file. ``code`` is stable, for an issue row."""

    code = "tableau_file_error"


class UnsafeArchiveError(TableauFileError):
    code = "unsafe_archive"


class LimitExceededError(TableauFileError):
    code = "limit_exceeded"


class MalformedFileError(TableauFileError):
    code = "malformed_file"


class NotATableauFileError(TableauFileError):
    code = "not_a_tableau_file"


class ReaderUnavailableError(TableauFileError):
    code = "reader_unavailable"


# -- the element tree ---------------------------------------------------------------------------------


class Node:
    """An element: local name (namespaces dropped), attributes, children, and its own character data.

    ``text`` is the element's direct character data, character for character: a leaf keeps all of it,
    including leading, trailing and whitespace-only text; mixed content keeps the text around its
    children joined in order. The one thing dropped is the indentation between the child elements of
    an element that has no text of its own, because that is formatting and not content. Attribute values
    are different: XML itself turns a literal tab, CR or LF in one into a space before this code sees it.
    """

    __slots__ = ("tag", "attrib", "children", "_parts", "_has_text", "_mark")

    def __init__(self, tag: str, attrib: dict[str, str]):
        self.tag = tag
        self.attrib = attrib
        self.children: list[Node] = []
        self._parts: list[str] | None = None
        self._has_text = False
        self._mark = 0  # where the uncompacted tail of _parts begins

    @property
    def text(self) -> str:
        return "".join(self._parts) if self._parts else ""

    def get(self, name: str) -> str | None:
        return self.attrib.get(name)

    def find(self, tag: str) -> Node | None:
        for child in self.children:
            if child.tag == tag:
                return child
        return None

    def findall(self, tag: str) -> list[Node]:
        return [c for c in self.children if c.tag == tag]

    def iter(self, tag: str | None = None) -> list[Node]:
        """Descendants in document order, without recursion."""
        found: list[Node] = []
        stack = list(reversed(self.children))
        while stack:
            node = stack.pop()
            if tag is None or node.tag == tag:
                found.append(node)
            stack.extend(reversed(node.children))
        return found

    def __repr__(self) -> str:  # no attribute values: a node may be a connection
        return f"<Node {self.tag} attrs={len(self.attrib)} children={len(self.children)}>"


def _local(name: str) -> str:
    return name.rpartition("}")[2] if name.startswith("{") else name


_COMPACT_AT = 4096


class _TreeBuilder:
    """Parser target. The caps are enforced here, as elements arrive."""

    def __init__(self, limits: Limits):
        self.limits = limits
        self.root: Node | None = None
        self._stack: list[Node] = []
        self._count = 0

    def start(self, tag: str, attrib: dict[str, str]) -> None:
        if len(self._stack) >= self.limits.max_xml_depth:
            raise LimitExceededError(f"elements nest deeper than {self.limits.max_xml_depth}")
        self._count += 1
        if self._count > self.limits.max_elements:
            raise LimitExceededError(f"more than {self.limits.max_elements} elements")
        if len(attrib) > self.limits.max_attributes:
            raise LimitExceededError(f"an element has more than {self.limits.max_attributes} attributes")
        node = Node(_local(tag), {_local(k): v for k, v in attrib.items()})
        if self._stack:
            self._stack[-1].children.append(node)
        elif self.root is None:
            self.root = node
        else:  # expat already refuses this; kept so the tree can never hold two roots
            raise MalformedFileError("more than one root element")
        self._stack.append(node)

    def end(self, tag: str) -> None:
        node = self._stack.pop()
        if node.children and not node._has_text:
            node._parts = None  # whitespace that only indented the children

    def data(self, data: str) -> None:
        if not self._stack:
            return
        node = self._stack[-1]
        blank = not data.strip()
        if blank and node.children and not node._has_text:
            return  # indentation between the children of an element with no text of its own
        if not blank:
            node._has_text = True
        parts = node._parts
        if parts is None:
            node._parts = [data]
            return
        parts.append(data)
        if len(parts) - node._mark >= _COMPACT_AT:
            # expat reports a line at a time; a leaf of millions of blank lines would otherwise cost a list slot each.
            # Only the tail is joined, so every character is copied once here and once at the end: linear.
            parts[node._mark :] = ["".join(parts[node._mark :])]
            node._mark = len(parts)

    def close(self) -> Node | None:
        return self.root


def parse_xml(data: bytes, limits: Limits = DEFAULT_LIMITS) -> Node:
    """The bounded element tree of ``data``. Raises a :class:`TableauFileError` for anything else."""
    if len(data) > limits.max_xml_bytes:
        raise LimitExceededError(f"the XML is {len(data)} bytes, over the {limits.max_xml_bytes} limit")
    if not data.strip():
        raise MalformedFileError("the file is empty")
    try:
        from defusedxml import ElementTree as defused
        from defusedxml.common import DefusedXmlException
    except ImportError:
        raise ReaderUnavailableError(
            "reading Tableau files needs the 'tableau' extra (defusedxml); the standard XML parser is not used on untrusted files"
        ) from None
    builder = _TreeBuilder(limits)
    try:
        parser = defused.XMLParser(target=builder, forbid_dtd=True, forbid_entities=True, forbid_external=True)
        parser.feed(data)
        parser.close()
    except TableauFileError:
        raise
    except DefusedXmlException:
        raise MalformedFileError(
            "the file declares a document type or entities, which a Tableau file does not and this reader refuses"
        ) from None
    except RecursionError:  # the C parser is iterative; a Python fallback would not be. Belt and braces.
        raise LimitExceededError("the XML nests too deeply") from None
    except Exception as exc:  # ParseError and whatever a damaged stream makes expat raise
        position = getattr(exc, "position", None)
        where = f" at line {position[0]}, column {position[1]}" if isinstance(position, tuple) and len(position) == 2 else ""
        raise MalformedFileError(f"not well-formed XML{where}") from None
    if builder.root is None:
        raise MalformedFileError("the file has no root element")
    return builder.root


# -- zip ----------------------------------------------------------------------------------------------

ZIP_MAGICS = (b"PK\x03\x04", b"PK\x05\x06")  # a local header; an empty archive
_EOCD = b"PK\x05\x06"
_EOCD64 = b"PK\x06\x06"
_EOCD64_LOCATOR = b"PK\x06\x07"
_CENTRAL = b"PK\x01\x02"
_EOCD_MAX_COMMENT = 0xFFFF
_PACKABLE = (".twb", ".tds")


def looks_like_zip(data: bytes) -> bool:
    return data[:4] in ZIP_MAGICS


def _check_directory(data: bytes, limits: Limits) -> None:
    """Bound the central directory *before* zipfile builds an object for each entry of it.

    zipfile locates the directory from the end-of-central-directory record, but whenever a ZIP64 locator
    and record precede that record it takes the entry count and directory size from the ZIP64 record instead,
    markers or not; and it then reads the directory by its *size*, ignoring the count. So the numbers that
    matter are the ZIP64 ones when present, and the only trustworthy count is the one from walking the
    directory. This reads the same record, the same way, and walks the entries (46 bytes of header and the
    lengths of the variable fields) with an early exit at the cap, constructing nothing."""
    at = data.rfind(_EOCD, max(0, len(data) - (22 + _EOCD_MAX_COMMENT)))
    if at < 0 or len(data) < at + 22:
        raise UnsafeArchiveError("not a readable zip archive")
    entries, size = struct.unpack_from("<HI", data, at + 10)
    zip64_record = False
    if at >= 20 and data[at - 20 : at - 16] == _EOCD64_LOCATOR:
        _sig, disk, _offset, disks = struct.unpack_from("<4sLQL", data, at - 20)
        if disk != 0 or disks > 1:
            raise UnsafeArchiveError("not a readable zip archive")
        if at >= 20 + 56 and data[at - 76 : at - 72] == _EOCD64:
            fields = struct.unpack_from("<4sQ2H2L4Q", data, at - 76)
            entries, size = fields[7], fields[8]
            zip64_record = True
    if entries >= 0xFFFF or size >= 0xFFFFFFFF:  # an unset ZIP64 marker, or more than any workbook holds
        raise UnsafeArchiveError(f"the archive has more than {limits.max_zip_members} members")
    if entries > limits.max_zip_members:
        raise UnsafeArchiveError(f"the archive has {entries} members, over the {limits.max_zip_members} limit")
    if size > limits.max_zip_directory_bytes:
        raise UnsafeArchiveError(f"the archive's directory is {size} bytes, over the {limits.max_zip_directory_bytes} limit")
    start = at - size - (20 + 56 if zip64_record else 0)
    if start < 0:
        raise UnsafeArchiveError("not a readable zip archive")
    pos, end, count = start, start + size, 0
    while pos < end:
        if data[pos : pos + 4] != _CENTRAL or pos + 46 > end:
            raise UnsafeArchiveError("not a readable zip archive")
        name_len, extra_len, comment_len = struct.unpack_from("<HHH", data, pos + 28)
        pos += 46 + name_len + extra_len + comment_len
        count += 1
        if count > limits.max_zip_members:
            raise UnsafeArchiveError(f"the archive has more than {limits.max_zip_members} members")
    if pos != end:
        raise UnsafeArchiveError("not a readable zip archive")


def _unsafe_name(name: str) -> bool:
    path = name.replace("\\", "/")
    return (
        "\x00" in name
        or any(ord(c) < 32 for c in name)
        or len(name.encode("utf-8", "replace")) > MAX_NAME_BYTES
        or path.startswith("/")
        or (len(path) > 1 and path[1] == ":")
        or ".." in path.split("/")
    )


def _is_symlink(info: zipfile.ZipInfo) -> bool:
    return stat.S_ISLNK(info.external_attr >> 16)


def read_member(data: bytes, limits: Limits = DEFAULT_LIMITS) -> tuple[bytes, str]:
    """The XML bytes of the one ``.twb`` or ``.tds`` member of an archive, and its extension.

    The archive is refused whole for: a directory over the member or size caps, an unsafe member name
    (absolute, drive-lettered, ``..``, NUL or control characters) or a symlink anywhere in it, a repeated
    name, no top-level ``.twb``/``.tds`` or more than one, an encrypted member, a member over the size
    cap or the ratio cap, a member that is itself a zip. No other member is opened.
    """
    if len(data) > limits.max_file_bytes:
        raise LimitExceededError(f"the file is {len(data)} bytes, over the {limits.max_file_bytes} limit")
    _check_directory(data, limits)
    try:
        archive = zipfile.ZipFile(io.BytesIO(data))
    except Exception:
        raise UnsafeArchiveError("not a readable zip archive") from None
    with archive:
        infos = archive.infolist()
        if len(infos) > limits.max_zip_members:
            raise UnsafeArchiveError(f"the archive has {len(infos)} members, over the {limits.max_zip_members} limit")
        total = 0
        seen: set[str] = set()
        for info in infos:
            # orig_filename is what the directory said; zipfile cuts filename at the first NUL, so 'a.twb<NUL>png' reads as 'a.twb'
            if _unsafe_name(info.filename) or _unsafe_name(info.orig_filename):
                raise UnsafeArchiveError("a member name is absolute, climbs out with '..' or holds control characters")
            if _is_symlink(info):
                raise UnsafeArchiveError("the archive holds a symbolic link")
            if info.filename in seen:
                raise UnsafeArchiveError("the archive repeats a member name")
            seen.add(info.filename)
            total += info.file_size
        if total > limits.max_zip_total_bytes:
            raise UnsafeArchiveError(f"the archive claims {total} bytes uncompressed, over the {limits.max_zip_total_bytes} limit")
        candidates = [
            i for i in infos if "/" not in i.filename and not i.is_dir() and i.filename.lower().endswith(_PACKABLE)
        ]
        if not candidates:
            raise UnsafeArchiveError("the archive has no top-level .twb or .tds member")
        if len(candidates) > 1:
            raise UnsafeArchiveError(f"the archive has {len(candidates)} top-level .twb/.tds members; which is the file?")
        info = candidates[0]
        if info.flag_bits & 0x1:
            raise UnsafeArchiveError("the workbook member is encrypted")
        if info.file_size > limits.max_xml_bytes:
            raise LimitExceededError(f"the member is {info.file_size} bytes uncompressed, over the {limits.max_xml_bytes} limit")
        if info.file_size > limits.ratio_floor_bytes and info.file_size > limits.max_compression_ratio * max(info.compress_size, 1):
            raise UnsafeArchiveError(
                f"the member expands {info.file_size // max(info.compress_size, 1)}x, over the {limits.max_compression_ratio}x limit"
            )
        try:
            with archive.open(info) as member:
                # The header's size is the archive's claim. The read is bounded by our own limit whatever it says.
                body = member.read(limits.max_xml_bytes + 1)
        except Exception:
            raise UnsafeArchiveError("the workbook member cannot be read (corrupt, or a compression method this reader does not support)") from None
    if len(body) > limits.max_xml_bytes:
        raise LimitExceededError(f"the member expands past the {limits.max_xml_bytes} byte limit")
    if looks_like_zip(body):
        raise UnsafeArchiveError("the workbook member is itself a zip archive")
    return body, info.filename.rsplit(".", 1)[-1].lower()


def unpack(data: bytes, limits: Limits = DEFAULT_LIMITS) -> tuple[bytes, str | None]:
    """``(xml bytes, the member's extension)``, or ``(data, None)`` for a bare ``.twb``/``.tds``."""
    if looks_like_zip(data):
        return read_member(data, limits)
    return data, None  # a bare file's size is checked by parse_xml, which every path goes through


# What parsing costs on top of the XML bytes: the tree built from them. Issue #97 says "about ten times the size" (8 workers on workbooks
# with 20 MB of XML peaked at 1,390 MB, which is 8.5 times the XML per worker but includes the baseline and the rows the scan keeps). The
# marginal cost of one more file in flight, measured on the fake (3.10 follow-up in docs/tableau-scan-decisions.md), was 2.4 to 3.1 times
# the XML. Ten is therefore a deliberate over-estimate, about three times what was measured: the memory it protects is the customer's
# laptop, and a fake site's synthetic XML is not a real workbook.
PARSE_EXPANSION = 10


def parse_cost(data: bytes, limits: Limits = DEFAULT_LIMITS) -> int:
    """Estimated peak bytes to read ``data`` with ``read_summary``: the bytes themselves (they are held while the reader works) plus
    ``PARSE_EXPANSION`` times the XML. For an archive the XML is the size its directory gives the one top-level ``.twb``/``.tds`` member,
    not the archive's size: a workbook of 2 MB on the wire can hold 40 MB of XML. The directory is the archive's own claim; the read itself
    is bounded by ``max_xml_bytes`` whatever it says. A file the reader will refuse (not a readable archive, no member, too big) is
    refused before anything is parsed, so it costs only the bytes already held. Never raises."""
    held = len(data)
    if not looks_like_zip(data):
        if held > limits.max_xml_bytes:
            return held  # read_summary refuses it at once, before anything is parsed
        return held + PARSE_EXPANSION * held
    try:
        _check_directory(data, limits)  # bounds the directory before zipfile builds an object for each entry, as read_member does
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            candidates = [i for i in archive.infolist() if "/" not in i.filename and not i.is_dir() and i.filename.lower().endswith(_PACKABLE)]
    except Exception:  # noqa: BLE001 -- the reader will say why; here it only means nothing will be parsed
        return held
    if len(candidates) != 1 or candidates[0].file_size > limits.max_xml_bytes:
        return held  # refused by read_member before the member is read
    return held + PARSE_EXPANSION * candidates[0].file_size

"""Running DAX against a published semantic model.

The target half of a parity check. `executeQueries` is the only way to
ask a published model what it actually returns -- reading the TMDL tells
you what was *asked for*, which is the thing in doubt.

Note the audience: this is the Power BI REST surface, not the Fabric one,
so it needs a token for `analysis.windows.net/powerbi/api` rather than
`api.fabric.microsoft.com`. A token for one is rejected by the other,
which is why auth.py keeps the two scopes apart.
"""

from __future__ import annotations

import json
import os
import re
import time
from typing import Any

import requests

from . import daterange
from .auth import POWERBI_SCOPE, token
from .model import iso_date_parts, with_trimmed_text

API = "https://api.powerbi.com/v1.0/myorg"
# executeQueries is capped at one query per call on most capacities, and
# a DAX query is cheap, so there is no batching to do here.
REQUEST_TIMEOUT = 180
# Power BI cancels a query when it evicts the model to balance the CPU of the node (three lanes querying at once)
# and says itself "Please try again later" (bimcontrol#489): ask again after a pause, at most this many more times.
EVICTION_MARKER = "was evicted to balance the CPU load"
EVICTION_PAUSE_SECONDS = 20
EVICTION_RETRIES = 2
# A wide import model (1.7M rows x 263 columns, AR Aging-SW) takes over 20 minutes to load.
REFRESH_TIMEOUT_SECONDS = int(os.environ.get("BIMCONTROL_REFRESH_TIMEOUT", "3600"))


class PowerBIQueryError(Exception):
    pass


def _token_expired(response: requests.Response) -> bool:
    """Power BI answers 403 `TokenExpired` (and a plain 401) once the access token it was given has run out."""
    return response.status_code == 401 or (response.status_code == 403 and "TokenExpired" in response.text)


class _RenewingSession(requests.Session):
    """A session that gets a new access token and repeats a request once when the service says the token expired.

    A parity stage on a big dashboard outlives one token (Revenue Trend-SW, 2026-10-21: 33 cards answered 403 TokenExpired
    and were reported as the model not answering)."""

    def __init__(self, renew):
        super().__init__()
        self._renew = renew

    def request(self, method, url, **kwargs):
        response = super().request(method, url, **kwargs)
        if self._renew is not None and _token_expired(response):
            try:
                fresh = self._renew()
            except Exception as exc:  # noqa: BLE001 -- a dead refresh token (FabricAuthError, azure): what callers already handle
                raise PowerBIQueryError(
                    f"Power BI answered {response.status_code} (token expired) and a new token could not be fetched: {exc}") from exc
            self.headers.update({"Authorization": f"Bearer {fresh}"})
            kwargs["headers"] = {**(kwargs.get("headers") or {}), "Authorization": self.headers["Authorization"]}
            response = super().request(method, url, **kwargs)
        return response


class PowerBIQueryClient:
    def __init__(self, access_token: str | None = None, allow_prompt: bool = True):
        self._token = access_token or token(POWERBI_SCOPE, allow_prompt=allow_prompt)
        # A token handed in is the caller's to renew; one this client fetched it can fetch again.
        self.http = _RenewingSession(None if access_token else self._new_token(allow_prompt))
        self.http.headers.update({"Authorization": f"Bearer {self._token}"})
        self._sleep = time.sleep

    @staticmethod
    def _new_token(allow_prompt: bool):
        return lambda: token(POWERBI_SCOPE, allow_prompt=allow_prompt)

    def execute_dax(self, workspace_id: str, dataset_id: str, dax: str) -> list[dict[str, Any]]:
        """Run one DAX query and return its rows as dicts.

        Column keys come back fully qualified, e.g. `'Table'[Column]` for a
        grouping column and `[value]` for a named expression, which is why
        the caller matches on suffix rather than on an exact name.
        """
        url = f"{API}/groups/{workspace_id}/datasets/{dataset_id}/executeQueries"
        body = {"queries": [{"query": dax}], "serializerSettings": {"includeNulls": True}}
        response = self._post_query(url, body)
        for _ in range(EVICTION_RETRIES):
            if EVICTION_MARKER not in response.text:
                break
            self._sleep(EVICTION_PAUSE_SECONDS)
            response = self._post_query(url, body)
        if response.status_code >= 400:
            raise PowerBIQueryError(
                f"executeQueries -> {response.status_code}: {response.text[:400]}"
            )
        payload = response.json()
        results = payload.get("results") or []
        if not results:
            return []
        error = results[0].get("error")
        if error:
            raise PowerBIQueryError(f"DAX failed: {error}")
        tables = results[0].get("tables") or []
        if not tables:
            return []
        return tables[0].get("rows") or []

    def _post_query(self, url: str, body: dict[str, Any]) -> requests.Response:
        try:
            return self.http.post(url, json=body, timeout=REQUEST_TIMEOUT)
        except requests.exceptions.ReadTimeout:
            # A DirectQuery table of 20M rows can take longer than the timeout to answer the first time (14 of 15
            # `model_query_failed` cards in pass 7); the warehouse has the result by now, so the second ask is quick.
            return self.http.post(url, json=body, timeout=REQUEST_TIMEOUT)

    def _dataset_url(self, workspace_id: str, dataset_id: str) -> str:
        return f"{API}/groups/{workspace_id}/datasets/{dataset_id}"

    def set_basic_credentials(
        self, workspace_id: str, dataset_id: str, user: str, password: str,
    ) -> int:
        """Give every data source of an import-mode model a username and password.

        A model published from a PBIP has its sources but no credentials, so
        its first refresh fails before reading a row. The password goes to
        Power BI and is not kept here. Returns how many sources were set.
        """
        listing = self.http.get(
            f"{self._dataset_url(workspace_id, dataset_id)}/datasources", timeout=REQUEST_TIMEOUT)
        if listing.status_code >= 400:
            raise PowerBIQueryError(f"datasources -> {listing.status_code}: {listing.text[:400]}")
        details = {
            "credentialType": "Basic",
            "credentials": json.dumps({"credentialData": [
                {"name": "username", "value": user}, {"name": "password", "value": password},
            ]}),
            "encryptedConnection": "Encrypted",
            "encryptionAlgorithm": "None",
            "privacyLevel": "Organizational",
        }
        count = 0
        for source in listing.json().get("value") or []:
            if not source.get("gatewayId") or not source.get("datasourceId"):
                continue
            response = self.http.patch(
                f"{API}/gateways/{source['gatewayId']}/datasources/{source['datasourceId']}",
                json={"credentialDetails": details}, timeout=REQUEST_TIMEOUT,
            )
            if response.status_code >= 400:
                raise PowerBIQueryError(
                    f"set credentials -> {response.status_code}: {response.text[:400]}")
            count += 1
        return count

    def refresh(
        self, workspace_id: str, dataset_id: str, timeout_seconds: int = REFRESH_TIMEOUT_SECONDS,
        max_parallelism: int | None = None,
    ) -> dict[str, Any]:
        """Refresh the model and wait. Returns `{"status", "error"}`; status is
        `Completed`, `Failed` or `Timeout`.

        `max_parallelism` asks for an enhanced refresh, which can limit how many partitions load
        at once (a partitioned table that loads all of them together is as big as the whole).
        """
        url = f"{self._dataset_url(workspace_id, dataset_id)}/refreshes"
        body: dict[str, Any] = {"notifyOption": "NoNotification"}
        if max_parallelism:
            # partialBatch commits each batch of partitions as it finishes: a transactional refresh
            # of 24 partitions held everything until the end, slowed down from 37 s to 350 s a
            # partition and was dropped after 58 minutes (Revenue Trend-SW, bimcontrol#144).
            body.update({"type": "full", "commitMode": "partialBatch", "maxParallelism": max_parallelism})
        response = self.http.post(url, json=body, timeout=REQUEST_TIMEOUT)
        if response.status_code >= 400:
            raise PowerBIQueryError(f"refresh -> {response.status_code}: {response.text[:400]}")
        # An enhanced refresh is polled by its own id: the newest entry in the history can still
        # be the previous refresh for a few seconds.
        # (Not `x-ms-request-id`: that is the id of the POST itself.)
        request_id = _refresh_id(response) if max_parallelism else None
        poll = f"{url}/{request_id}" if request_id else f"{url}?$top=1"
        deadline = time.monotonic() + timeout_seconds
        while time.monotonic() < deadline:
            time.sleep(5)
            latest = self.http.get(poll, timeout=REQUEST_TIMEOUT)
            if latest.status_code >= 400:
                rows = []
            elif request_id:
                rows = [latest.json()]
            else:
                rows = latest.json().get("value") or []
            if rows and rows[0].get("status") not in (None, "Unknown", "NotStarted", "InProgress"):
                row = rows[0]
                error = None
                if row.get("serviceExceptionJson"):
                    try:
                        error = json.loads(row["serviceExceptionJson"]).get("errorDescription")
                    except ValueError:
                        error = row["serviceExceptionJson"]
                if not error and row.get("status") == "Failed":
                    error = "; ".join(str(m.get("message")) for m in row.get("messages") or [])[:600] or None
                return {"status": row["status"], "error": error}
        return {"status": "Timeout", "error": f"no result after {timeout_seconds}s"}


def _refresh_id(response: requests.Response) -> str | None:
    """The id of the refresh a POST started: the last segment of its Location, else RequestId."""
    location = response.headers.get("Location") or ""
    if "/refreshes/" in location:
        return location.rstrip("/").rsplit("/", 1)[-1]
    return response.headers.get("RequestId")


def quote_name(name: str) -> str:
    """A DAX table reference. Single quotes inside a name are doubled."""
    return "'" + name.replace("'", "''") + "'"


def _bracketed(name: str) -> str:
    """A DAX column or measure name in brackets; a closing bracket inside it is doubled."""
    return "[" + name.replace("]", "]]") + "]"


def column_ref(table: str, column: str) -> str:
    return f"{quote_name(table)}{_bracketed(column)}"


_COMPARISON_SYMBOLS = {0: "=", 1: ">", 2: ">=", 3: "<", 4: "<="}
_NUMERIC_TYPES = ("numeric", "long", "double", "decimal")


def _dax_literal(value: str, data_type: str | None) -> str:
    parts = iso_date_parts(value, data_type)
    if parts:
        # A text literal against a date column is a DAX type error ("Date with values of type Text").
        year, month, day, hour, minute, second = parts
        date = f"DATE({year}, {month}, {day})"
        return f"({date} + TIME({hour}, {minute}, {second}))" if (hour or minute or second) else date
    if (data_type or "").lower() in _NUMERIC_TYPES:
        try:
            number = float(value)
        except ValueError:
            number = None
        if number is not None:
            return str(int(number)) if number.is_integer() else repr(number)
    return '"' + value.replace('"', '""') + '"'


def filter_dax(filters: list[dict[str, Any]], default_table: str) -> list[str]:
    """Filter arguments for SUMMARIZECOLUMNS that repeat a visual's saved filters.

    The published visual carries these as PBIR filters; a query that skips them
    compares Domo's filtered figure with an unfiltered Power BI one.
    """
    args = []
    for item in filters:
        if item.get("field_kind") == "measure":
            continue                        # acts after the aggregation: see measure_filters
        if item.get("kind") == "tuples":
            # A table limited to the combinations of several columns (parity of a table Domo drew only part of).
            columns = ", ".join(column_ref(item.get("table") or default_table, c) for c in item["columns"])
            def literal(value, data_type):
                # A whole number is written as it is: _dax_literal goes through a float, which loses 16-digit ids.
                return value if data_type == "numeric" and re.fullmatch(r"-?\d+", value) else _dax_literal(value, data_type)

            cells = [", ".join(literal(v, t) for v, t in zip(row, item["data_types"])) for row in item["rows"]]
            members = ", ".join(cells if len(item["columns"]) == 1 else [f"({cell})" for cell in cells])
            args.append(f"TREATAS({{{members}}}, {columns})")
            continue
        column = column_ref(item.get("table") or default_table, item["column"])
        if item.get("kind") == "date_range" and item.get("date_range"):
            args.append(daterange.dax_filter(item["date_range"], column))
            continue
        predicate = _predicate(item, column)
        if predicate:
            args.append(f"FILTER(ALL({column}), {predicate})")
    return args


def _predicate(item: dict[str, Any], operand: str) -> str | None:
    """The test a saved `in` or comparison filter makes of `operand` (a column or a measure's value), or None."""
    values = item.get("values") or []
    data_type = item.get("data_type")
    if not values:
        return None
    if item.get("kind") == "in":
        members = ", ".join(_dax_literal(v, data_type) for v in with_trimmed_text(values, data_type, item.get("blank_held")))
        predicate = f"{operand} IN {{{members}}}"
    else:
        symbol = _COMPARISON_SYMBOLS.get(item.get("comparison"))
        if symbol is None:
            return None
        predicate = f"{operand} {symbol} {_dax_literal(values[0], data_type)}"
    return f"NOT({predicate})" if item.get("negated") else predicate


class FilterNotExpressed(ValueError):
    """A visual's filter on a measure that the comparison query cannot repeat (no value, or a comparison it has no symbol for)."""


def measure_filters(filters: list[dict[str, Any]]) -> tuple[list[str], str | None]:
    """A visual's filters on a model measure, which act on the aggregate (a PBIR `Measure` filter), as
    (extra SUMMARIZECOLUMNS arguments, test for `FILTER` over the result).

    `filter_dax` cannot write them (`FILTER(ALL('T'[m]), ...)` names a column the model does not have: a 400).
    Each measure is evaluated inside the SUMMARIZECOLUMNS, so the visual's other filters apply to it, as a
    named column `mf0`, `mf1`...; `FILTER` then keeps the groups that pass (#478)."""
    columns, tests = [], []
    for item in filters:
        if item.get("field_kind") != "measure":
            continue
        name = f"mf{len(columns)}"
        test = _predicate(item, f"[{name}]") if item.get("kind") in ("in", "compare") else None
        if test is None:
            # Left out, the query would compare Domo's filtered figures with unfiltered ones: say so instead.
            raise FilterNotExpressed(f"the filter on the measure {item['column']!r} cannot be written as a query")
        columns.append(f'"{name}", {_bracketed(item["column"])}')
        tests.append(test)
    return columns, (" && ".join(tests) if tests else None)


def summarize_filtered(grouping: list[str], filters: list[dict[str, Any]], default_table: str, values: list[str]) -> str:
    """`SUMMARIZECOLUMNS` of the grouping columns, the column filters and `values` (named arguments), with the
    filters on measures applied to the groups afterwards."""
    extra, test = measure_filters(filters)
    inner = (
        "SUMMARIZECOLUMNS(\n"
        + "".join(f"    {g},\n" for g in grouping)
        + "".join(f"    {f},\n" for f in filter_dax(filters, default_table))
        + ",\n".join(f"    {v}" for v in values + extra)
        + ("\n" if values or extra else "")
        + ")"
    )
    if not (values or extra):
        inner = inner.replace(",\n)", "\n)")          # no named argument: the last one ended in ",\n"
    return f"FILTER({inner}, {test})" if test else inner


def category_value_dax(
    table: str, category: str, value_expression: str, series: str | None = None,
    limit: int | None = None, filters: list[dict[str, Any]] | None = None,
) -> str:
    """A grouped aggregate, shaped like a bar chart's query.

    `SUMMARIZECOLUMNS` is the right primitive: it groups and evaluates in
    one pass with the model's own filter context, which is what the visual
    does. Building the same thing with `ADDCOLUMNS(VALUES(...))` would
    evaluate the measure outside that context and quietly disagree.
    """
    # A series chart groups by two columns, and comparing only the first
    # means comparing one number against the sum of several -- which looks
    # like a migration bug and is not one.
    grouping = [column_ref(table, category)]
    if series and column_ref(table, series).lower() != grouping[0].lower():
        # The same column as category and as series (DNFB Aging Buckets by Visits): SUMMARIZECOLUMNS refuses it twice.
        grouping.append(column_ref(table, series))
    inner = summarize_filtered(grouping, filters or [], table, [f'"value", {value_expression}'])
    if limit:
        return f"EVALUATE\nTOPN({limit}, {inner})"
    return f"EVALUATE\n{inner}"


def table_dax(
    columns: list[tuple[str, str]], values: list[str], default_table: str,
    filters: list[dict[str, Any]] | None = None,
) -> str:
    """The rows a table visual shows: `columns` as (table, name) grouping,
    `values` as measure expressions named v0, v1...

    Same primitive as `category_value_dax`, for the same reason. With no
    values it returns the distinct combinations of the columns, which is
    what a Power BI table of plain columns displays.
    """
    inner = summarize_filtered([column_ref(t, c) for t, c in columns], filters or [], default_table,
                               [f'"v{i}", {expr}' for i, expr in enumerate(values)])
    return f"EVALUATE\n{inner}"


def scalar_dax(value_expression: str) -> str:
    return f'EVALUATE\nROW("value", {value_expression})'


def measure_expression(table: str, name: str, kind: str, aggregation: str | None,
                       summarize_by: str | None = None) -> str:
    """The DAX for one projection, matching how the visual aggregates it.

    A bare column in a value bucket is summarised by the column's own `summarizeBy` in Power BI (a
    number column sums, as Domo does); text columns count."""
    if kind == "measure":
        return _bracketed(name)
    if kind == "aggregation":
        function = {
            "SUM": "SUM", "AVG": "AVERAGE", "AVERAGE": "AVERAGE",
            "MIN": "MIN", "MAX": "MAX",
            # Domo's COUNT counts non-nulls, which is COUNTA in DAX.
            "COUNT": "COUNTA", "COUNTNONNULL": "COUNTA",
            "DISTINCTCOUNT": "DISTINCTCOUNT", "COUNT DISTINCT": "DISTINCTCOUNT",
        }.get((aggregation or "SUM").upper(), "SUM")
        return f"{function}({column_ref(table, name)})"
    function = {"sum": "SUM", "average": "AVERAGE", "min": "MIN", "max": "MAX"}.get((summarize_by or "").lower(), "COUNTA")
    return f"{function}({column_ref(table, name)})"


def row_value(row: dict[str, Any], suffix: str, table: str | None = None) -> Any:
    """Pull a column out of an executeQueries row by its unqualified name.

    Two tables can each have a column of that name (`A[Month]`, `B[Month]`): with `table` the exact
    `Table[Column]` key is taken first."""
    if table is not None and f"{table}[{suffix}]" in row:
        return row[f"{table}[{suffix}]"]
    for key, value in row.items():
        if key == suffix or key.endswith(f"[{suffix}]"):
            return value
    return None

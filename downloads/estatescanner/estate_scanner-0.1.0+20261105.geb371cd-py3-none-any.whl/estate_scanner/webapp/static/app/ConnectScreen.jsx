import React from 'react';

export function ConnectScreen({ onConnected, onOpenBimdash }) {
  const [platforms, setPlatforms] = React.useState(null);
  const [sessionsByKey, setSessionsByKey] = React.useState({});
  const [instanceByKey, setInstanceByKey] = React.useState({});
  const [formByKey, setFormByKey] = React.useState({}); // { tableau: { server, site, token_name, secret } }
  const [connecting, setConnecting] = React.useState(null); // { key, jobId, status }
  const [error, setError] = React.useState(null);

  const reload = React.useCallback(function () {
    fetchPlatforms().then(function (list) {
      setPlatforms(list);
      list.filter(function (p) { return p.status === 'available'; }).forEach(function (p) {
        fetchPlatformSessions(p.key).then(function (sessions) {
          setSessionsByKey(function (prev) { return Object.assign({}, prev, { [p.key]: sessions }); });
        });
      });
    });
  }, []);

  React.useEffect(function () { reload(); }, [reload]);

  React.useEffect(function () {
    if (!connecting || connecting.status !== 'running') return undefined;
    const timer = setInterval(function () {
      fetchConnectStatus(connecting.key, connecting.jobId).then(function (job) {
        if (job.status === 'completed') {
          setConnecting(null);
          setError(null);
          reload();
          if (onConnected) onConnected(connecting.key, job.result && job.result.instance);
        } else if (job.status === 'failed') {
          setConnecting(null);
          setError(job.error || 'Connection failed');
        }
      });
    }, 2000);
    return function () { clearInterval(timer); };
  }, [connecting, reload, onConnected]);

  function setField(key, name, value) {
    setFormByKey(function (prev) { return Object.assign({}, prev, { [key]: Object.assign({}, prev[key], { [name]: value }) }); });
  }

  function missingField(p) {
    const values = formByKey[p.key] || {};
    return (p.connect_fields || []).find(function (f) { return f.required && !(values[f.name] || '').trim(); });
  }

  function connect(p) {
    let what;
    if (p.connect_fields && p.connect_fields.length) {
      if (missingField(p)) return;
      const values = formByKey[p.key] || {};
      what = {};
      p.connect_fields.forEach(function (f) {
        // The secret is sent exactly as typed (a secret may start or end with a space only by mistake, and the
        // server trims it); the other boxes are trimmed.
        what[f.name] = f.secret ? (values[f.name] || '') : (values[f.name] || '').trim();
      });
    } else {
      what = (instanceByKey[p.key] || '').trim();
      if (!what) return;
    }
    setError(null);
    connectPlatform(p.key, what).then(function (res) {
      // The server has the secret now, so the page does not keep it (a failed sign-in means typing it again).
      if (p.connect_fields && p.connect_fields.length) {
        p.connect_fields.filter(function (f) { return f.secret; }).forEach(function (f) { setField(p.key, f.name, ''); });
      }
      setConnecting({ key: p.key, jobId: res.job_id, status: 'running' });
    }).catch(function (e) { setError(String(e.message || e)); });
  }

  if (!platforms) return <Spinner />;

  return (
    <div style={{ padding: 24, display: 'flex', flexDirection: 'column', gap: 16, maxWidth: 720 }}>
      <div>
        <div style={{ fontSize: 'var(--text-3xl)', fontWeight: 'var(--weight-semibold)', letterSpacing: 'var(--tracking-heading)' }}>
          Connect a <span style={{ fontFamily: 'var(--font-editorial)', fontStyle: 'italic', fontWeight: 400, color: 'var(--provenance-target)' }}>BI platform</span>
        </div>
        <div style={{ fontSize: 'var(--text-md)', color: 'var(--text-secondary)', marginTop: 4 }}>
          Domo and Power BI open that platform's own login in a browser window (SSO and MFA are supported). Tableau signs in
          with a personal access token you create in Tableau, typed below. Nothing is sent anywhere but the platform itself
          and this machine's local database.
        </div>
      </div>

      {error && <Banner tone="error" title="Connection failed">{error}</Banner>}

      {onOpenBimdash && (
        <Banner tone="info" title="Have a code from BimDash?" actions={<Button size="sm" variant="secondary" onClick={onOpenBimdash}>Pair with BimDash</Button>}>
          This page connects Estate Scanner to a BI platform. The four-character code BimDash shows in its Scan your estate step is entered on the BimDash page.
        </Banner>
      )}

      {platforms.map(function (p) {
        const sessions = sessionsByKey[p.key] || [];
        const isConnecting = connecting && connecting.key === p.key;
        return (
          <Card key={p.key} title={p.display_name} actions={
            p.status === 'coming_soon' ? <Tag>Coming soon</Tag> : <StatusDot status={sessions.length ? 'ok' : 'idle'} label={sessions.length ? 'Connected' : 'Not connected'} />
          }>
            {p.status === 'coming_soon' ? (
              <div style={{ color: 'var(--text-tertiary)', fontSize: 'var(--text-sm)' }}>Support for {p.display_name} is planned but not built yet.</div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {sessions.length > 0 && (
                  <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                    {sessions.map(function (s) { return <Tag key={s.instance} tone="source">{s.instance}</Tag>; })}
                  </div>
                )}
                {p.notice && <Banner tone="warn" title={'Not yet tried on a real ' + p.display_name + ' site'}>{p.notice}</Banner>}
                {p.connect_fields && p.connect_fields.length > 0 ? (
                  <form
                    style={{ display: 'flex', flexDirection: 'column', gap: 10 }}
                    onSubmit={function (e) { e.preventDefault(); connect(p); }}
                  >
                    {p.connect_fields.map(function (f) {
                      return (
                        <Field key={f.name} label={f.label} hint={f.help} required={f.required} htmlFor={p.key + '-' + f.name}>
                          <Input
                            id={p.key + '-' + f.name}
                            name={f.name}
                            type={f.secret ? 'password' : 'text'}
                            autoComplete={f.secret ? 'off' : 'on'}
                            spellCheck={false}
                            placeholder={f.placeholder}
                            value={(formByKey[p.key] || {})[f.name] || ''}
                            onChange={function (e) { setField(p.key, f.name, e.target.value); }}
                            disabled={!!isConnecting}
                          />
                        </Field>
                      );
                    })}
                    <div>
                      <Button type="submit" disabled={!!isConnecting || !!missingField(p)} loading={!!isConnecting}>
                        {isConnecting ? 'Signing in…' : 'Sign in and save'}
                      </Button>
                    </div>
                  </form>
                ) : (
                  <div style={{ display: 'flex', gap: 8 }}>
                    <Input
                      placeholder={p.instance_hint || 'Instance name'}
                      value={instanceByKey[p.key] || ''}
                      onChange={function (e) { setInstanceByKey(Object.assign({}, instanceByKey, { [p.key]: e.target.value })); }}
                      disabled={!!isConnecting}
                    />
                    <Button onClick={function () { connect(p); }} disabled={!!isConnecting} loading={!!isConnecting}>
                      {isConnecting ? 'Waiting for sign-in…' : 'Connect'}
                    </Button>
                  </div>
                )}
                {isConnecting && !(p.connect_fields && p.connect_fields.length) && (
                  <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-tertiary)' }}>
                    Complete sign-in in the browser window that just opened.
                  </div>
                )}
              </div>
            )}
          </Card>
        );
      })}
    </div>
  );
}

"""FastAPI app factory: mounts the API routers, then the frontend static
files as a fallback. Runs entirely on 127.0.0.1 (see desktop.py) -- no
route here ever calls out to anything but the target BI platform itself
and the local SQLite file.
"""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from estate_scanner import adapters  # noqa: F401 -- import registers every platform
from estate_scanner.storage import db

from .routes import estate, export, graph, platforms, scans

STATIC_DIR = Path(__file__).parent / "static"


def create_app(db_path: str | Path | None = None) -> FastAPI:
    app = FastAPI(title="Estate Scanner")
    app.state.db_path = db_path or db.DEFAULT_DB_PATH

    # Ensure the schema exists before any request arrives.
    conn = db.connect(app.state.db_path)
    conn.close()

    app.include_router(platforms.router, prefix="/api/platforms", tags=["platforms"])
    app.include_router(scans.router, prefix="/api/scans", tags=["scans"])
    app.include_router(estate.router, prefix="/api/estate", tags=["estate"])
    app.include_router(export.router, prefix="/api/export", tags=["export"])
    app.include_router(graph.router, prefix="/api/graph", tags=["graph"])

    if STATIC_DIR.exists():
        app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="static")

    # This app only ever runs against a local webview or a developer's own
    # browser tab, never behind a CDN -- there's no upside to caching and a
    # real downside: the ds-preview.js loader fetches every .jsx source on
    # each page load, and a stale cached copy makes an edited screen look
    # like it never changed.
    @app.middleware("http")
    async def no_cache(request, call_next):
        response = await call_next(request)
        response.headers["Cache-Control"] = "no-store"
        return response

    return app

"""Domo chart types and column roles, mapped to Power BI visuals.

These are product decisions, so they live in named tables a reviewer can
read and a test can enumerate -- not buried in conditionals. Getting one
wrong produces a report that renders but says something different from
the original, which is the worst kind of migration bug.

Two vocabularies have to line up. Domo describes a card with a
`chartType` and a set of columns carrying a `mapping` (ITEM, VALUE,
SERIES, ROW) and a `columnType` (SELECT, FILTER, GROUP_BY, ORDER_BY,
DATE_GRAIN). Power BI describes a visual with a `visualType` and
projections bucketed into named roles, and the role names differ per
visual -- a bar chart's category bucket is `Category`, a matrix's is
`Rows`.
"""

from __future__ import annotations

import datetime
import re
from dataclasses import dataclass, field

from bimcontrol.targets.powerbi import calendar


@dataclass(frozen=True)
class VisualSpec:
    """One Power BI visual type, and where Domo's column roles go in it."""

    visual_type: str
    # Domo mapping -> Power BI role name for this visual.
    roles: dict[str, str]
    notes: str = ""


# Two naming traps here, both of which produce a report that loads and
# then shows "Can't display this visual".
#
# First, Domo "vert" means vertical bars, which Power BI calls a *column*
# chart; Domo "horiz" is Power BI's *bar* chart.
#
# Second, Power BI's built-in names are not what you would guess: the
# STACKED variants are the base names (`columnChart`, `barChart`), because
# stacked was the original default, and only the clustered ones carry a
# prefix. Asking for `stackedColumnChart` gets CustomVisualNotFound --
# Power BI looks for a custom visual by that name and finds none.
CATEGORY_ROLES = {"ITEM": "Category", "SERIES": "Series", "VALUE": "Y"}
TABLE_ROLES = {"ITEM": "Values", "VALUE": "Values", "SERIES": "Values", "ROW": "Values"}
# A pivot table's column dimension is mapped COLUMN (Domo's pivot vocabulary: ROW / COLUMN / VALUE).
MATRIX_ROLES = {"ROW": "Rows", "ITEM": "Rows", "SERIES": "Columns", "COLUMN": "Columns", "VALUE": "Values"}

CHART_MAP: dict[str, VisualSpec] = {
    # bars and columns
    "badge_vert_stackedbar": VisualSpec("columnChart", CATEGORY_ROLES),
    "badge_vert_multibar": VisualSpec("clusteredColumnChart", CATEGORY_ROLES),
    "badge_vert_bar": VisualSpec("clusteredColumnChart", CATEGORY_ROLES),
    "badge_horiz_stackedbar": VisualSpec("barChart", CATEGORY_ROLES),
    "badge_horiz_multibar": VisualSpec("clusteredBarChart", CATEGORY_ROLES),
    "badge_horiz_bar": VisualSpec("clusteredBarChart", CATEGORY_ROLES),
    "badge_vert_stackedbar100": VisualSpec("hundredPercentStackedColumnChart", CATEGORY_ROLES),
    "badge_horiz_stackedbar100": VisualSpec("hundredPercentStackedBarChart", CATEGORY_ROLES),
    # The names Domo's own cards carry (the estate holds 15 and 97 of them; the two above are not seen there).
    "badge_vert_100pct": VisualSpec("hundredPercentStackedColumnChart", CATEGORY_ROLES),
    "badge_horiz_100pct": VisualSpec("hundredPercentStackedBarChart", CATEGORY_ROLES),
    # lines and areas
    "badge_line": VisualSpec("lineChart", CATEGORY_ROLES),
    "badge_two_trendline": VisualSpec("lineChart", CATEGORY_ROLES,
                                      "Domo's second trendline becomes a second value field"),
    "badge_line_bar": VisualSpec("lineClusteredColumnComboChart", CATEGORY_ROLES,
                                 "Domo puts the line series on its own axis; check which measure landed where"),
    "badge_line_stackedbar": VisualSpec("lineStackedColumnComboChart", CATEGORY_ROLES,
                                        "Domo puts the line series on its own axis; check which measure landed where"),
    "badge_line_clusterbar": VisualSpec("lineClusteredColumnComboChart", CATEGORY_ROLES,
                                        "Domo puts the line series on its own axis; check which measure landed where"),
    "badge_area": VisualSpec("areaChart", CATEGORY_ROLES),
    "badge_stackedarea": VisualSpec("stackedAreaChart", CATEGORY_ROLES),
    # part-to-whole
    "badge_pie": VisualSpec("pieChart", {"ITEM": "Category", "VALUE": "Y"}),
    "badge_donut": VisualSpec("donutChart", {"ITEM": "Category", "VALUE": "Y"}),
    # single figures
    "badge_singlevalue": VisualSpec("card", {"VALUE": "Values"}),
    "badge_gauge": VisualSpec("gauge", {"VALUE": "Y"}),
    # tabular
    "badge_basic_table": VisualSpec("tableEx", TABLE_ROLES),
    "badge_table": VisualSpec("tableEx", TABLE_ROLES),
    "badge_pivot_table": VisualSpec("pivotTable", MATRIX_ROLES),
    "badge_heat_table": VisualSpec("pivotTable", MATRIX_ROLES,
                                   "Domo's heat colouring is not carried over"),
    # interactive controls, which Power BI models as slicers
    "badge_checkbox_selector": VisualSpec("slicer", {"ITEM": "Values", "VALUE": "Values"}),
    "badge_dropdown_selector": VisualSpec("slicer", {"ITEM": "Values", "VALUE": "Values"}),
}

# Card types that hold no query at all, so there is nothing to rebuild.
NON_DATA_CARD_TYPES = {"Text", "document", "domoapp", "notebook"}


def visual_for(chart_type: str | None) -> VisualSpec | None:
    return CHART_MAP.get((chart_type or "").strip())


@dataclass
class MappedColumn:
    name: str
    role: str
    aggregation: str | None = None
    alias: str | None = None
    is_formula: bool = False


_TEXT_TYPES = ("STRING", "TEXT")
_NUMBER_TYPES = ("LONG", "DOUBLE", "DECIMAL")


def filter_data_type(saved: str | None, column_type: str | None) -> str | None:
    """The type a filter's values are written in: the model column's, when it differs from the one Domo saved. Domo's
    filter on 'servicemonthfiscalyear' is `string` ("2024") while the column is a LONG; a text literal against a number
    column is a DAX type error in a query and an empty visual in a report (Worked RVU's by Service Date-SW)."""
    saved_kind = (saved or "").lower()
    number = saved_kind in ("numeric", "long", "double", "decimal")
    if column_type in _NUMBER_TYPES and not number:
        return "numeric"
    if column_type in _TEXT_TYPES and number:
        return "string"
    return saved


# Domo filter operand -> how Power BI expresses it in a visual filter.
# "in" is a categorical list; the rest are comparisons (PBIR
# ComparisonKind: 0 =, 1 >, 2 >=, 3 <, 4 <=). An operand not listed here is
# reported, never guessed.
FILTER_OPERANDS: dict[str, tuple[str, int | None, bool]] = {
    # operand: (kind, comparison kind, negated)
    "IN": ("in", None, False),
    "NOT_IN": ("in", None, True),
    "EQUALS": ("compare", 0, False),
    "NOT_EQUALS": ("compare", 0, True),
    "GREATER_THAN": ("compare", 1, False),
    "GREATER_THAN_EQUALS_TO": ("compare", 2, False),
    "GREAT_THAN_EQUALS_TO": ("compare", 2, False),  # Domo's own spelling
    "LESS_THAN": ("compare", 3, False),
    "LESS_THAN_EQUALS_TO": ("compare", 4, False),
}


@dataclass
class CardFilter:
    column: str
    operand: str
    values: list[str]
    data_type: str | None = None

    @property
    def supported(self) -> bool:
        if self.operand not in FILTER_OPERANDS or not self.values:
            return False
        kind = FILTER_OPERANDS[self.operand][0]
        return kind == "in" or len(self.values) == 1


@dataclass
class MappedCard:
    card_id: str
    title: str
    chart_type: str | None
    visual_type: str | None
    columns: list[MappedColumn] = field(default_factory=list)
    filters: list[str] = field(default_factory=list)
    card_filters: list[CardFilter] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def mapped(self) -> bool:
        return self.visual_type is not None


def map_card(card: dict) -> MappedCard:
    """Turn one card's `dataSubscriptions` into Power BI projections.

    Only `SELECT` columns become projections. GROUP_BY and ORDER_BY are
    Domo restating what the chart already implies, and Power BI derives
    both from the projections themselves, so carrying them over would
    duplicate fields in the visual. DATE_GRAIN and FILTER are recorded
    but not projected -- see the warnings each raises.
    """
    spec = visual_for(card.get("chart_type"))
    mapped = MappedCard(
        card_id=str(card.get("id")),
        title=card.get("name") or "Untitled",
        chart_type=card.get("chart_type"),
        visual_type=spec.visual_type if spec else None,
    )
    if spec is None:
        kind = card.get("card_type")
        if kind in NON_DATA_CARD_TYPES:
            mapped.warnings.append(f"{kind} card: no query to rebuild")
        else:
            mapped.warnings.append(f"No Power BI visual mapped for chart type {card.get('chart_type')!r}")
        return mapped
    if spec.notes:
        mapped.warnings.append(spec.notes)

    seen: set[tuple[str, str]] = set()
    cut_from = {c.field: c.name for c in calendar.calendar_columns(card)}
    subscriptions = card.get("data_subscriptions") or []
    # A card with a `main` component also has a `big_number` one (the summary figure on the card): its columns are
    # not columns of the visual (Outpatient - Volume and Revenue showed a 'Date' column Domo's table does not).
    if any(s.get("name") == "main" for s in subscriptions):
        subscriptions = [s for s in subscriptions if s.get("name") == "main"]
    for subscription in subscriptions:
        selected = [c for c in subscription.get("columns") or []
                    if (c.get("columnType") or "SELECT").upper() == "SELECT" and c.get("name")]
        # A column with no mapping is not placed on the card (Domo keeps it for the summary figure); skip it
        # when the component places others. A column with a mapping this vocabulary lacks is still a value.
        placed = any(c.get("mapping") for c in selected)
        for column in subscription.get("columns") or []:
            name = column.get("name")
            if not name:
                continue
            if (placed and not column.get("mapping")
                    and (column.get("columnType") or "SELECT").upper() == "SELECT"):
                continue
            column_type = (column.get("columnType") or "").upper()

            if column_type == "FILTER":
                mapped.filters.append(name)
                continue
            if column_type == "DATE_GRAIN":
                if cut_from:
                    continue  # applied: the calendar field is cut from this column at its grain
                grain = (column.get("extras") or [None])[0]
                mapped.warnings.append(
                    f"Date grain {grain or 'unspecified'} on {name!r} is not applied; "
                    "Power BI groups by the column as stored"
                )
                continue
            if column_type != "SELECT":
                continue  # GROUP_BY / ORDER_BY are implied by the projections

            if calendar.is_calendar(column):
                if column["name"] not in cut_from:
                    mapped.warnings.append(f"Calendar field {name!r} has no date column to be cut from")
                    continue
                name = cut_from[column["name"]]    # the calculated column build_model made for it

            role = spec.roles.get((column.get("mapping") or "").upper())
            if role is None:
                # A SELECT column with no mapping in this visual's vocabulary,
                # e.g. a pivot measure column on a bar chart.
                role = spec.roles.get("VALUE", "Values")
            key = (name, role)
            if key in seen:
                continue
            seen.add(key)
            mapped.columns.append(MappedColumn(
                name=name,
                role=role,
                aggregation=(column.get("aggregation") or None),
                alias=column.get("alias") or None,
                is_formula=bool(column.get("formula")),
            ))

    _map_filters(card, mapped)

    if not mapped.columns:
        mapped.warnings.append("No projectable columns found on this card")
    return mapped


def _map_filters(card: dict, mapped: MappedCard) -> None:
    """Saved filter values (the card's `subscriptions`) become visual filters.

    Without them the visual shows the unfiltered column, and parity compares
    a filtered Domo figure with an unfiltered Power BI one. A filter whose
    operand or values we do not map is warned about, not dropped silently.
    """
    for raw in card.get("filters") or []:
        column = raw.get("column")
        if not column:
            continue
        item = CardFilter(
            column=column,
            operand=str(raw.get("operand") or "").upper(),
            values=[str(v) for v in (raw.get("values") or [])],
            data_type=raw.get("dataType"),
        )
        if item.operand == "BETWEEN" and len(item.values) == 2:
            # A range is two bounds. Both ends are inside it; the end of a datetime range given as a date is the whole day.
            low, high = item.values
            upper = CardFilter(column=column, operand="LESS_THAN_EQUALS_TO", values=[high], data_type=item.data_type)
            if (item.data_type or "").lower() == "datetime" and re.fullmatch(r"\d{4}-\d{2}-\d{2}", high):
                try:
                    next_day = datetime.date.fromisoformat(high) + datetime.timedelta(days=1)
                except (ValueError, OverflowError):
                    next_day = None            # 2024-02-30, 9999-12-31: keep the inclusive bound as saved
                if next_day is not None:
                    upper = CardFilter(column=column, operand="LESS_THAN", values=[next_day.isoformat()],
                                       data_type=item.data_type)
            mapped.card_filters.extend([
                CardFilter(column=column, operand="GREATER_THAN_EQUALS_TO", values=[low], data_type=item.data_type), upper])
        elif item.supported:
            mapped.card_filters.append(item)
        else:
            mapped.warnings.append(
                f"Card filter on {column!r} ({item.operand or 'no operand'}, "
                f"{len(item.values)} value(s)) is not applied; no Power BI mapping for it"
            )
        if column in mapped.filters:
            mapped.filters.remove(column)
    for name in mapped.filters:
        mapped.warnings.append(
            f"Card filters on {name!r}, but the scan does not hold the filter values"
        )

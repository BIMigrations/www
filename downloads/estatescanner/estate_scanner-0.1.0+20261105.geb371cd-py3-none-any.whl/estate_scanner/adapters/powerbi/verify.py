"""Checks of a Power BI scan against the service itself (read-only).

A scan is only worth what an independent reading of the service says about it. Each check here
asks the service a question by a *different* path from the one the scan used and compares counts
and names with the scan database:

- ``items``    workspace items by type: Fabric ``/items`` against the scan's models, reports, dataflows
- ``models``   tables, columns, measures, calculated columns: ``INFO.VIEW.*`` (``executeQueries``,
               a metadata query that writes nothing) against the scan's schema and calculated fields
- ``reports``  visuals and pages: the PBIR parts of Fabric ``getDefinition`` against the scan's cards
- ``roles``    row-level-security roles: ``definition/roles/*.tmdl`` parts against the scan's policies

An object that does not answer is listed as such, never counted as matching. Nothing here writes to
the database or the tenant; run it through ``scripts/verify_powerbi_scan.py``.

Not compared: expression text. The service hides it from the VIEW functions and refuses
``INFO.MEASURES()``, so expressions can only be read back through ``getDefinition``, the path the scan used.
"""

from __future__ import annotations

import collections
import json
import sqlite3
from collections.abc import Callable, Iterable
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Any

from .http import PowerBiApiError

WORKERS = 4  # getDefinition costs seconds per item; the scan itself reads four at a time
FABRIC_TYPES = {"SemanticModel": "datasets", "Report": "dashboards (reports)", "Dataflow": "dataflows", "Dashboard": "dashboards (classic)"}


@dataclass
class CheckResult:
    name: str
    totals: collections.Counter = field(default_factory=collections.Counter)
    differences: list[str] = field(default_factory=list)  # the scan and the service disagree
    unanswered: list[str] = field(default_factory=list)  # the service did not answer: nothing is proven for these

    @property
    def status(self) -> str:
        return "DIFFERS" if self.differences else "INCOMPLETE" if self.unanswered else "matches"


def _each(items: Iterable[Any], fn: Callable[[Any], Any]) -> list[Any]:
    with ThreadPoolExecutor(WORKERS) as pool:
        return list(pool.map(fn, items))


def _safely(call: Callable[[], Any]) -> Any:
    """The answer, or the error text (a str) when the service refused or failed."""
    try:
        return call()
    except PowerBiApiError as exc:
        return str(exc)


def _folded(key: Any) -> Any:
    return tuple(str(part).casefold() for part in key) if isinstance(key, tuple) else str(key).casefold()


def _compare(result: CheckResult, label: str, name: str, service: set, scan: set) -> None:
    result.totals[f"{label} in the service"] += len(service)
    result.totals[f"{label} in the scan"] += len(scan)
    result.totals[f"{label} in both"] += len(service & scan)
    # Still a difference: which spelling is the model's own is not decided (#45). The line says
    # when the other side holds the same name in other letters, so the cases can be told apart.
    service_only, scan_only = service - scan, scan - service
    folded = {_folded(k) for k in service_only} & {_folded(k) for k in scan_only}
    for key in sorted(scan_only):
        note = ", same name in other letters on the service side" if _folded(key) in folded else ""
        result.differences.append(f"{name}: {label}, scan only {key}{note}")
    for key in sorted(service_only):
        note = ", same name in other letters on the scan side" if _folded(key) in folded else ""
        result.differences.append(f"{name}: {label}, service only {key}{note}")
    if folded:
        result.totals[f"{label} differing by letter case only"] += len(folded)


def _raw(text: str | None) -> dict:
    return json.loads(text) if text else {}


# -- items ---------------------------------------------------------------------------------------


def scanned_items(conn: sqlite3.Connection) -> dict[str, dict[str, dict[str, str]]]:
    """Per workspace id: the scan's objects by Fabric item type, as {item id: name}."""
    out: dict[str, dict[str, dict[str, str]]] = collections.defaultdict(lambda: collections.defaultdict(dict))
    for id_, name, raw in conn.execute("SELECT id, name, raw_json FROM datasets WHERE platform = 'powerbi'"):
        out[_raw(raw).get("workspaceId")]["SemanticModel"][id_] = name
    for id_, name, raw in conn.execute("SELECT id, name, raw_json FROM dashboards WHERE platform = 'powerbi'"):
        out[_raw(raw).get("workspaceId")]["Report" if _raw(raw).get("dashboardType") == "report" else "Dashboard"][id_] = name
    for id_, name, raw in conn.execute("SELECT id, name, raw_json FROM dataflows WHERE platform = 'powerbi'"):
        out[_raw(raw).get("workspaceId")]["Dataflow"][id_] = name
    return out


def check_items(conn: sqlite3.Connection, http) -> CheckResult:
    """Compares the ids, not the counts: an item republished after the scan (new id) is one in the scan only
    and one in the service only, not "one of each, matches"."""
    result = CheckResult("items per workspace")
    scanned = scanned_items(conn)
    for ws in http.list_workspaces():
        listed = _safely(lambda ws=ws: http.list_items(ws["id"]))
        label = f"{ws['displayName']} ({ws['id']})"
        if isinstance(listed, str):
            result.unanswered.append(f"{label}: {listed}")
            continue
        for item_type, kind in FABRIC_TYPES.items():
            service = {i["id"]: i.get("displayName") for i in listed if i["type"] == item_type}
            have = scanned.get(ws["id"], {}).get(item_type, {})
            result.totals[f"{kind} in the service"] += len(service)
            result.totals[f"{kind} in the scan"] += len(have)
            result.totals[f"{kind} in both"] += len(service.keys() & have.keys())
            for id_ in sorted(have.keys() - service.keys()):
                result.differences.append(f"{label}: {kind}, scan only {id_} ({have[id_]})")
            for id_ in sorted(service.keys() - have.keys()):
                result.differences.append(f"{label}: {kind}, service only {id_} ({service[id_]})")
    return result


# -- models: tables, columns, measures -----------------------------------------------------------


def info_view(http, workspace_id: str, dataset_id: str, function: str) -> list[dict]:
    """``EVALUATE INFO.VIEW.<function>()`` as a list of rows keyed by bare column name."""
    body = {"queries": [{"query": f"EVALUATE INFO.VIEW.{function}()"}], "serializerSettings": {"includeNulls": True}}
    answer = http.pbi_post(f"/groups/{workspace_id}/datasets/{dataset_id}/executeQueries", json=body) or {}
    tables = ((answer.get("results") or [{}])[0].get("tables")) or [{}]
    return [{key.split("[")[-1].rstrip("]"): value for key, value in row.items()} for row in tables[0].get("rows") or []]


def check_models(conn: sqlite3.Connection, http) -> CheckResult:
    result = CheckResult("tables, columns, measures per model")
    measures: dict[str, set] = collections.defaultdict(set)
    calculated: dict[str, set] = collections.defaultdict(set)
    for field_id, name, definition in conn.execute("SELECT id, name, definition_json FROM calculated_fields WHERE platform = 'powerbi'"):
        d = _raw(definition)
        (measures if d.get("kind") == "measure" else calculated)[field_id.split(":", 1)[0]].add((d.get("table"), name))
    models = [(i, n, _raw(raw).get("workspaceId"), cols) for i, n, raw, cols in conn.execute(
        "SELECT id, name, raw_json, schema_columns_json FROM datasets WHERE platform = 'powerbi' ORDER BY name")]

    def ask(model):
        _, _, ws, _ = model
        return {fn: _safely(lambda fn=fn: info_view(http, ws, model[0], fn)) for fn in ("TABLES", "COLUMNS", "MEASURES")}

    for model, got in zip(models, _each(models, ask)):
        dataset_id, name, _, cols = model
        errors = [v for v in got.values() if isinstance(v, str)]
        if errors:
            result.unanswered.append(f"{name}: {errors[0]}")
            continue
        result.totals["models compared"] += 1
        scan_cols = json.loads(cols or "[]")
        # RowNumber-* is the engine's own hidden key column; the scan does not list it.
        service_cols = [r for r in got["COLUMNS"] if r.get("Type") != "RowNumber"]
        _compare(result, "tables", name, {r["Name"] for r in got["TABLES"]}, {c["table"] for c in scan_cols})
        _compare(result, "columns", name, {(r["Table"], r["Name"]) for r in service_cols}, {(c["table"], c["name"]) for c in scan_cols})
        _compare(result, "measures", name, {(r["Table"], r["Name"]) for r in got["MEASURES"]}, measures.get(dataset_id, set()))
        _compare(result, "calculated columns", name,
                 {(r["Table"], r["Name"]) for r in service_cols if r.get("Type") == "Calculated"}, calculated.get(dataset_id, set()))
    return result


# -- reports and roles: the parts of getDefinition ----------------------------------------------


def definition_paths(http, workspace_id: str, item_id: str) -> list[str]:
    parts = ((http.item_definition(workspace_id, item_id) or {}).get("definition") or {}).get("parts") or []
    return [p["path"] for p in parts]


def check_reports(conn: sqlite3.Connection, http) -> CheckResult:
    result = CheckResult("pages and visuals per report")
    cards = collections.Counter(card_id.split(":")[0] for (card_id,) in conn.execute("SELECT id FROM cards WHERE platform = 'powerbi'"))
    reports = [(i, n, _raw(raw).get("workspaceId")) for i, n, raw in conn.execute(
        "SELECT id, name, raw_json FROM dashboards WHERE platform = 'powerbi' ORDER BY name")
        if _raw(raw).get("dashboardType") == "report"]
    for (report_id, name, ws), paths in zip(reports, _each(reports, lambda r: _safely(lambda: definition_paths(http, r[2], r[0])))):
        if isinstance(paths, str):
            result.unanswered.append(f"{name}: {paths}")
            continue
        pages = sum(1 for p in paths if p.startswith("definition/pages/") and p.endswith("/page.json"))
        visuals = sum(1 for p in paths if "/visuals/" in p and p.endswith("/visual.json"))
        if pages == 0 and "report.json" in paths:
            result.totals["legacy-format reports (not compared)"] += 1  # PBIR-Legacy keeps visuals inside report.json
            continue
        result.totals["reports compared"] += 1
        result.totals["pages in the service"] += pages
        result.totals["visuals in the service"] += visuals
        result.totals["cards in the scan"] += cards[report_id]
        if visuals != cards[report_id]:
            result.differences.append(f"{name} ({report_id[:8]}): service {visuals} visuals, scan {cards[report_id]} cards")
    return result


def check_roles(conn: sqlite3.Connection, http) -> CheckResult:
    result = CheckResult("row-level-security roles per model")
    models = [(i, n, _raw(raw).get("workspaceId"), len(json.loads(policies or "[]"))) for i, n, raw, policies in conn.execute(
        "SELECT id, name, raw_json, pdp_json FROM datasets WHERE platform = 'powerbi' ORDER BY name")]
    for (model_id, name, ws, in_scan), paths in zip(models, _each(models, lambda m: _safely(lambda: definition_paths(http, m[2], m[0])))):
        if isinstance(paths, str):
            result.unanswered.append(f"{name}: {paths}")
            continue
        roles = sum(1 for p in paths if p.startswith("definition/roles/") and p.endswith(".tmdl"))
        result.totals["models compared"] += 1
        result.totals["roles in the service"] += roles
        result.totals["policies in the scan"] += in_scan
        if roles != in_scan:
            result.differences.append(f"{name} ({model_id[:8]}): service {roles} roles, scan {in_scan} policies")
    return result


CHECKS: dict[str, Callable[[sqlite3.Connection, Any], CheckResult]] = {
    "items": check_items,
    "models": check_models,
    "reports": check_reports,
    "roles": check_roles,
}

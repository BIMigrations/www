"""BIMControl -- the worker node that migrates a BI estate from one platform
to another.

Takes an EstateScanner scan as input (read-only), resolves each migration
unit's dependency closure, delegates heavy transformation to external
converters, and writes the target platform's artefacts. Runs locally on a
machine inside the customer's network, either solo or as one node of a
swarm.
"""

__version__ = "0.1.0"

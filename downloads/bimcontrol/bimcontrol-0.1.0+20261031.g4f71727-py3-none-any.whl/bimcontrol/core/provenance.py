"""Which code produced each stage of a run, and which stage a later change can affect (#274).

A pass over a customer after a fix used to start every stale dashboard from the beginning, although a DAX or parity fix
cannot change what the converter produced (and conversion is the slow, serial stage). Each stage now leaves a
`stage.json` (the bimcontrol commit that ran it, the converter build and the estate scan it read); a later pass asks `restart_stage`: the earliest stage that a file changed
since then feeds. A run without that record is dated by its start (the commit that was current then, which can only be
older than the code that really ran, so it re-runs more, never less). Anything not recognised restarts from the start.
"""

from __future__ import annotations

import functools
import json
import sqlite3
import subprocess
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import requests

STAGE_FILE = "stage.json"
FIRST_STAGE = "resolve_closure"

# Source paths (relative to src/bimcontrol/) -> the first stage whose output they can change. Longest prefix wins.
_FEEDS = {
    "pipelines/data_plan.py": "plan_data",
    "warehouses/": "plan_data",
    # data_plan imports convert_etl's dependency order
    "pipelines/convert_etl.py": "plan_data",
    "pipelines/repair_sql.py": "convert_dataflows",
    "pipelines/stage_sql.py": "convert_dataflows",
    "pipelines/unique_ties.py": "convert_dataflows",
    "pipelines/estate_sql.py": "convert_dataflows",
    "converters/": "convert_dataflows",
    "pipelines/build_powerbi.py": "build_model",
    "targets/powerbi/model.py": "build_model",
    "targets/powerbi/dax.py": "build_model",
    "targets/powerbi/directquery.py": "build_model",
    "targets/powerbi/description.py": "build_model",
    "targets/powerbi/calendar.py": "build_model",
    "targets/powerbi/rls.py": "build_model",
    "targets/powerbi/prune.py": "build_model",
    "targets/powerbi/daterange.py": "build_model",
    "targets/powerbi/chart_map.py": "build_report",
    "targets/powerbi/dashboard_filters.py": "build_report",
    "targets/powerbi/writer.py": "build_model",      # build_model uses its M expressions and narrowing helpers
    "targets/powerbi/fabric.py": "publish_powerbi",
    "targets/powerbi/auth.py": "publish_powerbi",
    "targets/powerbi/query.py": "build_model",       # column_ref / quote_name are used from build_model to the parity check
    "pipelines/verify_parity.py": "verify_parity",
    "pipelines/drift.py": "resolve_closure",         # dataflow_drift runs in resolve_closure
    "core/parity_causes.py": "verify_parity",
    "pipelines/migration_report.py": "report",
}
# What no stage of a run reads: the console, the CLI, the batch driver, the export.
# Bookkeeping too: the run engine and its database change how stages are scheduled and recorded, not what they write
# (a change there that does alter a stage's output has to say so with `--from`), and the validation cache only
# remembers answers the warehouse gave.
_NO_STAGE = ("webapp/", "export/", "cli.py", "desktop.py", "core/customer.py", "__main__.py", "core/engine.py",
             "core/runner.py", "core/provenance.py", "storage/db.py", "warehouses/validation_cache.py")


def stage_feeds(path: str) -> str | None:
    """The first stage that a change to `path` (relative to src/bimcontrol/) can affect; None when no stage reads it.
    Unknown paths count as the first stage."""
    if path.startswith(_NO_STAGE):
        return None
    best = max((p for p in _FEEDS if path.startswith(p)), key=len, default=None)
    return _FEEDS[best] if best else FIRST_STAGE


@functools.lru_cache(maxsize=1)
def _checkout() -> Path | None:
    """The git work tree this code runs from (None for an installed copy)."""
    here = Path(__file__).resolve().parent
    try:
        top = subprocess.run(["git", "-C", str(here), "rev-parse", "--show-toplevel"], capture_output=True, text=True,
                             timeout=20, check=True).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return None
    return Path(top) if top and (Path(top) / "src" / "bimcontrol").is_dir() else None


def _git(*args: str) -> str | None:
    root = _checkout()
    if root is None:
        return None
    try:
        done = subprocess.run(["git", "-C", str(root), *args], capture_output=True, text=True, timeout=60)
    except (OSError, subprocess.SubprocessError):
        return None
    return done.stdout.strip() if done.returncode == 0 else None


@functools.lru_cache(maxsize=1)
def code_sha() -> str | None:
    """The commit of the code that is running, or None when it is not a git checkout. A dirty tree is marked."""
    sha = _git("rev-parse", "HEAD")
    if sha and _git("status", "--porcelain", "--", "src"):
        sha += "+"
    return sha


def converter_build(base_url: str | None) -> str | None:
    """The git commit the converter at `base_url` was built from (its `GET /api/version`); None when it does not say
    (an older build has no such endpoint, a stand-in has no URL, nothing answers within 3 s: a busy converter is one)."""
    if not base_url:
        return None
    try:
        response = requests.get(f"{base_url.rstrip('/')}/api/version", timeout=3)
        if response.status_code == 200:
            return (response.json() or {}).get("commit") or None
    except (requests.RequestException, ValueError, AttributeError):
        pass
    return None


CONVERTER_STAGE = "convert_dataflows"


def converter_url(project: dict[str, Any]) -> str | None:
    """The Domo ETL converter a project is configured to use."""
    return ((project.get("settings") or {}).get("converters") or {}).get("domo_etl") or None


def estate_scan(estate_db: str | Path | None) -> dict[str, Any] | None:
    """Which scan an estate database holds: `{id, finished_at}` of its latest completed scan. Two databases can both
    hold scan 1, so the pair is the identity."""
    if not estate_db:
        return None
    from ..estate.reader import EstateNotFoundError, EstateReader                 # the reader opens the file read-only
    try:
        with EstateReader(estate_db) as reader:
            scan = reader.latest_completed_scan()
    except (OSError, sqlite3.Error, ValueError, EstateNotFoundError):
        return None
    return {"id": scan["id"], "finished_at": scan["finished_at"]} if scan else None


def record_stage(stage_dir: Path, stage: str, *, converter_build: str | None = None, estate_scan: dict[str, Any] | None = None) -> None:
    """Leave `stage.json` in a stage's folder: which code ran it, when it finished, and what else it read: the converter
    build (the conversion stage) and the estate scan (the first stage), both sampled by the caller around the stage."""
    try:
        stage_dir.mkdir(parents=True, exist_ok=True)
        (stage_dir / STAGE_FILE).write_text(json.dumps({
            "stage": stage, "bimcontrol_sha": code_sha(),
            "converter_build": converter_build, "estate_scan": estate_scan,
            "finished_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        }), encoding="utf-8")
    except OSError:
        pass                                       # a record that cannot be written only costs a longer restart later


def recorded(run_dir: Path, stage: str) -> dict[str, Any]:
    """A stage's `stage.json` ({} when it has none or cannot be read)."""
    try:
        data = json.loads((run_dir / stage / STAGE_FILE).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return data if isinstance(data, dict) else {}


def _recorded_sha(run_dir: Path, stage: str) -> str | None:
    return recorded(run_dir, stage).get("bimcontrol_sha")


def _sha_before(moment: datetime) -> str | None:
    """The commit that was current an hour before `moment` (by commit date: a commit made earlier but merged later may
    be counted as having been there; the hour is a margin for the code that was loaded before the run began)."""
    return _git("rev-list", "-1", f"--before={(moment - timedelta(hours=1)).astimezone(timezone.utc).isoformat()}", "HEAD")


def _changed_since(sha: str, head: str) -> list[str] | None:
    out = _git("diff", "--name-only", "--no-renames", sha, head, "--", "src/bimcontrol")
    return None if out is None else [line.removeprefix("src/bimcontrol/") for line in out.splitlines() if line]


def restart_stage(run_dir: Path, stages: list[dict[str, Any]], run_started: datetime, *, converter_changed_since: datetime | None = None,
                  converter_now: str | None = None) -> str | None:
    """The stage to resume `--from` so that a run carries the current code, or None to start the run over.

    `stages` are the run's stage rows in order. Per stage: the commit that ran it (its `stage.json`, else the commit
    current when the run began) against the current one; the earliest stage a changed file feeds. A converter change
    leaves no file here: `converter_now` (the build that is running) against the build the conversion recorded, else
    `converter_changed_since` (when the converter was redeployed) against when the conversion finished, re-converts the run. Nothing changed: `verify_parity`. A stage that did not finish is where the run carries on at the latest; a
    git history that cannot answer gives None."""
    head = code_sha()
    if head is None:
        return None
    names = [s["name"] for s in stages]
    # With no change that any stage reads, the run is still worth a fresh comparison with the sources that moved.
    earliest = names.index("verify_parity") if "verify_parity" in names else len(names)
    for index, stage in enumerate(stages):                  # a stage that did not finish is where the run carries on
        if stage["status"] not in ("succeeded", "skipped"):
            earliest = min(earliest, index)
            stages = stages[:index]
            break
    for index, stage in enumerate(stages):
        sha = _recorded_sha(run_dir, stage["name"]) or _sha_before(run_started)
        if sha is None:
            return None
        if sha.endswith("+") or head.endswith("+"):         # uncommitted edits: what ran cannot be told from a commit
            return None
        files = [] if sha == head else _changed_since(sha, head)
        if files is None:
            return None
        for path in files:
            feeds = stage_feeds(path)
            if feeds is not None and feeds in names:
                earliest = min(earliest, names.index(feeds))
        if stage["name"] == CONVERTER_STAGE:
            built = recorded(run_dir, stage["name"]).get("converter_build")
            if built and converter_now:                      # both known: compare builds, not clocks
                if built != converter_now or built.endswith("-dirty"):
                    earliest = min(earliest, index)
            elif converter_changed_since is not None and stage.get("finished_at"):
                finished = datetime.fromisoformat(stage["finished_at"])
                if (finished if finished.tzinfo else finished.replace(tzinfo=timezone.utc)) < converter_changed_since:
                    earliest = min(earliest, index)
    if "convert_dataflows" in names and earliest < names.index("convert_dataflows"):
        # A resume reuses the warehouse copies of source tables that were built after the run began (`reuse_since`), so a
        # fix to how they are built reaches the data only in a run that starts over.
        return None
    return names[earliest] if earliest < len(names) else None

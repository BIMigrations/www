"""Live calls to a source BI platform, for what a scan cannot hold.

A scan is a point-in-time inventory: it records that a dataset exists, its
schema and its lineage, but not its rows, and not the parts of a card
Domo only serves on request. When a migration needs those, it comes here.

Each platform gets a package. BIMControl keeps its own session rather than
borrowing EstateScanner's -- see sources/domo/session.py for why.
"""

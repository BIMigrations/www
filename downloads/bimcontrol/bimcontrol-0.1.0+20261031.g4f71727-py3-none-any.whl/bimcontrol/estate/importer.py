"""Import an EstateScanner export zip (`EstateScan-*.zip`) as the loaded scan.

The zip holds `estate.db` and `manifest.json` (see EstateScanner's
export.py). Importing validates both, extracts the database to
`~/.bimcontrol/estates/` under a name that never collides with an existing
file, and records it as the current estate. The imported file is only ever
opened read-only afterwards, like any other estate database.
"""

from __future__ import annotations

import json
import re
import shutil
import sqlite3
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any

from bimcontrol import paths

DB_NAME = "estate.db"
MANIFEST_NAME = "manifest.json"
# What the reader and the pipelines query; a database without these is not a
# scan this version can use, whatever EstateScanner version made it.
REQUIRED_TABLES = ("scans", "dashboards", "cards", "datasets", "dataflows", "calculated_fields", "edges")
MAX_DB_BYTES = 8 * 1024**3


class ImportError_(ValueError):
    """The zip is not a usable export; the message is shown to the operator."""


def _read_manifest(zf: zipfile.ZipFile) -> dict[str, Any]:
    names = set(zf.namelist())
    missing = {DB_NAME, MANIFEST_NAME} - names
    if missing:
        raise ImportError_(
            f"This is not an EstateScanner export: {', '.join(sorted(missing))} missing from the zip."
        )
    try:
        manifest = json.loads(zf.read(MANIFEST_NAME))
    except ValueError as exc:
        raise ImportError_("manifest.json in the zip is not valid JSON.") from exc
    if not isinstance(manifest, dict) or not manifest.get("latest_completed_scan"):
        raise ImportError_("The export has no completed scan in its manifest. Run a scan and export again.")
    if manifest.get("contains_sessions"):
        raise ImportError_("This export says it contains sign-in sessions; refusing to import it.")
    if zf.getinfo(DB_NAME).file_size > MAX_DB_BYTES:
        raise ImportError_("The database in the zip is implausibly large.")
    return manifest


def _validate_db(path: Path) -> None:
    try:
        conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    except sqlite3.Error as exc:
        raise ImportError_(f"estate.db in the zip is not a SQLite database: {exc}") from exc
    try:
        try:
            tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        except sqlite3.DatabaseError as exc:
            raise ImportError_(f"estate.db in the zip is not a SQLite database: {exc}") from exc
        missing = [t for t in REQUIRED_TABLES if t not in tables]
        if missing:
            raise ImportError_(
                "estate.db has a schema this BIMControl cannot read (missing tables: "
                + ", ".join(missing) + "). Export again with a matching EstateScanner version."
            )
        if "platform_sessions" in tables and conn.execute("SELECT COUNT(*) FROM platform_sessions").fetchone()[0]:
            raise ImportError_("estate.db still holds sign-in sessions; refusing to import it.")
    finally:
        conn.close()


def _target_path(manifest: dict[str, Any]) -> Path:
    scan = manifest["latest_completed_scan"]
    instance = re.sub(r"[^A-Za-z0-9_-]", "_", str(scan.get("instance") or "estate"))
    stem = f"{instance}-scan{scan.get('scan_id')}-{datetime.now():%Y%m%d-%H%M%S}"
    directory = paths.estates_dir()
    directory.mkdir(parents=True, exist_ok=True)
    candidate, n = directory / f"{stem}.db", 1
    while candidate.exists():  # never overwrite an earlier import
        n += 1
        candidate = directory / f"{stem}-{n}.db"
    return candidate


def import_zip(zip_path: str | Path) -> dict[str, Any]:
    """Validate and extract; returns {path, manifest}. Raises ImportError_."""
    try:
        zf = zipfile.ZipFile(zip_path)
    except zipfile.BadZipFile as exc:
        raise ImportError_("That file is not a zip.") from exc
    with zf:
        manifest = _read_manifest(zf)
        target = _target_path(manifest)
        partial = target.with_suffix(".db.partial")
        try:
            with zf.open(DB_NAME) as src, open(partial, "wb") as out:
                shutil.copyfileobj(src, out)
            _validate_db(partial)
            partial.replace(target)
        finally:
            partial.unlink(missing_ok=True)
    paths.set_current_estate(target)
    return {"path": target, "manifest": manifest}

"""Reading a Tableau permission list (M3 3.7): who is granted which capabilities on one object.

**Nothing here has talked to a real Tableau server.** The shapes are the documented XML rendered as JSON [U: no JSON answer
was seen]; the template table is read from Tableau's help, and how its capability names map to REST's is partly a guess
(each is tagged). A capability set that matches no template is ``"Custom"``, which is never wrong, only less informative.

A Tableau grant is not one role: it is a set of capabilities, each ``Allow`` or ``Deny`` (REST: ``capability name= mode=``) [C R10].
The edge keeps the whole set (``capabilities``) and a one-word summary (``role``) for readers that look only at ``role``.

    GET .../workbooks/{id}/permissions   (2.0)  {"permissions": {"workbook": {...}, "granteeCapabilities": [
                                                   {"group": {"id": ...}, "capabilities": {"capability": [{"name": "Read", "mode": "Allow"}]}}]}}
    GET .../views/{id}/permissions       (3.2)  the same, with ``view``
    GET .../datasources/{id}/permissions (2.0)  the same, with ``datasource``
    GET .../projects/{id}/permissions    (2.0)  the same, with ``project``
    GET .../projects/{id}/default-permissions/{workbooks|datasources|flows}  (2.1)  [U: the answer has no object element]

Who may ask [C R10]: workbook and project lists need a (site) administrator; a view or data source list also allows a user
with Read on it. Everything else is a 403, which the scan counts per kind and reports (client.py).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

ALLOW, DENY = "Allow", "Deny"

# The three values of a project's ``contentPermissions`` [C R11]. Anything else is kept as the server said and counted.
LOCK_MODES = ("ManagedByOwner", "LockedToProject", "LockedToProjectWithoutNested")

# Content types a project gives default permissions for, in the URL's own spelling. Others exist (data roles, lenses, metrics,
# virtual connections, databases, tables [C R10]) but a migration to Power BI has no use for them, and each is a call per project.
DEFAULT_TYPES = ("workbooks", "datasources", "flows")


def _cumulative(*steps: set[str]) -> list[frozenset[str]]:
    out, held = [], set()
    for step in steps:
        held = held | step
        out.append(frozenset(held))
    return out


# Tableau's permission templates (View, Explore, Publish, Administer) are cumulative [C: "the Explore template includes everything
# from the View template plus additional capabilities"], so each is listed as what it adds. The UI names the capabilities
# differently from REST; the mapping to REST's names is from the REST method pages' lists and is [U] where marked:
#   Download Summary Data = ExportData [U], Download Full Data = ViewUnderlyingData [U], Share Customized = ShareView,
#   Web Edit = WebAuthoring, Download Workbook/Save a Copy = ExportXml [U], Overwrite = Write, Move = ChangeHierarchy,
#   Set Permissions = ChangePermissions.
# Capabilities the UI lists that REST has no name for (API Access, AI Access, Full Data Query, Refresh Extracts on workbooks)
# are not in the sets: a site whose rules carry them under another name will read as Custom until the live check (3.12) says what
# REST really returns for each template.
_TEMPLATES: dict[str, list[tuple[str, frozenset[str]]]] = {
    "workbook": list(zip(("View", "Explore", "Publish", "Administer"), _cumulative(
        {"Read", "Filter", "ViewComments", "AddComment", "ExportImage", "ExportData"},
        {"ShareView", "ViewUnderlyingData", "WebAuthoring", "RunExplainData"},
        {"ExportXml", "Write", "CreateRefreshMetrics"},
        {"ChangeHierarchy", "Delete", "ChangePermissions"}))),
    # Views have the workbook's capabilities except Overwrite, Download Workbook and Move, which belong to the workbook [C]. [U: the REST page
    # lists ExportXml and Write for views and not CreateRefreshMetrics or RunExplainData, so these rows probably read as Custom on a real site.]
    "view": list(zip(("View", "Explore", "Publish", "Administer"), _cumulative(
        {"Read", "Filter", "ViewComments", "AddComment", "ExportImage", "ExportData"},
        {"ShareView", "ViewUnderlyingData", "WebAuthoring", "RunExplainData"},
        {"CreateRefreshMetrics"},
        {"Delete", "ChangePermissions"}))),
    "datasource": list(zip(("View", "Explore", "Publish", "Administer"), _cumulative(
        {"Read", "Connect"}, {"ExportXml"}, {"Write"}, {"Delete", "ChangePermissions", "ExtractRefresh"}))),
    "flow": list(zip(("View", "Explore", "Publish", "Administer"), _cumulative(
        {"Read"}, {"ExportXml", "Execute"}, {"Write"}, {"ChangeHierarchy", "Delete", "ChangePermissions"}))),
    # Projects have two capabilities and two templates [C]; Publish is "Write" in REST [C: the project example lists Read and Write].
    "project": [("View", frozenset({"Read"})), ("Publish", frozenset({"Read", "Write"}))],
}
# The content type a default-permissions URL names, in the template table's spelling.
_TEMPLATE_KIND = {"workbooks": "workbook", "datasources": "datasource", "flows": "flow"}


def template_name(kind: str, capabilities: dict[str, str]) -> str:
    """The Tableau template whose capabilities are exactly the ones allowed here, else ``"Custom"``. A single ``Deny`` makes it
    Custom: a template only allows. ``kind`` is ``workbook``, ``view``, ``datasource``, ``flow``, ``project`` or a default-permissions
    type (``workbooks``, ``datasources``, ``flows``)."""
    if not capabilities or any(mode != ALLOW for mode in capabilities.values()):
        return "Custom"
    allowed = frozenset(capabilities)
    for name, held in _TEMPLATES.get(_TEMPLATE_KIND.get(kind, kind), []):
        if held == allowed:
            return name
    return "Custom"


@dataclass
class Grant:
    """One user's or group's capabilities on one object, as the server listed them."""

    grantee_type: str  # "user" | "group"
    grantee_id: str
    capabilities: dict[str, str]

    def as_json(self, kind: str) -> dict:
        return {"grantee": {"type": self.grantee_type, "id": self.grantee_id}, "role": template_name(kind, self.capabilities),
                "capabilities": dict(self.capabilities)}


@dataclass
class Parsed:
    grants: list[Grant] = field(default_factory=list)
    shape_ok: bool = True  # the body held a permission list at all (an empty list is a list)
    bad_grantees: int = 0  # entries naming neither a user nor a group with a usable id, or holding no ``capabilities.capability`` list at all
    bad_capabilities: int = 0  # capabilities without a name, or with a mode other than Allow / Deny
    dropped_capabilities: int = 0  # capabilities beyond MAX_CAPABILITIES for one grantee
    unknown_shape: bool = False  # the permissions object holds keys this reader does not know (a renamed ``granteeCapabilities``, say)


# What a permission answer's ``permissions`` object may hold besides the grantee list: the object it is about and its parent [C R10]. Anything
# else means the shape is not the one this reader was written for; an object nobody holds a grant on has none of them and is not that.
_KNOWN_KEYS = frozenset({"granteeCapabilities", "project", "workbook", "view", "datasource", "flow", "parent", "owner"})


def _many(value: Any) -> list:
    """A repeated XML element rendered as JSON is a list, or the bare object when there is one [U]."""
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


# A capability name is one of Tableau's own words (Read, ExportData, ...). Anything else is not stored: the name goes into an edge's
# JSON, and a server's free text has no business there.
_CAPABILITY = re.compile(r"[A-Za-z][A-Za-z0-9]{0,63}")
# Tableau has fewer than thirty capabilities for any content type; a grantee listing hundreds is a hostile or broken server, and a row
# should not be as large as it likes.
MAX_CAPABILITIES = 200
MAX_ID = 200  # characters of a grantee id (a LUID is 36)


def _id(value: Any) -> str | None:
    ident = value.get("id") if isinstance(value, dict) else None
    if isinstance(ident, str) and ident and len(ident) <= MAX_ID:
        try:
            ident.encode("utf-8")  # a lone surrogate would raise on insert
        except UnicodeEncodeError:
            return None
        return ident
    return None


def parse_permissions(body: Any) -> Parsed:
    """The grants in a permission-list answer. Nothing in it is trusted: an entry that is not a user or a group with an id, a capability
    without a name or with another mode than Allow / Deny, is counted and left out, never raised. The same grantee listed twice is
    one grant (a ``Deny`` beats an ``Allow`` of the same capability, as it does in Tableau's own evaluation [U: that Deny wins is from memory of the help, not read])."""
    perms = body.get("permissions") if isinstance(body, dict) else None
    if not isinstance(perms, dict) or not isinstance(perms.get("granteeCapabilities", []), (list, dict)):
        return Parsed(shape_ok=False)
    out = Parsed(unknown_shape=any(key not in _KNOWN_KEYS for key in perms))
    merged: dict[tuple[str, str], dict[str, str]] = {}
    for entry in _many(perms.get("granteeCapabilities")):
        if not isinstance(entry, dict):
            out.bad_grantees += 1
            continue
        # An entry names a user or a group; if one names both (not documented) both are kept rather than one silently dropped.
        who = [(t, _id(entry.get(t))) for t in ("user", "group") if _id(entry.get(t))]
        caps = entry.get("capabilities")
        listed = _many(caps.get("capability") if isinstance(caps, dict) else None)
        if not who or not listed:
            # No grantee, or no `capabilities.capability` where the documentation puts it. A grant with nothing in it is not a thing Tableau
            # lists, and a key that moved (the likeliest surprise of a first real run) must not read as "nobody was granted anything".
            out.bad_grantees += 1
            continue
        for key in who:
            held = merged.setdefault(key, {})
            for cap in listed:
                name = cap.get("name") if isinstance(cap, dict) else None
                mode = cap.get("mode").capitalize() if isinstance(cap, dict) and isinstance(cap.get("mode"), str) else None
                if not isinstance(name, str) or not _CAPABILITY.fullmatch(name) or mode not in (ALLOW, DENY):
                    out.bad_capabilities += 1
                    continue
                if name not in held and len(held) >= MAX_CAPABILITIES:
                    out.dropped_capabilities += 1
                    continue
                if held.get(name) != DENY:
                    held[name] = mode
    out.grants = [Grant(t, i, caps) for (t, i), caps in merged.items() if caps]  # a rule with no capability grants nothing
    return out

"""Snowflake -- not built yet.

Registered so it appears wherever warehouses are listed and fails with a
straight answer rather than a KeyError, and so the work needed is written
down at the point someone will look for it.

**What this needs when it is built**

- `snowflake-connector-python`, added to the `warehouse` extra.
- Loading is a two-step: `PUT file://... @stage` then `COPY INTO table
  FROM @stage FILE_FORMAT = (TYPE = CSV SKIP_HEADER = 1)`. Unlike
  Redshift, the internal stage means no customer-owned bucket is required
  for the common case -- so `s3_bucket` has no equivalent here and the
  size threshold in base.py is about connector efficiency rather than
  viability.
- Type mapping from Domo: STRING -> VARCHAR (no length needed, unlike
  Redshift, so `scan_csv_widths` can be skipped entirely), LONG -> NUMBER(38,0),
  DOUBLE -> FLOAT, DECIMAL -> NUMBER(38,6), DATE -> DATE,
  DATETIME -> TIMESTAMP_NTZ.
- Identifiers fold to upper case unless quoted. Quote them, as the
  Redshift adapter does, or Domo column names with spaces will not survive.
- Settings: account, warehouse, database, schema, role, user. Password or
  key-pair from the environment (`SNOWFLAKE_PASSWORD` /
  `SNOWFLAKE_PRIVATE_KEY_PATH`), never the control database.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .base import LoadResult, TableSpec, WarehouseAdapter, WarehouseError

_MESSAGE = (
    "Snowflake support is not built yet -- only Redshift is implemented. "
    "See src/bimcontrol/warehouses/snowflake.py for what it needs."
)


class SnowflakeAdapter(WarehouseAdapter):
    key = "snowflake"
    display_name = "Snowflake (not built yet)"
    implemented = False

    def connect(self) -> None:
        raise WarehouseError(_MESSAGE)

    def close(self) -> None:
        return None

    def ensure_schema(self, schema: str) -> None:
        raise WarehouseError(_MESSAGE)

    def create_table(self, spec: TableSpec, replace: bool = True) -> None:
        raise WarehouseError(_MESSAGE)

    def load_csv(self, spec: TableSpec, csv_path: Path, row_count: int | None = None) -> LoadResult:
        raise WarehouseError(_MESSAGE)

    def row_count(self, schema: str, table: str) -> int:
        raise WarehouseError(_MESSAGE)

    def table_exists(self, schema: str, table: str) -> bool:
        raise WarehouseError(_MESSAGE)

    def check(self) -> dict[str, Any]:
        return {"warehouse": self.key, "ok": False, "error": _MESSAGE}

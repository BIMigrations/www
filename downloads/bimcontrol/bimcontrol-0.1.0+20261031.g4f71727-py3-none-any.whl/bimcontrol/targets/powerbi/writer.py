"""Writes a PBIP: the text form of a Power BI project.

A `.pbip` is a folder, not a file: a semantic model written in TMDL and a
report written as PBIR JSON. It is the format to generate because it is
text -- diffable, reviewable, and produced without Power BI Desktop,
which does not run on macOS or in CI. Opening it in Desktop and saving
gives a `.pbix`; publishing it to Fabric gives the same thing server
side.

Two mechanical details that break the format silently if you get them
wrong:

- **TMDL is indentation-sensitive and wants tabs.** Mixing spaces in
  parses as a different structure, not as an error you can see.
- **M expressions are embedded in TMDL**, so a generated SQL string has
  to survive two levels of quoting: `"` doubled for M, then the whole
  block indented one level deeper than `source =`.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import uuid
from pathlib import Path

from . import daterange
from .model import iso_date_parts, with_trimmed_text, Page, Role, Projection, Report, SemanticModel, Table, Visual, VisualFilter

SCHEMA = "https://developer.microsoft.com/json-schemas/fabric/item"

# PBIR schema versions, taken from the Fabric report-definition reference
# rather than guessed: the payload is validated against these on import,
# and an older version is rejected rather than tolerated.
PBIR_REPORT_SCHEMA = "report/3.1.0"
PBIR_PAGE_SCHEMA = "page/2.0.0"
# Not in the reference, and 2.0.0 does not exist -- Fabric answers
# "Can't resolve schema '2.0.0' in 'pages/pages.json'".
PBIR_PAGES_SCHEMA = "pagesMetadata/1.0.0"
PBIR_VISUAL_SCHEMA = "visualContainer/2.0.0"
PBIR_PROPERTIES_SCHEMA = "definitionProperties/2.0.0"
PBIR_VERSION_SCHEMA = "versionMetadata/1.0.0"
# The theme records which content versions the report was authored against.
REPORT_VERSION_AT_IMPORT = {"visual": "2.5.0", "report": "3.1.0", "page": "2.3.0"}
PLATFORM_SCHEMA = (
    "https://developer.microsoft.com/json-schemas/fabric/gitIntegration/"
    "platformProperties/2.0.0/schema.json"
)

# Power BI's aggregate function enum, as PBIR encodes it.
AGGREGATION_CODES = {
    "SUM": 0, "AVG": 1, "AVERAGE": 1, "MIN": 2, "MAX": 3,
    "DISTINCTCOUNT": 4, "COUNT DISTINCT": 4, "COUNT": 5, "COUNTNONNULL": 5,
}
AGGREGATION_NAMES = {
    0: "Sum", 1: "Avg", 2: "Min", 3: "Max", 4: "CountDistinct", 5: "CountNonNull",
}


def _guid() -> str:
    return str(uuid.uuid4())


def _tmdl_name(name: str) -> str:
    """Quote a TMDL identifier unless it is a bare word.

    Domo names routinely contain spaces, slashes and `#`, none of which
    survive unquoted. A quote inside a name is doubled (`FTE's` -> `'FTE''s'`).
    """
    if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name):
        return name
    return "'" + name.replace("'", "''") + "'"


def _source_column(name: str) -> str:
    """The value of a column's `sourceColumn`. TMDL trims an unquoted value, so a name with a leading or trailing space
    (Domo's ' ER Departure-Admit') is looked up without it and the refresh fails ("The 'ER Departure-Admit' column does
    not exist in the rowset": Emergency-SW). Double quotes keep it (measured on a published probe model: unquoted and
    single-quoted fail, double-quoted refreshes)."""
    return f'"{name}"' if name != name.strip() and '"' not in name else name


def _m_string(text: str) -> str:
    """Escape a string for embedding in a Power Query literal.

    Newlines become `#(lf)` rather than staying as real line breaks. A
    multi-line M literal is not valid, and the TMDL writer indents every
    line of the expression -- which would otherwise push tabs into the
    middle of the SQL string. Collapsing to one physical line avoids
    both, and `#(lf)` keeps the statement readable if anyone prints it.

    The `#` escape itself has to be escaped first, or a SQL string
    containing `#(` would be read as an escape sequence.
    """
    return (
        text.replace("#", "#(#)")
        .replace('"', '""')
        .replace("\r\n", "#(lf)")
        .replace("\n", "#(lf)")
        .replace("\t", "#(tab)")
    )


def narrowed_statement(
    statement: str, columns: list[str], widths: dict[str, int] | None = None,
    case_insensitive: set[str] | frozenset[str] | None = None,
) -> str:
    """`statement` limited to `columns`, for a native query.

    A native query runs with folding off, so Power BI fetches every column the
    statement returns even when the model keeps a handful. A dataflow output
    with 409 columns and 1.7M rows ran Redshift out of memory ("out of memory
    for query result") on refresh; selecting only the model's columns fixes it.

    `widths` re-declares a text column as VARCHAR(n): see `text_widths`. `case_insensitive` names the text columns
    that take Redshift's case-insensitive collation, so that comparing and grouping them reads 'Lab Serology' and
    'LAB SEROLOGY' as one value, as Domo (and the model's own engine) does.
    """
    widths = widths or {}
    case_insensitive = case_insensitive or frozenset()

    def select(c: str) -> str:
        quoted = '"' + c.replace('"', '""') + '"'
        item = f"CAST({quoted} AS VARCHAR({widths[c]}))" if c in widths else quoted
        if c in case_insensitive:
            return f"COLLATE({item}, 'case_insensitive') AS {quoted}"
        return f"{item} AS {quoted}" if c in widths else item

    selected = ", ".join(select(c) for c in columns)
    return f"SELECT {selected}\nFROM (\n{statement}\n) AS _model"


def text_widths(measured: dict[str, int]) -> dict[str, int]:
    """The width to declare for each text column, from the longest value it holds.

    A dataflow output declares its text columns VARCHAR(65535) whatever they hold, and the
    driver in the Power BI service may size its buffers by the declared width. A 6M-row probe
    with narrow widths refreshed in 12 min where 5.2M rows with the declared widths lost the
    connection, but the two differed in other ways too, so this is a precaution, not a proven
    fix. Twice the longest value leaves room for the next load (an explicit CAST cuts a longer one).
    """
    return {c: min(65535, max(32, 2 * longest)) for c, longest in measured.items()}


# A table is split into partitions that each stay under this many cells (rows x columns).
# What runs the service out of memory is the rows in flight, not one partition: a refresh starts
# the next partition's query while the previous one is still streaming, so two or three are
# held at once (maxParallelism 1 did not prevent it). Measured 2026-10-17 on the 77-column
# Daily Charge output: a one-table probe read 3M rows in 4 min and 6M in 12 min; the real model
# lost the connection with 2 partitions of 3.4M rows in flight (6.8M) and also at 5.2M and 10M
# rows per partition; Daily Revenue-SW read 20.7M rows x 21 columns (434M cells) in one query.
# So about 400M cells in flight is the limit, and a partition is a quarter of that.
PARTITION_CELLS = int(os.environ.get("BIMCONTROL_PARTITION_CELLS", "100000000"))
MAX_PARTITIONS = 40
_HASH_COLUMNS = 48


def partition_count(rows: int | None, columns: int) -> int:
    if not rows or columns <= 0:
        return 1
    return max(1, min(MAX_PARTITIONS, -(-rows * columns // PARTITION_CELLS)))


def partition_statements(
    statement: str, columns: list[str], count: int, widths: dict[str, int] | None = None,
) -> list[str]:
    """`count` statements that together return exactly the rows of `statement`.

    A row goes to the partition its hash picks, so the split holds without a key column
    and copies of one row stay together. The hash reads up to 48 of the columns, spread
    across the list, with NULL read as '' so no row falls out of every partition.
    """
    base = narrowed_statement(statement, columns, widths)
    step = max(1, -(-len(columns) // _HASH_COLUMNS))
    key = " || '|' || ".join(
        "COALESCE(CAST(\"" + c.replace('"', '""') + "\" AS VARCHAR), '')" for c in columns[::step])
    return [f"{base}\nWHERE ABS(MOD(FNV_HASH({key}), {count})) = {i}" for i in range(count)]


# Power BI's Redshift connection renders a float as text with 17 digits ('1.824' is '1.8240000000000001'); the
# session every other client opens renders the shortest form Domo does. Joins on, and keys built from, a float
# cast to text then stopped matching (Human Resource-SW: 6,184 of 12,908 rows kept their department).
# Measured on a published probe: this statement ahead of the query gives '1.824'.
SESSION_SETUP = "SET extra_float_digits TO 0;\n"


def redshift_m(host: str, port: int | str, database: str, sql: str) -> str:
    """A Power Query expression reading a native query from Redshift.

    `EnableFolding=false` because the SQL is already the finished query --
    letting Power BI try to fold further onto a statement of chained CTEs
    is how you get a query that works in the editor and fails on refresh.
    """
    server = f"{host}:{port}"
    return (
        "let\n"
        f'    Source = AmazonRedshift.Database("{_m_string(server)}", "{_m_string(database)}"),\n'
        f'    Data = Value.NativeQuery(Source, "{_m_string(SESSION_SETUP + sql)}", null, [EnableFolding=false])\n'
        "in\n"
        "    Data"
    )


def redshift_table_m(host: str, port: int | str, database: str, schema: str, table: str) -> str:
    """A Power Query expression that navigates to one Redshift table, so the service can fold
    every query onto it (the source of a DirectQuery table)."""
    server = f"{host}:{port}"
    return (
        "let\n"
        f'    Source = AmazonRedshift.Database("{_m_string(server)}", "{_m_string(database)}"),\n'
        f'    Schema = Source{{[Name="{_m_string(schema)}"]}}[Data],\n'
        f'    Data = Schema{{[Name="{_m_string(table)}"]}}[Data]\n'
        "in\n"
        "    Data"
    )


# Primitive type names, not `type text`: inside a table type's field list Power Query takes
# a bare type (`[a = text]`) and rejects `type text` ("Token ',' expected" at import).
_M_TYPES = {
    "int64": "number", "double": "number", "decimal": "number",
    "dateTime": "datetime", "boolean": "logical", "string": "text",
}


def empty_table_m(table: Table) -> str:
    """A Power Query expression for a zero-row table with `table`'s columns."""
    columns = ", ".join(
        f'#"{_m_string(c.name)}" = {_M_TYPES.get(c.data_type, "text")}' for c in table.columns
    )
    return f"#table(type table [{columns}], {{}})"


# ---- TMDL ---------------------------------------------------------------


def table_tmdl(table: Table) -> str:
    lines = [f"table {_tmdl_name(table.name)}", f"\tlineageTag: {_guid()}", *(["\tisHidden"] if table.hidden else []), ""]
    direct_query = bool(table.source and table.source.direct_query)

    for column in table.columns:
        if column.expression is not None:
            for line in (column.description or "").splitlines():
                lines.append(f"\t/// {line}")
            lines += [
                f"\tcolumn {_tmdl_name(column.name)} = {column.expression}",
                f"\t\tdataType: {column.data_type}",
                f"\t\tlineageTag: {_guid()}",
                f"\t\tsummarizeBy: {column.summarize_by}",
            ]
            if column.hidden:
                lines.append("\t\tisHidden")
            if column.sort_by:
                lines.append(f"\t\tsortByColumn: {_tmdl_name(column.sort_by)}")
            lines.append("")
            continue
        lines += [
            f"\tcolumn {_tmdl_name(column.name)}",
            f"\t\tdataType: {column.data_type}",
            f"\t\tlineageTag: {_guid()}",
            f"\t\tsummarizeBy: {column.summarize_by}",
            # Redshift folds names to lower case and a DirectQuery column is read by its warehouse name.
            f"\t\tsourceColumn: {_source_column(column.name.lower() if direct_query else column.name)}",
            *([f"\t\tsortByColumn: {_tmdl_name(column.sort_by)}"] if column.sort_by else []),
            "",
            "\t\tannotation SummarizationSetBy = Automatic",
            "",
        ]

    for measure in table.measures:
        if measure.description:
            # A TMDL description precedes the object it describes and sits
            # at the same indentation. Putting it after the declaration
            # parses as "Unexpected line type: Property" -- which is how
            # Fabric rejected the first version of this file.
            #
            # Kept on the measure so the original formula travels with the
            # report rather than living only in a run's artefacts.
            for line in measure.description.splitlines():
                lines.append(f"\t/// {line}")
        lines.append(f"\tmeasure {_tmdl_name(measure.name)} = {measure.expression}")
        lines += [f"\t\tlineageTag: {_guid()}", ""]

    if table.source is not None:
        expressions = table.source.partitions or [table.source.m_expression]
        for number, expression in enumerate(expressions, start=1):
            name = table.name if len(expressions) == 1 else f"{table.name} {number}"
            mode = "directQuery" if table.source.direct_query else "import"
            lines += [f"\tpartition {_tmdl_name(name)} = m", f"\t\tmode: {mode}", "\t\tsource ="]
            for line in expression.splitlines():
                lines.append(f"\t\t\t\t{line}")
            lines.append("")
    else:
        # No query to load from (a `table_without_source` review item). Fabric
        # rejects a table with no partition, so give it an empty one with the
        # right columns: the model and report still publish and can be inspected.
        lines += [f"\tpartition {_tmdl_name(table.name)} = m", "\t\tmode: import", "\t\tsource ="]
        for line in empty_table_m(table).splitlines():
            lines.append(f"\t\t\t\t{line}")
        lines.append("")

    lines.append(f"\tannotation PBI_ResultType = Table")
    lines.append("")
    return "\n".join(lines)


def model_tmdl(model: SemanticModel) -> str:
    order = ", ".join(f'"{t.name}"' for t in model.tables)
    lines = [
        "model Model",
        f"\tculture: {model.culture}",
        "\tdefaultPowerBIDataSourceVersion: powerBI_V3",
        f"\tsourceQueryCulture: {model.culture}",
        "",
        f"\tannotation PBI_QueryOrder = [{order}]",
        "",
    ]
    for table in model.tables:
        lines.append(f"ref table {_tmdl_name(table.name)}")
    for role in model.roles:
        lines.append(f"ref role {_tmdl_name(role.name)}")
    lines.append("")
    return "\n".join(lines)


def role_tmdl(role: Role) -> str:
    """A row-level security role. No members: those need a user mapping."""
    lines = []
    for line in (role.description or "").splitlines():
        lines.append(f"/// {line}")
    lines += [f"role {_tmdl_name(role.name)}", "\tmodelPermission: read", ""]
    for table, expression in role.filters.items():
        lines.append(f"\ttablePermission {_tmdl_name(table)} = {expression}")
    lines.append("")
    return "\n".join(lines)


# ---- PBIR ---------------------------------------------------------------


def _projection(projection: Projection) -> dict:
    entity = {"Expression": {"SourceRef": {"Entity": projection.table}}}
    # What the visual shows when it is not the field's own name: a Domo alias, or the Domo name of a
    # beast mode that is "<name> (<table>)" in the model because measure names are unique model-wide.
    shown = ({"displayName": projection.display_name}
             if projection.display_name and projection.display_name != projection.name else {})

    if projection.kind == "measure":
        return {
            "field": {"Measure": {**entity, "Property": projection.name}},
            "queryRef": f"{projection.table}.{projection.name}",
            "nativeQueryRef": projection.name,
            **shown,
        }
    if projection.kind == "aggregation":
        code = AGGREGATION_CODES.get((projection.aggregation or "SUM").upper(), 0)
        return {
            "field": {
                "Aggregation": {
                    "Expression": {"Column": {**entity, "Property": projection.name}},
                    "Function": code,
                }
            },
            "queryRef": f"{AGGREGATION_NAMES[code]}({projection.table}.{projection.name})",
            "nativeQueryRef": f"{AGGREGATION_NAMES[code]} of {projection.name}",
            **shown,
        }
    return {
        "field": {"Column": {**entity, "Property": projection.name}},
        "queryRef": f"{projection.table}.{projection.name}",
        "nativeQueryRef": projection.name,
        **shown,
    }


def _literal(value: str, data_type: str | None) -> dict:
    """A PBIR filter literal. Numbers carry a type suffix; text is quoted."""
    kind = (data_type or "").lower()
    parts = iso_date_parts(value, data_type)
    if parts:
        year, month, day, hour, minute, second = parts
        return {"Literal": {"Value": f"datetime'{year:04}-{month:02}-{day:02}T{hour:02}:{minute:02}:{second:02}'"}}
    if kind in ("numeric", "long", "double", "decimal"):
        try:
            number = float(value)
        except ValueError:
            number = None
        if number is not None:
            text = f"{int(number)}L" if number.is_integer() else f"{number}D"
            return {"Literal": {"Value": text}}
    return {"Literal": {"Value": "'" + value.replace("'", "''") + "'"}}


def _filter_type(flt: VisualFilter) -> str:
    if flt.kind == "top_n":
        return "TopN"
    if flt.kind == "in":
        return "Categorical"
    if flt.kind == "date_range" and flt.date_range["type"] != "FIXED_RANGE":
        return "RelativeDate"
    return "Advanced"


def _filter_json(flt: VisualFilter) -> dict:
    """One visual-level filter in PBIR `filterConfig` form."""
    source = "t"
    field_kind = "Measure" if flt.field_kind == "measure" else "Column"
    column = {field_kind: {"Expression": {"SourceRef": {"Source": source}}, "Property": flt.column}}
    if flt.kind == "top_n":
        return _top_n_json(flt)
    if flt.kind == "date_range":
        condition = daterange.pbir_condition(flt.date_range, column)
    elif flt.kind == "in":
        condition = {"In": {
            "Expressions": [column],
            "Values": [[_literal(v, flt.data_type)] for v in with_trimmed_text(flt.values, flt.data_type, flt.blank_held)],
        }}
    else:
        condition = {"Comparison": {
            "ComparisonKind": flt.comparison,
            "Left": column,
            "Right": _literal(flt.values[0], flt.data_type),
        }}
    if flt.negated:
        condition = {"Not": {"Expression": condition}}
    return {
        "name": _guid().replace("-", "")[:20],
        "field": {field_kind: {"Expression": {"SourceRef": {"Entity": flt.table}}, "Property": flt.column}},
        "type": _filter_type(flt),
        "filter": {
            "Version": 2,
            "From": [{"Name": source, "Entity": flt.table, "Type": 0}],
            "Where": [{"Condition": condition}],
        },
    }


def _top_n_json(flt: VisualFilter) -> dict:
    """A Top N filter: the category values that rank in the first N by an aggregate (Power BI's own shape: the
    visual keeps the rows whose category is `In` a subquery that selects it ordered and limited)."""
    top = flt.top_n
    by = top["by"]
    owner = {"Expression": {"SourceRef": {"Source": "t"}}}
    if by["kind"] == "measure":
        ordering = {"Measure": {**owner, "Property": by["name"]}}
    else:
        code = AGGREGATION_CODES.get((by.get("aggregation") or "SUM").upper(), 0)
        ordering = {"Aggregation": {"Expression": {"Column": {**owner, "Property": by["name"]}}, "Function": code}}
    category = {"Column": {**owner, "Property": flt.column}}
    return {
        "name": _guid().replace("-", "")[:20],
        "field": {"Column": {"Expression": {"SourceRef": {"Entity": flt.table}}, "Property": flt.column}},
        "type": "TopN",
        "filter": {
            "Version": 2,
            "From": [
                {"Name": "subquery", "Type": 2, "Expression": {"Subquery": {"Query": {
                    "Version": 2,
                    "From": [{"Name": "t", "Entity": flt.table, "Type": 0}],
                    "Select": [{**category, "Name": "field"}],
                    "OrderBy": [{"Direction": 2 if top["descending"] else 1, "Expression": ordering}],
                    "Top": top["limit"]}}}},
                {"Name": "t", "Entity": flt.table, "Type": 0},
            ],
            "Where": [{"Condition": {"In": {"Expressions": [category], "Table": {"SourceRef": {"Source": "subquery"}}}}}],
        },
    }


def _slicer_json(visual: Visual, tab_order: int) -> dict:
    """A slicer on one column. Its title is the Domo filter's label."""
    payload = visual_json(visual, tab_order)
    payload["visual"]["objects"]["data"] = [{"properties": {
        "mode": {"expr": {"Literal": {"Value": f"'{visual.slicer_mode or 'Dropdown'}'"}}}}}]
    payload["visual"]["objects"]["header"] = [{"properties": {
        "show": {"expr": {"Literal": {"Value": "false"}}}}}]
    payload["visual"]["visualContainerObjects"]["title"][0]["properties"]["show"] = {"expr": {"Literal": {"Value": "true"}}}
    if visual.sync_group:
        payload["visual"]["syncGroup"] = {"groupName": visual.sync_group,
                                "fieldChanges": True, "filterChanges": True}
    return payload


def _textbox_json(visual: Visual, tab_order: int) -> dict:
    """A text box: the words are paragraphs of text runs, not a query."""
    style = {"fontWeight": "bold"} if visual.bold else {}
    if visual.text_size:
        style["fontSize"] = f"{visual.text_size}pt"
    # One paragraph per line of the text (a Notebook card's paragraphs); a title or header is a single line.
    paragraphs = [{"textRuns": [{"value": line, **({"textStyle": style} if style else {})}]}
                  for line in (visual.text or "").split("\n")]
    return {
        "$schema": f"{SCHEMA}/report/definition/{PBIR_VISUAL_SCHEMA}/schema.json",
        "name": _guid(),
        "position": {
            "x": round(visual.x, 2), "y": round(visual.y, 2), "z": tab_order,
            "width": round(visual.width, 2), "height": round(visual.height, 2),
            "tabOrder": tab_order,
        },
        "visual": {
            "visualType": "textbox",
            "objects": {"general": [{"properties": {"paragraphs": paragraphs}}]},
            "drillFilterOtherVisuals": True,
        },
    }


def visual_json(visual: Visual, tab_order: int) -> dict:
    query_state = {
        role: {"projections": [_projection(p) for p in fields]}
        for role, fields in visual.buckets.items()
        if fields
    }
    return {
        "$schema": f"{SCHEMA}/report/definition/{PBIR_VISUAL_SCHEMA}/schema.json",
        "name": _guid(),
        "position": {
            "x": round(visual.x, 2), "y": round(visual.y, 2), "z": tab_order,
            "width": round(visual.width, 2), "height": round(visual.height, 2),
            "tabOrder": tab_order,
        },
        "visual": {
            "visualType": visual.visual_type,
            "query": {"queryState": query_state, **_sort_json(visual)},
            "objects": _style_objects(visual),
            # The container's own formatting (title, background, border) is not part of `objects`: a title written
            # there is ignored and Power BI names the visual 'Val by Name and Grp' (seen 2026-10-19 on a render).
            "visualContainerObjects": {
                "title": [{
                    "properties": {
                        # PBIR literals are quoted inside the value itself.
                        "text": {"expr": {"Literal": {"Value": "'" + visual.title.replace("'", "''") + "'"}}},
                        "show": {"expr": {"Literal": {"Value": "true"}}},
                    }
                }]
            },
            "drillFilterOtherVisuals": True,
        },
    }


def _sort_json(visual: Visual) -> dict:
    """The visual's sort order as PBIR `sortDefinition` (fields must be among the query's projections)."""
    if not visual.sort:
        return {}
    return {"sortDefinition": {
        "sort": [{"field": _projection(p)["field"], "direction": direction} for p, direction in visual.sort],
        "isDefaultSort": True}}


def _style_objects(visual: Visual) -> dict:
    """The `objects` that carry how Domo drew the chart: values on the marks, the legend's place."""
    def literal(value: str) -> dict:
        return {"expr": {"Literal": {"Value": value}}}

    objects: dict = {}
    if visual.data_labels:
        objects["labels"] = [{"properties": {"show": literal("true")}}]
    if visual.legend_position == "Hide":
        objects["legend"] = [{"properties": {"show": literal("false")}}]
    elif visual.legend_position:
        objects["legend"] = [{"properties": {"show": literal("true"), "position": literal(f"'{visual.legend_position}'")}}]
    return objects


def _with_filters(payload: dict, visual: Visual) -> dict:
    if visual.filters:
        payload["filterConfig"] = {"filters": [_filter_json(f) for f in visual.filters]}
    return payload


def page_json(page: Page) -> dict:
    payload = {
        "$schema": f"{SCHEMA}/report/definition/{PBIR_PAGE_SCHEMA}/schema.json",
        "name": page.name,
        "displayName": page.display_name,
        # A Domo page is a long scroll. Fit-to-page would shrink it to a sliver.
        "displayOption": "FitToWidth" if page.height > page.width * 1.5 else "FitToPage",
        "width": page.width,
        "height": page.height,
    }
    if page.drillthrough:
        # A drillthrough page is a filter with no values yet, plus a binding
        # that tells Power BI which field offers it. Hidden from the page tabs:
        # it is reached by right-clicking a value, as in Domo.
        entity = {"Expression": {"SourceRef": {"Entity": page.drillthrough.table}}}
        field_expr = {"Column": {**entity, "Property": page.drillthrough.column}}
        filter_name = hashlib.sha1(page.name.encode()).hexdigest()[:20]
        payload["visibility"] = "HiddenInViewMode"
        payload["type"] = "Drillthrough"
        payload["filterConfig"] = {"filters": [
            {"name": filter_name, "field": field_expr, "type": "Categorical"}]}
        payload["pageBinding"] = {
            "name": hashlib.sha1(("binding" + page.name).encode()).hexdigest()[:20],
            "type": "Drillthrough",
            "referenceScope": "Default",
            "parameters": [{"name": "Param_Filter", "boundFilter": filter_name,
                            "fieldExpr": field_expr}],
        }
    return payload


def _platform(item_type: str, display_name: str, description: str | None = None) -> dict:
    metadata = {"type": item_type, "displayName": display_name}
    if description:
        metadata["description"] = description
    return {
        "$schema": PLATFORM_SCHEMA,
        "metadata": metadata,
        "config": {"version": "2.0", "logicalId": _guid()},
    }


def write_pbip(
    destination: Path, name: str, model: SemanticModel, report: Report, description: str | None = None,
) -> list[Path]:
    """Write the whole project. Returns every file written.

    `description` is stamped on both items; publishing reads it back to
    tell a re-publish of the same dashboard from a different dashboard
    that happens to share its name.
    """
    # Wipe first. Visual folders are GUID-named, so writing over an
    # existing project leaves every previous run's visuals behind and the
    # report deploys with duplicates -- eight cards became twenty-four
    # before this was caught.
    if destination.exists():
        shutil.rmtree(destination)
    destination.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []

    def put(path: Path, text: str) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
        written.append(path)

    def put_json(path: Path, payload: dict) -> None:
        put(path, json.dumps(payload, indent=2))

    model_dir = destination / f"{name}.SemanticModel"
    report_dir = destination / f"{name}.Report"

    # The .pbip file is only a pointer to the report item.
    put_json(destination / f"{name}.pbip", {
        "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/pbip/definitionProperties/1.0.0/schema.json",
        "version": "1.0",
        "artifacts": [{"report": {"path": f"{name}.Report"}}],
        "settings": {"enableAutoRecovery": True},
    })

    # ---- semantic model
    put_json(model_dir / ".platform", _platform("SemanticModel", name, description))
    put_json(model_dir / "definition.pbism", {"version": "4.0", "settings": {}})
    put(model_dir / "definition" / "database.tmdl", "database\n\tcompatibilityLevel: 1601\n")
    put(model_dir / "definition" / "model.tmdl", model_tmdl(model))
    for table in model.tables:
        put(model_dir / "definition" / "tables" / f"{table.name}.tmdl", table_tmdl(table))

    for role in model.roles:
        put(model_dir / "definition" / "roles" / f"{role.name}.tmdl", role_tmdl(role))

    # ---- report
    put_json(report_dir / ".platform", _platform("Report", name, description))
    put_json(report_dir / "definition.pbir", {
        "$schema": f"{SCHEMA}/report/{PBIR_PROPERTIES_SCHEMA}/schema.json",
        "version": "4.0",
        "datasetReference": {"byPath": {"path": f"../{name}.SemanticModel"}},
    })
    # Required by the importer, and its absence fails the whole report
    # with "Cannot find file 'version.json'".
    put_json(report_dir / "definition" / "version.json", {
        "$schema": f"{SCHEMA}/report/definition/{PBIR_VERSION_SCHEMA}/schema.json",
        "version": "2.0.0",
    })
    put_json(report_dir / "definition" / "report.json", {
        "$schema": f"{SCHEMA}/report/definition/{PBIR_REPORT_SCHEMA}/schema.json",
        "themeCollection": {"baseTheme": {
            "name": "CY25SU12",
            "reportVersionAtImport": REPORT_VERSION_AT_IMPORT,
            "type": "SharedResources",
        }},
        "settings": {"useStylableVisualContainerHeader": True},
        **({"filterConfig": {"filters": [_filter_json(f) for f in report.filters]}}
           if report.filters else {}),
    })
    put_json(report_dir / "definition" / "pages" / "pages.json", {
        "$schema": f"{SCHEMA}/report/definition/{PBIR_PAGES_SCHEMA}/schema.json",
        "pageOrder": [p.name for p in report.pages],
        "activePageName": report.pages[0].name if report.pages else "",
    })
    for page in report.pages:
        page_dir = report_dir / "definition" / "pages" / page.name
        put_json(page_dir / "page.json", page_json(page))
        for index, visual in enumerate(page.visuals):
            build = {"slicer": _slicer_json, "textbox": _textbox_json}.get(visual.visual_type, visual_json)
            payload = _with_filters(build(visual, index), visual)
            put_json(page_dir / "visuals" / payload["name"] / "visual.json", payload)

    return written

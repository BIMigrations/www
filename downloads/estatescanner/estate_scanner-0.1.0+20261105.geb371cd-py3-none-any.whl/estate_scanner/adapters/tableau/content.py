"""What a workbook or data-source file adds to the scan: rows and edges, from 3.4's summary (M3 3.6).

Pure functions from a :class:`FileSummary` (``workbook.read_summary``) and what REST already listed to core models. No I/O,
no clock; the client (``client.py``) downloads, calls these and yields the results from its phases.

**Nothing here has seen a file Tableau saved.** The summary's own provenance note applies (``workbook.py``), and so does every
[U] below: they are assumptions the live exit of 3.6 checks. The tests use crafted files (``tests/tableau_estate_files.py``).

What it decides (the table is in docs/tableau-scan-decisions.md, "3.6")
-----------------------------------------------------------------------
- **A calculation is a ``calculated_field``**, id ``<data source id>:<internal name>``, formula character for character,
  language ``tableau_calc``; a bin, group or cluster (not a formula) is ``tableau_bin`` / ``tableau_group`` / ``tableau_cluster``
  (``formula_language``). A parameter is one with language ``tableau_parameter`` and the id
  ``<workbook id>:Parameters:<name>`` (a parameter belongs to the workbook, not to a data source: [U] the ``Parameters``
  pseudo data source), its formula the parameter's current value.
- **Edges.** ``used_by_calculated_field`` runs from the user to the calculation, as the fixture and BIMControl's reader have
  it (``reader.calculated_fields_for(x)`` follows edges *from* x): the data source that holds the calculation, the worksheets
  whose ``datasource-dependencies`` list it, and every calculation whose formula refers to it. So a calculation that calls
  another has an edge *to* that one. A reference is resolved by internal name (``[Calculation_123]``, which is what a
  workbook file stores [U]); ``[Parameters].[Parameter 1]`` and ``[data source].[name]`` too. A name that is none of those is
  a plain field and makes no edge.
- **Worksheet and dashboard edges the structure phase could not know**: ``visualized_by`` (data source to worksheet, and to the
  dashboard that holds it) and ``part_of`` (worksheet to dashboard). A worksheet or dashboard is matched to its REST view by
  *name* within the workbook; a name that two views share, or that the file does not hold, is left out and counted, never guessed.
- **A published data source in a workbook** (``<repository-location>`` [U]) is an embedded row that wraps it
  (``definition.published_source``); worksheets are linked to both, the wrapper and the published data source, so the closure
  from a dashboard reaches the published source's row-level security.
- **Row-level security** is ``datasets.pdp_json``: a list of policies, each ``{name, kind, filters: [{calculation, formula}],
  users, groups, functions, unconfirmed: true, basis}``. ``kind`` says how strong the evidence is (see ``POLICY_KINDS``).
  ``None`` means the file could not be read; ``[]`` that it was read and held none. Every policy is marked unconfirmed:
  how Tableau serialises a "user filter" is not known from any file we have read.
- **Extract configuration** goes to ``definition.extract`` (enabled, units, count, type, user-specific, the extract's own
  connection attributes and filters). The Hyper file is never read.
"""

from __future__ import annotations

import posixpath
import re
from dataclasses import asdict, dataclass, field, replace
from datetime import datetime
from typing import Any

from estate_scanner.core.models import CalculatedField, Dataset, DashboardFilter, ObjectRef

from .workbook import (
    _REF,
    _TOKEN,
    PARAMETERS_DATASOURCE,
    CalculationInfo,
    ConnectionInfo,
    DataSourceInfo,
    FileSummary,
    FilterInfo,
    ParameterInfo,
    SheetInfo,
    StructureInfo,
    UserFunctionRef,
    _column_key,
    _s,
)

LANG_CALC = "tableau_calc"
LANG_PARAMETER = "tableau_parameter"
# A bin, a group and a cluster are not formulas, so none of them is ``tableau_calc``: a translator that branches on the language can
# never be handed a bin's ``[Profit]`` as an expression (Linus, estatescanner#81, 2026-11-03).
LANG_BIN = "tableau_bin"
LANG_GROUP = "tableau_group"
LANG_CLUSTER = "tableau_cluster"
CLASS_BIN, CLASS_GROUP = "bin", "categorical-bin"  # ``<calculation class=...>``: a group and a cluster are both the second
CLUSTER_SUFFIX = " (clusters)]"  # Tableau names a cluster field ``[<field> (clusters)]`` and a group ``[<field> (group)]`` [U: one workbook, World Indicators]

KIND_WORKSHEET, KIND_DASHBOARD, KIND_STORY = "worksheet", "dashboard", "story"

# How a policy came to be listed in pdp_json, strongest first. Only the first three restrict rows for everyone who uses the
# data source; the rest say that a user function is in play and that someone must look. [U: all of it].
POLICY_KINDS = (
    "data_source_filter",     # a data source filter on a calculation that calls a user function
    "extract_filter",         # the same, on the extract's filters
    "user_filter",            # a filter whose members name users (Tableau's "create user filter") [U: serialisation]
    "extract_user_specific",  # the extract is flagged user-specific [U: attribute]
    "sheet_filter",           # a worksheet filter on such a calculation: personalisation, or security enforced only in that sheet
    "calculation",            # a calculation calls a user function and no filter was found that uses it
)

# Table calculations (they need a view's partitioning and addressing) and aggregates, for ``classify_formula``.
# [U: the lists are from the function reference as remembered; a missing one is classed as a plain row calculation].
TABLE_CALCS = frozenset({
    "LOOKUP", "PREVIOUS_VALUE", "INDEX", "FIRST", "LAST", "SIZE", "RANK", "RANK_DENSE", "RANK_MODIFIED", "RANK_UNIQUE", "RANK_PERCENTILE",
    "RUNNING_SUM", "RUNNING_AVG", "RUNNING_MIN", "RUNNING_MAX", "RUNNING_COUNT", "TOTAL", "WINDOW_SUM", "WINDOW_AVG", "WINDOW_MIN",
    "WINDOW_MAX", "WINDOW_COUNT", "WINDOW_MEDIAN", "WINDOW_PERCENTILE", "WINDOW_STDEV", "WINDOW_STDEVP", "WINDOW_VAR", "WINDOW_VARP",
    "WINDOW_CORR", "WINDOW_COVAR", "WINDOW_COVARP", "MODEL_PERCENTILE", "MODEL_QUANTILE", "SCRIPT_REAL", "SCRIPT_INT", "SCRIPT_STR", "SCRIPT_BOOL",
})
AGGREGATES = frozenset({
    "SUM", "AVG", "COUNT", "COUNTD", "MIN", "MAX", "MEDIAN", "ATTR", "STDEV", "STDEVP", "VAR", "VARP", "PERCENTILE", "COLLECT", "CORR",
    "COVAR", "COVARP", "AGG",
})
_BLANK = (None, "", "false")


# -- formulas ---------------------------------------------------------------------------------------------


def formula_refs(formula: str | None) -> list[tuple[str | None, str]]:
    """The ``[field]`` and ``[source].[field]`` references in a formula, as ``(source or None, name)`` in order, with strings
    and comments skipped. ``[Parameters].[Parameter 1]`` is one reference, not two. Linear in the formula's length."""
    if not formula:
        return []
    found: list[tuple[str | None, str, int]] = []
    for m in _TOKEN.finditer(formula):
        if m.lastgroup != "field" or not m.group().endswith("]"):
            continue
        name = m.group()[1:-1]
        if found and found[-1][2] + 1 == m.start() and formula[m.start() - 1] == "." and found[-1][0] is None:
            found[-1] = (found[-1][1], name, m.end())
        else:
            found.append((None, name, m.end()))
    return [(src, name) for src, name, _ in found]


def formula_language(info: CalculationInfo) -> str:
    """``tableau_bin`` for ``class='bin'``, ``tableau_cluster`` for a ``categorical-bin`` whose field is named ``[... (clusters)]``,
    ``tableau_group`` for any other ``categorical-bin``, else ``tableau_calc``. [U] for the cluster rule: the XML of a saved cluster
    and of a group is the same element; only the field's name (Tableau's own) tells them apart."""
    if info.class_ == CLASS_BIN:
        return LANG_BIN
    if info.class_ == CLASS_GROUP:
        return LANG_CLUSTER if (info.column or "").endswith(CLUSTER_SUFFIX) else LANG_GROUP
    return LANG_CALC


def classify_formula(formula: str | None) -> str:
    """``lod`` (a ``{ ... }`` expression), ``table_calc``, ``aggregate`` or ``row``, from the function names outside strings,
    comments and field references. A heuristic [U]: ``MIN(a, b)`` is a row function that is called an aggregate here."""
    if not formula:
        return "row"
    code = _TOKEN.sub(lambda m: m.group() if m.lastgroup == "ident" else " ", formula)
    if "{" in code:
        return "lod"
    names = {m.group().upper() for m in re.finditer(r"[A-Za-z_][A-Za-z0-9_]*", code)}
    if names & TABLE_CALCS:
        return "table_calc"
    if names & AGGREGATES:
        return "aggregate"
    return "row"


# -- inputs and outputs -------------------------------------------------------------------------------------


@dataclass
class WorkbookContext:
    """What REST already told the scan about one workbook."""

    workbook_id: str
    owner_id: str | None = None
    project_id: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None
    views: list[dict] = field(default_factory=list)  # the workbook's rows from GET views: id, name
    views_complete: bool = False  # the whole GET views list was read: only then is "the REST list has no view of this name" a fact
    published: dict[str, tuple[str, str | None]] = field(default_factory=dict)  # contentUrl -> (data source id, name)
    connections: list[dict] = field(default_factory=list)  # the workbook's stored connection rows: id, type, serverAddress, ...


@dataclass
class WorkbookRows:
    datasets: list[Dataset] = field(default_factory=list)
    calculated_fields: list[CalculatedField] = field(default_factory=list)
    kinds: dict[str, str] = field(default_factory=dict)  # view id -> worksheet / dashboard / story
    cards: dict[str, dict] = field(default_factory=dict)  # view id -> {"card_type", "dataset_ids", "definition"}
    file_cards: dict[str, dict] = field(default_factory=dict)  # card id (``<workbook id>:<sheet name>``) -> {"name", "card_type", "dataset_ids", "definition"}: a worksheet with no view
    dashboards: dict[str, dict] = field(default_factory=dict)  # view id -> {"card_ids", "dataset_ids", "filters", "layout"}
    file_meta: dict = field(default_factory=dict)
    # Counted, not listed: (what, how many). The client turns them into one issue per kind for the whole scan.
    notes: dict[str, int] = field(default_factory=dict)

    def note(self, what: str, n: int = 1) -> None:
        self.notes[what] = self.notes.get(what, 0) + n


# -- pieces --------------------------------------------------------------------------------------------------


def _name_of(col: str | None) -> str:
    return (col or "").strip("[]") or (col or "")


def _users_groups(functions: list[UserFunctionRef]) -> tuple[list[str], list[str]]:
    users: list[str] = []
    groups: list[str] = []
    for fn in functions:
        if not fn.argument:
            continue
        target = groups if fn.function == "ISMEMBEROF" else users if fn.function in ("ISUSERNAME", "ISFULLNAME") else None
        if target is not None and fn.argument not in target:
            target.append(fn.argument)
    return users, groups


def _function_dicts(functions: list[UserFunctionRef]) -> list[dict]:
    return [{"function": f.function, "argument": f.argument} for f in functions]


def _filter_target(flt: FilterInfo, default_ds: str | None) -> tuple[str | None, str | None]:
    """``(data source name, column key)`` a filter's ``column`` names: ``[ds].[none:Calc:nk]`` or a bare ``[Calc]``."""
    parts = _REF.findall(flt.column or "")
    return (parts[0] if len(parts) >= 2 else default_ds), _column_key(flt.column)


def _is_true(value: str | None) -> bool:
    return isinstance(value, str) and value.strip().lower() in ("true", "yes", "1")


def _provider(ds: DataSourceInfo) -> str | None:
    for role in ("named", "direct"):
        for c in ds.connections:
            if c.role == role and c.class_:
                return c.class_
    return next((c.class_ for c in ds.connections if c.class_ and c.role != "extract"), None)


def _tables(ds: DataSourceInfo) -> list[dict]:
    out = []
    for c in ds.connections:
        for r in c.relations:
            out.append({k: v for k, v in (("name", r.name), ("table", r.table), ("type", r.type), ("connection", r.connection), ("join", r.join), ("text", r.text)) if v})
    return out


def _extract_dict(ds: DataSourceInfo) -> dict | None:
    e = ds.extract
    if e is None:
        return None
    return {"enabled": e.enabled, "units": e.units, "count": e.count, "type": e.type, "user_specific": e.user_specific,
            "connection": asdict(e.connection) if e.connection else None, "filters": [asdict(f) for f in e.filters]}


def _schema_columns(ds: DataSourceInfo) -> list[dict]:
    return [{"name": c.name, "type": c.datatype, "role": c.role, "calculated": c.is_calculation or c.is_parameter, "hidden": c.hidden} for c in ds.columns]


def _structure(ds: DataSourceInfo) -> dict:
    """``definition["structure"]``: the data source's own tables and columns, the field map and the relationships, in the keys BIMControl's
    ``describe_datasource`` returns from the file (``tables``, ``field_map``, ``joins``, ``relationships``), plus ``truncated`` (what a cap cut)."""
    st = ds.structure
    return {"tables": [asdict(t) for t in st.tables], "field_map": st.field_map, "joins": st.joins,
            "relationships": [asdict(r) for r in st.relationships], "truncated": st.truncated}


def _raw_datasource(ds: DataSourceInfo) -> dict:
    """The summary of a data source without the lists that become rows of their own (columns, calculations) or live in the definition (structure)."""
    raw = asdict(replace(ds, structure=StructureInfo()))  # (not `asdict(ds)`: that would copy a structure of megabytes to throw it away)
    raw["columns"] = len(ds.columns)
    raw["calculations"] = len(ds.calculations)
    raw["structure"] = {"tables": len(ds.structure.tables), "field_map": len(ds.structure.field_map), "relationships": len(ds.structure.relationships)}
    return raw


@dataclass
class _Calc:
    id: str
    ds: DataSourceInfo
    info: CalculationInfo
    holder: ObjectRef  # the dataset that holds it


def _policies(ds: DataSourceInfo, calcs_by_col: dict[str, "_Calc"], sheets: list[SheetInfo]) -> tuple[list[dict], dict[str, str]]:
    """``(the data source's pdp policies, {calculation column: how it is used})`` -- the second feeds each calculation's
    ``definition.used_as``. A calculation that calls a user function is a policy whatever it is used for; the kind says which."""
    used_as: dict[str, str] = {}
    policies: list[dict] = []
    listed: set[tuple[str, str]] = set()

    def entry(kind: str, calc: _Calc | None, name: str, basis: str, *, users=None, groups=None, functions=None, formula=None) -> None:
        key = (kind, calc.id if calc else name)
        if key in listed:
            earlier = next(p for p in policies if (p["kind"], p["filters"][0]["calculation"] if p["filters"] else p["name"]) == key)
            earlier["users"] += [u for u in (users or []) if u not in earlier["users"]]  # the same filter on another worksheet: merge, never drop
            earlier["groups"] += [g for g in (groups or []) if g not in earlier["groups"]]
            return
        listed.add(key)
        policy = {"name": name, "kind": kind, "filters": [], "users": list(users or []), "groups": list(groups or []),
                  "functions": _function_dicts(functions or []), "unconfirmed": True, "basis": basis}
        if calc is not None:
            policy["filters"].append({"calculation": calc.id, "formula": calc.info.formula if formula is None else formula})
        policies.append(policy)

    def from_filters(filters: list[FilterInfo], kind: str, where: str, default_ds: str | None) -> None:
        for flt in filters:
            target_ds, key = _filter_target(flt, default_ds)
            calc = calcs_by_col.get(key) if key and target_ds == ds.name else None
            if calc is not None and calc.info.user_functions:
                users, groups = _users_groups(calc.info.user_functions)
                entry(kind, calc, calc.info.caption or _name_of(calc.info.column), f"{where} on a calculation that calls a user function [U]",
                      users=users, groups=groups, functions=calc.info.user_functions)
                used_as.setdefault(calc.info.column or "", kind)
            members = [m for m in flt.members if m.user]
            if members and target_ds == ds.name:
                entry("user_filter", None, f"user filter on {flt.column or '(unnamed column)'}", f"{where} whose members name users [U: serialisation]",
                      users=[m.user for m in members])

    from_filters(ds.filters, "data_source_filter", "a data source filter", ds.name)
    if ds.extract is not None:
        from_filters(ds.extract.filters, "extract_filter", "an extract filter", ds.name)
        if _is_true(ds.extract.user_specific):
            entry("extract_user_specific", None, "user-specific extract", "the extract is flagged user-specific [U: attribute]")
    for sheet in sheets:
        from_filters(sheet.filters, "sheet_filter", f"a filter on worksheet {sheet.name!r}", None)
    for col, calc in calcs_by_col.items():
        if calc.info.user_functions and col not in used_as:
            users, groups = _users_groups(calc.info.user_functions)
            entry("calculation", calc, calc.info.caption or _name_of(col), "a calculation calls a user function; no filter was found that uses it [U]",
                  users=users, groups=groups, functions=calc.info.user_functions)
            used_as[col] = "calculation"
    policies.sort(key=lambda p: POLICY_KINDS.index(p["kind"]))
    return policies, used_as


def _calculated_field(calc: _Calc, owner_id: str | None, used_as: str | None, workbook_id: str | None, refs: list[ObjectRef],
                      resolved: list[str], plain_fields: list[str], origin_note: dict, wrapper_of: str | None = None) -> CalculatedField:
    info = calc.info
    language = formula_language(info)
    definition: dict[str, Any] = {
        "kind": classify_formula(info.formula) if language == LANG_CALC else language.removeprefix("tableau_"), "role": info.role, "datasource_id": calc.holder.id, "datasource_name": calc.ds.name,
        "internal_name": info.column, "calc_class": info.class_, "origin": info.origin, "references": resolved,
        "field_references": plain_fields[:200], "uses_user_function": bool(info.user_functions),
        "user_functions": _function_dicts(info.user_functions),
    }
    if info.grouping is not None:
        definition["grouping"] = info.grouping  # as read: the bin's size and peg, the group's column, default and members
    if used_as:
        definition["used_as"] = used_as
    if workbook_id:
        definition["workbook_id"] = workbook_id
    if wrapper_of:
        definition["wrapper_of"] = wrapper_of
    return CalculatedField(
        id=calc.id, name=info.caption or _name_of(info.column), owner_id=owner_id, formula_language=language, formula=info.formula,
        data_type=info.datatype, linked_object_refs=refs, definition=definition,
        raw_payload={"caption": info.caption, "name": info.column, "class": info.class_, "datasource": calc.ds.name, **origin_note},
    )


def _source_text(info: CalculationInfo) -> str | None:
    """What a calculation refers to by name: its formula; for a group, the column it groups; for a bin also the parameter that sets its size."""
    grouping = info.grouping or {}
    parts = [info.formula if info.formula is not None else grouping.get("column"), (grouping.get("attributes") or {}).get("size-parameter")]
    return " ".join(p for p in parts if p) or None


def _resolve(calc: _Calc, ds_calcs: dict[str, dict[str, _Calc]], by_ds_alias: dict[str, str], params: dict[str, str],
             memo: dict[int, tuple[dict[str, list[_Calc]], set[str]]]) -> tuple[list[str], list[str]]:
    """``(ids of the calculations and parameters this formula refers to, names that are plain fields)``. By internal name [U]; a
    name that matches nothing there but is the unique caption of a calculation in the same data source falls back to that."""
    mine = ds_calcs.get(calc.ds.name or "", {})
    if id(calc.ds) not in memo:  # once per data source: building these per calculation made a big workbook quadratic
        by_caption: dict[str, list[_Calc]] = {}
        for other in mine.values():
            if other.info.caption:
                by_caption.setdefault(other.info.caption, []).append(other)
        memo[id(calc.ds)] = (by_caption, {c.name for c in calc.ds.columns if c.name})
    captions, columns = memo[id(calc.ds)]
    ids: list[str] = []
    plain: list[str] = []
    text = _source_text(calc.info)
    for source, name in formula_refs(text):
        key = f"[{name}]"
        target: str | None = None
        if source is None:
            if key in mine and mine[key].id != calc.id:
                target = mine[key].id
            elif key in mine:
                continue  # a calculation naming itself
            elif key in params and key not in columns:
                target = params[key]
            elif key not in columns and len(captions.get(name, [])) == 1 and captions[name][0].id != calc.id:
                target = captions[name][0].id
        elif source == PARAMETERS_DATASOURCE:
            target = params.get(key)
        else:
            owner = by_ds_alias.get(source, source)
            other = ds_calcs.get(owner, {}).get(key)
            target = other.id if other and other.id != calc.id else None
        if target is None:
            if name not in plain:
                plain.append(name)
        elif target not in ids:
            ids.append(target)
    return ids, plain


# -- a workbook ------------------------------------------------------------------------------------------------


def derive_workbook(ctx: WorkbookContext, summary: FileSummary) -> WorkbookRows:
    """Everything a downloaded workbook adds. Idempotent and deterministic: ids come from the file and the REST ids, never from
    the order of arrival, so two scans of the same workbook write the same rows."""
    out = WorkbookRows()
    wid = ctx.workbook_id
    out.file_meta = {"format": summary.file_format, "version": summary.version, "original-version": summary.original_version,
                     "source-build": summary.source_build}

    # data sources of the file -> dataset ids
    dataset_id: dict[str, str] = {}
    published_id: dict[str, str] = {}  # data source name -> the published data source's id, when the wrapper resolves
    for ds in summary.datasources:
        if not ds.name:
            out.note("data sources without a name were skipped")
            continue
        dataset_id[ds.name] = f"{wid}:{ds.name}"
        if ds.published and ds.published.id and ds.published.id in ctx.published:
            published_id[ds.name] = ctx.published[ds.published.id][0]
        elif ds.published and ds.published.id:
            out.note("published data sources the workbook uses are not in the data source list (not visible, or deleted)")

    # calculations and parameters: ids first, so a formula can refer forwards
    ds_calcs: dict[str, dict[str, _Calc]] = {}
    ordered: list[_Calc] = []
    seen_ids: set[str] = set()
    for ds in summary.datasources:
        if not ds.name or ds.name not in dataset_id:
            continue
        mine = ds_calcs.setdefault(ds.name, {})
        for info in ds.calculations:
            if not info.column:
                out.note("calculations without a name were skipped")
                continue
            calc = _Calc(f"{dataset_id[ds.name]}:{info.column}", ds, info, ObjectRef("dataset", dataset_id[ds.name]))
            if calc.id in seen_ids:
                out.note("calculations share an id with another in the same data source; the first is kept")
                continue
            seen_ids.add(calc.id)
            mine[info.column] = calc
            ordered.append(calc)
    params: dict[str, str] = {}
    param_rows: list[ParameterInfo] = []
    for p in summary.parameters:
        if not p.name:
            out.note("parameters without a name were skipped")
            continue
        pid = f"{wid}:{PARAMETERS_DATASOURCE}:{p.name}"
        if pid in seen_ids:
            out.note("parameters share an id; the first is kept")
            continue
        seen_ids.add(pid)
        params[p.name] = pid
        param_rows.append(p)
    caption_count: dict[str, int] = {}
    for ds in summary.datasources:
        if ds.caption and ds.name:
            caption_count[ds.caption] = caption_count.get(ds.caption, 0) + 1
    out.note("data source captions are shared by two data sources of a workbook, so a reference by caption is left unresolved",
             sum(1 for n in caption_count.values() if n > 1))
    alias_to_name = {ds.caption: ds.name for ds in summary.datasources if ds.caption and ds.name and caption_count[ds.caption] == 1}
    by_alias = {**{k: v for k, v in alias_to_name.items() if k not in dataset_id}, **{n: n for n in dataset_id}}

    # REST views <-> the file's sheets, by name. The reader cleans a file's names (a credential-looking text is redacted, a long name cut): the REST name
    # is cleaned the same way, or `Key: Metrics` would match no view and the sheet that has one would become a second card.
    view_ids: dict[str, list[str]] = {}
    for v in ctx.views:
        if isinstance(v.get("name"), str) and isinstance(v.get("id"), str):
            view_ids.setdefault(_s(v["name"]) or "", []).append(v["id"])
    sheet_count: dict[str, int] = {}
    for s in summary.sheets:
        if s.name:
            sheet_count[s.name] = sheet_count.get(s.name, 0) + 1
    sheets = {s.name: s for s in summary.sheets if s.name and sheet_count[s.name] == 1}  # two sheets whose cleaned names are equal are told apart by neither
    dashboards = {d.name: d for d in summary.dashboards if d.name}
    stories = {s.name: s for s in summary.stories if s.name}
    file_kind: dict[str, str | None] = {}
    for name, kind in [(n, KIND_WORKSHEET) for n in sheets] + [(n, KIND_DASHBOARD) for n in dashboards] + [(n, KIND_STORY) for n in stories]:
        file_kind[name] = None if name in file_kind else kind  # one name for two kinds: leave it unknown
    view_of: dict[str, str] = {}  # file sheet / dashboard name -> its one REST view id
    for name, kind in file_kind.items():
        ids = view_ids.get(name, [])
        if kind is None or len(ids) != 1:
            if len(ids) > 1:
                out.note("view names are shared by two views of one workbook, so those views are left unmatched")
            continue
        view_of[name] = ids[0]
        out.kinds[ids[0]] = kind
    # A worksheet with no view of its name in the REST list (used only on a dashboard, hidden, or not visible to this account) is a card of its own,
    # identified by the workbook and its name. Only when the whole view list was read, and never for a name a view of another kind may carry.
    file_only: dict[str, str] = {}
    if ctx.views_complete:
        file_only = {n: f"{wid}:{n}" for n in sheets if file_kind.get(n) == KIND_WORKSHEET and n not in view_ids}
    card_of: dict[str, str] = {n: view_of[n] for n in sheets if n in view_of} | file_only  # file worksheet name -> its card id
    out.note("worksheets of workbook files have no card: the view list was not read whole, or their name is also a dashboard's, a story's or another view's",
             sum(1 for s in summary.sheets if s.name and s.name not in card_of))

    # who uses which calculation: the data source that holds it, the sheets that list it, the calculations that call it
    users_of: dict[str, dict[ObjectRef, None]] = {c.id: {c.holder: None} for c in ordered}  # ordered sets
    for pid in params.values():
        users_of[pid] = {}
    resolved: dict[str, tuple[list[str], list[str]]] = {}
    memo: dict = {}
    for calc in ordered:
        ids, plain = _resolve(calc, ds_calcs, by_alias, params, memo)
        resolved[calc.id] = (ids, plain)
        for target in ids:
            users_of[target][ObjectRef("calculated_field", calc.id)] = None
    for sheet in summary.sheets:
        vid = card_of.get(sheet.name or "")
        if not vid:
            continue
        for ds_name, columns in sheet.fields_used.items():
            for col in columns:
                if ds_name == PARAMETERS_DATASOURCE:
                    target = params.get(col)
                else:
                    held = ds_calcs.get(by_alias.get(ds_name, ds_name), {}).get(col)
                    target = held.id if held else None
                if target in users_of:
                    users_of[target][ObjectRef("card", vid)] = None
    param_ref_datasets = [ObjectRef("dataset", i) for i in dataset_id.values()]

    # REST connections -> embedded data sources; one that fits two data sources is not given to either
    matches = {ds.name: _match_connections(ds, ctx.connections) for ds in summary.datasources if ds.name in dataset_id}
    claimed: dict[str, int] = {}
    for ids in matches.values():
        for cid in ids:
            claimed[cid] = claimed.get(cid, 0) + 1
    out.note("connections fit more than one data source of their workbook and were given to none", sum(1 for n in claimed.values() if n > 1))

    # datasets
    all_sheets = list(summary.sheets)
    for ds in summary.datasources:
        if not ds.name or ds.name not in dataset_id:
            continue
        calcs_by_col = ds_calcs.get(ds.name, {})
        policies, used_as = _policies(ds, calcs_by_col, all_sheets)
        published = None
        if ds.published and (ds.published.id or ds.published.path):
            published = {"id": published_id.get(ds.name), "name": ctx.published.get(ds.published.id or "", (None, None))[1], "content_url": ds.published.id,
                         "path": ds.published.path, "revision": ds.published.revision, "site": ds.published.site}
        out.datasets.append(Dataset(
            id=dataset_id[ds.name], name=ds.caption or ds.name, provider_type=_provider(ds), owner_id=ctx.owner_id, workspace_id=None,
            created_at=ctx.created_at, updated_at=ctx.updated_at, schema_columns=_schema_columns(ds), column_count=len(ds.columns),
            pdp_policies=policies,
            definition={"kind": "embedded", "workbook_id": wid, "datasource_name": ds.name, "hasExtracts": ds.is_extract, "extract": _extract_dict(ds),
                        "published_source": published, "tables": _tables(ds), "structure": _structure(ds), "filters": [asdict(f) for f in ds.filters],
                        "connections": [asdict(c) for c in ds.connections], "unread_elements": ds.unread_elements},
            raw_payload={"embedded": True, "workbookId": wid, "datasourceName": ds.name, "datasource": _raw_datasource(ds)},
            account_ids=[c for c in matches.get(ds.name, []) if claimed[c] == 1],
        ))
        for col, calc in calcs_by_col.items():
            ids, plain = resolved[calc.id]
            out.calculated_fields.append(_calculated_field(
                calc, ctx.owner_id, used_as.get(col), wid, list(users_of[calc.id]), ids, plain,
                {"workbookId": wid} | ({"origin": calc.info.origin} if calc.info.origin != "datasource" else {}), published_id.get(ds.name)))
    for p in param_rows:
        pid = params[p.name or ""]
        out.calculated_fields.append(CalculatedField(
            id=pid, name=p.caption or _name_of(p.name), owner_id=ctx.owner_id, formula_language=LANG_PARAMETER,
            formula=p.value if p.value is not None else p.formula, data_type=p.datatype,
            linked_object_refs=param_ref_datasets + list(users_of[pid]),
            definition={"kind": "parameter", "datasource_id": None, "workbook_id": wid, "internal_name": p.name, "allowable_values": p.domain_type,
                        "range": p.range, "members": p.allowed_values, "default_formula": p.formula, "role": p.role},
            raw_payload={"caption": p.caption, "name": p.name, "param-domain-type": p.domain_type, "workbookId": wid},
        ))

    # worksheets and dashboards
    def dataset_ids_of(sheet: SheetInfo) -> list[str]:
        ids: list[str] = []
        for ref in sheet.datasources:
            name = by_alias.get(ref, ref)
            for found in (dataset_id.get(name), published_id.get(name)):
                if found and found not in ids:
                    ids.append(found)
        return ids

    for sheet in summary.sheets:
        vid = card_of.get(sheet.name or "")
        if not vid or (vid in out.kinds and out.kinds[vid] != KIND_WORKSHEET):
            continue
        card = {
            "card_type": sheet.marks[0] if sheet.marks else None,
            "dataset_ids": dataset_ids_of(sheet),
            "definition": {"mark": sheet.marks[0] if sheet.marks else None, "marks": sheet.marks, "rows": sheet.rows, "columns": sheet.cols,
                           "filters": [asdict(f) for f in sheet.filters], "fields_used": sheet.fields_used, "slices": sheet.slices,
                           "panes": [asdict(p) for p in sheet.panes], "on_dashboards": sheet.on_dashboards, "hidden": sheet.hidden,
                           "workbook_id": wid, "kind_known": True, "unread_elements": sheet.unread_elements},
        }
        if vid in out.kinds:
            out.cards[vid] = card
        else:
            out.file_cards[vid] = {"name": sheet.name, **card, "definition": {**card["definition"], "source": "workbook file"}}
    zone_target = {**view_of, **file_only}  # what a dashboard's zone name can stand for: a view of the workbook, or a worksheet with none
    for dash in summary.dashboards:
        vid = view_of.get(dash.name or "")
        if not vid or out.kinds.get(vid) != KIND_DASHBOARD:
            continue
        cards = [zone_target[n] for n in dash.sheets if n in zone_target]
        out.note("dashboard worksheets have no card, so their part_of edge is missing", len(dash.sheets) - len(cards))
        datasets: list[str] = []
        for n in dash.sheets:
            if n in sheets:
                for d in dataset_ids_of(sheets[n]):
                    if d not in datasets:
                        datasets.append(d)
        out.dashboards[vid] = {
            "card_ids": cards, "dataset_ids": datasets,
            "filters": [DashboardFilter(field=z.param, label=z.name, filter_type="filter", raw_payload={"zone": z.id, "layout": z.layout})
                        for z in dash.zones if z.type_v2 == "filter" and (z.param or z.name)],
            "layout": {"zones": [asdict(z) for z in dash.zones], "size": dash.size, "device_layouts": dash.device_layouts,
                       "actions": [asdict(a) for a in summary.actions if a.source_dashboard == dash.name], "hidden": dash.hidden,
                       "missing_sheets": dash.missing_sheets, "unread_elements": dash.unread_elements},
        }
    for story in summary.stories:
        vid = view_of.get(story.name or "")
        if not vid or out.kinds.get(vid) != KIND_STORY:
            continue
        captured = []
        for pt in story.points:
            if pt.captured_sheet in card_of and card_of[pt.captured_sheet] not in captured:
                captured.append(card_of[pt.captured_sheet])
        out.dashboards[vid] = {"card_ids": captured, "dataset_ids": [], "filters": [],
                               "layout": {"story_points": [asdict(p) for p in story.points], "zones": [asdict(z) for z in story.zones], "hidden": story.hidden}}
    return out


# -- connections -----------------------------------------------------------------------------------------------------


def _norm(value: Any) -> str | None:
    return value.strip().lower() if isinstance(value, str) and value.strip() else None


def _match_connections(ds: DataSourceInfo, rest: list[dict]) -> list[str]:
    """Ids of the workbook's REST connections that belong to this data source, by what both sides say [U: REST's ``datasource``
    reference is not known to name the embedded data source]. A connection matches when its type equals a file connection's class
    and at least one of server, database, file name, or the data source name agrees and none disagrees. A connection that fits
    two data sources of the workbook is dropped by the caller (it must not be given to the wrong one)."""
    candidates = [c for c in ds.connections if c.role in ("named", "direct") and c.class_]
    out: list[str] = []
    for row in rest:
        if not isinstance(row.get("id"), str):
            continue
        for c in candidates:
            if _connection_agrees(c, row, ds):
                out.append(row["id"])
                break
    return out


def _connection_agrees(c: ConnectionInfo, row: dict, ds: DataSourceInfo) -> bool:
    if _norm(row.get("type")) != _norm(c.class_):
        return False
    attrs = c.attributes
    pairs = [
        (row.get("serverAddress"), attrs.get("server")),
        (row.get("userName"), attrs.get("username")),
        (row.get("dbName") or row.get("databaseName"), attrs.get("dbname") or attrs.get("database")),
    ]
    if isinstance(row.get("serverPort"), (str, int)) and attrs.get("port") is not None:
        pairs.append((str(row["serverPort"]), attrs.get("port")))
    positive = False
    for rest_value, file_value in pairs:
        a, b = _norm(rest_value if rest_value is None or isinstance(rest_value, str) else str(rest_value)), _norm(file_value)
        if a is None or b is None:
            continue
        if a != b:
            return False
        positive = positive or rest_value is not row.get("userName")  # a user name alone does not tie a connection to a data source
    names = {_norm(x) for x in (ds.name, ds.caption, c.caption, c.name)}
    filename = attrs.get("filename")
    if filename:
        names.add(_norm(posixpath.basename(filename.replace("\\", "/"))))
    stored_name = _norm(((row.get("datasource") or {}).get("name")) if isinstance(row.get("datasource"), dict) else None)
    file_ok = _norm(row.get("filename"))
    if stored_name and stored_name in names:
        positive = True
    if file_ok and filename and file_ok == _norm(posixpath.basename(filename.replace("\\", "/"))):
        positive = True
    return positive


# -- a published data source's file ----------------------------------------------------------------------------------------


@dataclass
class DatasourceRows:
    calculated_fields: list[CalculatedField] = field(default_factory=list)
    schema_columns: list[dict] | None = None
    pdp_policies: list[dict] | None = None
    definition: dict = field(default_factory=dict)  # merged into the REST-built definition
    file_meta: dict = field(default_factory=dict)
    notes: dict[str, int] = field(default_factory=dict)


def derive_datasource(datasource_id: str, owner_id: str | None, summary: FileSummary) -> DatasourceRows:
    """What a downloaded ``.tds``/``.tdsx`` adds to a published data source's row. The calculations take the published id."""
    out = DatasourceRows(file_meta={"format": summary.file_format, "version": summary.version, "original-version": summary.original_version})
    ds_calcs: dict[str, dict[str, _Calc]] = {}
    ordered: list[_Calc] = []
    seen_ids: set[str] = set()
    main = next((d for d in summary.datasources if d.connections), summary.datasources[0] if summary.datasources else None)
    holder = ObjectRef("dataset", datasource_id)
    for ds in summary.datasources:
        mine = ds_calcs.setdefault(ds.name or "", {})
        for info in ds.calculations:
            if not info.column:
                out.notes["calculations without a name were skipped"] = out.notes.get("calculations without a name were skipped", 0) + 1
                continue
            calc = _Calc(f"{datasource_id}:{info.column}", ds, info, holder)
            if calc.id in seen_ids:
                out.notes["calculations share an id; the first is kept"] = out.notes.get("calculations share an id; the first is kept", 0) + 1
                continue
            mine[info.column] = calc
            seen_ids.add(calc.id)
            ordered.append(calc)
    # a published source's calculations all belong to the published id, whichever <datasource> of the file held them
    policies: list[dict] = []
    used_as: dict[str, str] = {}
    for ds in summary.datasources:
        got, used = _policies(ds, ds_calcs.get(ds.name or "", {}), [])
        policies += got
        used_as.update(used)
    users_of = {c.id: {holder: None} for c in ordered}
    resolved = {}
    memo: dict = {}
    for calc in ordered:
        ids, plain = _resolve(calc, ds_calcs, {}, {}, memo)
        resolved[calc.id] = (ids, plain)
        for target in ids:
            users_of[target][ObjectRef("calculated_field", calc.id)] = None
    for calc in ordered:
        ids, plain = resolved[calc.id]
        out.calculated_fields.append(_calculated_field(calc, owner_id, used_as.get(calc.info.column or ""), None, list(users_of[calc.id]), ids, plain,
                                                       {"datasourceId": datasource_id} | ({"origin": calc.info.origin} if calc.info.origin != "datasource" else {})))
    if main is not None:
        out.schema_columns = _schema_columns(main)
        out.definition = {"tables": _tables(main), "structure": _structure(main), "extract": _extract_dict(main), "filters": [asdict(f) for f in main.filters],
                          "connections": [asdict(c) for c in main.connections], "file_hasExtract": main.is_extract,
                          "unread_elements": main.unread_elements}
    out.pdp_policies = policies
    return out


def drop_wrapper_copies(workbook: WorkbookRows, published: dict[str, DatasourceRows]) -> int:
    """A workbook data source that wraps a published one (``<repository-location>``) repeats that source's calculations. When the
    published source's own file was read, a wrapper calculation with the same internal name and the same formula is the same
    calculation: the published row owns it. The copy and its policy are dropped, what used the copy (the wrapper data source,
    worksheets, other calculations) is moved onto the published calculation, and references in other calculations are renamed.
    A wrapper calculation that differs (in its formula, or in the definition of a bin or group: a group has no formula) or whose source file was not read
    is kept: it is the only evidence there is. Returns how many."""
    rename: dict[str, str] = {}
    for cf in workbook.calculated_fields:
        pid = (cf.definition or {}).get("wrapper_of")
        owner = published.get(pid) if pid else None
        theirs = next((p for p in (owner.calculated_fields if owner else []) if (p.definition or {}).get("internal_name") == cf.definition.get("internal_name")), None)
        if theirs is not None and (theirs.formula, (theirs.definition or {}).get("grouping")) == (cf.formula, cf.definition.get("grouping")):
            rename[cf.id] = theirs.id
            seen = set(theirs.linked_object_refs)
            theirs.linked_object_refs += [r for r in cf.linked_object_refs if r not in seen]
    if not rename:
        return 0
    workbook.calculated_fields = [cf for cf in workbook.calculated_fields if cf.id not in rename]
    for cf in workbook.calculated_fields:
        cf.linked_object_refs = [ObjectRef(r.object_type, rename.get(r.id, r.id)) if r.object_type == "calculated_field" else r for r in cf.linked_object_refs]
        cf.definition["references"] = [rename.get(i, i) for i in cf.definition.get("references", [])]
    for ds in workbook.datasets:
        ds.pdp_policies = [p for p in ds.pdp_policies or [] if not any(f["calculation"] in rename for f in p["filters"])]
    return len(rename)

"""A memory budget the file workers share (M3, #97).

The scan reads workbook and data source files with several threads. Each one holds the downloaded bytes, the XML inside them and the
element tree built from it, which is about ten times the XML (``files.PARSE_EXPANSION``). The reader caps one file, but nothing capped
the *sum* over the workers: on the scale fake, 8 workers on workbooks with 20 MB of XML peaked at 1,390 MB, and a site of large
workbooks can use gigabytes on a customer's laptop. A worker therefore asks this budget for room, in estimated peak bytes (what
``files.parse_cost`` says the read will take, not the size of the file on the wire), before it starts to parse, and gives it back when
it has made its rows.

Rules, each pinned by a test:

- A request that does not fit waits for the holders to finish. Requests are served in the order they arrived, so a big file is not
  starved by small ones that keep slipping in beside the holders.
- A request larger than the whole budget is never refused: it waits until nothing else is held, then runs alone. Nothing joins it.
- The room is given back on every way out of ``hold``: normally, by an exception, by ``KeyboardInterrupt``/``SystemExit``. A worker that
  is interrupted while it waits leaves the line, so the ones behind it are not stuck.

What this does not bound: the bytes of a file are downloaded before the budget can know what they cost (the parse cost comes from the
archive's own directory, which is at the end of the file), so a worker that has to wait waits holding its downloaded bytes. That is at
most one downloaded file per worker (a compressed archive, or a bare XML file at its full size), each up to the client's
``max_file_bytes`` (1 GiB), so the worst case outside the budget is 8 x ``max_file_bytes``, not ten times its XML. The rows the workers make are also not in the budget; they are held until
the dataset phase (3.10 measures them).
"""

from __future__ import annotations

import collections
import contextlib
import os
import sys
import threading
import time
from collections.abc import Callable, Iterator, Mapping

MIB = 1024 * 1024
GIB = 1024 * MIB

# Where the budget comes from: a fraction of the memory available, because the scan shares the machine with the rows it keeps (about 58 KB
# per workbook measured on the fake), SQLite, the window, and whatever else the person is running. An eighth leaves seven eighths of what is
# free for all of that; it is a judgement, not a measured optimum. Bounded below so that a small laptop can still read an ordinary large
# workbook (256 MiB is a 25 MB XML at 10x, alone) and above so that a big server does not hold files at once it has no use for.
AVAILABLE_FRACTION = 8
MIN_BYTES = 256 * MIB
MAX_BYTES = 2 * GIB
# When the memory cannot be read at all: what a 4 GB laptop with an ordinary session open could give (an eighth of 4 GB), the smallest
# machine this is likely to run on. Too small is slow, too large is a crash, so the fallback is the cautious one.
FALLBACK_BYTES = 512 * MIB

# Set to a number of MiB to use that instead of the machine's. Anything that is not a positive whole number is ignored.
FILE_MEMORY_ENV = "ESTATE_SCANNER_TABLEAU_FILE_MEMORY_MB"
_MAX_ENV_MIB = 1 << 24  # 16 TiB: past this it is a typo, not a setting


class ByteBudget:
    """``with budget.hold(n):`` waits until ``n`` bytes of the total are free, holds them for the block and gives them back."""

    def __init__(self, total: int, *, clock: Callable[[], float] = time.monotonic):
        try:
            self.total = max(1, int(total))
        except (OverflowError, ValueError):  # nan, inf: not a size; the cautious budget instead of a failed scan
            self.total = FALLBACK_BYTES
        self._clock = clock
        self._cond = threading.Condition()
        self._queue: collections.deque[object] = collections.deque()
        self.in_flight = 0
        # What the scan reports: how often a worker had to wait, for how long in all, how often a request was over the whole budget
        # (and so ran alone), and the most held at once.
        self.waits = 0
        self.waited_s = 0.0
        self.oversize = 0
        self.peak_in_flight = 0

    @property
    def waiting(self) -> int:
        with self._cond:
            return len(self._queue)

    def _may_go(self, ticket: object, n: int) -> bool:
        if self._queue[0] is not ticket:
            return False
        # ``in_flight == 0`` is what lets a request larger than the whole budget through, once, alone.
        return self.in_flight + n <= self.total or self.in_flight == 0

    @contextlib.contextmanager
    def hold(self, n: int) -> Iterator[None]:
        n = max(1, int(n))
        ticket = object()
        with self._cond:
            self._queue.append(ticket)
            began: float | None = None
            try:
                while not self._may_go(ticket, n):
                    if began is None:
                        began = self._clock()
                    self._cond.wait()
                waited = self._clock() - began if began is not None else None  # (before anything is taken: a clock that raises costs nothing)
            finally:
                self._queue.remove(ticket)  # admitted or not, it is no longer in line
                self._cond.notify_all()  # the next in line may now be at the head
            self.in_flight += n
            self.peak_in_flight = max(self.peak_in_flight, self.in_flight)
            if waited is not None:
                self.waits += 1
                self.waited_s += waited
            if n > self.total:
                self.oversize += 1
        try:
            yield
        finally:
            with self._cond:
                self.in_flight -= n
                self._cond.notify_all()

    def note(self) -> str | None:
        """The sentence for the scan's notes, or None when no worker ever waited and no file was over the budget."""
        if not self.waits and not self.oversize:
            return None
        parts = []
        if self.waits:
            parts.append(f"{self.waits} file reads waited for room in the memory budget ({self.waited_s:.1f} s in total)")
        if self.oversize:
            parts.append(f"{self.oversize} of the files were larger than the whole budget and were read alone")
        size = f"{self.total / MIB:.1f}" if self.total < 10 * MIB else str(self.total // MIB)
        return (f"{'; '.join(parts)}; the budget is {size} MiB of estimated peak memory for the files being read at once"
                f" (an eighth of the memory available, or {FILE_MEMORY_ENV}); the rows are the same, the scan took longer")


# -- the size ---------------------------------------------------------------------------------------------------------------------


def _within_cgroup(free: int, path: str = "/sys/fs/cgroup/memory.max") -> int:
    """``MemAvailable`` is the host's: in a container with a memory limit the limit is the ceiling (cgroup v2; v1 and no limit leave
    ``free`` as it is)."""
    try:
        with open(path, encoding="ascii") as handle:
            limit = int(handle.read().strip())  # "max" when there is none: ValueError, ignored
    except (OSError, ValueError):
        return free
    return min(free, limit) if limit > 0 else free


def available_memory_bytes() -> int | None:
    """Memory the machine could give a new allocation now, or None when it cannot be read. Linux: ``MemAvailable``. Windows: the
    available physical memory. Elsewhere (macOS has no cheap, standard way to ask) half the physical memory is assumed available: the
    scan is run by a person with other things open, and half is neither the whole machine nor nothing."""
    try:
        if sys.platform.startswith("linux"):
            with open("/proc/meminfo", encoding="ascii") as handle:
                for line in handle:
                    if line.startswith("MemAvailable:"):
                        return _within_cgroup(int(line.split()[1]) * 1024)
            return None
        if sys.platform == "win32":
            import ctypes

            class Status(ctypes.Structure):
                _fields_ = [("length", ctypes.c_ulong), ("load", ctypes.c_ulong), ("total_phys", ctypes.c_ulonglong),
                            ("avail_phys", ctypes.c_ulonglong), ("total_page", ctypes.c_ulonglong), ("avail_page", ctypes.c_ulonglong),
                            ("total_virtual", ctypes.c_ulonglong), ("avail_virtual", ctypes.c_ulonglong), ("avail_ext", ctypes.c_ulonglong)]

            status = Status()
            status.length = ctypes.sizeof(Status)
            if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):  # type: ignore[attr-defined]
                return None
            return int(status.avail_phys)
        return os.sysconf("SC_PHYS_PAGES") * os.sysconf("SC_PAGE_SIZE") // 2
    except (OSError, ValueError, AttributeError, IndexError, KeyError):
        return None


def default_budget_bytes(env: Mapping[str, str] | None = None, available: Callable[[], int | None] = available_memory_bytes) -> int:
    """The environment's setting if it is a sensible one, else an eighth of the memory available (between ``MIN_BYTES`` and
    ``MAX_BYTES``), else ``FALLBACK_BYTES`` when the memory cannot be read."""
    env = os.environ if env is None else env
    raw = (env.get(FILE_MEMORY_ENV) or "").strip()
    if len(raw) <= 9 and raw.isascii() and raw.isdigit() and 0 < int(raw) <= _MAX_ENV_MIB:  # (int() of thousands of digits raises)
        return int(raw) * MIB
    try:
        free = available()
    except Exception:  # noqa: BLE001 -- an unreadable machine is the fallback, never a failed scan
        free = None
    if not free or free <= 0:
        return FALLBACK_BYTES
    return max(MIN_BYTES, min(MAX_BYTES, free // AVAILABLE_FRACTION))

"""A Domo session for BIMControl's own live calls.

Deliberately separate from EstateScanner's. That tool stores its session
in the estate database's `platform_sessions` table, and the rule in
estate/reader.py is that BIMControl never reads it: a scan file gets
copied around and handed over, and quietly lifting a live credential out
of one would make every copy of it a liability.

So BIMControl takes its own session, from a cookie file the operator
exports or from the environment. A Playwright sign-in like EstateScanner's
is the obvious next step; it is not here yet because the first use (a CSV
export during a migration) happens on a machine where somebody has just
signed in anyway.

Same shape as Domo's own web app uses: session cookies plus the
`x-csrf-token` header. There is no API key and no OAuth app.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import requests

# The cookies Domo's private API actually needs. Others in an export are
# harmless but pointless to carry.
SESSION_COOKIES = ("PLAY_SESSION", "SESSION_TOE", "_pubweb_idc", "csrf-token", "DA-SID", "DA-SSID")


class DomoAuthError(Exception):
    pass


class DomoSessionExpired(DomoAuthError):
    pass


@dataclass
class DomoSession:
    instance: str
    cookies: dict[str, str]
    csrf_token: str | None = None

    @property
    def base_url(self) -> str:
        return f"https://{self.instance}.domo.com"

    @classmethod
    def from_cookie_file(cls, instance: str, path: str | Path) -> "DomoSession":
        """Load a cookie jar exported from a browser or by Playwright.

        Accepts either a bare mapping or the list-of-objects shape that
        `context.cookies()` and most browser extensions produce, since
        whichever one the operator has to hand is the one they will use.
        """
        path = Path(path).expanduser()
        if not path.exists():
            raise DomoAuthError(f"No Domo cookie file at {path}")
        payload = json.loads(path.read_text())

        if isinstance(payload, dict) and "cookies" in payload:
            payload = payload["cookies"]
        if isinstance(payload, dict):
            cookies = {str(k): str(v) for k, v in payload.items()}
        else:
            cookies = {
                str(c["name"]): str(c["value"])
                for c in payload
                if isinstance(c, dict) and c.get("name") and c.get("value") is not None
            }
        if not cookies:
            raise DomoAuthError(f"{path} holds no cookies")
        return cls(instance=instance, cookies=cookies, csrf_token=cookies.get("csrf-token"))

    @classmethod
    def from_env(cls, instance: str | None = None) -> "DomoSession":
        instance = instance or os.environ.get("DOMO_INSTANCE")
        cookie_file = os.environ.get("DOMO_COOKIE_FILE")
        if not instance:
            raise DomoAuthError("No Domo instance. Set DOMO_INSTANCE or pass one.")
        if not cookie_file:
            raise DomoAuthError(
                "No Domo session. Set DOMO_COOKIE_FILE to a cookie jar exported "
                "from a signed-in browser session."
            )
        return cls.from_cookie_file(instance, cookie_file)

    def requests_session(self) -> requests.Session:
        session = requests.Session()
        for name, value in self.cookies.items():
            session.cookies.set(name, value, domain=".domo.com")
        session.headers.update({"accept": "application/json"})
        if self.csrf_token:
            session.headers["x-csrf-token"] = self.csrf_token
        return session

    def redacted(self) -> dict[str, Any]:
        """Safe to log or put in an event: names only, never values."""
        return {"instance": self.instance, "cookies": sorted(self.cookies), "has_csrf": bool(self.csrf_token)}

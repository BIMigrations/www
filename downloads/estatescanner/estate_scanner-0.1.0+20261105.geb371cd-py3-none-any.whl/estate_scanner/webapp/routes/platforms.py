from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from estate_scanner.core import registry
from estate_scanner.core.instances import normalise_instance
from estate_scanner.core.platform import PlatformError
from estate_scanner.storage import db

from ..deps import get_conn
from ..jobs import jobs

router = APIRouter()


def _descriptor(key: str):
    try:
        return registry.get_platform(key)
    except KeyError:
        raise HTTPException(404, f"Unknown platform: {key}") from None


@router.get("")
def list_platforms():
    return [
        {"key": d.key, "display_name": d.display_name, "status": d.status, "auth_mode": d.auth_mode,
         "instance_hint": d.instance_hint, "notice": d.notice,
         "connect_fields": [
             {"name": f.name, "label": f.label, "placeholder": f.placeholder, "help": f.help,
              "secret": f.secret, "required": f.required}
             for f in d.connect_fields
         ]}
        for d in registry.all_platforms()
    ]


@router.get("/{key}/sessions")
def list_sessions(key: str, conn=Depends(get_conn)):
    _descriptor(key)
    rows = conn.execute(
        "SELECT instance, updated_at FROM platform_sessions WHERE platform = ? ORDER BY updated_at DESC", (key,)
    ).fetchall()
    return [{"instance": r["instance"], "updated_at": r["updated_at"]} for r in rows]


class ConnectRequest(BaseModel):
    instance: str | None = None
    cookie_file: str | None = None
    # Tableau's token sign-in (the Connect form's four fields). The secret is written to a mode-600
    # file beside the database and never to platform_sessions; it is not echoed back anywhere.
    server: str | None = None
    site: str | None = None
    token_name: str | None = None
    secret: str | None = None

    def sign_in_fields(self) -> dict:
        return {k: v for k, v in (("server", self.server), ("site", self.site), ("token_name", self.token_name), ("secret", self.secret)) if v is not None}


@router.post("/{key}/connect")
def connect_platform(key: str, body: ConnectRequest, request: Request):
    """Kicks off sign-in in a background thread and returns immediately --
    for Domo this opens a real, visible browser window and can take minutes
    while a human completes SSO. Poll GET .../connect/{job_id} for status.
    """
    descriptor = _descriptor(key)
    db_path = request.app.state.db_path
    fields = body.sign_in_fields()
    try:
        derived = descriptor.authenticator_cls().instance_for(**fields)
    except PlatformError as exc:
        raise HTTPException(400, str(exc)) from None
    # the name the database stores and the sign-in URL is built from
    instance = normalise_instance(key, derived or body.instance)
    if not instance:
        raise HTTPException(400, "Name the instance to connect to.")

    def do_connect(job):
        authenticator = descriptor.authenticator_cls()
        # The name as typed, for a platform whose instance name is case-sensitive (a Tableau site); the
        # database key (`instance`) is the lower-cased one.
        login_name = (derived or body.instance or "").strip() if authenticator.case_sensitive_instance else instance
        try:
            if body.cookie_file:
                session = authenticator.load_cookie_file(instance, body.cookie_file)
            else:
                # secret_dir: the secret file sits beside this database, not in it
                session = authenticator.login_interactive(login_name, secret_dir=Path(db_path).parent, **fields)
        except Exception as exc:
            # The job's error text goes to the browser. The adapters keep secrets out of their messages;
            # this is the backstop for one that did not.
            secret = body.secret
            if secret and secret in str(exc):
                raise PlatformError(str(exc).replace(secret, "***")) from None
            raise
        conn = db.connect(db_path)
        try:
            db.persist_session(conn, session)
        finally:
            conn.close()
        return {"instance": instance}

    job = jobs.start("connect", do_connect)
    return {"job_id": job.id}


@router.get("/{key}/connect/{job_id}")
def connect_status(key: str, job_id: str):
    _descriptor(key)
    job = jobs.get(job_id)
    if job is None:
        raise HTTPException(404, "Unknown job")
    return {"status": job.status, "result": job.result, "error": job.error}

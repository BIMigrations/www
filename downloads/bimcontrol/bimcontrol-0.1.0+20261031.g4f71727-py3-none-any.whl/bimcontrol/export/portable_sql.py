"""A portable rendering of the SQL the converter wrote, and of each dataset's table.

The converter's SQL is Redshift SQL, the dialect the warehouse accepted and checked. "Standard SQL" is a
judgement, so this does two honest things and claims no more:

1. **Renders** it in PostgreSQL syntax, the widely available dialect closest to ISO SQL: the query is parsed as
   Redshift, written out for PostgreSQL, and the result is parsed again to prove it is still a query. Redshift-only
   syntax (``::`` casts, ``DATEADD``, ``NVL``, ``~``) becomes PostgreSQL's spelling. It is **not executed** anywhere;
   the warehouse's check applies to the Redshift original only. (sqlglot's dialect-less output was tried first and
   rejected: it leaks the library's internal function names, such as TS_OR_DS_DIFF, which no database has.)
2. **Lists the constructs outside a core ANSI set** (functions and operators a database may not have, or may
   spell differently), by name and count, so the reader knows where a port needs a person. The core set below is
   my reading of ISO SQL plus what every mainstream database accepts; a construct not in it is listed, not hidden.

sqlglot is optional (``pip install 'bimcontrol[export]'``). Without it nothing is rendered and the export says so.
"""

from __future__ import annotations

from collections import Counter
from typing import Any

try:  # optional extra; see pyproject.toml
    import sqlglot
    from sqlglot import exp
except ImportError:  # pragma: no cover - exercised only where the extra is absent
    sqlglot = None  # type: ignore[assignment]
    exp = None  # type: ignore[assignment]

RENDERED_DIALECT = "postgresql"

# Node classes counted as portable: structure, comparison and boolean logic, arithmetic, CAST, CASE, COALESCE,
# NULLIF, the standard aggregates and ranking/offset window functions, EXTRACT, POSITION, SUBSTRING, TRIM,
# UPPER/LOWER, || concatenation, CURRENT_DATE/TIMESTAMP, set operations, ABS/FLOOR/CEIL/ROUND.
_PORTABLE = {
    "Select", "From", "Where", "Group", "Having", "Order", "Ordered", "Limit", "Offset", "Join", "Union", "Intersect",
    "Except", "With", "CTE", "TableAlias", "Subquery", "Table", "Column", "Identifier", "Star", "Alias", "Paren",
    "Tuple", "Distinct", "Window", "WindowSpec", "Literal", "Null", "Boolean", "Var", "Placeholder", "Qualify",
    "EQ", "NEQ", "GT", "GTE", "LT", "LTE", "And", "Or", "Not", "In", "Between", "Like", "Is", "Exists", "Any", "All",
    "Add", "Sub", "Mul", "Div", "Mod", "Neg", "DPipe", "Cast", "Case", "If", "Coalesce", "Nullif",
    "Sum", "Avg", "Min", "Max", "Count", "RowNumber", "Rank", "DenseRank", "Lead", "Lag", "FirstValue", "LastValue",
    "Extract", "StrPosition", "Substring", "Trim", "Upper", "Lower", "Length", "Abs", "Floor", "Ceil", "Round",
    "CurrentDate", "CurrentTimestamp", "CurrentTime", "Interval", "DataType", "DataTypeParam",
    "ParameterizedAgg", "Condition", "Dot", "Bracket", "Values", "Lateral", "Unnest", "JoinHint", "Hint", "Cube",
    "Rollup", "GroupingSets", "Ntile", "PercentRank", "CumeDist", "Stddev", "Variance", "Between",
}

# What to say about the constructs seen most often in converted Domo flows.
_ADVICE = {
    "Trunc": "date truncation: spelled DATE_TRUNC, TRUNC or DATETRUNC by database",
    "TsOrDsDiff": "date difference: DATEDIFF, DATE_DIFF or subtraction by database",
    "TsOrDsAdd": "date addition: DATEADD, DATE_ADD or interval arithmetic by database",
    "DateAdd": "date addition: DATEADD, DATE_ADD or interval arithmetic by database",
    "DateDiff": "date difference: DATEDIFF, DATE_DIFF or subtraction by database",
    "RegexpLike": "regular-expression match: ~, REGEXP_LIKE or RLIKE by database",
    "RegexpReplace": "regular-expression replace: spelling and flags differ by database",
    "RegexpExtract": "regular-expression extract: spelling differs by database",
    "Replace": "REPLACE is near-universal but not in the ISO core",
    "SplitPart": "SPLIT_PART exists in PostgreSQL-family databases, not in the ISO core",
    "Left": "LEFT is common but not in the ISO core (use SUBSTRING)",
    "Right": "RIGHT is common but not in the ISO core (use SUBSTRING)",
    "TimeToStr": "date formatting: TO_CHAR, FORMAT or DATE_FORMAT by database, with different format strings",
    "StrToTime": "date parsing: TO_TIMESTAMP, PARSE_DATETIME or STR_TO_DATE by database",
    "AnyValue": "ANY_VALUE is not available everywhere",
    "ILike": "ILIKE is PostgreSQL-family only",
    "Concat": "CONCAT() with several arguments is not ISO (|| is)",
    "GroupConcat": "string aggregation: LISTAGG, STRING_AGG or GROUP_CONCAT by database",
    "TryCast": "TRY_CAST is not available everywhere",
    "Pow": "POWER spelling and typing differ by database",
}


def available() -> bool:
    return sqlglot is not None


def _node_name(node: Any) -> str:
    return type(node).__name__


def constructs(tree: Any) -> list[dict[str, Any]]:
    """Constructs in ``tree`` outside the portable core: ``[{construct, count, note}]``, most frequent first."""
    seen: Counter[str] = Counter()
    for node in tree.walk():
        node = node[0] if isinstance(node, tuple) else node
        name = _node_name(node)
        if name == "Anonymous":
            seen[f"function {str(node.name).upper()}"] += 1
        elif name not in _PORTABLE:
            seen[name] += 1
    return [{"construct": c, "count": n, "note": _ADVICE.get(c)} for c, n in sorted(seen.items(), key=lambda kv: (-kv[1], kv[0]))]


def render(sql: str, read: str = "redshift") -> dict[str, Any]:
    """``{rendered, parsed, roundtrip_ok, not_portable, error}``. ``rendered`` is None when the SQL did not parse."""
    if sqlglot is None:
        return {"rendered": None, "parsed": False, "roundtrip_ok": False, "not_portable": [],
                "error": "sqlglot is not installed (pip install 'bimcontrol[export]')"}
    try:
        tree = sqlglot.parse_one(sql, read=read)
        rendered = tree.sql(dialect="postgres", pretty=True)
    except (Exception, RecursionError) as exc:  # noqa: BLE001 -- ParseError / TokenError, or a query nested too deep to print: "not rendered"
        return {"rendered": None, "parsed": False, "roundtrip_ok": False, "not_portable": [],
                "error": f"{type(exc).__name__}: {str(exc)[:200]}"}
    try:
        sqlglot.parse_one(rendered, read="postgres")
        roundtrip = True
    except Exception:  # noqa: BLE001
        roundtrip = False
    return {"rendered": rendered + "\n", "parsed": True, "roundtrip_ok": roundtrip,
            "not_portable": constructs(tree), "error": None}


# Domo / Power BI column type -> ISO SQL type.
_DDL_TYPES = {
    "STRING": "VARCHAR(65535)", "LONG": "BIGINT", "INTEGER": "INTEGER", "DOUBLE": "DOUBLE PRECISION",
    "DECIMAL": "DECIMAL(38, 10)", "BOOLEAN": "BOOLEAN", "DATE": "DATE", "DATETIME": "TIMESTAMP",
    "TIMESTAMP": "TIMESTAMP",
}


def _quote(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


def create_table(table: str, columns: list[dict[str, Any]]) -> dict[str, Any]:
    """``CREATE TABLE`` for a dataset's columns in ISO types. A column type the table does not know becomes
    ``VARCHAR`` and is listed in ``guessed`` rather than hidden. Domo keeps no precision, so DECIMAL is a wide default."""
    lines, guessed, seen = [], [], set()
    for col in columns:
        name = col.get("name")
        if not name or name in seen:
            continue
        seen.add(name)
        kind = str(col.get("type") or "").upper()
        sql_type = _DDL_TYPES.get(kind)
        if sql_type is None:
            sql_type = "VARCHAR(65535)"
            guessed.append({"column": name, "source_type": col.get("type")})
        lines.append(f"  {_quote(name)} {sql_type}")
    body = ",\n".join(lines) if lines else ""
    return {"sql": f"CREATE TABLE {_quote(table)} (\n{body}\n);\n" if lines else None, "guessed": guessed}

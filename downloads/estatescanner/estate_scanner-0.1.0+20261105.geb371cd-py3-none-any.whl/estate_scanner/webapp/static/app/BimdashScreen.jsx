import React from 'react';

const CODE_LENGTH = 4;

// The characters of a code a person typed or pasted: upper case, letters and digits only (fullwidth letters folded, spaces, dashes and
// zero-width characters dropped). From a longer text ("BimDash code: 4WEA") the standalone four-character word that is written in capitals
// and digits, as BimDash shows a code, is taken; otherwise the first four characters.
function codeCharacters(text) {
  const flat = (text || '').normalize('NFKC').replace(/[\u200B-\u200F\u2060\uFEFF\u00AD]/g, '');
  const letters = flat.replace(/[^A-Za-z0-9]/g, '');
  const word = flat.match(/(?:^|[^A-Za-z0-9])([A-Z0-9]{4})(?![A-Za-z0-9])/);
  return (word && letters.length > CODE_LENGTH ? word[1] : flat).toUpperCase().replace(/[^A-Z0-9]/g, '');
}

// Four boxes for the code BimDash shows, one real <input> each, like the boxes on BimDash's own page. `value` is an array of four
// one-character strings. Typing replaces the character in that box and moves on; Backspace clears it (and steps back from an empty
// box); a paste, or an autofill of several characters, fills the boxes from the first.
function CodeBoxes({ value, onChange, onSubmit, disabled, focusRef }) {
  const refs = React.useRef([]);
  React.useEffect(function () {
    focusRef.current = function () { if (refs.current[0]) refs.current[0].focus(); };
  }, [focusRef]);

  function fill(from, text) {
    const typed = codeCharacters(text);
    if (!typed) return;
    const next = value.slice();
    for (let k = 0; k < typed.length && from + k < CODE_LENGTH; k++) next[from + k] = typed[k];
    onChange(next);
    const at = Math.min(from + typed.length, CODE_LENGTH - 1);
    if (refs.current[at]) refs.current[at].focus();
  }

  function onKeyDown(index, e) {
    if (e.key === 'Backspace') {
      e.preventDefault();
      const next = value.slice();
      if (value[index]) {
        next[index] = '';
        onChange(next);
      } else if (index > 0) {
        next[index - 1] = '';
        onChange(next);
        refs.current[index - 1].focus();
      }
    } else if (e.key === 'ArrowLeft' && index > 0) {
      refs.current[index - 1].focus();
    } else if (e.key === 'ArrowRight' && index < CODE_LENGTH - 1) {
      refs.current[index + 1].focus();
    } else if (e.key === 'Enter') {
      e.preventDefault();
      onSubmit();
    }
  }

  return (
    <div role="group" aria-label="Code from BimDash" style={{ display: 'flex', gap: 10 }}>
      {Array.from({ length: CODE_LENGTH }).map(function (_, i) {
        return (
          <input
            key={i}
            ref={function (el) { refs.current[i] = el; }}
            aria-label={'Character ' + (i + 1) + ' of ' + CODE_LENGTH}
            value={value[i] || ''}
            onChange={function (e) { fill(i, e.target.value); }}
            onKeyDown={function (e) { onKeyDown(i, e); }}
            onPaste={function (e) { e.preventDefault(); fill(0, e.clipboardData.getData('text')); }}
            onFocus={function (e) { e.target.select(); }}
            disabled={disabled}
            autoComplete="off"
            autoCapitalize="characters"
            spellCheck={false}
            style={{
              width: 56, height: 64, textAlign: 'center', boxSizing: 'border-box',
              fontFamily: 'var(--font-mono)', fontSize: 'var(--text-3xl)', fontWeight: 'var(--weight-medium)',
              color: 'var(--text-primary)', background: disabled ? 'var(--surface-sunken)' : 'var(--surface-card)',
              border: '1px solid var(--border-default)', borderRadius: 'var(--radius-control)', outline: 'none',
              opacity: disabled ? 0.6 : 1,
            }}
          />
        );
      })}
    </div>
  );
}

function when(iso) {
  const d = new Date(iso);
  return isNaN(d.getTime()) ? iso : d.toLocaleString();
}

export function BimdashScreen({ onChanged }) {
  const [state, setState] = React.useState(null); // { connected, device_name, paired_at, bimdash, org_id, org_name, suggested_name, problem }
  const [code, setCode] = React.useState(['', '', '', '']); // one character per box
  const typedCode = code.join('');
  const busyRef = React.useRef(false); // set at once, where `busy` only changes on the next render: a second Enter in the same tick must not post again
  const focusCode = React.useRef(null);
  const [name, setName] = React.useState('');
  const [busy, setBusy] = React.useState(false);
  const [confirmingDisconnect, setConfirmingDisconnect] = React.useState(false);
  const [error, setError] = React.useState(null);

  React.useEffect(function () {
    fetchBimdash().then(function (s) {
      setState(s);
      setName(s.suggested_name || '');
    }).catch(function (e) { setError(String(e.message || e)); });
  }, []);

  function connect() {
    if (busyRef.current || typedCode.length !== CODE_LENGTH) return;
    busyRef.current = true;
    setBusy(true);
    setError(null);
    connectBimdash(typedCode, name.trim()).then(function (s) {
      setState(s);
      setCode(['', '', '', '']);
      if (onChanged) onChanged();
    }).catch(function (e) {
      setError(String(e.message || e));
      setCode(['', '', '', '']);
    }).then(function () {
      busyRef.current = false;
      setBusy(false);
      // the boxes were disabled while the call ran, which drops the focus: put it back in the first box for the next code
      setTimeout(function () { if (focusCode.current) focusCode.current(); }, 0);
    });
  }

  function disconnect() {
    setBusy(true);
    setError(null);
    disconnectBimdash().then(function (s) {
      setState(s);
      setName(s.suggested_name || '');
      setConfirmingDisconnect(false);
      if (onChanged) onChanged();
    }).catch(function (e) { setError(String(e.message || e)); }).then(function () { setBusy(false); });
  }

  if (!state) return error ? <div style={{ padding: 24 }}><Banner tone="error" title="Could not read the BimDash connection">{error}</Banner></div> : <Spinner />;

  const connected = !!state.connected;

  return (
    <div style={{ padding: 24, display: 'flex', flexDirection: 'column', gap: 16, maxWidth: 720 }}>
      <div>
        <div style={{ fontSize: 'var(--text-3xl)', fontWeight: 'var(--weight-semibold)', letterSpacing: 'var(--tracking-heading)' }}>
          Connect to <span style={{ fontFamily: 'var(--font-editorial)', fontStyle: 'italic', fontWeight: 400, color: 'var(--provenance-target)' }}>BimDash</span>
        </div>
        <div style={{ fontSize: 'var(--text-md)', color: 'var(--text-secondary)', marginTop: 4 }}>
          BimDash is where your BI Migrations organisation tracks the migration. Pairing tells BimDash that this copy of Estate
          Scanner is yours. It sends BimDash the code, a name for this machine, the operating system and this app's version, and
          nothing from your scans.
        </div>
      </div>

      {state.problem && <Banner tone="warn" title="The saved connection cannot be used">{state.problem}</Banner>}
      {error && <Banner tone="error" title={connected ? 'Could not disconnect' : 'Could not connect'}>{error}</Banner>}

      <Card title="Pair this machine" actions={<StatusDot status={connected ? 'ok' : 'idle'} label={connected ? 'Connected' : 'Not connected'} />}>
        {connected ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div style={{ fontSize: 'var(--text-lg)', fontWeight: 'var(--weight-semibold)', letterSpacing: 'var(--tracking-heading)' }}>
              Connected to <span style={{ fontFamily: 'var(--font-editorial)', fontStyle: 'italic', fontWeight: 400 }}>{state.org_name || state.org_id}</span>
            </div>
            <KeyValueList items={[
              { label: 'Listed in BimDash as', value: state.device_name },
              { label: 'Paired', value: when(state.paired_at) },
              { label: 'BimDash address', value: state.bimdash, mono: true },
              { label: 'Organisation', value: state.org_name || state.org_id, mono: !state.org_name },
            ]} />
            {confirmingDisconnect ? (
              <Banner tone="warn" title="Remove the saved code from this machine?" actions={
                <>
                  <Button size="sm" variant="danger" onClick={disconnect} loading={busy}>Disconnect</Button>
                  <Button size="sm" variant="secondary" onClick={function () { setConfirmingDisconnect(false); }} disabled={busy}>Keep it</Button>
                </>
              }>
                BimDash keeps listing this machine until you remove it under Devices in BimDash. To connect again you need a new code.
              </Banner>
            ) : (
              <div><Button variant="secondary" onClick={function () { setConfirmingDisconnect(true); }}>Disconnect</Button></div>
            )}
          </div>
        ) : (
          <form style={{ display: 'flex', flexDirection: 'column', gap: 16 }} onSubmit={function (e) { e.preventDefault(); connect(); }}>
            <ol style={{ margin: 0, paddingLeft: 20, display: 'flex', flexDirection: 'column', gap: 4, fontSize: 'var(--text-md)', color: 'var(--text-secondary)', lineHeight: 'var(--leading-body)' }}>
              <li>In BimDash, open <b>Scan your estate</b>: it shows a four-character code.</li>
              <li>Type it below or paste it. A code works once and lasts 10 minutes.</li>
              <li>Choose <b>Connect</b>. If the code has run out, make a new one in BimDash.</li>
            </ol>
            {state.bimdash && (
              <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-secondary)' }}>
                Pairs with BimDash at <span style={{ fontFamily: 'var(--font-mono)' }}>{state.bimdash}</span>. A code only works in the BimDash that made it.
              </div>
            )}
            <Field label="Code from BimDash" hint="Four characters, letters and digits. Pasting fills all four boxes.">
              <CodeBoxes value={code} onChange={setCode} onSubmit={connect} disabled={busy} focusRef={focusCode} />
            </Field>
            <Field label="Name for this machine" hint="How BimDash lists it under Devices. It is sent to BimDash, so change it if the machine's own name is not for sharing." htmlFor="bimdash-device-name">
              <Input id="bimdash-device-name" value={name} onChange={function (e) { setName(e.target.value); }} maxLength={80} disabled={busy} />
            </Field>
            <div>
              <Button type="submit" disabled={busy || typedCode.length !== CODE_LENGTH} loading={busy}>
                {busy ? 'Connecting…' : 'Connect'}
              </Button>
            </div>
          </form>
        )}
      </Card>

      <Card title="What stays on this machine">
        <ul style={{ margin: 0, paddingLeft: 20, display: 'flex', flexDirection: 'column', gap: 6, fontSize: 'var(--text-md)', color: 'var(--text-secondary)', lineHeight: 'var(--leading-body)' }}>
          <li>Pairing gives this machine a long key of its own. It is kept in this machine's OS keychain (Windows Credential Manager, macOS Keychain) -- never in a plain-text file, never inside the database -- so a scan you export or email does not carry it.</li>
          <li>The key is never shown, never written to a log and never sent to this page.</li>
          <li>Pairing does not send any scan. This page does not send scan results to BimDash yet.</li>
          <li>To stop BimDash accepting this machine, remove it under Devices in BimDash; Disconnect here removes the key from this machine only.</li>
        </ul>
      </Card>

      <Card title="No window on this machine?">
        <div style={{ fontSize: 'var(--text-md)', color: 'var(--text-secondary)', lineHeight: 'var(--leading-body)' }}>
          On a machine without a screen, run <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-sm)' }}>estate-scanner connect</span> and type
          the code when it asks, or give it with the command: <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-sm)' }}>estate-scanner connect 4WEA</span>.
        </div>
      </Card>
    </div>
  );
}

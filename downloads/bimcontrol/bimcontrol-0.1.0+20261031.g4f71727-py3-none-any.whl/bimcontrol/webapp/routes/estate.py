"""Estate browsing: which scan is loaded, which dashboards it holds, and
what each dashboard's migration closure looks like.

Read-only throughout -- these endpoints never write to the estate database.
A fresh EstateReader per request, closed when the request ends, keeps the
same connection-per-request discipline EstateScanner uses.
"""

from __future__ import annotations

from typing import Any

import tempfile
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Query, Request

from bimcontrol import paths
from bimcontrol.estate import importer
from bimcontrol.estate.closure import card_chart_type, resolve_dashboard
from bimcontrol.estate.reader import EstateNotFoundError, EstateObject, EstateReader

router = APIRouter()


def get_reader(request: Request, platform: str = "domo"):
    try:
        reader = EstateReader(request.app.state.estate_db_path, platform=platform)
    except EstateNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    try:
        yield reader
    finally:
        reader.close()


@router.get("/status")
def status(request: Request, reader: EstateReader = Depends(get_reader)) -> dict[str, Any]:
    return {
        "estate_db_path": str(request.app.state.estate_db_path),
        "platform": reader.platform,
        "scans": reader.scans(),
        "latest_completed_scan": reader.latest_completed_scan(),
        "counts": reader.counts(),
    }


@router.post("/import")
async def import_scan(request: Request) -> dict[str, Any]:
    """Load an EstateScanner export zip, sent as the raw request body (no
    multipart dependency). The extracted database becomes the loaded estate;
    an existing database is never overwritten, the import gets its own file."""
    paths.estates_dir().mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=paths.estates_dir(), suffix=".zip.partial", delete=False) as tmp:
        upload = Path(tmp.name)
        async for chunk in request.stream():
            tmp.write(chunk)
    try:
        result = importer.import_zip(upload)
    except importer.ImportError_ as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    finally:
        upload.unlink(missing_ok=True)
    previous = request.app.state.estate_db_path
    request.app.state.estate_db_path = result["path"]
    return {
        "estate_db_path": str(result["path"]),
        "previous_estate_db_path": str(previous),
        "manifest": result["manifest"],
    }


@router.get("/dashboards")
def list_dashboards(
    reader: EstateReader = Depends(get_reader),
    q: str | None = None,
    page: int = 1,
    page_size: int = Query(50, le=500),
    order: str = "cards",
) -> dict[str, Any]:
    offset = (max(page, 1) - 1) * page_size
    return {
        "total": reader.count_dashboards(search=q),
        "page": page,
        "page_size": page_size,
        "items": reader.list_dashboards(search=q, limit=page_size, offset=offset, order=order),
    }


@router.get("/dashboards/{dashboard_id}")
def get_dashboard(dashboard_id: str, reader: EstateReader = Depends(get_reader)) -> dict[str, Any]:
    try:
        dashboard = reader.get("dashboard", dashboard_id)
    except EstateNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return {
        "id": dashboard.id,
        "name": dashboard.name,
        "owner_id": dashboard.row.get("owner_id"),
        "parent_dashboard_id": dashboard.row.get("parent_dashboard_id"),
        "filters": dashboard.json_column("filters_json"),
        "layout": dashboard.json_column("layout_json"),
    }


@router.get("/dashboards/{dashboard_id}/closure")
def get_closure(dashboard_id: str, reader: EstateReader = Depends(get_reader)) -> dict[str, Any]:
    """The full migration unit: what would have to be converted to rebuild
    this dashboard on the target platform."""
    try:
        closure = resolve_dashboard(reader, dashboard_id)
    except EstateNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    return {
        "summary": closure.summary(),
        "dashboard": {"id": closure.dashboard.id, "name": closure.dashboard.name},
        "cards": [
            {
                "id": c.id,
                "name": c.name,
                "card_type": c.row.get("type"),
                "chart_type": card_chart_type(c),
                "dataset_ids": closure.card_datasets.get(c.id, []),
            }
            for c in closure.cards
        ],
        "datasets": [
            {
                "id": d.id,
                "name": d.name,
                "provider_type": d.row.get("provider_type"),
                "row_count": d.row.get("row_count"),
                "column_count": d.row.get("column_count"),
                "produced_by": closure.dataset_producer.get(d.id),
                "is_root": d.id in closure.root_dataset_ids,
            }
            for d in closure.datasets
        ],
        "dataflows": [
            {
                "id": f.id,
                "name": f.name,
                "engine": f.row.get("engine"),
                "num_inputs": f.row.get("num_inputs"),
                "num_outputs": f.row.get("num_outputs"),
            }
            for f in closure.dataflows
        ],
        "calculated_fields": [
            {
                "id": cf.id,
                "name": cf.name,
                "formula": cf.row.get("formula"),
                "data_type": cf.row.get("data_type"),
            }
            for cf in closure.calculated_fields
        ],
        "missing": [{"object_type": t, "id": i} for t, i in closure.missing],
    }


@router.get("/cards/{card_id}")
def get_card(card_id: str, reader: EstateReader = Depends(get_reader)) -> dict[str, Any]:
    """One card with the parts a migration actually reads: its chart type
    and its column roles (`dataSubscriptions`), which is where Domo records
    what sits on each axis."""
    try:
        card = reader.get("card", card_id)
    except EstateNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return {
        "id": card.id,
        "name": card.name,
        "card_type": card.row.get("type"),
        "chart_type": card_chart_type(card),
        "dataset_ids": reader.datasets_for_card(card),
        "data_subscriptions": card.raw.get("dataSubscriptions"),
        "definition": card.definition,
    }


@router.get("/datasets/{dataset_id}")
def get_dataset(dataset_id: str, reader: EstateReader = Depends(get_reader)) -> dict[str, Any]:
    try:
        dataset = reader.get("dataset", dataset_id)
    except EstateNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return _dataset_payload(dataset, reader)


def _dataset_payload(dataset: EstateObject, reader: EstateReader) -> dict[str, Any]:
    return {
        "id": dataset.id,
        "name": dataset.name,
        "provider_type": dataset.row.get("provider_type"),
        "row_count": dataset.row.get("row_count"),
        "columns": dataset.json_column("schema_columns_json"),
        "produced_by": reader.producing_dataflow(dataset.id),
    }

"""Importing this package registers every known platform adapter (real or
stub) into estate_scanner.core.registry. Anything that wants the registry
fully populated -- the CLI, the FastAPI app -- imports this package first.
"""

from . import domo, looker, powerbi, qlik, tableau  # noqa: F401

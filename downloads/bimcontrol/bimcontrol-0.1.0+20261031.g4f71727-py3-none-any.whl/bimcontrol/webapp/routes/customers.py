"""Customer batches: the rollup `bimcontrol customer` writes, and starting and stopping a batch from the screen.

The rollup is a file (`<home>/customers/<name>/rollup.json`), rewritten after
every dashboard of a batch, so reading it never touches the control database
or a running batch. A customer is named by its directory, and a request's
name is only ever compared with the directory listing, never joined onto a
path: that is the whole defence against `../`.

Starting a batch is the only thing here that writes: it saves the manifest next to the rollup and runs the
batch on a thread of this process (`core.batches`). The customer name in a POST is turned into a directory name by
`customer.rollup_path` (letters, digits, '-' and '_' only), so it cannot reach another path.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, Body, HTTPException, Request

from bimcontrol import paths
from bimcontrol.core import batches
from bimcontrol.core.customer import ROLLUP_FILE
from bimcontrol.estate.reader import EstateNotFoundError

router = APIRouter()


def _rollups() -> dict[str, Any]:
    """Directory name -> rollup path, for every customer that has a rollup."""
    root = paths.home() / "customers"
    try:
        return {d.name: d / ROLLUP_FILE for d in sorted(root.iterdir()) if (d / ROLLUP_FILE).is_file()}
    except OSError:
        return {}


def _read(path) -> dict[str, Any] | None:
    # The batch rewrites the file by rename, so a read never sees half of one;
    # an unreadable file is a customer we cannot show, not a server error.
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None


@router.get("/customers")
def list_customers() -> dict[str, Any]:
    items = []
    for name, path in _rollups().items():
        rollup = _read(path)
        if rollup is None:
            continue
        items.append({
            "name": name, "customer": rollup.get("customer") or name,
            "dashboards": rollup.get("dashboards"), "tally": rollup.get("tally") or {},
            "generated_at": rollup.get("generated_at"),
            "updated_at": datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).isoformat(timespec="seconds"),
        })
    # Most recently written first: the screen opens on the batch that is running.
    items.sort(key=lambda i: i["updated_at"], reverse=True)
    return {"items": items}


@router.get("/customers/{name}")
def get_customer(name: str) -> dict[str, Any]:
    path = _rollups().get(name)
    rollup = _read(path) if path else None
    if rollup is None:
        raise HTTPException(status_code=404, detail=f"No rollup for customer {name!r}")
    return {"name": name, **rollup}


def _manager(request: Request) -> batches.BatchManager:
    return request.app.state.batches


def _manifest_of(body: dict[str, Any]):
    try:
        return batches.validate_manifest(body.get("manifest"))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/customers/preview")
def preview(request: Request, body: dict[str, Any] = Body(default={})) -> dict[str, Any]:
    """The dashboards a manifest selects, cheapest first, without running anything."""
    manifest = _manifest_of(body)
    try:
        selected = batches.selection(request.app.state.estate_db_path, manifest)
    except EstateNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return {"customer": manifest.name, "total": len(selected), "dashboards": [
        {"id": s.id, "name": s.name, "cards": s.cards, "dataflows": s.dataflows, "source_rows": s.source_rows}
        for s in selected]}


@router.post("/customers/batches", status_code=202)
def start_batch(request: Request, body: dict[str, Any] = Body(default={})) -> dict[str, Any]:
    manifest = _manifest_of(body)
    options = body.get("options") or {}
    limit = options.get("limit")
    if limit is not None and (not isinstance(limit, int) or isinstance(limit, bool) or limit < 1):
        raise HTTPException(status_code=422, detail="limit must be a whole number of at least 1")
    try:
        return _manager(request).start(
            manifest, request.app.state.estate_db_path, limit=limit,
            rerun_unproven=bool(options.get("rerun_unproven")), retry_failed=options.get("retry_failed", True) is not False,
            force=bool(options.get("force")))
    except EstateNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.get("/customers/{name}/batch")
def batch_status(request: Request, name: str) -> dict[str, Any]:
    """The batch started from this screen (not one a terminal runs), and the manifest last saved for the customer."""
    return {"batch": _manager(request).status(name), "manifest": batches.saved_manifest(name)}


@router.post("/customers/{name}/batch/stop")
def stop_batch(request: Request, name: str, body: dict[str, Any] = Body(default={})) -> dict[str, Any]:
    if not _manager(request).stop(name, now=bool(body.get("now"))):
        raise HTTPException(status_code=409, detail=f"No batch of {name!r} is running")
    return {"batch": _manager(request).status(name)}

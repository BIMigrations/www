"""Builds ``Estate Scanner.app``, so the desktop UI gets its own Dock icon,
menu-bar name and Cmd-Tab entry instead of showing up as "Python".

**Why the bundle is assembled here, on the customer's Mac, and never shipped.**
macOS Gatekeeper only judges files carrying the ``com.apple.quarantine``
attribute, which browsers, Mail and AirDrop add when something is downloaded.
An app we built elsewhere and zipped would arrive quarantined and, being
unsigned, be refused. ``curl``, ``pip`` and this module never set the flag, so a
bundle created by the installer on the machine it will run on is an ordinary
local folder. There is nothing of ours to notarise because it contains no
compiled code of ours: just an Info.plist, an icon, a launcher script and a
symlink to the Python that is already installed.

**Why the executable is a symlink to the *real* interpreter.** A bundle is only
the app's identity for a process whose executable path is inside it, and
AppKit reads that path unresolved, so a symlink at
``Contents/MacOS/Estate Scanner`` is enough to make ``NSBundle.mainBundle`` this
bundle (hence its name and icon). It must point at the real Mach-O, not at
``bin/python3``: on a framework build (python.org, Homebrew) that is a stub which
re-execs ``Resources/Python.app/Contents/MacOS/Python`` and so hands the
process back to Python's own bundle and rocket icon. Python then finds its
standard library from a ``pyvenv.cfg`` placed beside ``MacOS/``, and its
packages from a symlink to the environment's ``site-packages``, so the bundle is
a thin view over the environment that ``install.sh`` already maintains and an
upgrade needs no rebuild of the app (the installer rebuilds it anyway).

A symlink cannot carry arguments, hence ``Contents/MacOS/launch``: a short shell
script (the bundle's ``CFBundleExecutable``) that sends output to a log and
``exec``s the symlink with ``-m estate_scanner ui``.
"""

from __future__ import annotations

import os
import plistlib
import shutil
import subprocess
import sys
import sysconfig
import tempfile
from importlib import metadata, resources
from pathlib import Path

APP_NAME = "Estate Scanner"
BUNDLE_ID = "com.bimigrations.estate-scanner"
ICON_FILE = "EstateScanner.icns"
# What LaunchServices starts. The symlink is named after the app so the running
# process is called "Estate Scanner" in Activity Monitor and `ps`, not "python".
LAUNCHER = "launch"
INTERPRETER = APP_NAME


class BundleError(Exception):
    """Something the user can act on; the message says what."""


def default_dest() -> Path:
    # Per-user, so no administrator rights; Spotlight and Launchpad index it.
    return Path.home() / "Applications"


def icon_source() -> Path:
    return Path(str(resources.files("estate_scanner") / "assets" / ICON_FILE))


def real_interpreter() -> Path:
    """The Mach-O that is actually the interpreter, as opposed to a stub for it."""
    base = Path(sys.base_prefix)
    framework_app = base / "Resources" / "Python.app" / "Contents" / "MacOS" / "Python"
    if framework_app.is_file():
        return framework_app
    # Not a framework build (uv's Python, conda, pyenv): bin/python3.x is the real thing.
    return Path(getattr(sys, "_base_executable", None) or sys.executable)


def _version() -> tuple[str, str]:
    """(short, full): Finder shows the first, Get Info both."""
    try:
        full = metadata.version("estate-scanner")
    except metadata.PackageNotFoundError:
        full = "0.0.0"
    # The installer stamps `0.1.0+20261026.gabc123`; the part after '+' is a build tag.
    return full.split("+")[0], full


def info_plist() -> dict:
    short, full = _version()
    return {
        "CFBundleName": APP_NAME,
        "CFBundleDisplayName": APP_NAME,
        "CFBundleIdentifier": BUNDLE_ID,
        "CFBundleExecutable": LAUNCHER,
        "CFBundleIconFile": ICON_FILE,
        "CFBundlePackageType": "APPL",
        "CFBundleShortVersionString": short,
        "CFBundleVersion": full,
        "NSPrincipalClass": "NSApplication",
        "NSHighResolutionCapable": True,
        "LSApplicationCategoryType": "public.app-category.business",
    }


def launcher_script() -> str:
    # POSIX sh, and `cd`/`pwd` rather than readlink: this runs from a bundle the
    # user may have dragged anywhere, with no PATH beyond LaunchServices' minimal one.
    return f"""#!/bin/sh
# {APP_NAME}'s launcher: the bundle's CFBundleExecutable. A symlink cannot carry
# arguments, so this hands the interpreter its own and nothing else. LaunchServices
# may append -psn_* arguments, which the app does not accept, so none are forwarded.
here="$(cd "$(dirname "$0")" && pwd)"
log_dir="$HOME/Library/Logs/{APP_NAME}"
mkdir -p "$log_dir"
# An app has no terminal, so the log is how a failed start is diagnosed. It holds
# the last run only, so it cannot grow without bound.
exec >"$log_dir/estate-scanner.log" 2>&1
if [ ! -x "$here/{INTERPRETER}" ]; then
  echo "The Python this app points at is gone: $(readlink "$here/{INTERPRETER}")"
  /usr/bin/osascript -e 'display alert "{APP_NAME} needs to be reinstalled" message "The Python it runs on has been removed or moved. Run the install command again; your scan data is not affected." as critical' >/dev/null 2>&1
  exit 1
fi
export PYTHONUNBUFFERED=1
exec "$here/{INTERPRETER}" -m estate_scanner ui
"""


def pyvenv_cfg() -> str:
    # `home` is the directory Python searches for its standard library from. Using
    # base_prefix (a Homebrew `opt` path, not a versioned Cellar one) means a
    # `brew upgrade` does not strand the app.
    return (
        f"home = {Path(sys.base_prefix) / 'bin'}\n"
        "include-system-site-packages = false\n"
        f"version = {sys.version.split()[0]}\n"
    )


def _is_ours(bundle: Path) -> bool:
    try:
        plist = plistlib.loads((bundle / "Contents" / "Info.plist").read_bytes())
    except (OSError, plistlib.InvalidFileException, ValueError):
        return False
    return plist.get("CFBundleIdentifier") == BUNDLE_ID


def _assemble(bundle: Path, *, interpreter: Path, site_packages: Path) -> None:
    contents = bundle / "Contents"
    macos = contents / "MacOS"
    macos.mkdir(parents=True)
    (contents / "Resources").mkdir()

    (contents / "Info.plist").write_bytes(plistlib.dumps(info_plist()))
    (contents / "PkgInfo").write_text("APPL????")
    shutil.copyfile(icon_source(), contents / "Resources" / ICON_FILE)

    launcher = macos / LAUNCHER
    launcher.write_text(launcher_script())
    launcher.chmod(0o755)
    (macos / INTERPRETER).symlink_to(interpreter)

    # Python looks for pyvenv.cfg in the executable's directory and its parent;
    # the parent of MacOS/ is Contents/, which then becomes sys.prefix.
    (contents / "pyvenv.cfg").write_text(pyvenv_cfg())
    lib = contents / "lib" / f"python{sys.version_info.major}.{sys.version_info.minor}"
    lib.mkdir(parents=True)
    (lib / "site-packages").symlink_to(site_packages)


def _verify(bundle: Path) -> None:
    """Run the bundle's own interpreter through the app's self-test, so a bundle
    that cannot start is reported now rather than as a Dock icon that bounces
    and gives up. The database is a throwaway: the self-test opens one, and it
    must never be the customer's."""
    with tempfile.TemporaryDirectory() as tmp:
        cmd = [str(bundle / "Contents" / "MacOS" / INTERPRETER), "-m", "estate_scanner", "--db-path", str(Path(tmp) / "verify.db"), "ui", "--check"]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        except subprocess.TimeoutExpired:
            raise BundleError("the new app did not pass its self-test (it timed out).") from None
    if result.returncode != 0:
        detail = (result.stdout + result.stderr).strip()
        raise BundleError(f"the new app did not pass its self-test:\n{detail}")


def _register(bundle: Path) -> None:
    """Best effort: tell LaunchServices about the app now so Spotlight, `open -a`
    and the Dock show the right name and icon on first use rather than after the
    next indexing pass. Nothing depends on it, so every failure is ignored."""
    lsregister = Path("/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister")
    if sys.platform == "darwin" and lsregister.exists():
        try:
            subprocess.run([str(lsregister), "-f", str(bundle)], capture_output=True, timeout=30)
        except (OSError, subprocess.SubprocessError):
            pass


def build_bundle(
    dest: str | Path | None = None,
    *,
    interpreter: Path | None = None,
    site_packages: Path | None = None,
    verify: bool = True,
) -> Path:
    """Create (or replace) ``<dest>/Estate Scanner.app`` and return its path.

    It is built in a hidden staging folder beside the destination and only moved
    into place once it has passed its self-test, so a failed rebuild leaves the
    previous, working app alone. An existing ``Estate Scanner.app`` that this
    module did not make is never touched."""
    dest = Path(dest).expanduser() if dest else default_dest()
    interpreter = interpreter or real_interpreter()
    site_packages = site_packages or Path(sysconfig.get_path("purelib"))
    if not interpreter.exists():
        raise BundleError(f"cannot find the Python interpreter at {interpreter}.")
    if not icon_source().is_file():
        raise BundleError(f"the app icon is missing from this installation ({icon_source()}); reinstall Estate Scanner.")

    final = dest / f"{APP_NAME}.app"
    if final.exists() and not _is_ours(final):
        raise BundleError(f"{final} already exists and was not created by Estate Scanner, so it was left alone. Move it, or choose another folder with --dest.")

    dest.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=f".{APP_NAME}-", suffix=".staging", dir=dest))
    try:
        staged = staging / f"{APP_NAME}.app"
        _assemble(staged, interpreter=interpreter, site_packages=site_packages)
        if verify:
            _verify(staged)
        if final.exists():
            shutil.rmtree(final)
        staged.rename(final)
    finally:
        shutil.rmtree(staging, ignore_errors=True)
    os.utime(final)  # nudges Finder to re-read the icon if the app was replaced
    _register(final)
    return final

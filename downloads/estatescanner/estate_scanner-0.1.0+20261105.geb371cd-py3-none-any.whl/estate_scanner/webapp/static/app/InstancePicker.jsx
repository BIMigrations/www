import React from 'react';

// Which instance the Estate and Lineage screens read. `scope` is null (the newest scan of each platform,
// what the server shows when nothing is named) or { platform, instance }. Only offered when the file
// holds more than one instance: with one there is nothing to pick.
export function InstancePicker({ instances, scope, onChange }) {
  if (!instances || instances.length < 2) return null;
  const several = new Set(instances.map(function (i) { return i.platform; })).size > 1;
  const value = scope ? scope.platform + '|' + scope.instance : '';
  return (
    <div style={{ padding: '14px 8px 0' }}>
      <div className="bit-eyebrow" style={{ marginBottom: 6 }}>Instance</div>
      <Select
        size="sm" value={value}
        onChange={function (e) {
          const at = e.target.value.indexOf('|');
          onChange(at < 0 ? null : { platform: e.target.value.slice(0, at), instance: e.target.value.slice(at + 1) });
        }}
        options={[{ value: '', label: 'Newest of each platform' }].concat(instances.map(function (i) {
          return { value: i.platform + '|' + i.instance, label: (several ? i.platform + ' · ' : '') + i.instance };
        }))}
      />
    </div>
  );
}

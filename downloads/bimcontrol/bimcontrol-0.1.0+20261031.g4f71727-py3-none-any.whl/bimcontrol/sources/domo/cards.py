"""Reading a Domo card's own figures.

This is the ground truth a migration is judged against. Not the dataset,
not the warehouse -- the numbers the card itself puts on screen, with its
own aggregation, filters and grouping applied. If the migrated visual
shows these, the migration is right; if it shows something else, no
amount of correct SQL underneath makes it right.

**Verified live against the source Domo instance on 2026-10-01.** The endpoint is
what Domo's dashboard calls to draw each card:

    PUT /api/content/v1/cards/kpi/{cardId}/render?parts=summary,graph

Found the same way as the export endpoint, and worth repeating as method:
the request body was read off the product by watching what the page sent,
not guessed. A guess returned 400; the real body has a `packet` and a
`cardLoadContext` that look like presentation details and are in fact
required.

The reply buries the data two levels down, under
`chart.datasources[<dataSourceId>].data`, which carries `columns`,
`mappings` (the same ITEM/VALUE/SERIES vocabulary the card definition
uses) and `rows`. The top-level `graph` component holds only chart
styling.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from html.parser import HTMLParser
from typing import Any

import requests

from .session import DomoSession, DomoSessionExpired

REQUEST_TIMEOUT = 180


class DomoCardError(Exception):
    pass


def _domo_error_text(response: requests.Response) -> str:
    """What Domo says is wrong with a card it will not draw: `Invalid column(s) referenced: hcpcsmod` (a column the card
    uses that its dataset no longer has) is in `details`, after the first 300 characters of the body. Else the start of the body."""
    try:
        body = response.json()
        details = body.get("details") if isinstance(body, dict) else None
        if isinstance(details, dict) and details.get("error"):
            columns = details.get("columns")
            if isinstance(columns, list) and columns:
                return f"{details['error']}: {', '.join(str(c) for c in columns)}"
            return str(details["error"])
    except ValueError:
        pass
    return response.text[:300]


@dataclass
class CardData:
    """One card's aggregated result, as the card itself computed it."""

    card_id: str
    columns: list[str] = field(default_factory=list)
    mappings: list[str] = field(default_factory=list)
    rows: list[list[Any]] = field(default_factory=list)
    data_source_id: str | None = None
    summary: Any = None
    limited: bool = False

    def column_index(self, mapping: str) -> int | None:
        """Where the ITEM / VALUE / SERIES column sits, by its Domo role."""
        for index, role in enumerate(self.mappings):
            if (role or "").upper() == mapping.upper():
                return index
        return None

    def series(self) -> list[tuple[Any, Any]]:
        """(category, value) pairs, for comparing against a target visual."""
        item = self.column_index("ITEM")
        value = self.column_index("VALUE")
        if item is None or value is None:
            return []
        return [(row[item], row[value]) for row in self.rows
                if len(row) > max(item, value)]


class Shown(float):
    """A number as a card prints it ("$2,976,487,750", "(1,234)", "12.5%"): the value plus how far the
    printed digits can be from the real one (half a unit of the last digit shown)."""

    tolerance: float = 0.0

    def __new__(cls, value: float, tolerance: float = 0.0):
        obj = super().__new__(cls, value)
        obj.tolerance = tolerance
        return obj


_PRINTED_NUMBER = re.compile(r"^\(?-?\$?\s*-?[\d,]*\.?\d+\s*%?\)?$")


def parse_printed_number(text: str) -> Shown | None:
    """`text` as the number it prints, or None when it is not one."""
    cleaned = text.strip().replace("\u00a0", " ")
    if not cleaned or not _PRINTED_NUMBER.match(cleaned):
        return None
    negative = cleaned.startswith("(") or "-" in cleaned
    percent = cleaned.rstrip(")").endswith("%")
    digits = re.sub(r"[^\d.]", "", cleaned)
    if not digits or digits == ".":
        return None
    if len(digits) > 1 and digits[0] == "0" and digits[1] != ".":
        return None                      # a code such as 00123, not a quantity
    decimals = len(digits.split(".")[1]) if "." in digits else 0
    value = float(digits)
    if percent:
        value, decimals = value / 100, decimals + 2
    return Shown(-value if negative else value, 0.5 * 10 ** -decimals)


class _TableReader(HTMLParser):
    """The first table of a card's html: header texts and the text of every cell of every row."""

    def __init__(self) -> None:
        super().__init__()
        self.rows: list[list[str]] = []
        self._cell: list[str] | None = None
        self._depth = 0

    def handle_starttag(self, tag, attrs):
        if tag == "table":
            self._depth += 1
        elif tag == "tr" and self._depth == 1:
            self.rows.append([])
        elif tag in ("td", "th") and self._depth == 1 and self.rows:
            self._cell = []

    def handle_endtag(self, tag):
        if tag == "table":
            self._depth -= 1
        elif tag in ("td", "th") and self._cell is not None:
            self.rows[-1].append("".join(self._cell).strip())
            self._cell = None

    def handle_data(self, data):
        if self._cell is not None:
            self._cell.append(data)


def parse_html_table(html: str) -> tuple[list[str], list[list[Any]]]:
    """(columns, rows) of the table a card draws as html (Domo's badge_table). A cell that prints a
    number becomes a `Shown`; a "Grand Total" row is left out. ([], []) when there is no table."""
    reader = _TableReader()
    reader.feed(html)
    if not reader.rows:
        return [], []
    columns, rows = reader.rows[0], []
    for index, cells in enumerate(_ungrouped([c for c in reader.rows[1:] if len(c) == len(columns)])):
        if any(c.lower() == "grand total" for c in cells) or index == 0 and _is_total_row(cells):
            continue
        rows.append([parse_printed_number(c) if parse_printed_number(c) is not None else c for c in cells])
    return columns, rows


def _is_total_row(cells: list[str]) -> bool:
    """The summary row Domo puts first in a table card with its totals on: a "Total" in a text cell and no other text
    (customer Revenue Impact's 'Charge Code Sorted by Highest Price Impact': `| | Total | 56,439,641 | ...`). A data
    row that is called Total has its other dimension cells filled, or is not the first."""
    text = [c for c in cells if c and parse_printed_number(c) is None]
    return len(text) == 1 and text[0].lower() == "total"


def _ungrouped(rows: list[list[str]]) -> list[list[str]]:
    """A table grouped by its first column draws the group's value once, on a row of its own with every other
    cell empty, leaves the first cell empty on the group's rows and closes the group with `<group> Total`
    (Overhead Departments Email-SW's P/L: `Revenue`, 7 rows, `Revenue Total`). Give each row its group and drop
    the header and total rows, so the rows are the ones the data has. A table without such header rows is returned as is."""
    def header(index: int) -> bool:
        cells = rows[index]
        return len(cells) > 1 and bool(cells[0]) and not any(cells[1:]) and index + 1 < len(rows) \
            and not rows[index + 1][0] and any(rows[index + 1][1:])

    if not any(header(i) for i in range(len(rows))):
        return rows
    out, group = [], ""
    for index, cells in enumerate(rows):
        if header(index):
            group = cells[0]                                  # the header row
        elif group and cells[0] == f"{group} Total":
            group = ""                                        # the subtotal row
        elif not cells[0] and group:
            out.append([group, *cells[1:]])
        else:
            out.append(cells)
    return out


def _parse_literal_call(expression: str) -> dict[str, Any] | None:
    """`DATE('2019-01-01')` as the parse tree Domo's page sends; None for anything else (a variable that is a plain
    string or number is not measured: it stays at whatever Domo last held)."""
    text = expression.strip()
    call = re.fullmatch(r"([A-Za-z_]\w*)\s*\(\s*'([^']*)'\s*\)", text)
    if call:
        return {"exprType": "FUNCTION", "name": call.group(1).upper(), "value": call.group(2),
                "arguments": [{"exprType": "STRING_VALUE", "value": call.group(2)}]}
    return None


def page_filter_overrides(page_filters: list[dict[str, Any]] | None, dataset_id: str,
                          dataset_columns: set[str]) -> list[dict[str, Any]]:
    """The dashboard's saved filters as Domo's page load sends them for a card on `dataset_id`.

    Only filters with values, and only those on a column the card's dataset has (a filter on
    another dataset's column does not reach the card). Domo fills `dataSourceId` from the card's
    own dataset; the saved filter leaves it empty.
    """
    overrides = []
    for item in page_filters or []:
        raw = item.get("raw") or item
        column = raw.get("column")
        if not raw.get("values") or column not in dataset_columns:
            continue
        overrides.append({
            "column": column, "values": raw["values"], "dataSourceId": dataset_id,
            "sourceCardURN": "", "affectedCardUrns": [], "operand": raw.get("operand") or "IN",
            "dataType": raw.get("dataType"), "key": f"{column}:", "label": item.get("label") or column,
        })
    return overrides


TALL_TABLE_HEIGHT = 100_000


class DomoCardReader:
    def __init__(self, session: DomoSession, timeout: int = REQUEST_TIMEOUT):
        self.session = session
        self.http = session.requests_session()
        self.timeout = timeout
        self._variables: dict[str, dict[str, Any]] = {}

    def dataset_row_count(self, dataset_id: str) -> int | None:
        """How many rows Domo's dataset holds now (a read-only SQL count), None when Domo will not say."""
        try:
            response = self.http.post(
                f"{self.session.base_url}/api/query/v1/execute/{dataset_id}",
                json={"sql": "SELECT COUNT(*) FROM table"}, timeout=self.timeout)
            response.raise_for_status()
            return int(response.json()["rows"][0][0])
        except (requests.RequestException, KeyError, IndexError, TypeError, ValueError):
            return None

    def variable_overrides(self, card_id: str) -> dict[str, Any]:
        """`queryOverrides.functionOverrides` for the card's Domo *variables* (beast modes flagged `variable`: the
        date window of a CFY/PFY column, say), set to their defaults, which is what the dashboard shows. Rendered
        without them Domo evaluates a variable at the value last selected on its control (Clinic Service Date
        Trend PoP-SW: a start date of 2023 where the page draws 2019) and the figures are another question."""
        if str(card_id) in self._variables:
            return self._variables[str(card_id)]
        try:
            response = self.http.put(
                f"{self.session.base_url}/api/content/v1/cards/variable/controls/default/list",
                json=[str(card_id)], timeout=self.timeout)
            response.raise_for_status()
            controls = response.json().get("controls") or []
        except (requests.RequestException, ValueError, AttributeError):
            return {}
        overrides: dict[str, Any] = {}
        for control in controls:
            function = control.get("function") if isinstance(control, dict) else None
            if not isinstance(function, dict):
                continue
            parsed = _parse_literal_call(function.get("expression") or "")
            if function.get("id") is not None and parsed is not None:
                overrides[str(function["id"])] = {
                    "name": function.get("name"), "functionName": function.get("name"), "parsedExpression": parsed}
        self._variables[str(card_id)] = overrides
        return overrides

    def dataset_updated(self, dataset_id: str) -> float | None:
        """When Domo last built (or loaded) the dataset, seconds since the epoch; None when Domo will not say."""
        try:
            response = self.http.get(
                f"{self.session.base_url}/api/data/v3/datasources/{dataset_id}",
                params={"part": "core"}, timeout=self.timeout)
            response.raise_for_status()
            return float(response.json()["lastUpdated"]) / 1000
        except (requests.RequestException, KeyError, TypeError, ValueError):
            return None

    def render(self, card_id: str, page_id: str | None = None,
               filters: list[dict[str, Any]] | None = None, height: int = 400) -> CardData:
        """Ask Domo to compute a card, and keep the numbers.

        `page_id` matters: a card on a dashboard is rendered in that
        page's context, and page-level filters apply. Rendering without
        it gives the card's unfiltered figures, which is a different
        question and usually not the one being asked. The page's *saved*
        filter values are applied by the browser, not by Domo: its own page
        load sends them as `queryOverrides.filters`, so pass them as
        `filters` (see `page_filter_overrides`) to get the figures the
        dashboard shows.
        """
        url = f"{self.session.base_url}/api/content/v1/cards/kpi/{card_id}/render"
        variables = self.variable_overrides(card_id)
        body = {
            "queryOverrides": {**({"filters": filters} if filters else {}),
                               **({"functionOverrides": variables} if variables else {})},
            # These look cosmetic and are not optional -- the request is
            # rejected with a bare 400 without them.
            "packet": {"pageLayout": True, "transparent": True},
            "imageMap": False,
            "pageLayout": None,
            "width": 800,
            "height": height,
            "scale": 1,
            "cardLoadContext": {
                "context": "page_layout",
                "visibilityState": "visible",
                "contextId": str(page_id) if page_id else None,
                "trigger": "initial_load",
            },
        }
        response = self.http.put(
            url, params={"parts": "summary,graph"}, json=body,
            headers={"accept": "application/json"}, timeout=self.timeout,
        )
        if response.status_code == 401:
            raise DomoSessionExpired("Domo rejected the session; sign in again.")
        if response.status_code >= 400:
            raise DomoCardError(
                f"Rendering card {card_id} -> {response.status_code}: {_domo_error_text(response)}"
            )

        payload = response.json()
        chart = payload.get("chart") or {}
        datasources = chart.get("datasources") or {}
        if not datasources and payload.get("html"):
            # A table card comes back as drawn html, with no data source, and only as many rows as fit the card's
            # height: 32 of 76 at 400 (Executive Summary-SW's 'Service Line Summary'), so ask for a tall one.
            if height < TALL_TABLE_HEIGHT:
                try:
                    return self.render(card_id, page_id=page_id, filters=filters, height=TALL_TABLE_HEIGHT)
                except (DomoCardError, requests.RequestException):
                    pass            # the card as drawn at the default height still beats no card
            # Its numbers carry the precision the card prints, which the comparison has to allow for.
            columns, rows = parse_html_table(payload["html"])
            if columns:
                return CardData(
                    card_id=str(card_id), columns=columns, rows=rows,
                    summary=(payload.get("summary") or {}).get("value"),
                    limited=bool(payload.get("limited") or payload.get("notAllDataShown")),
                )
        if not datasources:
            raise DomoCardError(f"Card {card_id} returned no data source")

        data_source_id, source = next(iter(datasources.items()))
        data = (source or {}).get("data") or {}
        return CardData(
            card_id=str(card_id),
            columns=list(data.get("columns") or []),
            mappings=list(data.get("mappings") or []),
            rows=list(data.get("rows") or []),
            data_source_id=data_source_id,
            summary=(payload.get("summary") or {}).get("value"),
            limited=bool(source.get("limited") or payload.get("limited")),
        )

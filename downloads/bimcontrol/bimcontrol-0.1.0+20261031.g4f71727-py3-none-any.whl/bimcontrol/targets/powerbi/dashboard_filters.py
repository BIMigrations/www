"""Domo dashboard filters -> Power BI slicers and report-level filters.

A Domo dashboard filter is a control in the filter bar: a column, an
operand, and optionally saved values (`dashboards.filters_json`). Most are
interactive only (no saved values), so the viewer picks values; those become
slicers, synced across pages by field the way Domo applies one filter to the
whole dashboard. A filter with saved values is already applied in Domo, so it
becomes a report-level filter and the migrated numbers match.

A slicer filters the table its column lives in. The generated model has no
relationships between tables, so a slicer only reaches visuals built from the
same table, which is why the plan is made per table, not per name.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .chart_map import FILTER_OPERANDS, filter_data_type
from .model import VisualFilter

SLICER_WIDTH = 190
SLICER_HEIGHT = 56
SLICER_GAP = 8

_RANGE_TYPES = ("int64", "double", "decimal", "datetime")
_RANGE_OPERANDS = {"GREAT_THAN_EQUALS_TO", "GREATER_THAN_EQUALS_TO", "GREATER_THAN", "LESS_THAN",
                   "LESS_THAN_EQUALS_TO", "BETWEEN"}


@dataclass
class SlicerSpec:
    table: str
    column: str
    label: str
    mode: str                      # "Dropdown" | "Between"

    @property
    def sync_group(self) -> str:
        return f"{self.table}.{self.column}"


@dataclass
class FilterPlan:
    slicers: list[SlicerSpec] = field(default_factory=list)
    report_filters: list[VisualFilter] = field(default_factory=list)
    # (label, reason) for filters that reach no table or cannot be mapped.
    unmapped: list[tuple[str, str]] = field(default_factory=list)


def _find_column(tables: list[dict[str, Any]], column: str) -> list[tuple[str, dict]]:
    exact = [(t["name"], c) for t in tables for c in t.get("columns") or [] if c["name"] == column]
    if exact:
        return exact
    lowered = column.lower()
    return [(t["name"], c) for t in tables for c in t.get("columns") or [] if c["name"].lower() == lowered]


def _data_type(column: dict) -> str:
    from .model import tmdl_type  # noqa: PLC0415 -- avoids widening the import block
    return tmdl_type(column.get("source_type"))


def plan_filters(raw_filters: list[dict] | None, tables: list[dict[str, Any]]) -> FilterPlan:
    """Decide, for each dashboard filter, what it becomes. Pure; no I/O."""
    plan = FilterPlan()
    seen: set[tuple[str, str]] = set()
    # A column can be listed twice, once with no values (a slicer on its dataset) and once with the saved selection
    # (Clinic Service Date Trend-SW: Service Year, then Service Year IN 2023). The saved values come first, or the
    # empty entry takes the column and the selection is lost (the report showed every year where Domo shows 2023).
    entries = sorted(raw_filters or [], key=lambda entry: not (entry.get("raw") or {}).get("values"))
    for entry in entries:
        raw = entry.get("raw") or {}
        column = raw.get("column") or entry.get("field")
        label = entry.get("label") or column or "unnamed filter"
        if not column:
            plan.unmapped.append((label, "the filter names no column"))
            continue
        operand = str(raw.get("operand") or "").upper()
        values = [str(v) for v in (raw.get("values") or [])]
        homes = _find_column(tables, column)
        if not homes:
            plan.unmapped.append((label, f"no table in the model has a column {column!r}"))
            continue

        if values:
            spec = FILTER_OPERANDS.get(operand)
            if spec is None or (spec[0] == "compare" and len(values) != 1):
                plan.unmapped.append((label, f"saved values with operand {operand or 'none'} are not translated"))
                continue
            kind, comparison, negated = spec
            for table, col in homes:
                if (table, col["name"]) in seen:
                    continue
                seen.add((table, col["name"]))
                plan.report_filters.append(VisualFilter(
                    table=table, column=col["name"], kind=kind, values=values,
                    data_type=filter_data_type(raw.get("dataType"), str(col.get("source_type") or "").upper()),
                    comparison=comparison, negated=negated))
            continue

        for table, col in homes:
            if (table, col["name"]) in seen:
                continue
            seen.add((table, col["name"]))
            ranged = operand in _RANGE_OPERANDS or _data_type(col) in _RANGE_TYPES
            plan.slicers.append(SlicerSpec(table, col["name"], label, "Between" if ranged else "Dropdown"))
    return plan

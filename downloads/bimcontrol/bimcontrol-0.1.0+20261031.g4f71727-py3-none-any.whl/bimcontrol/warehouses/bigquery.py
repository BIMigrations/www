"""Google BigQuery -- not built yet.

Registered so it appears wherever warehouses are listed and fails with a
straight answer rather than a KeyError, and so the work needed is written
down at the point someone will look for it.

**What this needs when it is built**

- `google-cloud-bigquery`, added to the `warehouse` extra.
- Loading is a load job, not SQL: `client.load_table_from_file()` with
  `LoadJobConfig(source_format=CSV, skip_leading_rows=1, autodetect=False)`.
  It takes a local file directly, so no staging bucket is needed below
  ~1GB and the Redshift-style `s3_bucket` requirement has no equivalent;
  above that, stage to GCS and load from there.
- BigQuery's vocabulary differs: a "dataset" is what the rest of this code
  calls a schema, which collides head-on with a *Domo* dataset. Whatever
  this adapter does internally, keep `TableSpec.schema` meaning schema, or
  reading the pipeline becomes a puzzle.
- Type mapping from Domo: STRING -> STRING (no length, so
  `scan_csv_widths` can be skipped), LONG -> INT64, DOUBLE -> FLOAT64,
  DECIMAL -> NUMERIC, DATE -> DATE, DATETIME -> DATETIME (TIMESTAMP only
  if the source values genuinely carry a zone).
- Column names are restricted to letters, digits and underscores, so Domo
  names with spaces or `#` must be renamed on the way in -- and the
  renaming has to be recorded, because the generated report references
  those columns by name.
- Auth is the standard Google chain (`GOOGLE_APPLICATION_CREDENTIALS` or
  workload identity), never the control database. Settings: project,
  dataset, location.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .base import LoadResult, TableSpec, WarehouseAdapter, WarehouseError

_MESSAGE = (
    "BigQuery support is not built yet -- only Redshift is implemented. "
    "See src/bimcontrol/warehouses/bigquery.py for what it needs."
)


class BigQueryAdapter(WarehouseAdapter):
    key = "bigquery"
    display_name = "Google BigQuery (not built yet)"
    implemented = False

    def connect(self) -> None:
        raise WarehouseError(_MESSAGE)

    def close(self) -> None:
        return None

    def ensure_schema(self, schema: str) -> None:
        raise WarehouseError(_MESSAGE)

    def create_table(self, spec: TableSpec, replace: bool = True) -> None:
        raise WarehouseError(_MESSAGE)

    def load_csv(self, spec: TableSpec, csv_path: Path, row_count: int | None = None) -> LoadResult:
        raise WarehouseError(_MESSAGE)

    def row_count(self, schema: str, table: str) -> int:
        raise WarehouseError(_MESSAGE)

    def table_exists(self, schema: str, table: str) -> bool:
        raise WarehouseError(_MESSAGE)

    def check(self) -> dict[str, Any]:
        return {"warehouse": self.key, "ok": False, "error": _MESSAGE}

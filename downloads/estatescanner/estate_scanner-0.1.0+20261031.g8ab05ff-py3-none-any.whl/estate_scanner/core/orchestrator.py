"""Platform-agnostic scan orchestration: calls each of a PlatformClient's
fetch_* methods, persists the resulting objects + derived edges, and emits
progress events. Never touches a platform-specific field name -- only the
shared dataclasses' common fields.
"""

from __future__ import annotations

import json
import sqlite3
import time
from collections.abc import Callable

from estate_scanner.core.platform import PlatformClient

from .models import ScanProgressEvent
from .relationships import derive_relationships

_PHASES = [
    ("workspace", "fetch_workspaces"),
    ("gateway", "fetch_gateways"),
    ("user", "fetch_users"),
    ("group", "fetch_groups"),
    ("account", "fetch_accounts"),
    ("dataset", "fetch_datasets"),
    ("dataflow", "fetch_dataflows"),
    ("card", "fetch_cards"),
    # app before dashboard: an adapter's fetch_apps() may discover extra
    # dashboard ids (e.g. Domo's app-view pages) that its fetch_dashboards()
    # needs to already know about to scan them -- see adapters/domo/client.py.
    ("app", "fetch_apps"),
    ("dashboard", "fetch_dashboards"),
    ("calculated_field", "fetch_calculated_fields"),
    ("alert", "fetch_alerts"),
]

OnProgress = Callable[[ScanProgressEvent], None]


def run_full_scan(
    conn: sqlite3.Connection,
    client: PlatformClient,
    platform: str,
    instance: str,
    on_progress: OnProgress | None = None,
    on_scan_started: Callable[[int], None] | None = None,
) -> int:
    from estate_scanner.storage import db

    start = time.monotonic()

    def emit(phase: str, completed: int, total: int | None, message: str | None = None) -> None:
        if on_progress:
            on_progress(ScanProgressEvent(phase=phase, completed=completed, total=total, elapsed_s=time.monotonic() - start, message=message))

    scan_id = db.start_scan(conn, platform, instance)
    if on_scan_started:
        on_scan_started(scan_id)  # a scan that fails has no return value; its id is still needed
    object_type = "setup"
    try:
        for object_type, fetch_method_name in _PHASES:
            total = client.estimate_total(object_type)
            fetch_method = getattr(client, fetch_method_name)
            n = 0
            try:
                objects = fetch_method()
            except NotImplementedError:
                # A partial adapter is still useful: a platform with no
                # analogue for an object type skips that phase. Not the same
                # as a phase that errored while fetching, which fails the scan.
                emit(object_type, 0, total, message="not supported by this platform")
                continue
            for obj in objects:
                db.upsert_object(conn, platform, object_type, obj, scan_id)
                db.record_raw(conn, scan_id, platform, object_type, obj.id, fetch_method_name, json.dumps(obj.raw_payload, default=str))
                for rel in derive_relationships(object_type, obj):
                    db.upsert_edge(conn, platform, rel.src.object_type, rel.src.id, rel.dst.object_type, rel.dst.id, rel.edge_type, scan_id, rel.weight,
                                   json.dumps(rel.data) if rel.data else None)
                n += 1
                if n % 50 == 0:
                    # Commit at the same cadence progress is reported, not
                    # just once at the end of the whole phase -- a phase can
                    # run for minutes (e.g. dataflows, each fetched with its
                    # own detail call), and holding one write lock that long
                    # starves any other connection to the same db file (the
                    # webapp opens one to show this very progress).
                    conn.commit()
                    emit(object_type, n, total)
            issues = client.take_issues()
            for issue in issues:
                db.record_issue(conn, scan_id, issue.phase or object_type, issue)
            conn.commit()
            emit(object_type, n, total, message=f"{len(issues)} could not be read" if issues else None)
        db.finish_scan(conn, scan_id, status="completed")
    except Exception:
        # What was skipped before the scan failed still explains how far it got.
        for issue in client.take_issues():
            db.record_issue(conn, scan_id, issue.phase or object_type, issue)
        db.finish_scan(conn, scan_id, status="failed")
        raise
    return scan_id

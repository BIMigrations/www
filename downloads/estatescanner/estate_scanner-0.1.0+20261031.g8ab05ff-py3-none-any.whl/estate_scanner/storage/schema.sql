-- Estate Scanner database schema.
--
-- Platform-agnostic by design: every table carries a `platform` column
-- (part of its primary key) so more than one BI platform's estate can
-- eventually share one database without id collisions. Typed tables carry
-- the fields useful to query/filter on directly; `raw_json` on every table
-- keeps the full adapter payload so nothing is lost even before a field is
-- promoted to a typed column. `edges` is a generic, type-tagged
-- relationship table so the whole estate loads as one weighted graph
-- (networkx) regardless of object type or which adapter produced it.
--
-- Deliberate scope cut: one `platform` column per edge means an edge can't
-- span two platforms. Fine while only one platform's data exists in a
-- database at a time; a future cross-platform link (e.g. "this Domo object
-- became that PowerBI object") would need src_platform/dst_platform instead.

CREATE TABLE IF NOT EXISTS scans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    platform TEXT NOT NULL,
    instance TEXT NOT NULL,
    started_at TEXT NOT NULL,
    finished_at TEXT,
    status TEXT NOT NULL DEFAULT 'running', -- running | completed | failed
    notes TEXT
);

-- What a scan could not read (a refused call, a disabled tenant setting, a
-- definition that would not download). A scan that finishes with rows here is
-- complete only for the rest of the estate; the Scan screen and the CLI say so.
CREATE TABLE IF NOT EXISTS scan_issues (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    scan_id INTEGER NOT NULL REFERENCES scans(id),
    phase TEXT NOT NULL,          -- the object type being fetched, or 'setup'
    scope TEXT NOT NULL,          -- what was being read
    message TEXT NOT NULL,
    http_status INTEGER,
    recorded_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_scan_issues_scan ON scan_issues(scan_id);

CREATE TABLE IF NOT EXISTS platform_sessions (
    platform TEXT NOT NULL,
    instance TEXT NOT NULL,
    credentials_json TEXT NOT NULL,   -- opaque: PlatformSession.to_persisted_dict()
    updated_at TEXT NOT NULL,
    PRIMARY KEY (platform, instance)
);

CREATE TABLE IF NOT EXISTS users (
    platform TEXT NOT NULL,
    id TEXT NOT NULL,
    name TEXT,
    email TEXT,
    role TEXT,
    title TEXT,
    raw_json TEXT,
    first_seen_scan_id INTEGER REFERENCES scans(id),
    last_seen_scan_id INTEGER REFERENCES scans(id),
    PRIMARY KEY (platform, id)
);

CREATE TABLE IF NOT EXISTS groups_ (
    platform TEXT NOT NULL,
    id TEXT NOT NULL,
    name TEXT,
    raw_json TEXT,
    first_seen_scan_id INTEGER REFERENCES scans(id),
    last_seen_scan_id INTEGER REFERENCES scans(id),
    PRIMARY KEY (platform, id)
);

CREATE TABLE IF NOT EXISTS accounts (
    platform TEXT NOT NULL,
    id TEXT NOT NULL,
    name TEXT,
    connector_type TEXT,
    owner_id TEXT,
    raw_json TEXT,
    first_seen_scan_id INTEGER REFERENCES scans(id),
    last_seen_scan_id INTEGER REFERENCES scans(id),
    PRIMARY KEY (platform, id)
);

CREATE TABLE IF NOT EXISTS datasets (
    platform TEXT NOT NULL,
    id TEXT NOT NULL,
    name TEXT,
    provider_type TEXT,          -- e.g. amazon-redshift, or a dataflow's own output
    stream_id TEXT,
    schema_columns_json TEXT,    -- [{name, type, ...}] -- promoted out of raw_json since it's used directly
    row_count INTEGER,
    column_count INTEGER,
    owner_id TEXT,
    created_at TEXT,
    updated_at TEXT,
    is_deleted INTEGER DEFAULT 0,
    -- A platform may precompute its own downstream-impact counts (Domo
    -- does); re-derivable from `edges` for platforms that don't.
    downstream_card_count INTEGER,
    downstream_dataflow_count INTEGER,
    downstream_dataset_count INTEGER,
    downstream_alert_count INTEGER,
    pdp_json TEXT,               -- row-level security (PDP) policies: [{name, filters, users, groups, ...}]; null = not captured
    definition_json TEXT,        -- the platform's modelling layer: Power BI tables/columns/measures/relationships/partitions/roles
    raw_json TEXT,
    first_seen_scan_id INTEGER REFERENCES scans(id),
    last_seen_scan_id INTEGER REFERENCES scans(id),
    PRIMARY KEY (platform, id)
);

CREATE TABLE IF NOT EXISTS dataflows (
    platform TEXT NOT NULL,
    id TEXT NOT NULL,
    name TEXT,
    engine TEXT,                 -- e.g. "magic" | "etl" | "mysql" -- generalizes Domo's is_magic
    is_deleted INTEGER,
    num_inputs INTEGER,          -- input datasets + (Power BI) datasource accounts + upstream dataflows
    num_outputs INTEGER,
    last_execution_state TEXT,
    last_execution_failed INTEGER,
    modified_at TEXT,
    owner_id TEXT,
    -- The full transform-tile DAG (every tile's type/config/dependencies) --
    -- what's actually needed to regenerate this ETL on another platform.
    definition_json TEXT,
    raw_json TEXT,                -- includes the input/output dataset lineage
    first_seen_scan_id INTEGER REFERENCES scans(id),
    last_seen_scan_id INTEGER REFERENCES scans(id),
    PRIMARY KEY (platform, id)
);

CREATE TABLE IF NOT EXISTS cards (
    platform TEXT NOT NULL,
    id TEXT NOT NULL,
    name TEXT,
    type TEXT,
    owner_id TEXT,
    dataset_id TEXT,              -- primary/first dataset for display; full lineage is in `edges`
    -- Full chart definition: formatting, drill paths, per-component
    -- overrides -- needed to recreate the exact visual elsewhere.
    definition_json TEXT,
    raw_json TEXT,
    first_seen_scan_id INTEGER REFERENCES scans(id),
    last_seen_scan_id INTEGER REFERENCES scans(id),
    PRIMARY KEY (platform, id)
);

CREATE TABLE IF NOT EXISTS dashboards (
    platform TEXT NOT NULL,
    id TEXT NOT NULL,
    name TEXT,
    parent_dashboard_id TEXT,
    owner_id TEXT,
    filters_json TEXT,            -- [{field, label, filterType, ...}]
    -- The grid/section layout: tile positions, sizes, per-tile display
    -- options -- needed to recreate the dashboard's actual arrangement.
    layout_json TEXT,
    raw_json TEXT,
    first_seen_scan_id INTEGER REFERENCES scans(id),
    last_seen_scan_id INTEGER REFERENCES scans(id),
    PRIMARY KEY (platform, id)
);

CREATE TABLE IF NOT EXISTS apps (
    platform TEXT NOT NULL,
    id TEXT NOT NULL,
    name TEXT,
    type TEXT,
    owner_id TEXT,
    landing_dashboard_id TEXT,
    -- Every screen in the app, its nav menu structure, and its branding --
    -- an app is a small multi-page product, not just a link to one page.
    views_json TEXT,
    navigations_json TEXT,
    theme_json TEXT,
    raw_json TEXT,
    first_seen_scan_id INTEGER REFERENCES scans(id),
    last_seen_scan_id INTEGER REFERENCES scans(id),
    PRIMARY KEY (platform, id)
);

-- A container other objects live in (Power BI / Fabric workspace). Added after
-- the first release: the other tables name their workspace only inside
-- raw_json, the `contains` edge is how a workspace reaches its content.
CREATE TABLE IF NOT EXISTS workspaces (
    platform TEXT NOT NULL,
    id TEXT NOT NULL,
    name TEXT,
    type TEXT,
    state TEXT,
    capacity_id TEXT,
    is_on_dedicated_capacity INTEGER,
    raw_json TEXT,
    first_seen_scan_id INTEGER REFERENCES scans(id),
    last_seen_scan_id INTEGER REFERENCES scans(id),
    PRIMARY KEY (platform, id)
);

-- An on-premises data gateway (Power BI). Its datasources are `accounts`; a
-- `hosts` edge runs from the gateway to each.
CREATE TABLE IF NOT EXISTS gateways (
    platform TEXT NOT NULL,
    id TEXT NOT NULL,
    name TEXT,
    type TEXT,
    status TEXT,
    machine TEXT,
    version TEXT,
    raw_json TEXT,
    first_seen_scan_id INTEGER REFERENCES scans(id),
    last_seen_scan_id INTEGER REFERENCES scans(id),
    PRIMARY KEY (platform, id)
);

-- One row per refresh of a dataset or dataflow (Power BI: refresh history and
-- dataflow transactions). Rows are kept after the platform stops returning them;
-- a later scan only adds new runs and finishes ones that were still running.
CREATE TABLE IF NOT EXISTS refreshes (
    platform TEXT NOT NULL,
    object_type TEXT NOT NULL,    -- 'dataset' | 'dataflow'
    object_id TEXT NOT NULL,
    id TEXT NOT NULL,             -- the platform's request/transaction id, else the start time
    refresh_type TEXT,
    status TEXT,
    started_at TEXT,
    ended_at TEXT,
    error TEXT,
    raw_json TEXT,
    first_seen_scan_id INTEGER REFERENCES scans(id),
    last_seen_scan_id INTEGER REFERENCES scans(id),
    PRIMARY KEY (platform, object_type, object_id, id)
);
CREATE INDEX IF NOT EXISTS idx_refreshes_object ON refreshes (platform, object_type, object_id, started_at);

-- Generalizes Domo's Beast Mode / PowerBI's DAX measures / Looker's derived
-- fields. Not tied to one dataset the way a column is -- linked_object_refs
-- (see edges) can point at multiple datasets/cards.
CREATE TABLE IF NOT EXISTS calculated_fields (
    platform TEXT NOT NULL,
    id TEXT NOT NULL,
    name TEXT,
    owner_id TEXT,
    status TEXT,
    formula_language TEXT,        -- e.g. "domo_beast_mode" | "dax" | "lookml"
    formula TEXT,                 -- expression text, where the platform exposes it
    data_type TEXT,
    is_global INTEGER,
    is_locked INTEGER,
    -- Everything beyond the bare expression: referenced functions, column
    -- positions, aggregation behavior -- needed to faithfully translate it.
    definition_json TEXT,
    raw_json TEXT,
    first_seen_scan_id INTEGER REFERENCES scans(id),
    last_seen_scan_id INTEGER REFERENCES scans(id),
    PRIMARY KEY (platform, id)
);

CREATE TABLE IF NOT EXISTS alerts (
    platform TEXT NOT NULL,
    id TEXT NOT NULL,
    name TEXT,
    rule TEXT,
    owner_id TEXT,
    resource_id TEXT,
    resource_type TEXT,           -- the generic object_type it watches, e.g. "card"
    disabled INTEGER,
    raw_json TEXT,
    first_seen_scan_id INTEGER REFERENCES scans(id),
    last_seen_scan_id INTEGER REFERENCES scans(id),
    PRIMARY KEY (platform, id)
);

-- Generic weighted-graph edge. (src_type, src_id) / (dst_type, dst_id) point
-- into whichever typed table matches that type ('dataset', 'dataflow',
-- 'card', 'dashboard', 'app', 'user', 'group', 'account',
-- 'calculated_field', 'alert', 'workspace', 'gateway'). edge_type vocabulary (10): owns,
-- consumed_by, produces, visualized_by, part_of (card->dashboard),
-- parent_of (dashboard->dashboard), used_by_calculated_field,
-- watched_by, opened_by (dashboard->app), member_of (user->group).
-- Added with the Power BI adapter: feeds (account->dataset, account->dataflow,
-- dataflow->dataflow for a dataflow built on another's output), source_of
-- (dashboard->card, a pinned tile's source report); visualized_by also runs
-- dataset->dashboard for a report bound to a model. has_role (user or group ->
-- workspace, dashboard, dataset or dataflow) carries the role in raw_json
-- ({"role": "Admin"}, plus "roles" when the service gave several); the
-- lineage graph leaves it out (graph.ACCESS_EDGE_TYPES).
CREATE TABLE IF NOT EXISTS edges (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    platform TEXT NOT NULL,
    src_type TEXT NOT NULL,
    src_id TEXT NOT NULL,
    dst_type TEXT NOT NULL,
    dst_id TEXT NOT NULL,
    edge_type TEXT NOT NULL,
    weight REAL NOT NULL DEFAULT 1.0,
    raw_json TEXT,
    scan_id INTEGER REFERENCES scans(id),
    UNIQUE(platform, src_type, src_id, dst_type, dst_id, edge_type)
);

CREATE INDEX IF NOT EXISTS idx_edges_src ON edges(platform, src_type, src_id);
CREATE INDEX IF NOT EXISTS idx_edges_dst ON edges(platform, dst_type, dst_id);

-- Append-only capture of every raw API response, keyed by scan. This is the
-- safety net: if a typed column turns out to be missing something, the full
-- payload is still here and can be re-parsed without re-scanning.
CREATE TABLE IF NOT EXISTS raw_objects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    platform TEXT NOT NULL,
    scan_id INTEGER REFERENCES scans(id),
    object_type TEXT NOT NULL,
    object_id TEXT,
    endpoint TEXT NOT NULL,
    fetched_at TEXT NOT NULL,
    body_json TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_raw_objects_type ON raw_objects(platform, object_type, object_id);

-- One-query view backing the Estate screen's "all objects" listing and the
-- summary/counts endpoint, instead of a client-side merge of the typed tables.
CREATE VIEW IF NOT EXISTS estate_objects AS
  SELECT platform, 'dataset' AS object_type, id, name, owner_id, created_at, updated_at,
         (COALESCE(row_count, 0) || ' rows · ' || COALESCE(column_count, 0) || ' cols') AS summary
    FROM datasets
  UNION ALL
  SELECT platform, 'dataflow', id, name, owner_id, NULL, modified_at,
         (COALESCE(num_inputs, 0) || ' in · ' || COALESCE(num_outputs, 0) || ' out')
    FROM dataflows
  UNION ALL
  SELECT platform, 'card', id, name, owner_id, NULL, NULL, type FROM cards
  UNION ALL
  SELECT platform, 'dashboard', id, name, owner_id, NULL, NULL, NULL FROM dashboards
  UNION ALL
  SELECT platform, 'user', id, name, NULL, NULL, NULL, email FROM users
  UNION ALL
  SELECT platform, 'group', id, name, NULL, NULL, NULL, NULL FROM groups_
  UNION ALL
  SELECT platform, 'account', id, name, owner_id, NULL, NULL, connector_type FROM accounts
  UNION ALL
  SELECT platform, 'calculated_field', id, name, owner_id, NULL, NULL, formula_language FROM calculated_fields
  UNION ALL
  SELECT platform, 'alert', id, name, owner_id, NULL, NULL, resource_type FROM alerts
  UNION ALL
  SELECT platform, 'app', id, name, owner_id, NULL, NULL, type FROM apps
  UNION ALL
  SELECT platform, 'workspace', id, name, NULL, NULL, NULL, type FROM workspaces
  UNION ALL
  SELECT platform, 'gateway', id, name, NULL, NULL, NULL, type FROM gateways;

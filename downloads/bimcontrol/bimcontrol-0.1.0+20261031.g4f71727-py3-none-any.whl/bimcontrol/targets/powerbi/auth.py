"""Signing in to Fabric once, rather than once per operation.

The naive approach -- construct an `InteractiveBrowserCredential` wherever
a token is needed -- opens a browser every single time. Publishing a
project, listing items and running a parity query is three sign-ins for
one migration, and a swarm node would be unusable.

Two things fix that, and both matter:

- **A persistent token cache.** MSAL keeps the refresh token in the OS
  keychain, so a later process gets a token silently. Without this the
  cache is in memory and dies with the process.
- **An authentication record.** The cache alone is not enough: the
  credential still has to know *which* account to look for. The record is
  that pointer, saved beside the cache, and it is what turns the second
  run into a silent one.

Together they mean one browser sign-in per machine, good until the
refresh token expires (typically weeks), with no secret stored by us --
the keychain holds it, we hold only an account pointer.
"""

from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any

from bimcontrol import paths

# What to ask for a token for. Fabric item management and the Power BI
# REST surface are separate audiences, so a token for one is not accepted
# by the other.
FABRIC_SCOPE = "https://api.fabric.microsoft.com/.default"
POWERBI_SCOPE = "https://analysis.windows.net/powerbi/api/.default"

CACHE_NAME = "bimcontrol-fabric"

# An operator-prepared MSAL token cache (serialized JSON with a refresh
# token). For unattended runs and tenants where the browser flow cannot be
# driven: someone signs in once elsewhere, and the run reads the cache.
# Refreshed tokens are written back so the refresh token keeps rolling.
MSAL_CACHE_ENV = "BIMCONTROL_MSAL_CACHE"
_PUBLIC_CLIENT = "04b07795-8ddb-461a-bbee-02f9e1bf7b46"  # Azure CLI, azure-identity's default
_AUTHORITY = "https://login.microsoftonline.com/organizations"


class FabricAuthError(Exception):
    pass


def _record_path() -> Path:
    return paths.home() / "auth" / "fabric-account.json"


def _msal_cache_path() -> Path | None:
    value = os.environ.get(MSAL_CACHE_ENV)
    return Path(value).expanduser() if value else None


class _AccessToken:
    def __init__(self, token: str, expires_on: int) -> None:
        self.token = token
        self.expires_on = expires_on


class MsalCacheCredential:
    """Silent tokens from an operator-prepared MSAL cache; never prompts."""

    def __init__(self, path: Path) -> None:
        self.path = path

    def _app(self):
        import msal  # noqa: PLC0415 -- ships with azure-identity

        cache = msal.SerializableTokenCache()
        try:
            cache.deserialize(self.path.read_text())
        except OSError as exc:
            raise FabricAuthError(f"Cannot read the MSAL cache {self.path}: {exc}") from exc
        return msal.PublicClientApplication(_PUBLIC_CLIENT, authority=_AUTHORITY, token_cache=cache), cache

    def accounts(self) -> list[dict[str, Any]]:
        return self._app()[0].get_accounts()

    def get_token(self, *scopes: str, **_: Any) -> _AccessToken:
        app, cache = self._app()
        accounts = app.get_accounts()
        if not accounts:
            raise FabricAuthError(f"The MSAL cache {self.path} has no signed-in account.")
        result = app.acquire_token_silent(list(scopes), account=accounts[0])
        if not result or "access_token" not in result:
            raise FabricAuthError(
                f"The MSAL cache {self.path} could not refresh a token for {accounts[0]['username']}; "
                "sign in again and replace the cache."
            )
        if cache.has_state_changed:
            self.path.write_text(cache.serialize())
        return _AccessToken(result["access_token"], int(time.time()) + int(result.get("expires_in", 0)))


def credential(scope: str = FABRIC_SCOPE, allow_prompt: bool = True):
    """A credential that prompts at most once per machine.

    `allow_prompt=False` is for anywhere a browser would be wrong -- a
    swarm node, a scheduled run -- and raises rather than hanging on a
    window nobody will see.
    """
    cache_path = _msal_cache_path()
    if cache_path:
        return MsalCacheCredential(cache_path)

    try:
        from azure.identity import (  # noqa: PLC0415 -- optional extra
            AuthenticationRecord,
            InteractiveBrowserCredential,
            TokenCachePersistenceOptions,
        )
    except ImportError as exc:
        raise FabricAuthError(
            "Publishing to Fabric needs the 'powerbi' extra: pip install 'bimcontrol[powerbi]'"
        ) from exc

    # allow_unencrypted_storage: on a headless or keychain-less machine MSAL
    # would otherwise refuse to persist at all, which is worse than a file
    # the OS already protects -- it means prompting on every run.
    cache = TokenCachePersistenceOptions(name=CACHE_NAME, allow_unencrypted_storage=True)
    record_path = _record_path()

    if record_path.exists():
        record = AuthenticationRecord.deserialize(record_path.read_text())
        return InteractiveBrowserCredential(
            cache_persistence_options=cache, authentication_record=record
        )

    if not allow_prompt:
        raise FabricAuthError(
            "No saved Fabric sign-in on this machine, and prompting is disabled. "
            "Run `bimcontrol fabric --login` once to sign in."
        )

    credential = InteractiveBrowserCredential(cache_persistence_options=cache)
    record = credential.authenticate(scopes=[scope])
    record_path.parent.mkdir(parents=True, exist_ok=True)
    record_path.write_text(record.serialize())
    # The record names the account; the secret stays in the OS keychain.
    record_path.chmod(0o600)
    return credential


def token(scope: str = FABRIC_SCOPE, allow_prompt: bool = True) -> str:
    return credential(scope, allow_prompt=allow_prompt).get_token(scope).token


def signed_in_account() -> dict[str, Any] | None:
    """Who the saved sign-in belongs to, for the Connections screen."""
    cache_path = _msal_cache_path()
    if cache_path:
        try:
            accounts = MsalCacheCredential(cache_path).accounts()
        except (FabricAuthError, ValueError):
            return None
        if not accounts:
            return None
        return {
            "username": accounts[0].get("username"),
            "tenant_id": accounts[0].get("realm"),
            "authority": _AUTHORITY,
        }
    path = _record_path()
    if not path.exists():
        return None
    try:
        record = json.loads(path.read_text())
    except ValueError:
        return None
    return {
        "username": record.get("username"),
        "tenant_id": record.get("tenantId"),
        "authority": record.get("authority"),
    }


def sign_out() -> bool:
    """Forget the account pointer, so the next run prompts again.

    Leaves the keychain entry alone: MSAL owns that, and the record is
    what makes a cached token findable.
    """
    path = _record_path()
    if path.exists():
        path.unlink()
        return True
    return False

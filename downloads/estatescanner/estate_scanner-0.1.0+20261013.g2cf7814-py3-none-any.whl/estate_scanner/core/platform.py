"""Abstract authentication + query interface every BI platform adapter
implements. Every method here defaults to raising NotImplementedError
rather than being a hard `abc.abstractmethod` -- so a stub adapter (Qlik,
Tableau, PowerBI, Looker today) can register with zero overrides, and a
partial real adapter isn't forced to implement object types it doesn't
support yet. Calling an unimplemented one fails clearly and immediately,
which is the point: no silent no-op behavior.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .models import (
        Account,
        Alert,
        App,
        CalculatedField,
        Card,
        Dashboard,
        Dataflow,
        Dataset,
        Group,
        User,
    )


class PlatformSession:
    """An authenticated session for one platform instance/tenant. Opaque
    outside the adapter that created it -- the only contract the rest of
    the system relies on is that it can round-trip through a dict for
    local persistence."""

    platform: str
    instance: str

    def to_persisted_dict(self) -> dict:
        raise NotImplementedError

    @classmethod
    def from_persisted_dict(cls, instance: str, data: dict) -> "PlatformSession":
        raise NotImplementedError


class PlatformAuthenticator:
    platform: str

    def login_interactive(self, instance: str, **kwargs) -> PlatformSession:
        raise NotImplementedError

    def restore_session(self, instance: str, persisted: dict) -> PlatformSession:
        raise NotImplementedError


class PlatformClient:
    platform: str

    def __init__(self, session: PlatformSession):
        self.session = session

    def verify_session(self) -> bool:
        raise NotImplementedError

    def fetch_users(self) -> Iterator["User"]:
        raise NotImplementedError

    def fetch_groups(self) -> Iterator["Group"]:
        raise NotImplementedError

    def fetch_accounts(self) -> Iterator["Account"]:
        raise NotImplementedError

    def fetch_datasets(self) -> Iterator["Dataset"]:
        raise NotImplementedError

    def fetch_dataflows(self) -> Iterator["Dataflow"]:
        raise NotImplementedError

    def fetch_cards(self) -> Iterator["Card"]:
        raise NotImplementedError

    def fetch_dashboards(self) -> Iterator["Dashboard"]:
        raise NotImplementedError

    def fetch_calculated_fields(self) -> Iterator["CalculatedField"]:
        raise NotImplementedError

    def fetch_alerts(self) -> Iterator["Alert"]:
        raise NotImplementedError

    def fetch_apps(self) -> Iterator["App"]:
        raise NotImplementedError

    def estimate_total(self, object_type: str) -> int | None:
        """Best-effort row count for progress reporting. None means unknown
        (the UI shows a running count without a "of N" total)."""
        return None

    def fetch_dataflow_detail(self, dataflow_id: str) -> dict | None:
        """Opt-in deep enrichment (e.g. a full tile-level ETL DAG) -- never
        called by the default scan, since it's one extra request per
        object. None means the platform doesn't support this."""
        return None

"""Reading a Power BI estate scan (EstateScanner's `powerbi` adapter) into the open export's vocabulary.

The export's documents are platform-neutral; the builders in `exporter.py` know Domo's shapes. This module
holds the Power BI half: the neutral kind of each Power BI visual type, a visual's fields, filters and page
layout from the saved PBIR definition, row-level-security roles, measure dependencies in DAX, dataflow
steps, and a stable stand-in for a person's sign-in name (the only identifier Power BI gives for a person).

Every mapping is a table or a small function, and anything it does not know is reported as `other` or left
empty, never guessed.
"""

from __future__ import annotations

import hashlib
import re
from typing import Any

# Power BI visualType -> (neutral kind, variant). Neutral kinds are those of `spec.neutral_visual`.
_VISUALS: dict[str, tuple[str, str | None]] = {
    "columnChart": ("column", "stacked"), "clusteredColumnChart": ("column", "clustered"),
    "hundredPercentStackedColumnChart": ("column", "stacked100"),
    "barChart": ("bar", "stacked"), "clusteredBarChart": ("bar", "clustered"),
    "hundredPercentStackedBarChart": ("bar", "stacked100"),
    "lineChart": ("line", None), "areaChart": ("area", None), "stackedAreaChart": ("area", "stacked"),
    "lineClusteredColumnComboChart": ("combo", "line_clustered_column"),
    "lineStackedColumnComboChart": ("combo", "line_stacked_column"),
    "ribbonChart": ("ribbon", None), "waterfallChart": ("waterfall", None), "funnel": ("funnel", None),
    "pieChart": ("pie", None), "donutChart": ("donut", None), "treemap": ("treemap", None),
    "card": ("single_value", None), "multiRowCard": ("single_value", "multi"), "kpi": ("single_value", "kpi"),
    "gauge": ("gauge", None),
    "tableEx": ("table", None), "pivotTable": ("pivot", None),
    "scatterChart": ("scatter", None),
    "map": ("map", None), "filledMap": ("map", "filled"), "shapeMap": ("map", "shape"), "azureMap": ("map", "azure"),
    "slicer": ("selector", "slicer"), "advancedSlicerVisual": ("selector", "tile"),
    "textbox": ("text", None),
}

# PBIR's aggregate function codes (the ones BIMControl's own writer emits).
_AGGREGATION = {0: "SUM", 1: "AVG", 2: "MIN", 3: "MAX", 4: "COUNT_DISTINCT", 5: "COUNT_NON_NULL"}

# Query bucket -> neutral role. The bucket itself is kept in each field.
_ROLES = {"Category": "item", "Axis": "item", "X": "item", "Rows": "item",
          "Series": "series", "Legend": "series", "Columns": "series",
          "Y": "value", "Y2": "value", "Size": "value", "Values": "value"}

_DAX_COLUMN = re.compile(r"(?:'((?:[^']|'')+)'|([A-Za-z_][A-Za-z0-9_]*))\[([^\]]+)\]")
_DAX_BARE = re.compile(r"(?<![A-Za-z0-9_'\]])\[([^\]]+)\]")


def neutral_visual(visual_type: str | None) -> tuple[str, str | None]:
    return _VISUALS.get(visual_type or "", ("other", None))


def principal_id(raw: Any) -> str | None:
    """A person's sign-in name is the only identifier Power BI gives them. It is an e-mail address, which the
    export never publishes, so it becomes a stable stand-in (the same person always gets the same id). The stand-in
    hides the address from a reader; it does not resist someone who tries the addresses of a known staff list.
    A group or application id (a GUID) is kept."""
    if raw in (None, ""):
        return None
    text = str(raw)
    if "@" not in text:
        return text
    return "upn-" + hashlib.sha256(text.lower().encode("utf-8")).hexdigest()[:12]


# Whether a field or parameter name says it holds a credential, read word by word (`ApiKey`, `x-api-key`, `client_secret`,
# `Access Token`): a substring test blanked `Designation` (sig) and `TokenEndpoint`. A bare `key` is a credential only
# as a URL parameter (`?key=`); in Power Query it is usually a join or record key.
_WORDS = re.compile(r"[A-Z]+(?![a-z])|[A-Z]?[a-z]+|[0-9]+")
_CREDENTIAL_WORDS = {"password", "passwd", "pwd", "secret", "token", "sig", "signature", "authorization", "credential", "credentials",
                     "apikey", "accesskey", "accountkey", "sharedkey"}
_KEY_QUALIFIERS = {"api", "account", "access", "subscription", "shared", "private", "secret", "client", "master"}
_CREDENTIAL_TAILS = ("password", "passwd", "secret", "token", "apikey")      # `dbpassword`, `clientsecret`, `authtoken`
_NAMES_OF_THINGS = {"name", "names", "id", "url", "uri", "endpoint", "type", "header", "headers", "field", "column", "param",
                    "parameter", "expiry", "expires", "expiration", "length", "count", "provider", "scheme", "kind", "style"}


def is_credential_name(name: str) -> bool:
    words = [w.lower() for w in _WORDS.findall(name)]
    if not words or words[-1] in _NAMES_OF_THINGS:
        return False
    if any(w in _CREDENTIAL_WORDS or w.rstrip("s").endswith(_CREDENTIAL_TAILS) for w in words):
        return True
    return any(a in _KEY_QUALIFIERS and b == "key" for a, b in zip(words, words[1:]))


_ASSIGNMENT = re.compile(
    r'(?P<left>#?"[^"=:\n]{1,60}"|[A-Za-z_][\w.\-]{0,60})(?P<op>\s*[=:]\s*)(?P<value>"(?:[^"]|"")*"|[^\s"&;,)\]}\[{(][^\s"&;,)\]}]*)')
_URL_PARAMETER = re.compile(r"([?&])([\w.\-]+)=([^&\s\"')]+)")
_JSON_IN_TEXT = re.compile(r'(""([\w\-]+)""\s*:\s*"")([^"]*)("")')
_STRING_LITERAL = re.compile(r'"(?:[^"]|"")*"')
# the value of a pair: quoted (`""p;ss""` in an M text, `'..'`, `{..}`), else up to `;`, a space, a quote or the next
# `&name=`; a bracket belongs to it only when more of the value follows (`PWD=ab)cd;`)
_PAIR = re.compile(r'''(?<![\w.\-])([\w.\-]{1,40})=(""[^"]*""|'[^']*'|\{[^}]*\}|(?:[^;&"\s)\]}]|&(?![\w.\-]+=)|[)\]}](?=[^;&"\s]))+)''')
_BEARER = re.compile(r"(?i)\b(bearer\s+)[A-Za-z0-9._~+/=-]{16,}")
_BASIC = re.compile(r"(?i)\b(basic\s+)(?=[A-Za-z0-9+/]*[0-9+/=])[A-Za-z0-9+/=]{16,}")
_JWT = re.compile(r"eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]*")


def _hide_assignment(match: re.Match[str]) -> str:
    left, value = match.group("left"), match.group("value")
    if not is_credential_name(left.strip('#"')) or not value.startswith('"'):
        return match.group(0)         # not a literal: Power Query code (`Token = Json.Document(...)`, `Authorization = Source`)
    return f'{left}{match.group("op")}"***"'


def _hide_pairs_in(text: str) -> str:
    return _PAIR.sub(lambda m: f"{m.group(1)}=***" if is_credential_name(m.group(1)) else m.group(0), text)


def _hide_pairs(match: re.Match[str]) -> str:
    """`PWD=...;`, `AccountKey=...;`, `client_secret=...&...` written inside a text literal (connection strings, form bodies)."""
    return _hide_pairs_in(match.group(0))


def scrub_secrets(value: Any) -> Any:
    """A definition copied into the export with credentials in its text blanked: a Power Query step can carry a bearer
    token, an API key in a header or a SAS signature in a URL, and the export is meant to be shared.

    Blanked: the string literal assigned to a name that says it is a credential (`Password="..."`, `[#"x-api-key"="..."]`),
    `name=value` pairs of that kind inside text literals (connection strings, form bodies) and in URLs (`?sig=...`), such
    values inside JSON written in a text literal, `Bearer`/`Basic` tokens and JWTs wherever they appear. Power Query code
    is left alone (`Token = Json.Document(...)` is a step name). A best effort on text of unknown shape: it cannot promise
    there is no secret left in a definition."""
    if isinstance(value, str):
        text = _URL_PARAMETER.sub(lambda m: f"{m.group(1)}{m.group(2)}=***" if is_credential_name(m.group(2)) or m.group(2).lower() == "key"
                                  else m.group(0), value)
        text = _JSON_IN_TEXT.sub(lambda m: m.group(1) + ("***" if is_credential_name(m.group(2)) else m.group(3)) + m.group(4), text)
        text = _STRING_LITERAL.sub(_hide_pairs, text)
        if not any(ch in text for ch in '"(['):
            text = _hide_pairs_in(text)       # the text is itself a literal (a JSON string holding a connection string), not M code
        text = _ASSIGNMENT.sub(_hide_assignment, text)
        return _JWT.sub("***", _BASIC.sub(lambda m: m.group(1) + "***", _BEARER.sub(lambda m: m.group(1) + "***", text)))
    if isinstance(value, list):
        return [scrub_secrets(v) for v in value]
    if isinstance(value, dict):
        return {k: "***" if isinstance(v, str) and is_credential_name(str(k)) else scrub_secrets(v) for k, v in value.items()}
    return value


def _literal(node: Any) -> str | None:
    try:
        value = node["Literal"]["Value"]
    except (KeyError, TypeError):
        return None
    if isinstance(value, str) and len(value) >= 2 and value[0] == "'" and value[-1] == "'":
        return value[1:-1].replace("''", "'")
    return value if isinstance(value, str) else None


def visual_fields(card_definition: dict[str, Any], dataset_id: str | None, metric_ids: set[str]) -> list[dict[str, Any]]:
    """Neutral fields from the scan's per-visual field list. A measure is linked to the exported metric
    `<dataset>:<table>:<name>` when the scan holds it; otherwise `metric_ref` keeps the name."""
    out = []
    for f in card_definition.get("fields") or []:
        kind = str(f.get("kind") or "")
        agg = None
        if kind.startswith("Aggregation("):
            code = kind[len("Aggregation("):-1]
            agg = _AGGREGATION.get(int(code)) if code.isdigit() else None
            if agg is None:
                agg = f"powerbi:{code}"
        is_measure = kind == "Measure"
        metric_id = f"{dataset_id}:{f.get('table')}:{f.get('name')}" if is_measure and dataset_id else None
        bucket = f.get("bucket")
        out.append({
            "role": _ROLES.get(bucket, str(bucket or "value").lower()), "component": "main", "bucket": bucket,
            "table": f.get("table"), "column": None if is_measure else f.get("name"),
            "metric": metric_id if metric_id in metric_ids else None,
            "metric_ref": f.get("name") if is_measure else None,
            "dataset": dataset_id, "aggregation": agg, "alias": None, "format": None,
        })
    return out


def _field_name(field: Any) -> str | None:
    """The column or measure a PBIR field expression names (`{"Column": {"Property": ...}}` and kin)."""
    if isinstance(field, dict):
        for body in field.values():
            if isinstance(body, dict):
                inner = body.get("Property") or body.get("Level")
                if inner:
                    return str(inner)
                nested = _field_name(body.get("Expression"))
                if nested:
                    return nested
    return None


def visual_filters(visual_file: dict[str, Any]) -> list[dict[str, Any]]:
    """Filters saved on a visual (`filterConfig`): the column, its kind, and the values of an `In` condition."""
    out = []
    for flt in ((visual_file.get("filterConfig") or {}).get("filters") or []):
        column = _field_name(flt.get("field"))
        values: list[Any] = []
        for where in ((flt.get("filter") or {}).get("Where") or []):
            condition = where.get("Condition") or {}
            for row in (condition.get("In") or {}).get("Values") or []:
                values += [v for v in (_literal(cell) for cell in row) if v is not None]
        out.append({"column": column, "operand": flt.get("type") or "unknown", "values": values,
                    "data_type": None, "label": flt.get("displayName"), "component": "main"})
    return out


def text_of_textbox(visual_file: dict[str, Any]) -> str | None:
    """Plain text of a text box (`objects.general[].properties.paragraphs`)."""
    pieces: list[str] = []
    for entry in (((visual_file.get("visual") or {}).get("objects") or {}).get("general") or []):
        for paragraph in ((entry.get("properties") or {}).get("paragraphs") or []):
            runs = paragraph.get("textRuns") or []
            pieces.append("".join(r.get("value") or "" for r in runs))
    text = "\n".join(p for p in pieces if p).strip()
    return text or None


def pages(layout: dict[str, Any] | None, title: str | None, card_ids: list[str], card_types: dict[str, str | None]) -> list[dict[str, Any]]:
    """Pages from the scan's report layout: one per report page, each visual with its source position."""
    out: list[dict[str, Any]] = []
    placed: set[str] = set()
    for page in (layout or {}).get("pages") or []:
        items = []
        for v in page.get("visuals") or []:
            pos = v.get("position") or {}
            kind = "text" if v.get("visual_type") == "textbox" else "visual"
            item: dict[str, Any] = {"kind": kind, "grid": {"x": pos.get("x") or 0, "y": pos.get("y") or 0,
                                                         "w": pos.get("width") or 0, "h": pos.get("height") or 0}}
            if kind == "text":
                item["text"] = v.get("title")
            item["visual"] = v.get("card_id")
            placed.add(v.get("card_id"))
            items.append(item)
        out.append({"title": page.get("display_name") or page.get("name") or title or "Page", "items": items})
    leftover = [c for c in card_ids if c not in placed]
    if leftover:
        if not out:
            out.append({"title": title or "Report", "items": []})
        out[0]["items"] += [{"kind": "visual", "visual": c} for c in leftover]
    return out


def policies(raw: list[dict[str, Any]] | None) -> list[dict[str, Any]]:
    """Row-level-security roles of a model, in the export's `access.policies` shape. A role's members are
    people, so they are replaced like any other person; its filter expressions are kept as DAX text."""
    out = []
    for role in raw or []:
        out.append({
            "id": role.get("name"), "name": role.get("name"), "type": "rls_role",
            "user_ids": [principal_id(m) for m in role.get("members") or [] if "@" in str(m)],
            "group_ids": [str(m) for m in role.get("members") or [] if "@" not in str(m)],
            "parameters": [], "model_permission": role.get("model_permission"),
            "expressions": [{"table": f.get("table"), "dax": f.get("expression")} for f in role.get("filters") or []],
        })
    return out


def dax_dependencies(expression: str | None, own_measures: dict[str, str]) -> dict[str, list[str]]:
    """`{columns, metrics}` a DAX expression refers to: `'Table'[Column]` is a column; a bare `[Name]` is a measure
    of the same model when one has that name (`own_measures`: name -> metric id), else a column."""
    columns: list[str] = []
    metrics: list[str] = []
    text = expression or ""
    for m in _DAX_COLUMN.finditer(text):
        name = m.group(3)
        if name in own_measures:
            metrics.append(own_measures[name])
        else:
            columns.append(name)
    for m in _DAX_BARE.finditer(text):
        name = m.group(1)
        (metrics if name in own_measures else columns).append(own_measures.get(name, name))
    return {"columns": list(dict.fromkeys(columns)), "metrics": list(dict.fromkeys(metrics))}


def dataflow_steps(definition: dict[str, Any]) -> list[dict[str, Any]]:
    """Steps of a Power BI dataflow's exported definition: one per entity, with its query text when present.
    Not seen on a real dataflow yet (the test tenant has none); the shape follows the documented model.json."""
    steps = []
    for entity in definition.get("entities") or []:
        if not isinstance(entity, dict) or not entity.get("name"):
            continue
        config = scrub_secrets({k: v for k, v in entity.items() if k in ("description", "attributes", "partitions", "pbi:refreshPolicy")})
        steps.append({"id": str(entity["name"]), "type": "power_query_entity", "name": entity.get("name"),
                      "depends_on": [], "config": config})
    mashup = ((definition.get("pbi:mashup") or {}).get("document")) if isinstance(definition.get("pbi:mashup"), dict) else None
    if mashup and steps:
        steps[0]["config"] = {**steps[0]["config"], "query_document": scrub_secrets(mashup)}
    return steps

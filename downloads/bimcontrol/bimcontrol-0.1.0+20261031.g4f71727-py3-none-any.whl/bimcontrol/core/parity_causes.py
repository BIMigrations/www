"""Why do a dashboard's figures differ from Domo's? Name the cause where the run's own evidence names one.

Parity already records two kinds of evidence that the source moved on: a model table that holds another row
count than Domo's dataset (`table_rows`) and a dataset Domo built before one of its inputs was updated
(`stale_inputs`). This reads them back per differing card, in the order the triage playbook checks them, so a
dashboard whose 3 differing values sit on a table that gained 40 rows reads differently from one with 4,000
differing values and equal row counts. It adds no data source: everything comes from the run's own artefacts.

A cause is evidence, not a verdict: nothing is dropped from the comparison, a dashboard with a named cause never
counts as proven, and the default is `unexplained`.
"""

from __future__ import annotations

import importlib.util
import json
import math
import os
import re
import time
from pathlib import Path
from typing import Any

from bimcontrol.core.column_lineage import CLOCK, UNKNOWN

INCOMPLETE_KEPT_SECONDS = 86400
CACHE_VERSION = 6       # bump when a cause rule changes: a kept answer is only as good as the rules that made it
_REFERENCE = re.compile(r"`([^`]+)`")
ROW_COUNT = "row_count"
STALE_INPUT = "stale_input"
SOURCE_MOVED = "source_moved"
CASE_COLLAPSE = "case_collapse"
RUN_DATE = "run_date"
UNEXPLAINED = "unexplained"
DRIFT_SHARE = 0.02     # a table off by more than 2% of Domo's rows is not the data moving on: a defect or another meaning
DRIFT_FLOOR = 2        # ...but a couple of rows are always the data moving on, whatever the table's size
DORMANT_DAYS = 30      # a dataset Domo built a month or more before its input moved is a flow that no longer runs, not drift
DIFFERING_SHARE = 0.25  # a cause that moved a quarter of a card's figures or more is not "a few late rows"


def within_drift(domo_rows: int, model_rows: int) -> bool:
    """Whether a model table's row count is close enough to Domo's to be the data moving on."""
    return abs(int(model_rows) - int(domo_rows)) <= max(DRIFT_SHARE * int(domo_rows), DRIFT_FLOOR)
CAUSES = (ROW_COUNT, STALE_INPUT, SOURCE_MOVED, RUN_DATE, CASE_COLLAPSE, UNEXPLAINED)


def _load(run_dir: Path, *parts: str) -> Any:
    try:
        return json.loads(run_dir.joinpath(*parts).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def _number(value: Any) -> float | None:
    return float(value) if isinstance(value, (int, float)) and not isinstance(value, bool) else None


def _case_collapsed_rows(card_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """The differing values of a card that are a spelling Power BI folded into another one.

    Power BI keeps text that differs only in letter case as one value (the first spelling it met); Domo and the warehouse keep
    them apart (Clinic Collections-SW 'Transaction Codes': `Balance forward` 31.68, `balance forward` 160.35 and `Balance Forward`
    20.00 are one row of 212.03). Arithmetic is the evidence, value by value: a differing grain counts when it has a case-folded
    twin with another spelling and the sum of the twins' source values equals one of their model values. A rate or an average does
    not add up and is not counted; the values beside it that do are (Clinic Collections-SW card 152432111: 73 of 96, #485)."""
    groups: dict[str, list[dict[str, Any]]] = {}
    for row in card_rows:
        groups.setdefault(str(row.get("grain")).casefold(), []).append(row)
    proven = []
    for row in card_rows:
        if row.get("state") != "error":
            continue
        group = groups[str(row.get("grain")).casefold()]
        if len({str(r.get("grain")) for r in group}) < 2:
            continue
        total = sum(_number(r.get("source")) or 0.0 for r in group)
        if any(t is not None and math.isclose(total, t, rel_tol=1e-6, abs_tol=1e-6) for t in (_number(r.get("target")) for r in group)):
            proven.append(row)
    return proven


def _moved_slightly(row: dict[str, Any]) -> bool:
    """Whether a differing value is paired (both sides drew the key) and within DRIFT_SHARE of Domo's figure.

    That is how a source that gained a few percent of its rows moves a total: every figure a little, none out of recognition. A
    key only one side has, a figure that is zero or missing in Domo, or a move beyond the bound is something else."""
    source, target = _number(row.get("source")), _number(row.get("target"))
    return not (source is None or target is None or source == 0 or abs(target - source) > DRIFT_SHARE * abs(source))


def _key_of_one_side(row: dict[str, Any]) -> bool:
    """Whether a differing value is a key only one side drew: Domo's row without a model value, or the model's without Domo's row.
    A key Domo drew with a blank cell (`source_row`) is paired: its value differs, its key does not."""
    if row.get("source") is None:
        return row.get("target") is not None and not row.get("source_row")
    return row.get("target") is None


def _upstream(dataset_ids: list[str], closure: dict[str, Any]) -> set[str]:
    """The datasets, and every dataset their dataflows read, transitively."""
    produced_by = {d["id"]: d.get("produced_by") for d in closure.get("datasets") or []}
    inputs = {f["id"]: f.get("input_dataset_ids") or [] for f in closure.get("dataflows") or []}
    seen: set[str] = set()
    todo = list(dataset_ids)
    while todo:
        current = todo.pop()
        if current in seen:
            continue
        seen.add(current)
        todo.extend(inputs.get(produced_by.get(current), []))
    return seen


def moved_inputs_of(dataset_ids: list[str], closure: dict[str, Any], parity: dict[str, Any]) -> list[dict[str, Any]]:
    """The warehouse tables upstream of these datasets that hold another row count than Domo's dataset, at most 2 % apart
    (parity's `moved_inputs`). A table further off is not the source moving on."""
    upstream = _upstream(dataset_ids, closure)
    return [e for e in parity.get("moved_inputs") or []
            if e.get("dataset_id") in upstream and within_drift(e["domo_rows"], e["warehouse_rows"])]


class _Lineage:
    """The run's column lineage, built when the first card asks (sqlglot is an optional dependency: none means no evidence)."""

    def __init__(self, run_dir: Path, dormant: set[str]):
        self._run_dir = run_dir
        self._dormant = dormant
        self._lineage: Any = None
        self._tried = False

    def reaches(self, dataset_id: str, dormant: set[str]) -> bool:
        self._open()
        try:
            return bool(self._lineage and self._lineage.reaches(dataset_id, dormant))
        except Exception:  # noqa: BLE001 -- no evidence is not a stop
            return False

    def feeders(self, dataset_id: str, column: str) -> frozenset[str]:
        self._open()
        return self._lineage.feeders(dataset_id, column) if self._lineage else frozenset({UNKNOWN})

    @property
    def exhausted(self) -> bool:
        """Whether the lineage ran out of time: the answer built with it depends on the machine, so it is not kept."""
        return bool(self._lineage and self._lineage.exhausted)

    def _open(self) -> None:
        if not self._tried:
            self._tried = True
            try:
                from bimcontrol.core.column_lineage import ColumnLineage  # noqa: PLC0415

                self._lineage = ColumnLineage(self._run_dir, self._dormant)
            except Exception:  # noqa: BLE001 -- sqlglot is not installed, or the artefacts are of another shape: no evidence
                self._lineage = None


def _only_frozen(dataset_id: str, columns: list[str], dormant: set[str], lineage: _Lineage) -> bool:
    """Whether the columns are read from dormant datasets and from no other dataset a flow built.

    A key that is a union of a frozen history and live feeders (Productivity's pay periods: sixteen datasets, some of them
    this year's) moves only where the frozen part is; "reads a dormant dataset" is not enough, so every flow-built feeder must be one."""
    feeders: set[str] = set()
    for column in columns:
        feeders |= lineage.feeders(dataset_id, column) - {CLOCK}
    return bool(feeders) and feeders <= dormant


def _shown(column: dict[str, Any]) -> bool:
    """A column the card draws (not one that only filters, orders or sets the date grain)."""
    return column.get("columnType") in (None, "SELECT", "GROUP_BY", "DATE_GRAIN")


def _frozen(card: dict[str, Any], name: str, dormant: set[str], lineage: _Lineage, calculated: dict[str, str]) -> bool:
    """Whether every column of the card called `name` (its field name, its alias, or a card formula's name) is read only from dormant datasets."""
    found = False
    for subscription in card.get("data_subscriptions") or []:
        dataset_id = str(subscription.get("dataSourceId") or "")
        for column in subscription.get("columns") or []:
            if _shown(column) and name.lower() in {str(column.get("name")).lower(), str(column.get("alias")).lower()}:
                if column.get("formula") and column.get("name") in calculated:
                    references = _REFERENCE.findall(calculated[column["name"]])
                else:
                    references = [str(column["name"])]
                if not dataset_id or not references or not _only_frozen(dataset_id, references, dormant, lineage):
                    return False
                found = True
    return found


def _keys_frozen(subscription: dict[str, Any], dormant: set[str], lineage: _Lineage) -> bool | None:
    """Whether the keys of one dataset of a card are read only from dormant datasets (None: it has no key to say)."""
    keys = [str(c["name"]) for c in subscription.get("columns") or []
            if c.get("name") and _shown(c) and not c.get("aggregation") and not c.get("formula")]
    return _only_frozen(str(subscription["dataSourceId"]), keys, dormant, lineage) if keys else None


def _keys_read_clock(card: dict[str, Any], lineage: _Lineage) -> bool:
    """Whether a column the card is keyed on (shown, no aggregation, no card formula) is computed from the date the flow runs.

    Executive Summary Productivity 'Employee by Pay Type Category': `Years of Service` is the days from the hire date to the
    flow's CURRENT_DATE. Domo's dataset holds the value of its last run, the model the value of the day ours ran, so the
    rows of every employee still employed carry a key the other side does not have."""
    for subscription in card.get("data_subscriptions") or []:
        dataset_id = str(subscription.get("dataSourceId") or "")
        for column in subscription.get("columns") or []:
            if dataset_id and column.get("name") and _shown(column) and not column.get("aggregation") and not column.get("formula") \
                    and CLOCK in lineage.feeders(dataset_id, str(column["name"])):
                return True
    return False


def _frozen_cause(card: dict[str, Any], measures: set[str], dormant: set[str], lineage: _Lineage, calculated: dict[str, str]) -> bool:
    """A card whose figures differ wholesale, with a frozen dataset behind the *column* that moves them.

    Only the columns derived from a dormant dataset are frozen (Profitability Trend-SW 'Patient Class': `Bad Debt Ins Code`
    is a LEFT JOIN to a Bad Debt dataset Domo built 840 days before its input; `Cases` under it sums to the same total on
    both sides). So either the columns the card groups by (no aggregation, no card formula) are read from dormant datasets
    and from no live flow: every row moves under a shifted key; or every measure whose figures differ is (BD Patient Class:
    Bad Debt Acct Bal, Bad debt SP...: the other measures of the card are equal). A column that cannot be traced says no."""
    subscriptions = [sub for sub in card.get("data_subscriptions") or [] if sub.get("dataSourceId")]
    if not subscriptions or not all(lineage.reaches(str(sub["dataSourceId"]), dormant) for sub in subscriptions):
        return False                # a dataset of the card that no frozen one reaches could be what differs
    if all(_keys_frozen(sub, dormant, lineage) is not False for sub in subscriptions) \
            and any(_keys_frozen(sub, dormant, lineage) for sub in subscriptions):
        return True
    return bool(measures) and all(_frozen(card, m, dormant, lineage, calculated) for m in measures)


def explain_differences(run_dir: str | Path) -> dict[str, Any] | None:
    """`_explain` that never stops a rollup: artefacts of an older shape just have no causes.

    The answer is kept beside the parity file it was read from (`verify_parity/causes.json`, keyed on that file's and the
    conversion's size and time, on CACHE_VERSION and on whether sqlglot is there): a rollup asks about every differing run
    each time a dashboard finishes, and the column lineage behind a frozen-feeder cause takes seconds on a large flow. An
    answer built after the lineage ran out of time is the conservative one (no frozen cause named) and depends on the
    machine, so it is kept for a day only (INCOMPLETE_KEPT_SECONDS), not for good."""
    run_dir = Path(run_dir)
    key = _cache_key(run_dir)
    cached = _load(run_dir, "verify_parity", "causes.json")
    if key and isinstance(cached, dict) and cached.get("key") == key and "result" in cached \
            and (not cached.get("incomplete") or time.time() - float(cached.get("at") or 0) < INCOMPLETE_KEPT_SECONDS):
        return cached["result"]
    try:
        result = _explain(run_dir)
    except (KeyError, TypeError, ValueError, AttributeError):
        return None
    if result is None:
        return None
    incomplete = bool(result.pop("incomplete", False))
    if key:
        try:
            target = run_dir / "verify_parity" / "causes.json"
            temporary = target.with_suffix(f".{os.getpid()}.tmp")
            temporary.write_text(json.dumps({"key": key, "result": result, "incomplete": incomplete, "at": time.time()}), encoding="utf-8")
            temporary.replace(target)
        except OSError:
            pass            # a run directory that cannot be written is explained again next time
    return result


def _cache_key(run_dir: Path) -> list[Any] | None:
    try:
        stat = run_dir.joinpath("verify_parity", "parity.json").stat()
    except OSError:
        return None
    try:
        conversion = run_dir.joinpath("convert_dataflows", "conversion.json").stat()
        converted = [conversion.st_size, conversion.st_mtime_ns]
    except OSError:
        converted = []
    return [CACHE_VERSION, stat.st_size, stat.st_mtime_ns, converted, importlib.util.find_spec("sqlglot") is not None]


def _explain(run_dir: Path) -> dict[str, Any] | None:
    """Per cause, how many differing values and cards the evidence explains (None: no parity to read).

    - `row_count`: a table the card reads holds another row count than Domo's dataset, by at most 2% of Domo's
      rows (more is not drift: Accts Receivable's Monthly SnapShot held 1.7M of Domo's 23.7M, an append dataflow's
      history), **and** the card's differing values are no more than the rows that table gained or lost. One late
      row moves one group, so more differing values than that cannot be put down to the extra rows alone.
    - `stale_input`: the card reads a dataset Domo built before one of its inputs (or an input's input) was
      updated: Domo's figures are those of the older data.
    - Neither cause applies to a card a quarter or more of whose figures differ (Query - Encounter w/ Charge Detail:
      15,810 of 15,813 differ, every key missing from Domo's render: not late rows, not an old input).
    - `run_date`: every differing value is a key only one side has, and a column the card is keyed on is computed from the
      date the flow runs (`CURRENT_DATE`, `GETDATE()`): Domo's dataset holds the keys of its last run, the model those of
      the day ours ran. Named even when most of the card differs, since the whole card moves with the key.
    - `source_moved`: the card reads, through its dataflows, a warehouse table that holds another row count than the Domo
      dataset does now (or the scan's, when Domo would not answer: parity's `moved_inputs`, at most 2 % apart), and every
      differing value is paired and within 2 % of Domo's figure. Consistent with the source having moved on: a connector dataset
      is an import, the model reads the live table, so every figure built on it would move a little (Clinic AR Balance - SW:
      142,376 rows posted after Domo's import, 81 of 109 values off by 0.1-1.3 %). The figures do not confirm it: the row gap is not
      tied to the size of the shift (a card keyed on a computed ratio loses 2,347 pairs to a 0.94 % gap), so it is a possible cause.
      Only where nothing above applies. A card with a key only one side has, or a value that moved further, stays
      `unexplained` as a card, but its values that are paired and within the bound are still counted `source_moved` (per
      value, as `case_collapse` is: Clinic AR Balance - SW, 80 values within 0.63 % and one at 2.31 %, #494).
    - `case_collapse`: a differing value is text that differs only in letter case from a twin, and the twins' source values add
      up to a model value (Power BI shows such text as one value). Counted per value and ahead of every other cause: the
      arithmetic accounts for each value, whatever share of the card they are, and a card in which every differing value is
      one is `case_collapse` as a whole. The card's other values keep its own cause. A table far from Domo's row count still
      rules it out.
    - `unexplained`: everything else, and any card reading a table far from Domo's row count (or empty), whatever
      else is stale. Triage these first. The exception is a non-empty table whose own dataset Domo built 30 or more
      days before an input moved (a dataflow that no longer runs): Domo's rows are those of the old build, so the
      count is not evidence of a defect and the card falls to `stale_input`, however many of its figures differ.
    """
    parity = _load(run_dir, "verify_parity", "parity.json")
    if not parity or not parity.get("checked"):
        return None
    closure = _load(run_dir, "resolve_closure", "closure.json") or {}
    model = _load(run_dir, "build_model", "semantic_model.json") or {}

    cards = {str(c["id"]): c for c in closure.get("cards") or []}
    origin_of = {t["name"]: t.get("origin") for t in model.get("tables") or []}
    names = {d["id"]: d["name"] for d in closure.get("datasets") or []}
    stale_ids = {s["dataset_id"] for s in parity.get("stale_inputs") or [] if s.get("dataset_id")}
    stale_names = {s["dataset"] for s in parity.get("stale_inputs") or [] if not s.get("dataset_id")}  # older runs
    dormant = {s["dataset_id"] for s in parity.get("stale_inputs") or []
               if s.get("dataset_id") and (s.get("days") or 0) >= DORMANT_DAYS}
    moved: dict[str, int] = {}
    broken: set[str] = set()        # tables too far from Domo's to be the data moving on (an empty table included)
    for t in parity.get("table_rows") or []:
        origin = origin_of.get(t["table"])
        if not (t.get("differs") and t.get("model_rows") is not None and origin):
            continue
        if within_drift(t["domo_rows"], t["model_rows"]):
            moved[origin] = abs(int(t["model_rows"]) - int(t["domo_rows"]))
        elif origin in dormant and int(t["model_rows"]) > 0:
            continue    # Domo's copy is frozen at an older build (Labor & Benefits: last built 568 days before its inputs): its rows are not the bar
        else:
            broken.add(origin)

    grains: dict[str, set[str]] = {}
    one_sided: dict[str, bool] = {}     # every differing row of the card is a key only one side has
    measures: dict[str, set[str]] = {}
    calculated = {f["name"]: f.get("formula") or "" for f in closure.get("calculated_fields") or [] if f.get("name")}
    compared: dict[str, int] = {}
    card_rows: dict[str, list[dict[str, Any]]] = {}
    for row in parity.get("rows") or []:
        compared[str(row["card_id"])] = compared.get(str(row["card_id"]), 0) + 1
        card_rows.setdefault(str(row["card_id"]), []).append(row)
        if row.get("state") == "error":
            grains.setdefault(str(row["card_id"]), set()).add(str(row.get("grain")))
            one_sided[str(row["card_id"])] = one_sided.get(str(row["card_id"]), True) and _key_of_one_side(row)
            measures.setdefault(str(row["card_id"]), set()).add(str(row.get("grain")).rsplit(" · ", 1)[-1])   # 'row = key · measure'

    lineage = _Lineage(run_dir, dormant)
    values = {c: 0 for c in CAUSES}
    by_card: dict[str, str] = {}
    for card_id, differing in grains.items():
        card = cards.get(card_id) or {}
        read = [str(d) for d in card.get("dataset_ids") or []]
        rows_moved = sum(moved.get(d, 0) for d in read)
        # A frozen Domo dataset differs wholesale from a rebuild on today's inputs: "mostly off" is what it looks like.
        mostly_off = len(differing) >= DIFFERING_SHARE * compared[card_id] and not dormant.intersection(read)
        input_moved = bool(moved_inputs_of(read, closure, parity))
        differing_rows = [r for r in card_rows[card_id] if r.get("state") == "error"]
        # differing_rows is never empty here: grains only holds cards with at least one error row (all([]) would be True)
        source_moved = input_moved and all(_moved_slightly(r) for r in differing_rows)
        errors = len(differing_rows)
        folded_rows = [] if broken.intersection(read) else _case_collapsed_rows(card_rows[card_id])
        proven = len(folded_rows)
        folded = proven == errors       # every differing value of the card is a folded spelling: the card is case_collapse as a whole
        frozen = (not folded and mostly_off and dormant and not broken.intersection(read)
                  and _frozen_cause(card, measures.get(card_id, set()), dormant, lineage, calculated))
        if folded:
            cause = CASE_COLLAPSE       # every differing value is a spelling Power BI folded into another one: the totals agree
        elif broken.intersection(read):
            cause = UNEXPLAINED         # a table Domo's rows do not fit: not drift
        elif frozen:
            cause = STALE_INPUT         # a frozen dataset behind the column that moves the figures: Domo's figures are the old build's
        elif mostly_off:               # not a few late rows: a key computed from the run date is the one thing that still names it
            cause = RUN_DATE if one_sided[card_id] and _keys_read_clock(card, lineage) else (SOURCE_MOVED if source_moved else UNEXPLAINED)
        elif rows_moved and len(differing) <= rows_moved:
            cause = ROW_COUNT
        elif any(d in stale_ids or names.get(d) in stale_names for d in _upstream(read, closure)):
            cause = STALE_INPUT
        elif one_sided[card_id] and _keys_read_clock(card, lineage):
            cause = RUN_DATE            # a key computed from the run date: the rows of the two days cannot pair
        elif source_moved:
            cause = SOURCE_MOVED        # an input table holds another row count than Domo's dataset (a gap that can be rows posted since its import), and every figure moved only slightly
        else:
            cause = UNEXPLAINED
        by_card[card_id] = cause
        # The values the arithmetic proves are case_collapse whatever the card's own cause is (a stronger claim than a stale
        # input's date); the others keep the label the card had before this was counted per value, so nothing else moves.
        values[CASE_COLLAPSE] += proven
        # A card with one value past the bound stays unexplained (triage it), but the values within the bound are still the
        # source moving: counted per value, as case_collapse is, so one outlier does not take the others with it (#494).
        folded_ids = {id(r) for r in folded_rows}
        slight = (sum(1 for r in differing_rows if id(r) not in folded_ids and _moved_slightly(r))
                  if cause == UNEXPLAINED and input_moved and not broken.intersection(read) else 0)
        values[SOURCE_MOVED] += slight
        values[cause] += errors - proven - slight
    cards_by = {c: sum(1 for v in by_card.values() if v == c) for c in CAUSES}
    return {"values": values, "cards": cards_by, "by_card": by_card, "incomplete": lineage.exhausted}

"""Power BI / Microsoft Fabric sign-in: the PlatformAuthenticator implementation.

Power BI is a real OAuth surface, so this talks to MSAL directly instead of
driving a browser the way Domo's login does. Two things shape the flow:

- **Device code is not an option.** Tenants with Entra security defaults (every
  new tenant since July 2026) block the device-code flow outright (AADSTS530035).
  The authorization-code flow with PKCE is allowed, so the operator path is
  ``acquire_token_interactive``: MSAL opens the system browser, the person signs
  in, and a localhost redirect hands the code back.
- **Unattended runs read an MSAL cache.** Someone signs in once (here, or with
  any tool that writes an MSAL token cache), and every later run, including a
  scheduled one, refreshes silently. ``ESTATE_SCANNER_MSAL_CACHE`` points at a
  cache prepared elsewhere; otherwise the scanner keeps its own beside the
  database. The refresh token is a credential: the file is mode 600, and
  nothing here ever prints or exports a token.

The public client is Microsoft's own "Azure CLI" app, the one azure-identity
falls back to, so there is no app registration to provision. The persisted
session holds only an account pointer (username, cache path), never a token.
"""

from __future__ import annotations

import os
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from estate_scanner.core.platform import PlatformAuthenticator, PlatformError, PlatformSession

# Fabric item management and the classic Power BI REST surface are separate
# token audiences -- a token for one is not accepted by the other.
FABRIC_SCOPE = "https://api.fabric.microsoft.com/.default"
POWERBI_SCOPE = "https://analysis.windows.net/powerbi/api/.default"

PUBLIC_CLIENT_ID = "04b07795-8ddb-461a-bbee-02f9e1bf7b46"  # Azure CLI, azure-identity's default
AUTHORITY = "https://login.microsoftonline.com/organizations"
MSAL_CACHE_ENV = "ESTATE_SCANNER_MSAL_CACHE"
LOGIN_TIMEOUT_S = 600
# Refresh a little before the token really expires so a request in flight
# never carries a dead one.
_EXPIRY_MARGIN_S = 120


class PowerBiAuthError(PlatformError):
    pass


def default_cache_path() -> Path:
    override = os.environ.get(MSAL_CACHE_ENV)
    if override:
        return Path(override).expanduser()
    return Path.home() / ".estate-scanner" / "powerbi-msal-cache.json"


@dataclass
class PowerBiSession(PlatformSession):
    instance: str
    username: str | None = None
    cache_path: str | None = None
    platform: str = "powerbi"

    def to_persisted_dict(self) -> dict:
        return {"username": self.username, "cache_path": self.cache_path}

    @classmethod
    def from_persisted_dict(cls, instance: str, data: dict) -> "PowerBiSession":
        return cls(instance=instance, username=data.get("username"), cache_path=data.get("cache_path"))


def _msal():
    try:
        import msal  # noqa: PLC0415 -- optional extra, see pyproject.toml
    except ImportError as exc:
        raise PowerBiAuthError(
            "Power BI / Fabric needs the 'powerbi' extra: pip install 'estate-scanner[powerbi]'"
        ) from exc
    return msal


class TokenProvider:
    """Silent access tokens from an MSAL cache file, one per scope, kept until
    shortly before they expire. Safe to share between threads. Never prompts."""

    def __init__(self, cache_path: Path, username: str | None = None):
        self._path = Path(cache_path)
        self._username = username
        self._lock = threading.Lock()
        self._tokens: dict[str, tuple[str, float]] = {}

    def _app(self):
        msal = _msal()
        cache = msal.SerializableTokenCache()
        try:
            cache.deserialize(self._path.read_text())
        except (OSError, ValueError) as exc:
            raise PowerBiAuthError(f"Cannot read the Power BI sign-in cache {self._path}: {exc}") from exc
        app = msal.PublicClientApplication(PUBLIC_CLIENT_ID, authority=AUTHORITY, token_cache=cache)
        return app, cache

    def _account(self, app) -> dict:
        accounts = app.get_accounts()
        if self._username:
            # Never fall back to another account: a replaced cache must not scan as someone else.
            accounts = [a for a in accounts if a["username"].lower() == self._username.lower()]
            if not accounts:
                raise PowerBiAuthError(f"The sign-in cache {self._path} has no sign-in for {self._username}; sign in again.")
        if not accounts:
            raise PowerBiAuthError(f"The sign-in cache {self._path} has no signed-in account; sign in again.")
        return accounts[0]

    def token(self, scope: str) -> str:
        with self._lock:
            cached = self._tokens.get(scope)
            if cached and cached[1] - _EXPIRY_MARGIN_S > time.time():
                return cached[0]
            app, cache = self._app()
            account = self._account(app)
            try:
                result = app.acquire_token_silent([scope], account=account)
            except Exception as exc:  # noqa: BLE001 -- msal surfaces network errors as requests exceptions
                raise PowerBiAuthError(f"Could not refresh a Power BI token for {account['username']}: {type(exc).__name__}") from exc
            if not result or "access_token" not in result:
                raise PowerBiAuthError(
                    f"Could not refresh a Power BI token for {account['username']} from {self._path}; sign in again."
                )
            if cache.has_state_changed:
                _write_private(self._path, cache.serialize())
            expires = time.time() + int(result.get("expires_in", 0))
            self._tokens[scope] = (result["access_token"], expires)
            return result["access_token"]


def _write_private(path: Path, text: str) -> None:
    """Replace the file whole (a reader never sees a half-written cache), mode 600."""
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".{os.getpid()}.tmp")
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as fh:
        fh.write(text)
    os.replace(tmp, path)


def provider_for(session: PowerBiSession) -> TokenProvider:
    return TokenProvider(Path(session.cache_path) if session.cache_path else default_cache_path(), session.username)


class PowerBiAuthenticator(PlatformAuthenticator):
    platform = "powerbi"

    def login_interactive(self, instance: str, *, login_hint: str | None = None, **kwargs: Any) -> PowerBiSession:
        """Use the saved sign-in when the cache already holds one (so an
        unattended machine never opens a window); otherwise open the system
        browser once. With ESTATE_SCANNER_MSAL_CACHE set it never opens one. `instance` is only this session's label, e.g. the tenant
        domain: Entra decides the tenant from whichever account signs in."""
        msal = _msal()
        path = default_cache_path()
        cache = msal.SerializableTokenCache()
        if path.exists():
            cache.deserialize(path.read_text())
        prepared = bool(os.environ.get(MSAL_CACHE_ENV))
        app = msal.PublicClientApplication(PUBLIC_CLIENT_ID, authority=AUTHORITY, token_cache=cache)
        accounts = app.get_accounts()
        if login_hint:  # asking for a particular account: only that one will do
            accounts = [a for a in accounts if a["username"].lower() == login_hint.lower()]
        if accounts:
            silent = app.acquire_token_silent([FABRIC_SCOPE], account=accounts[0])
            if silent and "access_token" in silent:
                return PowerBiSession(instance=instance, username=accounts[0]["username"], cache_path=str(path))
        if prepared:
            # An operator named the cache for an unattended run: a window nobody
            # will see would only hang until the timeout.
            raise PowerBiAuthError(
                f"{MSAL_CACHE_ENV} points at {path}, which holds no usable sign-in; sign in again and replace it."
            )
        result = app.acquire_token_interactive(
            [FABRIC_SCOPE], login_hint=login_hint, timeout=LOGIN_TIMEOUT_S, prompt="select_account"
        )
        if "access_token" not in result:
            raise PowerBiAuthError(f"Sign-in failed: {result.get('error_description') or result.get('error')}")
        _write_private(path, cache.serialize())
        username = (result.get("id_token_claims") or {}).get("preferred_username")
        return PowerBiSession(instance=instance, username=username, cache_path=str(path))

    def restore_session(self, instance: str, persisted: dict) -> PowerBiSession:
        return PowerBiSession.from_persisted_dict(instance, persisted)

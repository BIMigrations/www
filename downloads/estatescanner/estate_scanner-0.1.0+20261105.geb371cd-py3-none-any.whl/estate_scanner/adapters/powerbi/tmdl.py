"""A small reader for the parts of TMDL the scan needs: which tables, columns,
measures and row-level-security roles a semantic model holds.

TMDL is indentation-based: an object keyword at some depth (``table``,
``column``, ``measure``, ``role``), its properties one level deeper
(``formatString: 0``), and an expression either on the keyword line after ``=``
or on the lines below it (indented deeper, or fenced with ``` ``` ```). This
reader does not try to validate the language; it pulls out names, expressions
and a handful of properties, and leaves the full text in the stored definition.
"""

from __future__ import annotations

import re
import textwrap
from typing import Any

_KEYWORD = re.compile(r"^(?P<kw>table|column|measure|role|tablePermission|partition|hierarchy|calculationGroup)\s+(?P<rest>.*)$")
_PROPERTY = re.compile(r"^(?P<key>[A-Za-z][A-Za-z0-9_]*)\s*(?::\s*(?P<value>.*))?$")
_PROPERTIES_KEPT = {
    "dataType", "formatString", "displayFolder", "isHidden", "sourceColumn", "summarizeBy", "description",
    "modelPermission", "mode", "isKey", "dataCategory", "lineageTag",
}


def _depth(line: str) -> int:
    n = 0
    for ch in line:
        if ch == "\t":
            n += 1
        else:
            break
    return n


def _unquote(name: str) -> str:
    name = name.strip()
    if len(name) >= 2 and name[0] == "'" and name[-1] == "'":
        return name[1:-1].replace("''", "'")
    return name


def _split_name_expression(rest: str) -> tuple[str, str | None]:
    """``'My Measure' = SUM(...)`` -> (name, expression); quotes may hold ``=``."""
    rest = rest.strip()
    if rest.startswith("'"):
        i = 1
        while i < len(rest):
            if rest[i] == "'":
                if i + 1 < len(rest) and rest[i + 1] == "'":
                    i += 2
                    continue
                break
            i += 1
        name = _unquote(rest[: i + 1])
        tail = rest[i + 1 :].strip()
    else:
        m = re.match(r"^([^=\s]+)\s*(.*)$", rest)
        name, tail = (m.group(1), m.group(2).strip()) if m else (rest, "")
    if tail.startswith("="):
        return name, tail[1:].strip() or None
    return name, None


def _block(lines: list[str], start: int) -> tuple[int, int]:
    """Index range of the lines after ``start`` that are deeper than it."""
    d = _depth(lines[start])
    end = start + 1
    while end < len(lines) and (not lines[end].strip() or _depth(lines[end]) > d):
        end += 1
    while end > start + 1 and not lines[end - 1].strip():
        end -= 1
    return start + 1, end


_FLAGS = {"isHidden", "isKey"}
_FENCE = "```"


def _dedent(lines: list[str]) -> str:
    return textwrap.dedent("\n".join(lines)).strip("\n").strip()


def _read_object(lines: list[str], start: int) -> dict[str, Any]:
    """One keyword line plus its body: the object's own expression, kept properties,
    and (for a partition) its ``source`` query.

    The body is read by level. A line one level below the keyword is the object's own
    property (``formatString: 0``), a ``source =`` query, or a nested object (annotation,
    variation, ``formatStringDefinition = ...``) whose deeper lines are not ours. Lines two or
    more levels below, before any such line, are the object's expression; a fence (three
    backticks) opens and closes a block, on its own lines or around a one-line expression.
    """
    d = _depth(lines[start])
    stripped = lines[start].strip()
    m = _KEYWORD.match(stripped)
    kw = m.group("kw") if m else ""
    name, tail = _split_name_expression(m.group("rest")) if m else (stripped, None)
    first, end = _block(lines, start)
    properties: dict[str, Any] = {}
    buffers: dict[str, list[str]] = {"main": [], "source": []}
    owner = "main"
    fenced = False

    def open_tail(tail_text: str | None, target: str) -> None:
        """Take the text after ``=`` on a header line: an inline expression, or a fence opener."""
        nonlocal fenced
        if not tail_text:
            return
        if tail_text.startswith(_FENCE):
            rest = tail_text[len(_FENCE):]
            if rest.rstrip().endswith(_FENCE):  # fence opens and closes on the same line
                buffers[target].append(rest.rstrip()[: -len(_FENCE)].strip())
            else:
                fenced = True
                if rest.strip():
                    buffers[target].append(rest.strip())
        else:
            buffers[target].append(tail_text)

    open_tail(tail, "main")
    for raw in lines[first:end]:
        text = raw.strip()
        if fenced:
            if text.startswith(_FENCE):
                fenced = False
            elif owner in buffers:
                buffers[owner].append(raw)
            continue
        if not text or text.startswith("///"):
            continue
        depth = _depth(raw)
        if depth >= d + 2:
            if owner in buffers:
                buffers[owner].append(raw)
            continue
        if text.startswith(_FENCE):  # a stray fence line at property level: take it as the owner's block
            fenced = True
            continue
        p = _PROPERTY.match(text)
        if p and (p.group("value") is not None or text in _FLAGS):
            owner = "ignore"
            key, value = p.group("key"), p.group("value")
            if value is not None and value.strip().startswith(_FENCE):
                fenced = True  # a multi-line property value: skip its block
            elif key in _PROPERTIES_KEPT:
                properties[key] = True if value is None else value.strip()
        elif kw == "partition" and re.match(r"^source\s*=", text):
            owner = "source"
            open_tail(text.split("=", 1)[1].strip(), "source")
        else:  # annotation, variation, extendedProperty, formatStringDefinition = ..., and the like
            owner = "ignore"
            tail_text = text.split("=", 1)[1].strip() if "=" in text else ""
            if tail_text.startswith(_FENCE) and not tail_text[len(_FENCE):].rstrip().endswith(_FENCE):
                fenced = True
    out: dict[str, Any] = {"kind": kw, "name": name, "properties": properties}
    if kw == "partition":
        out["source_type"] = _dedent(buffers["main"]) or None
        if buffers["source"]:
            out["expression"] = _dedent(buffers["source"])
    elif buffers["main"]:
        out["expression"] = _dedent(buffers["main"])
    return out


def parse_table(text: str) -> dict[str, Any]:
    """One table file: ``{name, columns, measures, partitions}``. A column with an
    expression is a calculated column; its ``expression`` is the DAX."""
    lines = text.splitlines()
    table: dict[str, Any] = {"name": None, "columns": [], "measures": [], "partitions": []}
    for i, line in enumerate(lines):
        if not line.strip() or line.strip().startswith("///"):
            continue
        d, stripped = _depth(line), line.strip()
        m = _KEYWORD.match(stripped)
        if not m:
            continue
        kw = m.group("kw")
        if d == 0 and kw == "table":
            table["name"] = _split_name_expression(m.group("rest"))[0]
        elif d == 1 and kw == "column":
            table["columns"].append(_read_object(lines, i))
        elif d == 1 and kw == "measure":
            table["measures"].append(_read_object(lines, i))
        elif d == 1 and kw == "partition":
            table["partitions"].append(_read_object(lines, i))
    return table


def parse_role(text: str) -> dict[str, Any]:
    """One role file: its name, model permission, per-table filter expressions and members."""
    lines = text.splitlines()
    role: dict[str, Any] = {"name": None, "model_permission": None, "table_permissions": [], "members": []}
    for i, line in enumerate(lines):
        d, stripped = _depth(line), line.strip()
        m = _KEYWORD.match(stripped)
        if d == 0 and m and m.group("kw") == "role":
            role["name"] = _split_name_expression(m.group("rest"))[0]
        elif d == 1 and stripped.startswith("modelPermission:"):
            role["model_permission"] = stripped.split(":", 1)[1].strip()
        elif d == 1 and m and m.group("kw") == "tablePermission":
            obj = _read_object(lines, i)
            role["table_permissions"].append({"table": obj["name"], "filter": obj.get("expression")})
        elif d == 1 and stripped.startswith("member "):
            role["members"].append(_split_name_expression(stripped[len("member "):])[0])
    return role


def summarize_model(parts: list[dict]) -> dict[str, Any]:
    """From decoded definition parts (``{path, content}``): tables, measures,
    calculated columns and roles, or ``{}`` when the parts hold no TMDL."""
    tables, roles = [], []
    for part in parts:
        path, content = part.get("path") or "", part.get("content")
        if not isinstance(content, str):
            continue
        if path.startswith("definition/tables/") and path.endswith(".tmdl"):
            tables.append(parse_table(content))
        elif path.startswith("definition/roles/") and path.endswith(".tmdl"):
            roles.append(parse_role(content))
    if not tables and not roles:
        return {}
    return {"tables": tables, "roles": roles}

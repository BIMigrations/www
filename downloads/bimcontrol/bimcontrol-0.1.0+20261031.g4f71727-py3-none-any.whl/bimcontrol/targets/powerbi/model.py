"""The intermediate representation for a Power BI project.

Source-neutral on purpose: nothing here mentions Domo. A pipeline turns
its source's vocabulary into this, and the writer turns this into files,
so adding a source means writing one translation rather than touching the
writer, and adding a target means writing one writer.

Every node carries `origin` -- the id of the source object it came from --
so the migration report can say which Domo card produced which visual,
and the UI can put them side by side.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

# Domo's column types, mapped to the Tabular data types TMDL expects.
TMDL_TYPES = {
    "STRING": "string",
    "LONG": "int64",
    "INTEGER": "int64",
    "DOUBLE": "double",
    # Not Power BI's `decimal`: that is the fixed-decimal type (four places), so Domo's 30.19726 came back as 30.1973.
    "DECIMAL": "double",
    "DATE": "dateTime",
    "DATETIME": "dateTime",
    "TIMESTAMP": "dateTime",
    "BOOLEAN": "boolean",
}


def tmdl_type(source_type: str | None) -> str:
    return TMDL_TYPES.get((source_type or "STRING").upper(), "string")


@dataclass
class Column:
    name: str
    source_type: str = "STRING"
    origin: str | None = None
    # Set for a calculated column (a row-level beast mode): the DAX that
    # computes it, instead of a source column to read.
    expression: str | None = None
    description: str | None = None
    needs_review: bool = False
    # A column this one sorts by (a text month label sorts by the month's first day).
    sort_by: str | None = None
    hidden: bool = False

    @property
    def data_type(self) -> str:
        return tmdl_type(self.source_type)

    @property
    def summarize_by(self) -> str:
        """Whether Power BI offers to aggregate this column by default.

        Numeric columns default to summing, which is wrong for anything
        that is an identifier or a year rather than a quantity -- a chart
        of "Fiscal Year" should not show 2022 summed across rows.
        """
        if self.data_type in ("int64", "double", "decimal"):
            lowered = self.name.lower()
            if any(token in lowered for token in ("year", "id", "rank", "#", "number", "code")):
                return "none"
            return "sum"
        return "none"


@dataclass
class Measure:
    name: str
    expression: str
    origin: str | None = None
    description: str | None = None
    needs_review: bool = False


@dataclass
class DataSource:
    """Where a table's rows come from, as a Power Query expression."""

    kind: str                    # redshift_sql | warehouse_table | csv
    m_expression: str
    detail: dict[str, Any] = field(default_factory=dict)
    # A table too big for one query is loaded as several partitions, one
    # Power Query expression each. Empty means `m_expression` alone.
    partitions: list[str] = field(default_factory=list)
    # Read live from the warehouse at query time; nothing is imported or refreshed (bimcontrol#144).
    direct_query: bool = False


@dataclass
class Table:
    name: str
    columns: list[Column] = field(default_factory=list)
    measures: list[Measure] = field(default_factory=list)
    source: DataSource | None = None
    origin: str | None = None
    hidden: bool = False
    # {column: {filter value ending in blanks: which spellings the data holds}}, for the values a filter of the report
    # lists (see `with_trimmed_text`): "blank" (the value as written), "trimmed" (without the blanks), "both" or "neither".
    # A column or value missing here was not asked about.
    blank_values: dict[str, dict[str, str]] = field(default_factory=dict)


@dataclass
class Role:
    """A row-level security role: who sees which rows of which tables.

    `filters` maps a table name to the DAX boolean expression that rows
    must satisfy. Members are added in Power BI once a user mapping exists.
    """

    name: str
    filters: dict[str, str] = field(default_factory=dict)
    origin: str | None = None
    description: str | None = None


@dataclass
class SemanticModel:
    name: str
    tables: list[Table] = field(default_factory=list)
    roles: list[Role] = field(default_factory=list)
    culture: str = "en-GB"
    # Where each card's beast modes ended up: {card id: {Domo name: (table, model name, "measure"|"column")}}.
    # Two cards can use a beast mode of the same name with different formulas.
    card_fields: dict[str, dict[str, tuple[str, str, str]]] = field(default_factory=dict)

    def table(self, name: str) -> Table | None:
        return next((t for t in self.tables if t.name == name), None)


@dataclass
class Projection:
    """One field in one bucket of a visual."""

    table: str
    name: str
    kind: str = "column"          # column | measure | aggregation
    aggregation: str | None = None   # for kind == aggregation
    display_name: str | None = None


@dataclass
class VisualFilter:
    table: str
    column: str
    kind: str  # "in" | "compare" | "date_range"
    values: list[str]
    data_type: str | None = None
    comparison: int | None = None  # PBIR ComparisonKind, for "compare"
    negated: bool = False
    date_range: dict | None = None  # for kind "date_range": see targets/powerbi/daterange.py
    # for kind "top_n": {"limit": 15, "descending": True, "by": {"table", "name", "kind", "aggregation"}}; `column` is
    # the category the rows are limited by, and `values` is unused.
    top_n: dict | None = None
    # "measure": `column` names a measure of `table` and the filter is on its value per row of the visual (Domo's
    # filter on an aggregate, a HAVING), not on a column.
    field_kind: str = "column"
    # for kind "in": {value ending in a blank: the spellings the data holds} (`Table.blank_values`); None = not asked.
    blank_held: dict[str, str] | None = None


@dataclass
class Visual:
    visual_type: str
    title: str
    x: float
    y: float
    width: float
    height: float
    # role name -> the fields in it, e.g. {"Category": [...], "Y": [...]}
    buckets: dict[str, list[Projection]] = field(default_factory=dict)
    origin: str | None = None
    # Saved Domo filters, applied as visual-level filters.
    filters: list[VisualFilter] = field(default_factory=list)
    # The row limit Domo's card carries ("Top 15 by Cases"), whether or not it became a Top N filter; parity compares only
    # Domo's rows of a card that has one.
    row_limit: int | None = None
    # Slicers only: the Dropdown/Between mode, and the group that keeps the
    # same field's slicers in step across pages.
    slicer_mode: str | None = None
    sync_group: str | None = None
    # How Domo draws the chart: values on the marks, and where the legend goes ('Bottom', 'Right', 'Hide'; None: leave
    # Power BI's default).
    data_labels: bool = False
    legend_position: str | None = None
    # The order Domo's card sorts its rows in: (field, "Ascending" | "Descending"), first sort first. A field the visual
    # does not show is projected in the Tooltips role so the query holds it (a sort can only use projected fields).
    sort: list[tuple[Projection, str]] = field(default_factory=list)
    # Domo orders the category by a column the visual does not show (a rank, a month number): [{table, column, by}] asks the
    # model to sort `column` by `by`, which is how Power BI orders a category by a hidden field.
    sort_keys: list[dict] = field(default_factory=list)
    # Columns the Domo card groups by without showing them (an `orgno` beside `orgname`): the visual does not draw them, but the
    # model keeps them so that parity can ask for the rows at Domo's grain.
    kept_columns: list[dict] = field(default_factory=list)   # [{table, column}]
    # Text boxes only: the words, and how to draw them.
    text: str | None = None
    text_size: int | None = None
    bold: bool = False


@dataclass
class Drillthrough:
    """A page that other pages reach by drilling through on one column."""

    table: str
    column: str


@dataclass
class Page:
    name: str
    display_name: str
    width: int = 1280
    height: int = 720
    visuals: list[Visual] = field(default_factory=list)
    # Set on a hidden drillthrough page: the field it filters on.
    drillthrough: Drillthrough | None = None


@dataclass
class Report:
    name: str
    pages: list[Page] = field(default_factory=list)
    # Filters on the whole report (dashboard filters that carry saved values).
    filters: list[VisualFilter] = field(default_factory=list)


_DATE_TYPES = ("date", "datetime", "timestamp")
_ISO_DATE = re.compile(r"^\s*(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2}):(\d{2}))?")


def with_trimmed_text(values: list[str], data_type: str | None, held: dict[str, str] | None = None) -> list[str]:
    """The values of an IN filter, each text value that ends in blanks followed by the same without them.

    Domo keeps the blank ('11-30 ' in DNFB Aging Buckets); the Power BI engine answers and matches the text without it:
    `IN {"11-30 "}` kept no row of the 191 that `IN {"11-30"}` keeps. Both spellings match whichever way a model stores it.
    Only where the data holds the value with the blank: a column that holds 'CC' and never 'CC ' matches nothing in Domo
    for `'CC '`, and the widened filter kept 9,391 encounters Domo drops (Case Mix Index, #457). `held` says which spellings
    the data holds for a value ("blank", "trimmed", "both", "neither": `Table.blank_values`); a value it does not list
    is widened, as before it was asked."""
    if (data_type or "").lower() in ("numeric", "long", "double", "decimal") or (data_type or "").lower() in _DATE_TYPES:
        return list(values)
    out: list[str] = []
    for value in values:
        out.append(value)
        if (isinstance(value, str) and value != value.rstrip() and value.rstrip() not in values
                and (held or {}).get(value) not in ("trimmed", "neither")):
            out.append(value.rstrip())
    return out


def iso_date_parts(value: str, data_type: str | None) -> tuple[int, ...] | None:
    """(year, month, day, hour, minute, second) of a date filter value, or None when it is not one."""
    if (data_type or "").lower() not in _DATE_TYPES:
        return None
    match = _ISO_DATE.match(value)
    if not match:
        return None
    return tuple(int(g or 0) for g in match.groups())

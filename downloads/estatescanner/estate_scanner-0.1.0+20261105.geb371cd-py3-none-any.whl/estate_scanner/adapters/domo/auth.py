"""Domo session capture: the PlatformAuthenticator implementation.

Domo's private per-instance API (the same endpoints its own web app calls,
under ``https://{instance}.domo.com/api/...``) isn't reachable with an API
key -- it's authenticated by browser session cookies + a CSRF token header.
So instead of OAuth, this drives a real (visible) browser to Domo's login
page, lets a human complete SSO/MFA, then lifts the resulting cookies out of
the browser context and reuses them in a plain ``requests.Session``.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path

from estate_scanner.core.platform import PlatformAuthenticator, PlatformSession

LOGIN_POLL_INTERVAL_S = 2
LOGIN_TIMEOUT_S = 600
PROBE_PATH = "/api/dataprocessing/v1/dataflows?limit=1"


@dataclass
class DomoSession(PlatformSession):
    instance: str
    cookies: list[dict] = field(default_factory=list)
    csrf_token: str = ""
    platform: str = "domo"

    @property
    def base_url(self) -> str:
        return f"https://{self.instance}.domo.com"

    def to_persisted_dict(self) -> dict:
        return {"cookies": self.cookies, "csrf_token": self.csrf_token}

    @classmethod
    def from_persisted_dict(cls, instance: str, data: dict) -> "DomoSession":
        return cls(instance=instance, cookies=data["cookies"], csrf_token=data["csrf_token"])


def _extract_csrf_token(cookies: list[dict]) -> str | None:
    for cookie in cookies:
        if cookie["name"] == "csrf-token":
            return cookie["value"]
    return None


def _cookies_for_instance(all_cookies: list[dict], instance: str) -> list[dict]:
    # The SSO hop (through an auth.<instance>.com-style domain) leaves
    # unrelated-domain cookies in the browser context's cookie jar. Only the
    # *.domo.com ones are meaningful to the API host.
    return [c for c in all_cookies if c["domain"].endswith(".domo.com") or c["domain"] == f"{instance}.domo.com"]


def _launch_browser(pw):
    """Prefer the machine's own Chrome or Edge so a packaged build needs no
    downloaded Chromium; fall back to Playwright's bundled Chromium."""
    last_error: Exception | None = None
    for channel in ("chrome", "msedge", None):
        try:
            if channel is None:
                return pw.chromium.launch(headless=False)
            return pw.chromium.launch(channel=channel, headless=False)
        except Exception as exc:  # channel not installed
            last_error = exc
    raise RuntimeError(
        "No browser found for the Domo sign-in. Install Google Chrome or Microsoft Edge and try again."
    ) from last_error


class DomoAuthenticator(PlatformAuthenticator):
    platform = "domo"

    def login_interactive(self, instance: str, timeout_s: int = LOGIN_TIMEOUT_S, **kwargs) -> DomoSession:
        """Opens a visible browser at the instance and waits for a human to
        sign in, polling the same private API this whole client depends on
        from inside the page's own JS context (so it shares the page's
        cookies/CSRF handling exactly as the real web app would) until it
        stops 401ing.
        """
        try:
            from playwright.sync_api import sync_playwright
        except ImportError as exc:
            raise ImportError(
                "Domo login needs Playwright. Install it with: pip install 'estate-scanner[domo]' && playwright install chromium"
            ) from exc

        with sync_playwright() as pw:
            browser = _launch_browser(pw)
            context = browser.new_context()
            page = context.new_page()
            page.goto(f"https://{instance}.domo.com")

            deadline = time.monotonic() + timeout_s
            authenticated = False
            while time.monotonic() < deadline:
                try:
                    status = page.evaluate(
                        """async (path) => {
                            const res = await fetch(path, { credentials: 'include' });
                            return res.status;
                        }""",
                        PROBE_PATH,
                    )
                    if status == 200:
                        authenticated = True
                        break
                except Exception:
                    pass  # navigation in progress, execution context destroyed, etc.
                time.sleep(LOGIN_POLL_INTERVAL_S)

            if not authenticated:
                browser.close()
                raise TimeoutError(f"Timed out waiting for interactive Domo login after {timeout_s}s")

            raw_cookies = context.cookies()
            browser.close()

        cookies = _cookies_for_instance(raw_cookies, instance)
        csrf_token = _extract_csrf_token(cookies)
        if not csrf_token:
            raise RuntimeError("Authenticated, but no csrf-token cookie was present")
        return DomoSession(instance=instance, cookies=cookies, csrf_token=csrf_token)

    def load_cookie_file(self, instance: str, path: Path | str) -> DomoSession:
        """Build a session from a JSON cookie file: a list of {name, value, domain, path?}."""
        raw_cookies = json.loads(Path(path).read_text())
        cookies = _cookies_for_instance(raw_cookies, instance)
        csrf_token = _extract_csrf_token(cookies)
        if not csrf_token:
            raise RuntimeError(f"No csrf-token cookie found in {path}")
        return DomoSession(instance=instance, cookies=cookies, csrf_token=csrf_token)

    def restore_session(self, instance: str, persisted: dict) -> DomoSession:
        return DomoSession.from_persisted_dict(instance, persisted)

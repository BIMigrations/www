from __future__ import annotations

import subprocess
import sys
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from estate_scanner.export import export_scan

router = APIRouter()


class RevealRequest(BaseModel):
    path: str


@router.post("")
def create_export(request: Request):
    try:
        zip_path = export_scan(request.app.state.db_path)
    except (FileNotFoundError, ValueError) as exc:
        raise HTTPException(400, str(exc)) from None
    return {"path": str(zip_path), "filename": zip_path.name, "size_bytes": zip_path.stat().st_size}


@router.post("/reveal")
def reveal(body: RevealRequest, request: Request):
    """Show the exported file in Finder/Explorer. Only zips made by the exporter."""
    path = Path(body.path)
    if not (path.is_file() and path.suffix == ".zip" and path.name.startswith("EstateScan-")):
        raise HTTPException(400, "Not an exported scan")
    if sys.platform == "darwin":
        subprocess.Popen(["open", "-R", str(path)])
    elif sys.platform == "win32":
        subprocess.Popen(["explorer", "/select,", str(path)])
    else:
        subprocess.Popen(["xdg-open", str(path.parent)])
    return {"ok": True}

"""Delete a scan from the database, safely (#57).

What the data can and cannot undo: objects are upserted in place, so an object
seen in scans 3 and 5 holds scan 5's values and deleting scan 5 cannot give back
scan 3's. Only `scans`, `scan_issues` and `raw_objects` are per-scan. So deleting
a scan is exact for what only that scan wrote, and this module refuses the cases
where it would be an approximation (an older scan with a later one after it)
rather than ship a guess. What survives is said in the preview.

Nothing is deleted without the exact confirmation text, a backup is written
first, and the deletes run in one transaction.
"""

from __future__ import annotations

import re
import sqlite3
import time
from dataclasses import dataclass, field
from pathlib import Path

from ..core.instances import normalise_instance
from .backup import NotEnoughDiskSpace, backup_database, backup_path

# The edge end types (`src_type`/`dst_type`) and the typed table each one lives in.
OBJECT_TABLES = {
    "user": "users",
    "group": "groups_",
    "account": "accounts",
    "dataset": "datasets",
    "dataflow": "dataflows",
    "card": "cards",
    "dashboard": "dashboards",
    "app": "apps",
    "calculated_field": "calculated_fields",
    "alert": "alerts",
    "workspace": "workspaces",
    "gateway": "gateways",
}
# Typed tables that carry first/last_seen_scan_id but are not an edge end.
_OTHER_SEEN_TABLES = ("refreshes",)
SEEN_TABLES = tuple(OBJECT_TABLES.values()) + _OTHER_SEEN_TABLES

# The copy leaves this table out: it holds the saved sign-in in plain text, the delete never touches it,
# and a copy that is kept for good should not carry it (AGENTS.md: strip it before a file leaves the machine).
_LEFT_OUT_OF_THE_COPY = ("platform_sessions",)

# How long to wait for the database's write lock before saying another process holds it.
DEFAULT_LOCK_WAIT_MS = 3000

_COPY_NOTE = (
    "The copy is the database without the saved sign-in (you stay signed in; restoring the copy means signing in again). "
    "The app never deletes a copy: remove the file yourself when you no longer need it."
)


class DeleteRefused(Exception):
    """The delete was not done and nothing changed. The message says why."""


class UnknownTarget(DeleteRefused):
    """There is no such scan, or no scan of that instance."""


class BackupError(DeleteRefused):
    pass


@dataclass
class Backup:
    path: Path
    size_bytes: int


@dataclass
class DeleteScanPreview:
    scan_id: int
    platform: str
    instance: str
    status: str
    started_at: str
    finished_at: str | None
    confirm_text: str
    previous_scan_id: int | None
    refusal: str | None = None
    scan_issues: int = 0
    raw_objects: int = 0
    objects_deleted: dict[str, int] = field(default_factory=dict)
    objects_keep_scan_values: dict[str, int] = field(default_factory=dict)
    edges_deleted: int = 0
    edges_restamped: int = 0
    edges_restamp_scan_id: int | None = None    # the scan the kept edges are stamped with afterwards
    db_size_bytes: int = 0
    backup_path: Path | None = None

    def lines(self) -> list[str]:
        """The preview as text, shared by the CLI and the Scan screen."""
        out = [
            f"Scan {self.scan_id} of {self.platform}/{self.instance}: {self.status}, "
            f"started {self.started_at}, finished {self.finished_at or 'never'}.",
        ]
        if self.refusal:
            out.append(f"Refused: {self.refusal}")
            return out
        out.append(f"Would delete the scan record, {self.scan_issues} issue(s) and {self.raw_objects} raw capture(s).")
        if self.objects_deleted:
            total = sum(self.objects_deleted.values())
            detail = ", ".join(f"{n} {t}" for t, n in sorted(self.objects_deleted.items()))
            out.append(f"Would delete {total} object(s) only this scan saw: {detail}.")
        else:
            out.append("No object was seen only by this scan.")
        kept = sum(self.objects_keep_scan_values.values())
        if kept:
            out.append(
                f"{kept} object(s) were also seen by earlier scans: they stay and KEEP THIS SCAN'S VALUES "
                f"(earlier values are not stored), last seen moves to "
                + (f"scan {self.previous_scan_id}." if self.previous_scan_id is not None else "the scan that first saw them (no earlier scan completed).")
            )
        if self.edges_restamp_scan_id is None:
            out.append(f"Edges: all {self.edges_deleted} edge(s) of this scan go (no earlier scan exists to hand them to).")
        else:
            out.append(
                f"Edges: {self.edges_deleted} touching an object that goes are deleted; {self.edges_restamped} between objects that stay "
                f"are kept and stamped as last seen by scan {self.edges_restamp_scan_id} "
                "(an edge has one scan number, so an edge that an earlier scan also saw counts as this scan's: "
                "if one end of it could only be read since this scan, an older edge goes with that object)."
            )
        out.append("Not touched: other instances, the saved sign-in, any file other than the backup.")
        if self.backup_path:
            out.append(f"A backup of the whole database ({self.db_size_bytes / 1e6:.1f} MB) is written first to {self.backup_path}. {_COPY_NOTE}")
        out.append(f'To go ahead, confirm with exactly: {self.confirm_text}')
        return out


@dataclass
class DeleteScanResult:
    preview: DeleteScanPreview
    backup: Backup


def confirm_text_for_scan(platform: str, instance: str, scan_id: int) -> str:
    return f"{platform}/{instance} scan {scan_id}"


def _db_file(conn: sqlite3.Connection) -> Path:
    row = conn.execute("PRAGMA database_list").fetchone()
    file = row[2] if row else ""
    if not file:
        raise BackupError("This database has no file (in memory); a backup cannot be written.")
    return Path(file)


def _safe_reason(reason: str) -> str:
    """The reason goes into a file name next to the database: an instance name may hold `/`, spaces or be very long."""
    return re.sub(r"[^A-Za-z0-9_-]+", "_", reason)[:80]


def planned_backup_path(conn: sqlite3.Connection, reason: str) -> Path:
    return backup_path(_db_file(conn), _safe_reason(reason))


def _table_counts(conn: sqlite3.Connection) -> dict[str, int]:
    names = [
        r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' ORDER BY name")
    ]
    return {name: conn.execute(f'SELECT COUNT(*) FROM "{name}"').fetchone()[0] for name in names}


def verify_backup(path: Path, expected: dict[str, int]) -> None:
    """The copy opens, passes SQLite's own integrity check and holds the row counts the database had.

    Raises BackupError otherwise. `expected` is read under the write lock, so nothing can have moved.
    """
    try:
        copy = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)
        try:
            verdict = [r[0] for r in copy.execute("PRAGMA integrity_check")]
            if verdict != ["ok"]:
                raise BackupError(f"The backup failed SQLite's integrity check ({verdict[0]}). Nothing was deleted.")
            for table, rows in expected.items():
                want = 0 if table in _LEFT_OUT_OF_THE_COPY else rows
                got = copy.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0]
                if got != want:
                    raise BackupError(
                        f"The backup is not a faithful copy: {table} holds {got} row(s) in it and {want} were expected. Nothing was deleted."
                    )
        finally:
            copy.close()
    except sqlite3.Error as exc:
        raise BackupError(f"The backup could not be checked ({exc}). Nothing was deleted.") from exc


def take_backup(conn: sqlite3.Connection, reason: str) -> Backup:
    """The shared backup (storage/backup.py, #55) of the whole database file before something destructive.

    Called with the write lock held, so the copy is exactly what is about to be deleted from. Refuses, with nothing
    deleted, when the disk cannot hold the copy, the copy fails halfway, or the finished copy does not check out
    (a copy that fails the check is removed). Never pruned: a customer's evidence.
    """
    db_file = _db_file(conn)
    expected = _table_counts(conn)
    try:
        path = backup_database(db_file, _safe_reason(reason), exclude_tables=_LEFT_OUT_OF_THE_COPY)
    except NotEnoughDiskSpace as exc:
        raise BackupError(f"Not enough free disk for a backup. {exc} Nothing was deleted.") from exc
    except (sqlite3.Error, OSError) as exc:
        raise BackupError(f"The backup could not be written ({exc}). Nothing was deleted.") from exc
    try:
        verify_backup(path, expected)
    except BaseException:
        path.unlink(missing_ok=True)
        raise
    return Backup(path=path, size_bytes=path.stat().st_size)


def _begin(conn: sqlite3.Connection, lock_wait_ms: int) -> None:
    """Take the database's write lock now, or refuse. While held, no scan in any process can write a row.

    Polled here, not left to SQLite's busy timeout: on macOS that retries in whole seconds and a 1 s wait
    took 4 s (measured), so "wait up to N seconds, then say so" would not be true.
    """
    own = conn.execute("PRAGMA busy_timeout").fetchone()[0]
    conn.execute("PRAGMA busy_timeout = 0")
    deadline = time.monotonic() + lock_wait_ms / 1000
    try:
        while True:
            try:
                conn.execute("BEGIN IMMEDIATE")
                return
            except sqlite3.OperationalError as exc:
                if time.monotonic() >= deadline:
                    raise DeleteRefused(
                        f"Another process is writing to this database (a scan?) ({exc}). Nothing was deleted. "
                        "Wait for it to finish, then try again."
                    ) from exc
                time.sleep(0.05)
    finally:
        conn.execute(f"PRAGMA busy_timeout = {own}")


def _rollback(conn: sqlite3.Connection) -> None:
    if conn.in_transaction:
        conn.execute("ROLLBACK")


def _commit(conn: sqlite3.Connection) -> None:
    try:
        conn.execute("COMMIT")
    except sqlite3.OperationalError as exc:
        _rollback(conn)
        raise DeleteRefused(f"The delete could not be finished ({exc}) and was rolled back. Nothing was deleted.") from exc


def _only_this_scan(table: str) -> str:
    # `?` is the scan id; the platform is bound by the caller.
    return f"{table}.platform = :platform AND {table}.first_seen_scan_id = :scan AND {table}.last_seen_scan_id = :scan"


def _also_earlier(table: str) -> str:
    return f"{table}.platform = :platform AND {table}.last_seen_scan_id = :scan AND {table}.first_seen_scan_id < :scan"


def _end_deleted(column_type: str, column_id: str) -> str:
    """SQL true when an edge end is an object that only this scan saw."""
    branches = [
        f"({column_type} = '{kind}' AND {column_id} IN (SELECT id FROM {table} WHERE {_only_this_scan(table)}))"
        for kind, table in OBJECT_TABLES.items()
    ]
    return "(" + " OR ".join(branches) + ")"


def _edge_goes() -> str:
    """An edge of this scan goes when one of its ends does, or when no earlier scan exists to hand it to (`:restamp` is NULL)."""
    return (
        "edges.scan_id = :scan AND edges.platform = :platform AND "
        f"({_end_deleted('edges.src_type', 'edges.src_id')} OR {_end_deleted('edges.dst_type', 'edges.dst_id')} "
        "OR :restamp IS NULL)"
    )


def _running_message(what: str) -> str:
    return (
        f"{what} is marked running in the database: a scan in another process may still be writing it. Nothing was deleted. "
        "Wait for it to finish. If the app was closed during the scan and nothing is writing it any more, "
        "it can be removed from the command line with --abandoned."
    )


def preview_delete_scan(
    conn: sqlite3.Connection,
    scan_id: int,
    running_scan_ids: set[int] | frozenset[int] = frozenset(),
    *,
    abandoned: bool = False,
) -> DeleteScanPreview:
    """What deleting `scan_id` would do, without doing it.

    A scan whose row says `running` is refused: the database cannot tell a scan another process is writing from one
    a crash left behind. `abandoned=True` is the person saying it is the latter (the CLI's --abandoned); a job in
    this process (`running_scan_ids`) is refused whatever they say.
    """
    scan = conn.execute("SELECT * FROM scans WHERE id = ?", (scan_id,)).fetchone()
    if scan is None:
        raise UnknownTarget(f"There is no scan {scan_id}.")
    platform, instance = scan["platform"], scan["instance"]
    previous = conn.execute(
        "SELECT MAX(id) FROM scans WHERE platform = ? AND instance = ? AND id < ? AND status = 'completed'",
        (platform, instance, scan_id),
    ).fetchone()[0]     # a failed scan in between saw (almost) nothing: nothing moves back to it
    later = conn.execute(
        "SELECT COUNT(*) FROM scans WHERE platform = ? AND instance = ? AND id > ?", (platform, instance, scan_id)
    ).fetchone()[0]
    preview = DeleteScanPreview(
        scan_id=scan_id,
        platform=platform,
        instance=instance,
        status=scan["status"],
        started_at=scan["started_at"],
        finished_at=scan["finished_at"],
        confirm_text=confirm_text_for_scan(platform, instance, scan_id),
        previous_scan_id=previous,
    )
    # Where the kept edges go: the scan the objects move back to, else (a failed scan is all there is) the newest earlier one.
    restamp = previous
    if restamp is None:
        restamp = conn.execute(
            "SELECT MAX(id) FROM scans WHERE platform = ? AND instance = ? AND id < ?", (platform, instance, scan_id)
        ).fetchone()[0]
    preview.edges_restamp_scan_id = restamp
    params = {"scan": scan_id, "platform": platform, "previous": previous, "restamp": restamp}

    if scan_id in running_scan_ids:
        preview.refusal = "This scan is still running. Stop it first."
        return preview
    if scan["status"] == "running" and not abandoned:
        preview.refusal = _running_message(f"Scan {scan_id}")
        return preview
    if later and scan["status"] == "completed":
        preview.refusal = (
            f"Scan {scan_id} is not the latest scan of {platform}/{instance} (there are {later} later). "
            "Objects keep the values of the last scan that saw them, so the earlier values cannot be restored. "
            "Use start fresh to clear the instance and scan again."
        )
        return preview
    # A scan that is not the latest (failed, or stuck at running) can only go if no
    # object it first saw was seen again later: that object's first-seen could only be guessed.
    for table in SEEN_TABLES:
        n = conn.execute(
            f"SELECT COUNT(*) FROM {table} WHERE platform = :platform AND first_seen_scan_id = :scan AND last_seen_scan_id != :scan",
            params,
        ).fetchone()[0]
        if n:
            preview.refusal = (
                f"{n} {table} first seen in scan {scan_id} were seen again by a later scan, "
                "so their first-seen scan cannot be restored. Use start fresh to clear the instance and scan again."
            )
            return preview

    preview.scan_issues = conn.execute("SELECT COUNT(*) FROM scan_issues WHERE scan_id = ?", (scan_id,)).fetchone()[0]
    preview.raw_objects = conn.execute("SELECT COUNT(*) FROM raw_objects WHERE scan_id = ?", (scan_id,)).fetchone()[0]
    for table in SEEN_TABLES:
        gone = conn.execute(f"SELECT COUNT(*) FROM {table} WHERE {_only_this_scan(table)}", params).fetchone()[0]
        kept = conn.execute(f"SELECT COUNT(*) FROM {table} WHERE {_also_earlier(table)}", params).fetchone()[0]
        if gone:
            preview.objects_deleted[table] = gone
        if kept:
            preview.objects_keep_scan_values[table] = kept
    preview.edges_deleted = conn.execute(f"SELECT COUNT(*) FROM edges WHERE {_edge_goes()}", params).fetchone()[0]
    preview.edges_restamped = (
        conn.execute("SELECT COUNT(*) FROM edges WHERE scan_id = :scan AND platform = :platform", params).fetchone()[0]
        - preview.edges_deleted
    )
    try:
        preview.db_size_bytes = _db_file(conn).stat().st_size
        preview.backup_path = planned_backup_path(conn, f"delete-scan-{scan_id}")
    except BackupError:
        pass
    return preview


def delete_scan(
    conn: sqlite3.Connection,
    scan_id: int,
    confirm: str | None,
    running_scan_ids: set[int] | frozenset[int] = frozenset(),
    *,
    abandoned: bool = False,
    lock_wait_ms: int = DEFAULT_LOCK_WAIT_MS,
) -> DeleteScanResult:
    """Delete one scan after an exact confirmation and a backup. All or nothing.

    The order is the point: the write lock first (no scan in any process can write while it is held, and the
    answer to "is a scan running?" cannot go stale), the refusals read again under it, then the copy, the copy
    checked, and only then the deletes in the same transaction.

    Raises DeleteRefused (nothing changed) when the scan cannot be deleted honestly, the confirmation does not
    match exactly, the lock is held elsewhere, or the backup fails or does not check out.
    """
    preview = preview_delete_scan(conn, scan_id, running_scan_ids, abandoned=abandoned)
    if preview.refusal:
        raise DeleteRefused(preview.refusal)
    if confirm != preview.confirm_text:
        raise DeleteRefused(f'Not confirmed. Nothing was deleted. To go ahead, confirm with exactly: {preview.confirm_text}')
    if conn.in_transaction:
        raise DeleteRefused("The connection has an open transaction; refusing to delete inside it.")

    _begin(conn, lock_wait_ms)
    try:
        # The preview was read before the lock; look again under it.
        again = preview_delete_scan(conn, scan_id, running_scan_ids, abandoned=abandoned)
        if again.refusal:
            raise DeleteRefused(again.refusal)
        backup = take_backup(conn, f"delete-scan-{scan_id}")
        params = {"scan": scan_id, "platform": again.platform, "previous": again.previous_scan_id, "restamp": again.edges_restamp_scan_id}
        # Edges first: whether an end is "only this scan's" is read from the typed tables.
        conn.execute(f"DELETE FROM edges WHERE {_edge_goes()}", params)
        conn.execute("UPDATE edges SET scan_id = :restamp WHERE scan_id = :scan AND platform = :platform", params)
        for table in SEEN_TABLES:
            conn.execute(f"DELETE FROM {table} WHERE {_only_this_scan(table)}", params)
            conn.execute(
                f"UPDATE {table} SET last_seen_scan_id = MAX({table}.first_seen_scan_id, COALESCE(:previous, {table}.first_seen_scan_id)) WHERE {_also_earlier(table)}",
                params,
            )
        conn.execute("DELETE FROM raw_objects WHERE scan_id = ?", (scan_id,))
        conn.execute("DELETE FROM scan_issues WHERE scan_id = ?", (scan_id,))
        conn.execute("DELETE FROM scans WHERE id = ?", (scan_id,))
        _commit(conn)
    except BaseException:
        _rollback(conn)
        raise
    return DeleteScanResult(preview=again, backup=backup)


# ---- start fresh: clear one instance, keep the sign-in and every other instance ----


@dataclass
class StartFreshPreview:
    platform: str
    instance: str
    confirm_text: str
    scans: int = 0
    scan_issues: int = 0
    raw_objects: int = 0
    objects_deleted: dict[str, int] = field(default_factory=dict)
    edges_deleted: int = 0
    other_instances: list[str] = field(default_factory=list)
    refusal: str | None = None
    db_size_bytes: int = 0
    backup_path: Path | None = None

    def lines(self) -> list[str]:
        head = f"Start fresh for {self.platform}/{self.instance}: {self.scans} scan(s)."
        if self.refusal:
            return [head, f"Refused: {self.refusal}"]
        total = sum(self.objects_deleted.values())
        detail = ", ".join(f"{n} {t}" for t, n in sorted(self.objects_deleted.items())) or "none"
        out = [
            head,
            f"Would delete all {self.scans} scan record(s), {self.scan_issues} issue(s), {self.raw_objects} raw capture(s), "
            f"{total} object(s) ({detail}) and {self.edges_deleted} edge(s) of this instance.",
            "Kept: the saved sign-in (you stay signed in), "
            + (f"the other instances ({', '.join(self.other_instances)})" if self.other_instances else "no other instance is in this database")
            + ", and the backup.",
        ]
        if self.backup_path:
            out.append(f"A backup of the whole database ({self.db_size_bytes / 1e6:.1f} MB) is written first to {self.backup_path}. {_COPY_NOTE}")
        out.append(f"To go ahead, confirm with exactly: {self.confirm_text}")
        return out


@dataclass
class StartFreshResult:
    preview: StartFreshPreview
    backup: Backup


def confirm_text_for_start_fresh(platform: str, instance: str) -> str:
    return f"{platform}/{instance} start fresh"


def preview_start_fresh(
    conn: sqlite3.Connection,
    platform: str,
    instance: str,
    running_scan_ids: set[int] | frozenset[int] = frozenset(),
    *,
    abandoned: bool = False,
) -> StartFreshPreview:
    """What clearing `platform`/`instance` would do, without doing it. See preview_delete_scan for `abandoned`."""
    instance = normalise_instance(platform, instance)
    preview = StartFreshPreview(
        platform=platform, instance=instance, confirm_text=confirm_text_for_start_fresh(platform, instance)
    )
    rows = conn.execute("SELECT id, status FROM scans WHERE platform = ? AND instance = ?", (platform, instance)).fetchall()
    scan_ids = [r[0] for r in rows]
    marked_running = [r[0] for r in rows if r[1] == "running"]
    preview.scans = len(scan_ids)
    preview.other_instances = sorted(
        {r[0] for r in conn.execute("SELECT DISTINCT instance FROM scans WHERE platform = ? AND instance != ?", (platform, instance))}
    )
    if not scan_ids:
        raise UnknownTarget(f"The database holds no scan of {platform}/{instance}.")
    if set(scan_ids) & set(running_scan_ids):
        preview.refusal = "A scan of this instance is still running. Stop it first."
        return preview
    if marked_running and not abandoned:
        preview.refusal = _running_message(f"A scan of this instance (scan {marked_running[0]})")
        return preview
    marks = ",".join("?" * len(scan_ids))
    preview.scan_issues = conn.execute(f"SELECT COUNT(*) FROM scan_issues WHERE scan_id IN ({marks})", scan_ids).fetchone()[0]
    preview.raw_objects = conn.execute(f"SELECT COUNT(*) FROM raw_objects WHERE scan_id IN ({marks})", scan_ids).fetchone()[0]
    for table in SEEN_TABLES:
        n = conn.execute(f"SELECT COUNT(*) FROM {table} WHERE platform = ? AND instance = ?", (platform, instance)).fetchone()[0]
        if n:
            preview.objects_deleted[table] = n
    preview.edges_deleted = conn.execute(
        "SELECT COUNT(*) FROM edges WHERE platform = ? AND instance = ?", (platform, instance)
    ).fetchone()[0]
    try:
        preview.db_size_bytes = _db_file(conn).stat().st_size
        preview.backup_path = planned_backup_path(conn, f"start-fresh-{platform}-{instance}")
    except BackupError:
        pass
    return preview


def start_fresh(
    conn: sqlite3.Connection,
    platform: str,
    instance: str,
    confirm: str | None,
    running_scan_ids: set[int] | frozenset[int] = frozenset(),
    *,
    abandoned: bool = False,
    lock_wait_ms: int = DEFAULT_LOCK_WAIT_MS,
) -> StartFreshResult:
    """Clear one instance after an exact confirmation and a backup. All or nothing.

    Deletes the instance's scans, issues, raw captures, typed rows and edges. Never touches
    `platform_sessions` or another instance (every statement is keyed by platform AND instance,
    or by the scan ids of this instance).
    """
    preview = preview_start_fresh(conn, platform, instance, running_scan_ids, abandoned=abandoned)
    if preview.refusal:
        raise DeleteRefused(preview.refusal)
    if confirm != preview.confirm_text:
        raise DeleteRefused(f"Not confirmed. Nothing was deleted. To go ahead, confirm with exactly: {preview.confirm_text}")
    if conn.in_transaction:
        raise DeleteRefused("The connection has an open transaction; refusing to delete inside it.")

    where = {"platform": preview.platform, "instance": preview.instance}
    _begin(conn, lock_wait_ms)       # the lock first, as in delete_scan
    try:
        # The preview was read before the lock; look again under it.
        again = preview_start_fresh(conn, platform, instance, running_scan_ids, abandoned=abandoned)
        if again.refusal:
            raise DeleteRefused(again.refusal)
        backup = take_backup(conn, f"start-fresh-{preview.platform}-{preview.instance}")
        scans = "(SELECT id FROM scans WHERE platform = :platform AND instance = :instance)"
        conn.execute(f"DELETE FROM edges WHERE platform = :platform AND instance = :instance", where)
        for table in SEEN_TABLES:
            conn.execute(f"DELETE FROM {table} WHERE platform = :platform AND instance = :instance", where)
        conn.execute(f"DELETE FROM raw_objects WHERE scan_id IN {scans}", where)
        conn.execute(f"DELETE FROM scan_issues WHERE scan_id IN {scans}", where)
        conn.execute("DELETE FROM scans WHERE platform = :platform AND instance = :instance", where)
        _commit(conn)
    except BaseException:
        _rollback(conn)
        raise
    return StartFreshResult(preview=again, backup=backup)

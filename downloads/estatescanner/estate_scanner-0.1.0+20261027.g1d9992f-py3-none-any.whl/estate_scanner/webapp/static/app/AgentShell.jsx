import React from 'react';

const NAV = [
  { key: 'connect', label: 'Connect', icon: 'link' },
  { key: 'scan', label: 'Scan', icon: 'refresh' },
  { key: 'estate', label: 'Estate', icon: 'database' },
  { key: 'lineage', label: 'Lineage', icon: 'layers' },
];

export function AgentShell() {
  const [tab, setTab] = React.useState('estate');
  const [lastConnected, setLastConnected] = React.useState({ platform: null, instance: null });

  function goToScan(platform, instance) {
    setLastConnected({ platform: platform || lastConnected.platform, instance: instance || lastConnected.instance });
    setTab('scan');
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', background: 'var(--surface-canvas)' }}>
      <div style={{ height: 3, flex: 'none', background: 'linear-gradient(90deg, var(--provenance-source) 0%, var(--provenance-source) 42%, var(--provenance-target) 58%, var(--provenance-target) 100%)' }} />
      <div style={{ display: 'flex', flex: 1, minHeight: 0, color: 'var(--text-primary)', fontFamily: 'var(--font-ui)' }}>
        <div style={{
          width: 216, flex: 'none', background: 'var(--surface-chrome)',
          borderRight: '1px solid var(--border-hairline)',
          display: 'flex', flexDirection: 'column', padding: '18px 12px',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 11, padding: '2px 8px 22px' }}>
            <Logo variant="mark" size={30} />
            <div style={{ display: 'flex', flexDirection: 'column', gap: 3, minWidth: 0 }}>
              <div style={{
                fontSize: 'var(--text-lg)', fontWeight: 'var(--weight-semibold)',
                letterSpacing: 'var(--tracking-heading)', color: 'var(--text-primary)', lineHeight: 1,
                whiteSpace: 'nowrap',
              }}>Estate Scanner</div>
              <div style={{ fontSize: 9, fontWeight: 'var(--weight-semibold)', letterSpacing: '0.14em', textTransform: 'uppercase', color: 'var(--text-tertiary)', lineHeight: 1 }}>
                BI<span style={{ opacity: 0.5 }}>/</span>Migrations
              </div>
            </div>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            {NAV.map(function (n) {
              return (
                <NavItem
                  key={n.key}
                  label={n.label}
                  icon={<Icon name={n.icon} size={16} />}
                  active={tab === n.key}
                  onClick={function () { setTab(n.key); }}
                />
              );
            })}
          </div>

          <div style={{ flex: 1 }} />

          <div style={{ padding: '10px 8px 2px', borderTop: '1px solid var(--border-hairline)' }}>
            <div style={{ fontSize: 'var(--text-2xs)', color: 'var(--text-disabled)', letterSpacing: 'var(--tracking-micro)' }}>
              Runs locally &middot; nothing leaves this machine
            </div>
          </div>
        </div>

        <div style={{ flex: 1, minWidth: 0, overflow: 'auto', background: 'var(--surface-canvas)' }}>
          {tab === 'connect' && <ConnectScreen onConnected={goToScan} />}
          {tab === 'scan' && <ScanScreen defaultPlatform={lastConnected.platform} defaultInstance={lastConnected.instance} />}
          {tab === 'estate' && <EstateScreen onGoToScan={function () { setTab('scan'); }} />}
          {tab === 'lineage' && <LineageScreen />}
        </div>
      </div>
    </div>
  );
}

// Thin fetch() wrappers for the FastAPI backend. Loaded through the same
// zero-build ds-preview.js mechanism as the JSX files (Babel's react preset
// passes plain JS through unchanged), so every exported function here is
// available as a plain call inside any component via window.BITDS.
//
// Note the loader only picks up named `export function` declarations -- a
// `const` export is never merged into window.BITDS, which is why the lookup
// tables at the bottom are functions rather than objects.

export function apiGet(path) {
  return fetch(path).then((r) => {
    if (!r.ok) {
      return r.json().then(
        (b) => { throw new Error(b.detail || ('GET ' + path + ' -> ' + r.status)); },
        () => { throw new Error('GET ' + path + ' -> ' + r.status); }
      );
    }
    return r.json();
  });
}

export function apiPost(path, body) {
  return fetch(path, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body || {}),
  }).then((r) => {
    if (!r.ok) return r.json().then((b) => { throw new Error(b.detail || ('POST ' + path + ' -> ' + r.status)); });
    return r.json();
  });
}

export function uploadEstateZip(file) {
  // Raw body, not multipart: the server needs no form-parsing dependency.
  return fetch('/api/estate/import', { method: 'POST', body: file }).then((r) => {
    if (!r.ok) {
      return r.json().then(
        (b) => { throw new Error(b.detail || ('Import failed (' + r.status + ')')); },
        () => { throw new Error('Import failed (' + r.status + ')'); }
      );
    }
    return r.json();
  });
}

export function fetchEstateStatus() {
  return apiGet('/api/estate/status');
}

export function fetchDashboards(params) {
  const qs = new URLSearchParams(
    Object.fromEntries(Object.entries(params || {}).filter(([, v]) => v !== undefined && v !== null && v !== ''))
  ).toString();
  return apiGet('/api/estate/dashboards' + (qs ? '?' + qs : ''));
}

export function fetchClosure(dashboardId) {
  return apiGet('/api/estate/dashboards/' + encodeURIComponent(dashboardId) + '/closure');
}

export function fetchCard(cardId) {
  return apiGet('/api/estate/cards/' + encodeURIComponent(cardId));
}

export function fetchDataset(datasetId) {
  return apiGet('/api/estate/datasets/' + encodeURIComponent(datasetId));
}

export function formatCount(n) {
  if (n === null || n === undefined) return '--';
  return Number(n).toLocaleString('en-GB');
}

// Domo's chart type slugs are not readable on their own. This is the label
// only -- the actual Domo chart type to Power BI visual mapping lives in
// the backend (targets/powerbi/chart_map.py), because that is a migration
// decision, not a display one.
export function chartTypeLabel(chartType) {
  if (!chartType) return 'Unknown';
  return String(chartType)
    .replace(/^badge_/, '')
    .replace(/_/g, ' ')
    .replace(/^\w/, (c) => c.toUpperCase());
}

export function apiDelete(path) {
  return fetch(path, { method: 'DELETE' }).then((r) => {
    if (!r.ok) return r.json().then((b) => { throw new Error(b.detail || ('DELETE ' + path + ' -> ' + r.status)); });
    return r.json();
  });
}

// ---- migrations ---------------------------------------------------------

export function fetchRuns(params) {
  return apiGet('/api/runs' + queryString(params));
}

export function fetchRun(runId) {
  return apiGet('/api/runs/' + encodeURIComponent(runId));
}

export function startRun(dashboardId, options) {
  return apiPost('/api/runs', Object.assign({ dashboard_id: dashboardId }, options || {}));
}

export function resumeRun(runId, options) {
  return apiPost('/api/runs/' + encodeURIComponent(runId) + '/resume', options || {});
}

export function cancelRun(runId) {
  return apiPost('/api/runs/' + encodeURIComponent(runId) + '/cancel', {});
}

// The live log. `wait_seconds` holds the connection open until something
// happens, so following a run is one request rather than a poll loop --
// and a finished run returns at once rather than hanging.
export function fetchEvents(runId, afterSeq, waitSeconds) {
  return apiGet('/api/runs/' + encodeURIComponent(runId) + '/events'
    + queryString({ after_seq: afterSeq || 0, wait_seconds: waitSeconds || 0 }));
}

export function fetchReviews(params) {
  return apiGet('/api/reviews' + queryString(params));
}

export function resolveReview(itemId, status, note) {
  return apiPost('/api/reviews/' + itemId, { status: status, note: note });
}

export function artefactUrl(runId, artefactId) {
  return '/api/runs/' + encodeURIComponent(runId) + '/artefacts/' + artefactId + '/content';
}

export function fetchArtefactText(runId, artefactId) {
  return fetch(artefactUrl(runId, artefactId)).then((r) => {
    if (!r.ok) throw new Error('Could not read that artefact (' + r.status + ')');
    return r.text();
  });
}

// ---- parity and the report ---------------------------------------------

export function fetchParity(runId, state) {
  return apiGet('/api/runs/' + encodeURIComponent(runId) + '/parity' + queryString({ state: state }));
}

export function fetchReport(runId) {
  return apiGet('/api/runs/' + encodeURIComponent(runId) + '/report');
}

// Inline for the preview frame, attachment for the download button: a
// browser will not render a response marked as an attachment.
export function reportHtmlUrl(runId, download) {
  return '/api/runs/' + encodeURIComponent(runId) + '/report.html'
    + (download ? '?download=1' : '');
}

// ---- customer batches ----------------------------------------------------

export function fetchCustomers() {
  return apiGet('/api/customers');
}

export function fetchCustomer(name) {
  return apiGet('/api/customers/' + encodeURIComponent(name));
}

// The dashboards a manifest selects, cheapest first; runs nothing.
export function previewBatch(manifest) {
  return apiPost('/api/customers/preview', { manifest: manifest });
}

export function startBatch(manifest, options) {
  return apiPost('/api/customers/batches', { manifest: manifest, options: options || {} });
}

// The batch started from this screen and the manifest last saved for the customer.
export function fetchBatch(name) {
  return apiGet('/api/customers/' + encodeURIComponent(name) + '/batch');
}

// now: also cancel the dashboard in flight (default: let it finish).
export function stopBatch(name, now) {
  return apiPost('/api/customers/' + encodeURIComponent(name) + '/batch/stop', { now: !!now });
}

// ---- connections --------------------------------------------------------

export function fetchConnections() {
  return apiGet('/api/connections');
}

export function signInToDomo() {
  return apiPost('/api/connections/domo/signin', {});
}

export function forgetDomo() {
  return apiDelete('/api/connections/domo');
}

export function signInToPowerBI() {
  return apiPost('/api/connections/powerbi/signin', {});
}

export function signOutOfPowerBI() {
  return apiDelete('/api/connections/powerbi');
}

export function setConverterUrl(url) {
  return apiPost('/api/connections/converter', { url: url });
}

export function saveWarehouse(projectId, settings) {
  return apiPost('/api/projects/' + encodeURIComponent(projectId) + '/warehouse', settings);
}

export function queryString(params) {
  const entries = Object.entries(params || {}).filter(
    ([, v]) => v !== undefined && v !== null && v !== ''
  );
  const qs = new URLSearchParams(Object.fromEntries(entries)).toString();
  return qs ? '?' + qs : '';
}

export function formatPercent(delta) {
  if (delta === null || delta === undefined) return '--';
  if (!isFinite(delta)) return 'infinite';
  return (delta >= 0 ? '+' : '') + (delta * 100).toFixed(3) + '%';
}

export function formatFigure(value) {
  if (value === null || value === undefined) return '--';
  if (typeof value !== 'number') return String(value);
  return Number.isInteger(value) ? value.toLocaleString('en-GB')
    : value.toLocaleString('en-GB', { maximumFractionDigits: 4 });
}

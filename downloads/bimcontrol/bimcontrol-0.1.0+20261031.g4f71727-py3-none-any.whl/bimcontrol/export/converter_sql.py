"""SQL for every dataflow of a scan from the converter alone: no landing, no models, no warehouse.

The pipeline converts the dataflows a dashboard needs and checks the result against the warehouse; that covers the
dashboards a customer migrates (one customer: 179 of the estate's 1,323). The converter can also write a dataflow's SQL
from its definition in about a second, so the open export can carry SQL for the rest too. That SQL has not been run
against data: it says so (`converter_only`), ranks below any converted run of the same dataflow, and names its inputs
by Domo dataset id, which is all a reader of the open format has (`FROM "<dataset id>"`).

The folder written has the shape of a run's `convert_dataflows` (a `conversion.json` and the `.sql` files it names),
so `export --sql-from` reads it as it reads a run.
"""

from __future__ import annotations

import json
import os
import re
from collections import Counter
from pathlib import Path
from typing import Any, Callable, Iterable

CONVERSION_FILE = "conversion.json"

# `SELECT * FROM __TODO_TABLE__ /* Domo source: "Orders raw", dataSourceId=ccadee7b-... */`: the converter's mark for an input
# nobody told it a table for.
_PLACEHOLDER = re.compile(
    r'__TODO_TABLE__[ \t]*/\*[ \t]*Domo source:[ \t]*"(?P<name>(?:(?!\*/)[^\n])*?)",[ \t]*dataSourceId=(?P<id>[0-9A-Fa-f-]+)[ \t]*\*/')
_PLAIN_TABLE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*\.[A-Za-z_][A-Za-z0-9_]*")


def dataset_ref(dataset_id: str) -> str:
    """How the open SQL names an input: the Domo dataset id, as a quoted identifier."""
    return f'"{dataset_id}"'


def neutral_sql(sql: str, resolutions: dict[str, str] | None = None) -> tuple[str, int]:
    """The converter's script with each input named by its dataset id, and how many placeholders could not be.

    A table the converter was told for an input (a landed table of this machine, `<staging schema>.src_...`) is replaced as
    well: it is an artefact of whoever ran the converter. A resolution that is itself a query stays as it is."""
    def swap(match: re.Match[str]) -> str:
        name = match.group("name").replace("*/", "* /")
        return f"{dataset_ref(match.group('id'))} /* Domo dataset: {name} */"

    sql = _PLACEHOLDER.sub(swap, sql)
    named = {d: str(t).strip() for d, t in (resolutions or {}).items() if _PLAIN_TABLE.fullmatch(str(t or "").strip())}
    shared = {t for t, n in Counter(named.values()).items() if n > 1}      # two datasets over one table: not tellable apart
    tables = sorted(((d, t) for d, t in named.items() if t not in shared), key=lambda pair: -len(pair[1]))
    for dataset_id, table in tables:
        sql = re.sub(rf"(?<![A-Za-z0-9_.\"]){re.escape(table.strip())}(?![A-Za-z0-9_])", dataset_ref(dataset_id), sql)
    # inputs left unnamed: a placeholder with no dataset id, or a table of the converter's machine that two datasets share
    return sql, sql.count("__TODO_TABLE__") + sum(1 for table in shared if re.search(rf"(?<![A-Za-z0-9_.\"]){re.escape(table)}(?![A-Za-z0-9_])", sql))


def covered_flows(directories: Iterable[str | Path]) -> set[str]:
    """Ids of the dataflows a converter run already has SQL for (so asking the converter again is a waste)."""
    covered: set[str] = set()
    for directory in directories:
        try:
            payload = json.loads((Path(directory).expanduser() / CONVERSION_FILE).read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        covered.update(str(f.get("dataflow_id")) for f in payload.get("dataflows") or [] if f.get("outputs"))
    return covered


def convert_flows(
    client: Any, flows: Iterable[tuple[str, str]], out_dir: str | Path, skip: set[str] | None = None,
    progress: Callable[[str], None] = lambda message: None, save_every: int = 100,
) -> dict[str, Any]:
    """Ask the converter for each (id, name) and write the folder. A rerun keeps what an earlier one converted.

    One flow the converter cannot do is recorded with its reason and the rest go on."""
    out = Path(out_dir).expanduser()
    out.mkdir(parents=True, exist_ok=True)
    resolutions = client.list_resolutions() or {}
    previous: dict[str, dict[str, Any]] = {}
    try:
        for flow in json.loads((out / CONVERSION_FILE).read_text(encoding="utf-8")).get("dataflows") or []:
            if flow.get("outputs"):
                previous[str(flow["dataflow_id"])] = flow
    except (OSError, ValueError):
        pass
    converted: dict[str, dict[str, Any]] = dict(previous)
    todo = [(str(i), name) for i, name in flows if str(i) not in (skip or set()) and str(i) not in previous]

    def save() -> None:
        used: dict[str, str] = {}
        for flow in converted.values():
            for output in flow.get("outputs") or []:
                try:
                    text = (out / output["artefact"]).read_text(encoding="utf-8")
                except OSError:
                    continue
                for found in set(re.findall(r'"([0-9A-Fa-f-]{36})"', text)):
                    used[found] = dataset_ref(found)
        payload = {"dataflows": [converted[k] for k in sorted(converted, key=lambda k: (len(k), k))],
                   "resolutions": dict(sorted(used.items())), "validated": False, "converter_only": True}
        tmp = out / (CONVERSION_FILE + ".tmp")
        tmp.write_text(json.dumps(payload, indent=1), encoding="utf-8")
        os.replace(tmp, out / CONVERSION_FILE)

    for index, (flow_id, name) in enumerate(todo, start=1):
        try:
            answer = client.generate_sql(flow_id, force=False)
            error = None
        except Exception as exc:  # noqa: BLE001 -- the reason is the finding; the other flows go on
            answer, error = {}, str(exc).strip().splitlines()[0][:300] if str(exc).strip() else type(exc).__name__
        outputs = []
        for position, output in enumerate(answer.get("outputs") or []) if not error else []:
            if not str(output.get("sql") or "").strip():
                continue
            try:
                sql, left = neutral_sql(output["sql"], resolutions)
                dataset = output.get("dataSourceId")
                label = re.sub(r"[^A-Za-z0-9_.-]", "_", str(dataset or f"{output.get('cteName') or 'out'}_{position}"))
                filename = f"dataflow_{flow_id}_{label}.sql"
                (out / filename).write_text(sql if sql.endswith("\n") else sql + "\n", encoding="utf-8")
            except OSError as exc:          # one flow's file must not lose the others
                error = f"could not write the SQL: {exc}"
                outputs = []
                break
            outputs.append({"data_source_id": dataset, "destination_name": output.get("destinationName"),
                            "artefact": filename, "sql_chars": len(sql), "validated": False,
                            "unnamed_inputs": left})
        record: dict[str, Any] = {
            "dataflow_id": flow_id, "name": name, "outputs": outputs, "converter_only": True,
            "unsupported_tile_types": answer.get("unsupportedTileTypes") or [],
            "unresolved_sources": [], "tiles_with_warnings": 0, "repairs": []}
        if error or not outputs:
            record["error"] = error or "the converter returned no output"
            record["outputs"] = []
        converted[flow_id] = record
        if index % 25 == 0:
            progress(f"[{index}/{len(todo)}] {name!r}")
        if index % save_every == 0:
            save()
    save()
    ok = [f for f in converted.values() if f.get("outputs")]
    return {"flows": len(converted), "converted": len(ok), "failed": len(converted) - len(ok),
            "outputs": sum(len(f["outputs"]) for f in ok), "asked": len(todo), "kept": len(previous),
            "unnamed_inputs": sum(o.get("unnamed_inputs", 0) for f in ok for o in f["outputs"]),
            "with_unsupported_tiles": sum(1 for f in ok if f["unsupported_tile_types"])}

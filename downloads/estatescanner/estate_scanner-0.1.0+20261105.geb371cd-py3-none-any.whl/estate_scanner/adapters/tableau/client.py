"""Maps a Tableau site (Server or Cloud) into the platform-agnostic core models: the structure phases (M3 3.5).

**Nothing in this module has talked to a real Tableau server.** It was written from Tableau's published REST
documentation and tested against a fake backend (tests/tableau_estate_service.py) that serves the documented
shapes rendered as JSON. Every statement about what the REST API returns is tagged: **[C]** = read in the
documentation, **[U]** = unconfirmed (assumed, or not stated), checked by task 3.3 / the live exit of 3.5.
Where a field is [U] the code reads it defensively and the scan still produces the row without it.

What a scan reads (REST only; the site is the ``instance``, see docs/tableau-scan-decisions.md)
------------------------------------------------------------------------------------------------
  workspace   Each project (``type = project``). A nested project's ``parentProjectId`` becomes the ``contains`` edge
              from its parent. The site itself is not a row: ``_probe_site`` reads it only to check it is the site that
              was asked for and is active, and says so as an issue if not (the "sites" phase).
  user        ``GET /sites/{id}/users``. ``role`` = ``siteRole``. Membership comes from the groups (below).
  group       ``GET /sites/{id}/groups`` and, per group, ``GET /sites/{id}/groups/{id}/users`` for the ``member_of`` edges.
  app         Each workbook (``app_type = workbook``), in its project. ``views`` lists its dashboards and stories.
  dashboard   A view that is a dashboard or a story (``raw.dashboardType``).
  card        A view that is a worksheet. **REST does not say sheet or dashboard [U]**: the kind is taken from a
              ``sheetType`` the list may carry [U: unconfirmed that it exists], else from ``view_kinds`` (the hook the
              workbook-file reader fills in, 3.6), else the view is stored as a card of unknown kind and one issue
              says how many. The workbook file is authoritative.
  dataset     Each published data source. Embedded data sources exist only inside a workbook file: not here (3.6).
  account     Each connection that ``.../workbooks/{id}/connections`` and ``.../datasources/{id}/connections`` list.
              A published data source's connections get a ``feeds`` edge to it; a workbook's connections do not yet
              (which embedded data source they belong to is in the workbook file), so they have none until 3.6.

From the workbook and data source files (3.6; ``content.py`` says what is read and why, ``http.download`` how it is fetched)
  Each workbook and published data source is downloaded without its extract (``.../content?includeExtract=False``), read in
  memory by ``read_summary`` (3.4) and dropped; only the rows derived from it are kept. That adds: the embedded data sources
  (``dataset``), calculations and parameters (``calculated_field``), the sheet-to-data-source and dashboard edges, the sheet or
  dashboard kind of each view (the ``view_kinds`` hook), row-level security evidence (``datasets.pdp_json``), extract
  configuration, and each extract refresh task (``GET /tasks/extractRefreshes``) on the data source or workbook it targets.
  A file that cannot be downloaded or read is one issue naming the workbook or data source; the scan goes on.

Permissions (3.7, ``permissions.py``): each project, workbook, published data source and dashboard is asked who holds which capabilities
  on it, in its own phase (``role_holders``), and each holder is a ``has_role`` edge from the user or group to it, ``{"role": <template name or "Custom">, "capabilities": {"Read": "Allow", ...}}``; each project row also
  carries ``permissionSettings`` (its lock mode and, per content type, the default permissions it hands to new content). What a token
  that is not a site administrator cannot list is counted per kind in an issue.

Subscriptions, custom views, Prep flows and refresh history (3.8), each read on its own and each *documented shape only*: nothing here has
  talked to a real Tableau server, and the answers' JSON rendering is unconfirmed [U] (docs/tableau-scan-decisions.md, "3.8").
  alert       Each subscription (``GET /subscriptions``): ``rule`` is the schedule's frequency (Cloud) or its name (Server), a ``watched_by``
              edge goes to the view (a dashboard or a worksheet card) or the workbook (``app``) it sends.
  card        Each custom view (``GET /customviews``) as a card of type ``custom_view``; it has no edge to the view it was saved from, so
              BIMControl does not count it as a visual of that dashboard.
  dataflow    Each Prep flow (``GET /flows``) with its schedules (``/tasks/runFlow``) and its runs (``/flows/runs`` -> ``refreshes``).
  refreshes   Extract refresh jobs (``GET /jobs`` filtered to ``refresh_extracts``): a list row names no workbook or data source [C R12], so
              one ``GET /jobs/{id}`` per job (the newest ``MAX_JOB_DETAILS``) says which; the rows go on the published data source
              (``object_type = 'dataset'``) or the workbook (``'app'``).
  A list that cannot be read, answers in a shape this reader does not know, or is cut by a bound is an issue and, on the rows that
  depend on it, a marker (``refreshJobsRead`` / ``flowRunsRead`` / ``flowTasksRead`` = false): never a quiet empty result.

Nothing is trusted about the shape of an answer: an id that is a list, a name that is a dict, a body that is not an object
are counted in an issue and the row (or page) is skipped; they never end the scan.

Nothing is skipped silently. A page, a connection list or a group's members that cannot be read is a
``ScanIssue`` (what was being read, the HTTP status) and the scan goes on; an empty listing that should not be
(no workbooks, no projects, no users) is an issue too, never a quiet "completed". A lost sign-in is the one thing
that ends a scan (``TableauAuthError``, raised from ``http.py``).
"""

from __future__ import annotations

import datetime as _dt
import logging
import re
import threading
from collections.abc import Callable, Iterator
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Any

from estate_scanner.core.models import (
    Account,
    Alert,
    App,
    AppView,
    CalculatedField,
    Card,
    Dashboard,
    Dataflow,
    Dataset,
    Group,
    ObjectRef,
    Refresh,
    RoleAssignment,
    ScanIssue,
    User,
    Workspace,
)
from estate_scanner.core.platform import PlatformClient, PlatformError

from .auth import TableauAuthError, TableauSession
from .budget import ByteBudget, default_budget_bytes
from .content import DatasourceRows, WorkbookContext, WorkbookRows, derive_datasource, derive_workbook, drop_wrapper_copies
from .files import DEFAULT_LIMITS, Limits, TableauFileError, parse_cost
from .http import MAX_PAGE_SIZE, MAX_PAGES, DOWNLOAD_DEADLINE_S, ApiError, DownloadTooLarge, Paged, TableauHttp, _HEX_RUN, _views
from .permissions import DEFAULT_TYPES, LOCK_MODES, MAX_CAPABILITIES, Parsed, parse_permissions, template_name
from .scrub import fold_for_search, fold_keeping_case, is_secret_name, redact_inline
from .workbook import read_summary

log = logging.getLogger(__name__)

# Which sort to ask each list for: none. ``sort`` makes paging stable only where the endpoint supports it, and which
# endpoints do is unconfirmed [U]; a wrong ``sort`` could fail a whole phase, where the reconciliation pass in
# ``TableauHttp.list_paged`` already recovers an item that slipped between pages.
SORT: dict[str, str | None] = {}

# Workbook and data source files are downloaded by this many threads at once. Tableau Cloud caps long-running requests
# (downloads among them) at 20 concurrent and answers the excess with 429 [C R7]; the plan's default is 8, well under it.
# Memory: a file is held only while it is downloaded and read. What the workers hold at once is bounded by a shared byte budget
# (``budget.py``, sized from the machine): a worker asks for the file's estimated peak cost (its bytes plus ten times its XML, see
# ``files.parse_cost``) before it parses, and waits if the others hold the room. Until then it holds only the downloaded bytes.
# That is up to ``max_file_bytes`` (1 GiB) per worker, so 8 x 1 GiB is still the worst case outside the budget.
DOWNLOAD_WORKERS = 8
MAX_DOWNLOAD_WORKERS = 20
MAX_REFUSALS_LISTED = 20  # refused downloads that get an issue each; the rest are counted in one

# Permission lists are plain GETs, not long-running requests, so the 20-at-once cap of downloads does not apply; 8 at once is the same
# courtesy as the file workers, and a 5,000-workbook site's ~10,000 permission calls then take minutes, not the better part of an hour.
PERMISSION_WORKERS = 8
MAX_NAMES_LISTED = 5  # objects named in the issue for a kind whose permissions could not be read; the rest are counted
PERMISSION_CHUNK = 100  # objects whose permission lists are asked before their rows are written (an interrupted phase keeps the earlier chunks)
# A kind whose lists are refused (403) is stopped only if not one list of it has been read after this many refusals: a token that is not an
# administrator may still read some dashboards or data sources, wherever they fall in the listing, so a short run of refusals proves nothing.
MAX_ALL_REFUSED = 200
# Lists read (projects, workbooks and data sources together; a view inherits its workbook's and may be empty on any site), none holding a
# grantee, at least one of them in a shape this reader does not know: reported once as a probable change of shape.
MIN_LISTS_FOR_SHAPE_CHECK = 3
POOLED_KINDS = ("project", "workbook", "datasource")

# 3.8 lists (subscriptions, custom views, flows, jobs, flow run tasks): the most pages one pass reads. At 1,000 rows a page that is 100,000 rows, far
# more than a site holds of any of them; past it the listing says it was cut (``Paged.truncated_at``) and the scan goes on.
MAX_LIST_PAGES = min(100, MAX_PAGES)
# Extract refresh jobs: a list row names no workbook or data source [C R12], so each job costs one ``GET /jobs/{id}``. Only the newest this many are
# asked about; the issue says how many were not. A job is a few hundred bytes and one request, so 2,000 is ~25 s at 8 at once and bounds a
# site that has run a million refreshes.
MAX_JOB_DETAILS = 2000
# Flow runs are one answer (the page for them documents no paging [C R13]); more rows than this are not kept, and the flows are marked unread.
MAX_FLOW_RUNS = 20000
# What a job list may hold: the server is asked for ``refresh_extracts`` only; a server that ignores the filter is filtered here. [U: whether an
# incremental refresh (``increment_extracts``) is listed under the first; it is kept if it is listed.]
EXTRACT_JOB_TYPES = ("refresh_extracts", "increment_extracts")
# Subscriptions that none has a view or workbook reference, at least this many of them: reported as a probable change of shape.
MIN_ROWS_FOR_SHAPE_CHECK = 3
# The unpaged flow runs answer is read up to this many bytes and no further (it has no page size to bound it); over it, it is not parsed and the flows are marked unread.
MAX_FLOW_RUNS_BYTES = 16 << 20
CLEAN_CACHE_CHARS = 4_000_000  # characters (keys and values) the cache of cleaned texts may hold: a few tens of megabytes at most
CLEAN_CHARS_PER_ROW = 20_000  # characters of one stored row that are searched in full, counting the characters of the decoded views the search makes of each text (a text that is
# percent-encoded, entity-escaped or base64 is searched as 2 to 48 texts); a row with more than that (a hostile one: a normal row has about 2,000) has the rest withheld
CLEAN_VIEW_CHARS_PER_SCAN = 5_000_000  # characters of decoded views a whole scan may search (about a second per million): an ordinary text has none, so a scan spends a
# few thousand; after that a text that would make views is withheld, and one issue says so
WITHHELD_BUDGET_TEXT = "[withheld: too much text in this row to check]"
WITHHELD_SCAN_BUDGET_TEXT = "[withheld: this scan has spent its allowance for checking encoded text]"
# A text that can make a view of itself: a percent sign, an entity or a JSON escape, a plus (``unquote_plus``), a base64-looking run of 16 (which is also a base32
# run), or a run of 6 hex bytes in any spelling ``http._hex_runs`` decodes (12 digits in a row, ``70:61``, ``70 61``, ``0x70, 0x61``, ``\\x70``): the pattern
# for the last is the decoder's own, so the allowance's gate cannot fall behind it.
_DECODABLE = re.compile(r"[%&\\+]|[A-Za-z0-9+/_-]{16}|" + _HEX_RUN.pattern)
WITHHELD_TEXT = "[withheld: the text repeated a credential]"
MAX_STATUS_CHARS = 200
MAX_NAME_CHARS = 1000
DEFAULT_TEXT_CHARS = 2000  # a text column with no limit of its own (a file type, a status, a content URL, a user's name): far above any real one
CUT_MARGIN = 4  # a text is cut to this many times its limit before it is searched for credentials

KIND_DASHBOARD = "dashboard"
KIND_STORY = "story"
KIND_WORKSHEET = "worksheet"
# What a ``sheetType`` [U] or a ``view_kinds`` answer may say, normalised. Anything else is "unknown".
_KINDS = {
    "dashboard": KIND_DASHBOARD, "story": KIND_STORY, "storypoint": KIND_STORY,
    "worksheet": KIND_WORKSHEET, "sheet": KIND_WORKSHEET,
}

# A per-object loop (one call per workbook, per data source, per group) stops after this many failures in a row, with one
# issue naming how many objects were skipped. A server that is down or throttling would otherwise cost every object its
# full back-off: a hundred workbooks at three tries is 300 requests and many minutes. A 429 means the server has asked us
# to slow down and the transport has already waited out its retries, so two in a row is enough; an object the account may
# not read (403) is a fact about that object, so many in a row are tolerated.
MAX_CONSECUTIVE_THROTTLED = 2
MAX_CONSECUTIVE_FAILURES = 5
MAX_CONSECUTIVE_REFUSALS = 25

# The connection fields that are stored. An allow-list, not a deny-list: a connection row can carry anything a data
# source type defines (connection strings, keys, tokens, nested objects), and none of it can be known in advance, so
# what is not listed is not kept. A flag says *whether* a password is stored, never the password.
_CONNECTION_TEXT = ("id", "type", "serverAddress", "serverPort", "userName", "authenticationType", "dbName", "databaseName", "filename")
_CONNECTION_FLAGS = ("embedPassword", "useOAuthManagedKeychain", "queryTaggingEnabled")

# The patterns of ``clean_text``. Written to take time linear in the text: a hostile text is megabytes long to begin with and a regular expression
# with a leading optional group or nested quantifiers tries every start and scans to the end from each (``"a" * 4000`` took half a second, ``"auth" * 1000``
# minutes). So the two userinfo forms and the ``key=value`` form are found with a delimiter or a key regular expression that can fail in one pass, and the rest
# (which key is secret, where userinfo starts) is decided in code.
#
# user:password@host, with or without a scheme (a server address pasted from a URL or a connection string): in a run of text without ``/``, white space
# or ``@``, ending in ``@``, everything from the user name (which has no ``:=;&``) to the ``@`` goes; the scheme before it stays.
_DELIMITERS = re.compile(r"[/\s@]")
_SCHEME_CHAR = re.compile(r"(?i)[a-z0-9+.\-]")
_SCHEME_LETTER = re.compile(r"(?i)[a-z]")
# A secret-looking key and its value. Two forms, because ``:`` is also what separates a host from its port:
# - ``key=value``: the key may be any identifier that contains a secret-ish word (``accessKey``, ``client_secret``,
#   ``keycloak.secret``); a host does not contain ``=``, so nothing here can eat one. The key is the whole identifier before the ``=``, whatever is in it.
# - ``key: value`` / ``key:value``: only a key that is exactly a known secret name. ``keycloak.example.com:8443``,
#   ``sas-prod.corp:1433`` and ``author-db:5432`` are hosts that merely contain ``key``, ``sas`` or ``auth``. The shortest,
#   most ambiguous names (``sas``, ``sig``, ``auth``, ``key``, ``pass``) count only when a space follows the colon.
# The key must start a token: nothing word-like, a dot or a hyphen directly before it.
_EQUALS_KEY = re.compile(r"(?<![\w.\-])(?P<key>[\w.\-]+)\s*=\s*")
_SECRET_WORD = re.compile(r"(?i)pass|pwd|secret|token|key|credential|auth|sas|signature|sig")
_VALUE = re.compile(r"\"[^\"]*\"|'[^']*'|[^;&\s,]*")
_SECRET_COLON = re.compile(
    r"(?i)(?<![\w.\-])(?:(?P<key>password|passwd|pwd|token|secret|apikey|api[_-]key|access[_-]?key|private[_-]?key|client[_-]?secret|"
    r"authorization|signature|credentials?)\s*:\s*|(?P<short>pass|sas|sig|auth|key)\s*:\s+)"
    r"(?:\"[^\"]*\"|'[^']*'|[^;&\s,]*)"
)
_BEARER = re.compile(r"(?i)\b(?P<scheme>bearer|basic)\s+[A-Za-z0-9._~+/=\-]+")

ViewKinds = Callable[[str], "dict[str, str] | None"]


def _s(value: Any) -> str | None:
    return None if value is None else str(value)


def _usable_id(value: Any) -> str | None:
    """An identifier as text, or None if it is not one: a non-empty string or an integer. A list or dict is not an id
    (``str()`` of it would make a junk row and a junk edge)."""
    if isinstance(value, str) and value != "":
        return value if _encodable(value) else value.encode("utf-8", "replace").decode("utf-8")
    if isinstance(value, int) and not isinstance(value, bool):
        return str(value)
    return None


def _encodable(text: str) -> bool:
    try:
        text.encode("utf-8")
        return True
    except UnicodeEncodeError:
        return False


def _when(value: Any) -> _dt.datetime | None:
    if not value:
        return None
    try:
        return _dt.datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None


def _flag(value: Any) -> bool | None:
    """XML attributes arrive as ``"true"`` / ``"false"``; the JSON rendering may use real booleans [U]."""
    if isinstance(value, bool):
        return value
    if isinstance(value, str) and value.strip().lower() in ("true", "false"):
        return value.strip().lower() == "true"
    return None


def normalise_kind(value: Any) -> str | None:
    return _KINDS.get(value.strip().lower()) if isinstance(value, str) and value.strip() else None


def _drop_userinfo(text: str) -> str:
    """``user:password@`` taken out, with or without a scheme before it (the scheme stays). One pass over the ``@`` signs: the run of text before each, back to
    the last ``/``, white space or ``@``, is userinfo when it holds a ``:``; the user name starts after the last ``=``, ``;`` or ``&`` before that colon."""
    if "@" not in text or ":" not in text:
        return text
    out: list[str] = []
    copied = start = 0
    for match in _DELIMITERS.finditer(text):
        end = match.start()
        if text[end] == "@":
            colon = text.find(":", start, end)
            if colon >= 0:
                begin = max(text.rfind(c, start, colon) for c in "=;&")
                out.append(text[copied:start if begin < 0 else begin + 1])
                copied = end + 1
        start = end + 1
    out.append(text[copied:])
    return "".join(out)


def _drop_scheme_user(text: str) -> str:
    """``scheme://user@`` with the user name taken out (the scheme stays): after each ``://`` that follows a run of scheme characters with a letter in it, the
    text up to the next ``/``, white space or ``@`` goes when that is an ``@`` and the user name is not empty."""
    if "://" not in text or "@" not in text:
        return text
    out: list[str] = []
    copied = pos = 0
    while True:
        at = text.find("://", pos)
        if at < 0:
            break
        pos = at + 1
        back, lettered = at, False
        while back > 0 and _SCHEME_CHAR.match(text[back - 1]):
            back -= 1
            lettered = lettered or _SCHEME_LETTER.match(text[back]) is not None
        if not lettered:
            continue
        begin = at + 3
        stop = _DELIMITERS.search(text, begin)
        if stop is not None and text[stop.start()] == "@" and stop.start() > begin:
            out.append(text[copied:begin])
            copied = pos = stop.end()
    out.append(text[copied:])
    return "".join(out)


def _redact_equals(text: str) -> str:
    """The value of every ``key=value`` whose key (the whole identifier before the ``=``) holds a secret-ish word becomes ``[removed]`` (a quoted value to its
    closing quote, else to the next ``;``, ``&``, white space or comma)."""
    out: list[str] = []
    copied = pos = 0
    while True:
        match = _EQUALS_KEY.search(text, pos)
        if match is None:
            break
        pos = match.end()
        if _SECRET_WORD.search(match.group("key")):
            value = _VALUE.match(text, pos)
            out.append(f"{text[copied:match.start()]}{match.group('key')}=[removed]")
            copied = pos = value.end()
    out.append(text[copied:])
    return "".join(out)


def clean_text(value: str) -> str:
    """A string with the credentials taken out: ``user:password@`` before a host (with or without a scheme), the value of
    any secret-looking ``key=value`` pair (a connection string, a query), and a Bearer/Basic token. Takes time linear in the text."""
    value = _drop_userinfo(value)
    value = _drop_scheme_user(value)
    value = _BEARER.sub(lambda m: f"{m.group('scheme')} [removed]", value)  # first: "authorization: Bearer x" must not leave x behind
    value = _redact_equals(value)
    return _SECRET_COLON.sub(lambda m: f"{m.group('key') or m.group('short')}=[removed]", value)


def scrub_connection(row: dict) -> dict:
    """The part of a connection row that is stored: the allow-listed fields only, text cleaned of credentials, flags as
    real booleans (they arrive as ``"true"``), the data source reference cut to its id and name. ``fieldsNotStored`` counts
    what was left out (the names are not kept: a name can itself be a value)."""
    kept: dict[str, Any] = {}
    for key in _CONNECTION_TEXT:
        value = row.get(key)
        if isinstance(value, str):
            kept[key] = clean_text(value)
        elif isinstance(value, int) and not isinstance(value, bool):
            kept[key] = value
    for key in _CONNECTION_FLAGS:
        flag = _flag(row.get(key))
        if flag is not None:
            kept[key] = flag
    datasource = row.get("datasource")
    if isinstance(datasource, dict):
        kept["datasource"] = {k: clean_text(datasource[k]) for k in ("id", "name") if isinstance(datasource.get(k), str)}
    kept["fieldsNotStored"] = len([k for k in row if k not in kept])
    return kept


class _Breaker:
    """Counts failures in a row in one per-object loop; ``failed`` says when the loop should give up."""

    def __init__(self) -> None:
        self.run = 0

    def ok(self) -> None:
        self.run = 0

    def failed(self, exc: ApiError) -> bool:
        self.run += 1
        status = exc.status
        if status == 429:
            limit = MAX_CONSECUTIVE_THROTTLED
        elif status is not None and 400 <= status < 500 and status != 408:
            limit = MAX_CONSECUTIVE_REFUSALS
        else:
            limit = MAX_CONSECUTIVE_FAILURES
        return self.run >= limit


def _plural(n: int, noun: str) -> str:
    return f"{n} {noun}" if n == 1 else f"{n} {noun}s"


@dataclass
class _Listing:
    """One site-wide listing as read: the rows, what the server said exists, and whether it could be read at all."""

    items: list[dict] = field(default_factory=list)
    total: int | None = None  # ``totalAvailable``, when the server said
    failed: bool = False  # nothing could be read (so the count is unknown, not zero)
    complete: bool = False  # every row the server said exists was received
    dropped: int = 0  # rows that came back without a usable id (counted in an issue, not in ``items``)

    @property
    def estimate(self) -> int | None:
        """What the phase will yield. The server's claim, unless it under-reports (more rows arrived than it said)."""
        if self.total is not None:
            return max(self.total, len(self.items))
        return None if self.failed else len(self.items)


class TableauClient(PlatformClient):
    platform = "tableau"

    def __init__(self, session: TableauSession, http: TableauHttp | None = None, *, view_kinds: ViewKinds | None = None,
                 page_size: int = MAX_PAGE_SIZE, read_files: bool = True, limits: Limits = DEFAULT_LIMITS,
                 download_workers: int = DOWNLOAD_WORKERS, download_deadline_s: float = DOWNLOAD_DEADLINE_S,
                 file_memory_bytes: int | None = None):
        """``view_kinds(workbook_id)`` returns ``{view id: "dashboard" | "story" | "worksheet"}`` for that workbook, or None.
        It is asked once per workbook that has a view whose kind the REST list did not give, and an error in it is an
        issue, not a failed scan. Left out, it is answered from the workbook file the scan downloads anyway (3.6).

        ``read_files=False`` is the 3.5 scan: structure only, nothing downloaded, the file-backed phases skipped.
        ``limits`` are the reader's (``files.py``); its ``max_file_bytes`` is also the download's hard cap.

        ``file_memory_bytes`` is the budget the file workers share, in estimated peak bytes (``budget.py``). Left out: the environment's
        ``ESTATE_SCANNER_TABLEAU_FILE_MEMORY_MB`` if set, else an eighth of the memory available on this machine."""
        super().__init__(session)
        self._http = http or TableauHttp(session)
        self._read_files = read_files
        self._deadline_s = download_deadline_s
        self._limits = limits
        self._download_workers = max(1, min(download_workers, MAX_DOWNLOAD_WORKERS))
        self._budget = ByteBudget(file_memory_bytes if file_memory_bytes is not None else default_budget_bytes())
        self._view_kinds = view_kinds or (self._file_view_kinds if read_files else None)
        self._file_data: _FileData | None = None
        self._file_findings: dict[str, tuple[int, str | None]] = {}
        self._task_index: dict[str, list[dict]] | None = None
        self._tasks_read = False
        self._tasks_whole = False
        self._page_size = page_size
        self._issues: list[ScanIssue] = []
        self._malformed: dict[tuple[str, str], int] = {}
        self._lock = threading.Lock()
        self._listings: dict[str, _Listing] = {}
        self._site_probed = False
        self.site: dict | None = None  # what ``GET /sites/{id}`` said; not a row (the site is the instance)
        self._memberships: dict[str, list[str]] | None = None
        self._connections: dict | None = None
        self._classified: dict | None = None
        self._dashboards_by_workbook: dict[str, list[dict]] = {}
        self._checked: set[str] = set()
        self._parents: dict[str, str | None] | None = None
        self._perm = _PermState()
        self._admin_checked = False
        self.permission_requests = 0  # permission GETs made (see ``_grants`` for what that comes to on a big site)
        self._job_state = _PermState()  # the job-detail lookups (3.8) are the permission lookups' machinery over another kind of answer
        self.job_requests = 0  # ``GET /jobs/{id}`` calls made
        self._history: _History | None = None
        self._flow_data: _FlowData | None = None
        self._admin_noted: set[str] = set()
        self._cleaned_chars = 0
        self._view_chars_left = CLEAN_VIEW_CHARS_PER_SCAN
        self._cleaned: dict[str, str] = {}  # text -> its cleaned form: the same status, id or name comes back in thousands of rows

    # -- issues ------------------------------------------------------------------

    def _issue(self, scope: str, exc: Exception | str, phase: str, status: int | None = None) -> None:
        status = exc.status if isinstance(exc, ApiError) else status
        with self._lock:
            self._issues.append(ScanIssue(scope=scope, message=str(exc), status=status, phase=phase))

    def _bad(self, phase: str, what: str) -> None:
        """Count a value that was not the type it should be. One issue per phase and kind is raised in ``take_issues``,
        not one per row: a hostile or broken server could otherwise write a million issues."""
        with self._lock:
            self._malformed[(phase, what)] = self._malformed.get((phase, what), 0) + 1

    def take_issues(self) -> list[ScanIssue]:
        with self._lock:
            issues, self._issues = self._issues, []
            malformed, self._malformed = self._malformed, {}
            findings, self._file_findings = self._file_findings, {}
        for code, (n, first) in sorted(findings.items()):
            issues.append(ScanIssue(scope="workbook files", message=f"{_plural(n, 'finding')} of kind {code} while reading files; the first: {first}", phase="dataset"))
        for (phase, what), n in malformed.items():
            issues.append(ScanIssue(scope=f"{phase} rows", message=f"{n} {what} (skipped or left empty; the raw row is stored as received)", phase=phase))
        return issues + self._permission_issues() + self._job_issues()

    def verify_session(self) -> bool:
        try:
            self._http.get(self._http.site_path())
            return True
        except PlatformError:  # sign-in lost or refused (TableauAuthError) or the call refused; anything else is a bug and should show
            return False

    # -- reading values, none of them trusted ----------------------------------------

    def _text(self, value: Any, phase: str, limit: int | None = None) -> str | None:
        """A value for a text column: a string made safe for the database (a lone surrogate would raise on insert), with no credential in it, a
        number as text, None as None. Anything else (a dict, a list, a bool) is counted and left empty. ``limit`` cuts the answer: the text is
        first cut to ``CUT_MARGIN`` times the limit (a hostile server's text may be megabytes, and the credential patterns cost more than linear
        time on them), cleaned, and then cut to the limit, so a credential that starts inside the limit is seen whole."""
        if value is None:
            return None
        if isinstance(value, str):
            limit = DEFAULT_TEXT_CHARS if limit is None else limit  # (no text is searched at the length a hostile server chose: the search costs about 12 seconds a megabyte)
            value = value[:limit * CUT_MARGIN]
            cleaned = self._clean(value if _encodable(value) else value.encode("utf-8", "replace").decode("utf-8"))
            return cleaned[:limit]
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            return str(value)
        self._bad(phase, "values of an unexpected type")
        return None

    def _id(self, value: Any, phase: str) -> str | None:
        found = self._safe_id(value)
        if found is None and value is not None:
            self._bad(phase, "references of an unexpected type")
        return found

    def _qref(self, row: dict, key: str) -> str | None:
        """Like ``_ref`` but silent: the phase that stores the row already counts a malformed reference. A reference that repeats a credential is None."""
        value = row.get(key)
        return self._safe_id(value.get("id")) if isinstance(value, dict) else None

    def _ref(self, row: dict, key: str, phase: str) -> str | None:
        """The id of a nested reference such as ``owner: {id}`` or ``project: {id}`` (the XML's child element)."""
        value = row.get(key)
        if value is None:
            return None
        if not isinstance(value, dict):
            self._bad(phase, "references of an unexpected type")
            return None
        return self._id(value.get("id"), phase)

    def _build(self, rows: list[dict], phase: str, make: Callable[[dict], Any]) -> Iterator[Any]:
        """``make`` applied to each row; a row that cannot be mapped is counted and skipped, never fatal."""
        for row in rows:
            try:
                obj = make(row)
            except (TypeError, ValueError, AttributeError, UnicodeError):
                self._bad(phase, "rows that could not be mapped")
                continue
            yield obj

    # -- listings ----------------------------------------------------------------

    def _list(self, key: str, suffix: str, collection: str, item: str, phase: str, label: str, *, expect_some: str | None = None,
              params: dict | None = None, strict: bool = False, lost: str | None = None, hint403: str | None = None,
              max_pages: int | None = None) -> _Listing:
        """A whole site-wide listing, read once. A page that cannot be read is an issue and the others are kept;
        a listing that comes back empty is an issue too when ``expect_some`` says why that is not believable.

        ``strict``, ``lost``, ``hint403`` and ``max_pages`` are the 3.8 lists': an answer that is not a page of the collection is an issue
        (never an empty list), ``lost`` is what the issue says is missing when nothing could be read, ``hint403`` what a refusal means."""
        if key in self._listings:
            return self._listings[key]
        listing = _Listing()
        try:
            paged: Paged = self._http.list_paged(
                self._http.site_path(suffix), collection, item, page_size=self._page_size, sort=SORT.get(key), tolerate_page_errors=True,
                params=params, strict=strict, max_pages=max_pages)
        except ApiError as exc:  # page failures are tolerated inside list_paged; this is only a belt for an error raised outside a page
            listing.failed = True
            self._issue(label, exc, phase)
            self._listings[key] = listing
            return listing
        rows = []
        leaky = 0
        for r in paged.items:
            found = _usable_id(r.get("id")) if isinstance(r, dict) else None
            if found is not None and self._repeats_credential(found):
                leaky += 1  # an id that repeats a credential is a key: it cannot be stored as something else, so the row is not made
                continue
            if found is not None:
                rows.append(r if r["id"] == found else {**r, "id": found})
        if leaky:
            self._issue(label, f"{_plural(leaky, item)} had an id that repeats a credential and {'was' if leaky == 1 else 'were'} not stored", phase)
        if len(rows) + leaky != len(paged.items):
            self._issue(label, f"{len(paged.items) - len(rows) - leaky} {item}(s) came back without a usable id and were skipped", phase)
            listing.dropped = len(paged.items) - len(rows) - leaky
        listing.items, listing.total = rows, paged.total_available
        self._report_failed_pages(label, paged, phase, lost, hint403)
        if paged.missing and not paged.failed_pages:
            # The server said N exist and a second pass still received fewer: an item removed or added between pages, or a server that skips.
            self._issue(label, f"The server lists {paged.total_available} {collection} but {len(rows)} were received after {paged.passes} passes; "
                               f"{paged.missing} are missing from this scan", phase)
        if paged.exceeded:
            self._issue(label, f"The server stated {paged.total_available} {collection} but {len(paged.items)} arrived "
                               f"({paged.exceeded} more than stated); it under-reports its total, and every row received was kept", phase)
        if paged.truncated_at:
            self._issue(label, f"Listing stopped after {paged.truncated_at} pages (the page cap) while rows were still arriving; "
                               f"the rest of the {collection} are missing from this scan", phase)
        if paged.stopped:
            self._issue(label, f"Listing stopped early: {paged.stopped}; the pages that never answered were not read, so the rest of the {collection} are missing from this scan", phase)
        if not rows and not paged.failed_pages:
            if expect_some:
                self._issue(label, f"0 {collection}: {expect_some}", phase)
        elif not rows:
            listing.failed = True
        listing.complete = not paged.failed_pages and not paged.missing and not paged.truncated_at and not leaky
        self._listings[key] = listing
        return listing

    def _report_failed_pages(self, label: str, paged: Paged, phase: str, lost: str | None = None, hint403: str | None = None) -> None:
        """One issue per page that never answered and is still needed. If no page ever answered (the server never said
        how long the list is) there is nothing to say per page: one issue for the listing, with the first error. ``lost`` says
        what that leaves out of the scan, ``hint403`` why a refusal is to be expected."""
        if not paged.failed_pages:
            return
        if paged.total_available is None:
            pages = ", ".join(str(p) for p, _ in paged.failed_pages)
            first = paged.failed_pages[0][1]
            hint = f" {hint403}" if hint403 and first.status == 403 else ""
            self._issue(label, f"{first} (pages {pages} tried); {lost or 'nothing could be read'}.{hint}" if lost else
                               f"{first} (pages {pages} tried); nothing could be read{hint}", phase, first.status)
            return
        for page, exc in paged.failed_pages:
            self._issue(f"{label}, page {page}", f"{exc}; " + ("the pages that answered were kept" if paged.stopped else "the other pages were read") + (
                f" ({paged.missing} of {paged.total_available} not received)" if paged.missing else ""), phase, exc.status)

    def _probe_site(self) -> None:
        """The "sites" phase. The site is the instance, not a row, so this reads ``GET /sites/{id}`` only to check
        that the sign-in landed on the site asked for and that it is active; a Server's other sites are not scanned
        (a token is valid for one site only [C R2]) and listing them is unconfirmed [U: Query Sites page not read]."""
        if self._site_probed:
            return
        self._site_probed = True
        try:
            body = self._http.get(self._http.site_path()) or {}
        except ApiError as exc:
            self._issue("site", f"{exc}; the site's own details are missing from this scan", "workspace", exc.status)
            return
        site = body.get("site") if isinstance(body, dict) else None
        if not isinstance(site, dict):
            self._issue("site", "The site's details were not in the expected shape [U: JSON rendering of Get Site]", "workspace")
            return
        self.site = site
        wanted = self.session.site or ""
        got = site.get("contentUrl")
        if isinstance(got, str) and got != wanted:
            self._issue("site", f"Signed in to site {got!r} but {wanted!r} was asked for; everything in this scan is from {got!r}", "workspace")
        state = site.get("state")
        if isinstance(state, str) and state and state.lower() != "active":
            self._issue("site", f"The site's state is {state}, not Active; what it lists may be incomplete", "workspace")

    def _projects(self) -> _Listing:
        self._probe_site()
        return self._list("projects", "/projects", "projects", "project", "workspace", "projects",
                          expect_some="a site always has at least the Default project, so this scan is empty. Check that the "
                                      "account is the intended one (a site administrator, to see everything)")

    def _users(self) -> _Listing:
        return self._list("users", "/users", "users", "user", "user", "users",
                          expect_some="the signed-in user is itself a user of the site, so this list should not be empty")

    def _groups(self) -> _Listing:
        return self._list("groups", "/groups", "groups", "group", "group", "groups")

    def _workbooks(self) -> _Listing:
        return self._list("workbooks", "/workbooks", "workbooks", "workbook", "app", "workbooks",
                          expect_some="the site has no workbooks, or this account can see none (a user who is not an administrator "
                                      "sees only what they may read). Check the site and the account before relying on this scan")

    def _views(self) -> _Listing:
        return self._list("views", "/views", "views", "view", "dashboard", "views")

    def _datasources(self) -> _Listing:
        return self._list("datasources", "/datasources", "datasources", "datasource", "dataset", "data sources")

    # -- consistency checks that cost nothing ------------------------------------------

    def _check_owners(self, key: str, rows: list[dict], noun: str, phase: str) -> None:
        """One issue naming how many rows have an owner the user list does not hold (a deleted user, or a user this account
        cannot list). The ``owns`` edge is still written, dangling, as for any object outside what the account can see; the
        issue says it is not a mistake in the scan. Skipped when the user list itself is incomplete: then it proves nothing."""
        if key in self._checked:
            return
        self._checked.add(key)
        users = self._users()
        if users.failed or not users.complete:
            return
        known = {u["id"] for u in users.items}
        missing = 0
        for row in rows:
            owner = row.get("owner")
            owner_id = _usable_id(owner.get("id")) if isinstance(owner, dict) else None
            if owner_id is not None and owner_id not in known:
                missing += 1
        if missing:
            self._issue(f"{noun}s", f"{_plural(missing, noun)} {'is' if missing == 1 else 'are'} owned by a user who is not in the user list "
                                    "(deleted, or not visible to this account); the owner is kept as it was given", phase)

    def _project_parents(self, rows: list[dict]) -> dict[str, str | None]:
        """``{project id: parent id to use}``. A project that is its own parent has none (a ``contains`` edge to itself
        means nothing). Cycles and parents that are not in the list are kept as given and counted in one issue each."""
        if self._parents is not None:
            return self._parents
        ids = {r["id"] for r in rows}
        parent: dict[str, str | None] = {}
        for r in rows:
            value = r.get("parentProjectId")
            parent[r["id"]] = self._safe_id(value) if value not in (None, "") else None
            if value not in (None, "") and parent[r["id"]] is None:
                self._bad("workspace", "references of an unexpected type")
        selfish = [i for i, p in parent.items() if p == i]
        for i in selfish:
            parent[i] = None
        in_cycle = 0
        for start in parent:
            seen, node = {start}, parent[start]
            while node is not None and node in parent:
                if node == start:
                    in_cycle += 1
                    break
                if node in seen:
                    break
                seen.add(node)
                node = parent[node]
        listing = self._listings.get("projects")
        orphans = sum(1 for p in parent.values() if p is not None and p not in ids) if listing and listing.complete else 0
        if selfish:
            self._issue("projects", f"{_plural(len(selfish), 'project')} {'is' if len(selfish) == 1 else 'are'} {'its' if len(selfish) == 1 else 'their'} own parent; no parent was recorded for {'it' if len(selfish) == 1 else 'them'}", "workspace")
        if in_cycle:
            self._issue("projects", f"{_plural(in_cycle, 'project')} {'is' if in_cycle == 1 else 'are'} in a parent cycle (each is its own ancestor); "
                                    "the parent links are kept as given", "workspace")
        if orphans:
            self._issue("projects", f"{_plural(orphans, 'project')} {'names' if orphans == 1 else 'name'} a parent that is not in the project list "
                                    "(not visible to this account, or deleted); the link is kept as given", "workspace")
        self._parents = parent
        return parent

    # -- group membership ----------------------------------------------------------

    def _group_memberships(self) -> dict[str, list[str]]:
        """``{user id: [group ids]}``, one listing per group (the other way round, one per user, is a call per user
        and needs REST 3.7). A group whose members cannot be read is an issue; its members just have no edge to it. After
        a few groups in a row fail the rest are skipped, with one issue saying how many."""
        if self._memberships is not None:
            return self._memberships
        found: dict[str, list[str]] = {}
        groups = self._groups().items
        breaker = _Breaker()
        for index, group in enumerate(groups):
            gid, gname = group["id"], _usable_label(group.get("name"), group["id"])
            label = f"group {gname} / members"
            try:
                paged = self._http.list_paged(
                    self._http.site_path(f"/groups/{gid}/users"), "users", "user", page_size=self._page_size, tolerate_page_errors=True)
            except ApiError as exc:
                self._issue(label, exc, "group")
                if breaker.failed(exc):
                    self._give_up("group", "group", len(groups) - index - 1, exc)
                    break
                continue
            self._report_failed_pages(label, paged, "group")
            if paged.missing and not paged.failed_pages:
                self._issue(label, f"{paged.missing} of {paged.total_available} members missing after {paged.passes} passes", "group")
            nothing_read = bool(paged.failed_pages) and not paged.items
            if nothing_read:
                if breaker.failed(paged.failed_pages[0][1]):
                    self._give_up("group", "group", len(groups) - index - 1, paged.failed_pages[0][1])
                    break
            else:
                breaker.ok()
            for user in paged.items:
                uid = self._safe_id(user.get("id")) if isinstance(user, dict) else None
                if uid is None:
                    self._bad("group", "member entries without a usable id")
                elif gid not in found.setdefault(uid, []):
                    found[uid].append(gid)
        self._memberships = found
        return found

    def _give_up(self, phase: str, noun: str, skipped: int, exc: ApiError) -> None:
        """The one issue a tripped breaker leaves: how many objects were not asked about, and why the loop stopped."""
        if skipped:
            self._issue(f"{noun}s", f"Stopped after repeated failures in a row ({exc}); {_plural(skipped, noun)} skipped, "
                                    f"so their {'members' if phase == 'group' else 'connections'} are missing from this scan", phase, exc.status)

    # -- views: sheet or dashboard? -------------------------------------------------

    def _view_kind_table(self) -> dict[str, tuple[str | None, dict]]:
        """``{view id: (kind or None, row)}`` for every view, in the order listed. The kind is the list's own
        ``sheetType`` [U], else the hook's answer for that view's workbook; None when neither knows. One issue says
        how many views are unknown, because they are stored as cards and that is a guess the workbook file corrects."""
        if self._classified is not None:
            return self._classified
        rows = self._views().items
        self._check_owners("views", rows, "view", "dashboard")
        table: dict[str, tuple[str | None, dict]] = {r["id"]: (normalise_kind(r.get("sheetType")), r) for r in rows}
        if self._view_kinds:
            by_workbook: dict[str, list[str]] = {}
            for vid, (kind, row) in table.items():
                wid = self._ref(row, "workbook", "dashboard")
                if kind is None and wid:
                    by_workbook.setdefault(wid, []).append(vid)
            for wid, vids in by_workbook.items():
                try:
                    answer = self._view_kinds(wid) or {}
                except Exception as exc:  # noqa: BLE001 -- the hook is another reader's code; its failure must not end the scan
                    self._issue(f"workbook {wid} / view kinds", f"{type(exc).__name__}: the workbook reader failed, its views stay unclassified", "dashboard")
                    continue
                for vid in vids:
                    kind = normalise_kind(answer.get(vid)) if isinstance(answer, dict) else None
                    if kind:
                        table[vid] = (kind, table[vid][1])
        if self._read_files:  # the file is authoritative: tables and edges must use one kind per view
            disagree = 0
            for read in self._files().workbooks.values():
                for vid, found in read.kinds.items():
                    if vid in table and normalise_kind(found) and table[vid][0] and table[vid][0] != normalise_kind(found):
                        table[vid] = (normalise_kind(found), table[vid][1])
                        disagree += 1
            if disagree:
                self._issue("views", f"{_plural(disagree, 'view')} had a sheetType from REST that disagrees with the workbook file; the file's kind is used", "dashboard")
        unknown = sum(1 for kind, _ in table.values() if kind is None)
        if unknown:
            self._issue(
                "views", f"{unknown} of {len(table)} views could not be told apart as worksheet or dashboard: the REST list does not say "
                         "[U] and the workbook file was not read. They are stored as cards (definition.kind_known = false); the workbook "
                         "file decides which are dashboards", "card")
        # Grouped once: finding a workbook's dashboards by scanning every view for every workbook is quadratic.
        by_workbook_dashboards: dict[str, list[dict]] = {}
        for kind, row in table.values():
            if kind in (KIND_DASHBOARD, KIND_STORY):
                wid = _usable_id((row.get("workbook") or {}).get("id")) if isinstance(row.get("workbook"), dict) else None
                if wid is not None:
                    by_workbook_dashboards.setdefault(wid, []).append(row)
        self._dashboards_by_workbook = by_workbook_dashboards
        self._classified = table
        return table

    def _dashboards_of(self, workbook_id: str) -> list[dict]:
        self._view_kind_table()
        return self._dashboards_by_workbook.get(workbook_id, [])

    # -- connections ---------------------------------------------------------------

    def _read_connections(self) -> dict:
        """Every connection of every workbook and published data source: ``{"accounts": {id: Account},
        "by_datasource": {datasource id: [connection ids]}, "by_workbook": {workbook id: [connection ids]}, "complete": bool}``. One call per workbook and per data source,
        none paged [U: the connection lists are not documented to be]; a call that fails is an issue and the rest go on,
        until several fail in a row (then the loop stops with one issue saying how many were skipped)."""
        if self._connections is not None:
            return self._connections
        accounts: dict[str, Account] = {}
        by_datasource: dict[str, list[str]] = {}
        by_workbook: dict[str, list[str]] = {}
        state = {"complete": True}

        def read(kind: str, owner_row: dict, suffix: str, label: str) -> ApiError | None:
            oid, name = owner_row["id"], _usable_label(owner_row.get("name"), owner_row["id"])
            scope = f"{label} {name} / connections"
            try:
                body = self._http.get(self._http.site_path(f"/{suffix}/{oid}/connections")) or {}
            except ApiError as exc:
                self._issue(scope, exc, "account")
                state["complete"] = False
                return exc
            rows = []
            if isinstance(body, dict):
                group = body.get("connections")
                rows = group.get("connection") if isinstance(group, dict) else []
                if isinstance(rows, dict):  # a one-row collection is not always rendered as a list [U]
                    rows = [rows]
                if not isinstance(rows, list):
                    rows = []
                pagination = body.get("pagination") if isinstance(body.get("pagination"), dict) else {}
                try:
                    if int(pagination["totalAvailable"]) > len(rows):
                        self._issue(scope, f"The server lists {pagination['totalAvailable']} connections but returned {len(rows)}; the rest are missing", "account")
                        state["complete"] = False
                except (KeyError, TypeError, ValueError):
                    pass
            else:
                self._issue(scope, "The connection list was not in the documented shape", "account")
                state["complete"] = False
            for row in rows:
                cid = self._safe_id(row.get("id")) if isinstance(row, dict) else None
                if cid is None:
                    self._bad("account", "connections without a usable id")
                    continue
                held = by_datasource if kind == "datasource" else by_workbook
                if cid not in held.setdefault(oid, []):
                    held[oid].append(cid)
                if cid in accounts:
                    continue
                stored = scrub_connection(row)
                text = stored.get("serverAddress") or (stored.get("datasource") or {}).get("name") or stored.get("type") or cid
                accounts[cid] = Account(
                    id=cid, name=text, connector_type=stored.get("type"),
                    # A connection has no owner of its own; the one who published the content holds its stored credentials.
                    owner_id=self._ref(owner_row, "owner", "account"),
                    raw_payload={**stored, "foundOn": {"kind": kind, "id": oid, "name": name}},
                )
            return None

        for suffix, label, listing in (("workbooks", "workbook", self._workbooks()), ("datasources", "data source", self._datasources())):
            if not listing.complete:
                state["complete"] = False
            breaker = _Breaker()
            for index, row in enumerate(listing.items):
                failure = read(suffix[:-1], row, suffix, label)
                if failure is None:
                    breaker.ok()
                elif breaker.failed(failure):
                    self._give_up("account", label, len(listing.items) - index - 1, failure)
                    break
        self._connections = {"accounts": accounts, "by_datasource": by_datasource, "by_workbook": by_workbook, "complete": state["complete"]}
        return self._connections

    # -- workbook and data source files (3.6) -----------------------------------------------------------

    def _files(self) -> "_FileData":
        """Every workbook and published data source downloaded, read and turned into rows, once. A file that cannot be
        fetched or read is one issue and its id in ``failed``; the others are kept. Only the derived rows are retained
        (the bytes and the summary are dropped as soon as a worker has made them), so memory is the rows plus, at the
        peak, ``download_workers`` files."""
        if self._file_data is not None:
            return self._file_data
        data = _FileData()
        self._file_data = data
        if not self._read_files:
            return data
        workbooks, sources = self._workbooks(), self._datasources()
        connections = self._read_connections()
        views = self._views()
        views_by_workbook: dict[str, list[dict]] = {}
        unattached = 0  # views that name no workbook or have no name: one of them may be a worksheet of any workbook, so no workbook's view list is whole
        for view in views.items:
            wid = self._qref(view, "workbook")
            if wid:
                views_by_workbook.setdefault(wid, []).append(view)
            if not wid or not isinstance(view.get("name"), str):
                unattached += 1
        published = {r["contentUrl"]: (r["id"], r.get("name") if isinstance(r.get("name"), str) else None)
                     for r in sources.items if isinstance(r.get("contentUrl"), str) and r["contentUrl"]}
        jobs: list[tuple[str, dict, WorkbookContext | None]] = []
        for row in workbooks.items:
            stored = [{**connections["accounts"][cid].raw_payload, "id": cid} for cid in connections["by_workbook"].get(row["id"], []) if cid in connections["accounts"]]
            ctx = WorkbookContext(
                workbook_id=row["id"], owner_id=self._qref(row, "owner"), project_id=self._qref(row, "project"), created_at=_when(row.get("createdAt")),
                updated_at=_when(row.get("updatedAt")), views=views_by_workbook.get(row["id"], []),
                views_complete=views.complete and not views.dropped and not unattached, published=published, connections=stored)
            jobs.append(("workbook", row, ctx))
        jobs += [("datasource", row, None) for row in sources.items]
        if not jobs:
            return data
        lock = threading.Lock()
        breakers = {"workbook": _Breaker(), "datasource": _Breaker()}
        stopped = {"workbook": threading.Event(), "datasource": threading.Event(), "all": threading.Event()}
        skipped = {"workbook": 0, "datasource": 0}
        refused = {"workbook": 0, "datasource": 0}
        last_failure: dict[str, ApiError] = {}

        def work(job):
            kind, row, ctx = job
            oid = row["id"]
            label = "workbook" if kind == "workbook" else "data source"
            scope = f"{label} {_usable_label(row.get('name'), oid)} / file"
            if stopped[kind].is_set() or stopped["all"].is_set():
                with lock:
                    skipped[kind] += 1
                return kind, oid, None
            try:
                blob = self._http.download(self._http.site_path(f"/{kind}s/{oid}/content"), max_bytes=self._limits.max_file_bytes,
                                           params={"includeExtract": "False"}, deadline_s=self._deadline_s)
            except DownloadTooLarge as exc:
                self._issue(scope, f"{exc}; its calculations, parameters and sheet edges are missing from this scan", "dataset", exc.status)
                return kind, oid, None
            except ApiError as exc:
                if exc.status in (403, 404):
                    # A permission or a deleted file is a fact about that one object, not a sign the server is failing: it must not
                    # stop the files after it. The first few are issues of their own; the rest are counted in one.
                    with lock:
                        refused[kind] += 1
                        own = refused[kind] <= MAX_REFUSALS_LISTED
                    if own:
                        self._issue(scope, f"{exc}; its calculations, parameters and sheet edges are missing from this scan", "dataset", exc.status)
                    return kind, oid, None
                self._issue(scope, f"{exc}; its calculations, parameters and sheet edges are missing from this scan", "dataset", exc.status)
                with lock:
                    last_failure[kind] = exc
                    if breakers[kind].failed(exc):
                        stopped[kind].set()
                return kind, oid, None
            except TableauAuthError:
                stopped["all"].set()  # a lost sign-in ends the scan: the other workers stop taking new files
                raise
            except Exception as exc:  # noqa: BLE001 -- whatever a download raises costs that file, never the scan
                self._issue(scope, f"{type(exc).__name__} while downloading the file; its calculations, parameters and sheet edges are missing from this scan", "dataset")
                return kind, oid, None
            with lock:
                breakers[kind].ok()
            try:
                # The room is asked for with the bytes in hand (the cost is read from the archive's directory, at the end of the file) and
                # held until the rows are made: the summary is the big thing, and it is dropped when this block ends.
                with self._budget.hold(parse_cost(blob, self._limits)):
                    summary = read_summary(blob, self._limits)
                    del blob
                    rows = derive_workbook(ctx, summary) if kind == "workbook" else derive_datasource(oid, self._qref(row, "owner"), summary)
                    for item in summary.issues:  # the reader's own: counted per code, never a copy of the file's text
                        self._file_issue(scope, item.code, item.message, item.where)
            except TableauFileError as exc:
                self._issue(scope, f"{exc.code}: {exc}; the file was not read, so its calculations, parameters and sheet edges are missing from this scan", "dataset")
                return kind, oid, None
            except Exception as exc:  # noqa: BLE001 -- a hostile or odd file must cost one file, never the scan
                self._issue(scope, f"{type(exc).__name__} while reading the file; its calculations, parameters and sheet edges are missing from this scan", "dataset")
                return kind, oid, None
            return kind, oid, rows

        pool = ThreadPoolExecutor(max_workers=min(self._download_workers, len(jobs)), thread_name_prefix="tableau-files")
        try:
            results = list(pool.map(work, jobs))
        finally:
            pool.shutdown(wait=True, cancel_futures=True)
        for kind, oid, rows in results:
            if rows is None:
                data.failed.add(oid)
            elif kind == "workbook":
                data.workbooks[oid] = rows
            else:
                data.datasources[oid] = rows
        for kind, label in (("workbook", "workbook"), ("datasource", "data source")):
            if refused[kind] > MAX_REFUSALS_LISTED:
                self._issue(f"{label}s / files", f"{_plural(refused[kind], label + ' file')} could not be downloaded (403 or 404: no permission, or deleted); "
                                                  f"the first {MAX_REFUSALS_LISTED} are listed above, and each one's calculations, parameters and sheet edges are missing from this scan", "dataset", 403)
            if skipped[kind]:
                exc = last_failure.get(kind)
                self._issue(f"{label}s / files", f"Stopped downloading {label} files after repeated failures in a row ({exc}); {_plural(skipped[kind], label)} "
                                                  "not downloaded, so their calculations, parameters and sheet edges are missing from this scan", "dataset",
                            exc.status if exc else None)
        if note := self._budget.note():
            self._issue("workbook files", note, "dataset")
        notes: dict[str, int] = {}
        copies = sum(drop_wrapper_copies(w, data.datasources) for w in data.workbooks.values())
        if copies:
            notes["calculations of workbook data sources that wrap a published source repeat the published source's own and were not stored twice"] = copies
        for rows in (*data.workbooks.values(), *data.datasources.values()):
            for what, n in rows.notes.items():
                notes[what] = notes.get(what, 0) + n
        for what, n in sorted(notes.items()):
            if n:
                self._issue("workbook files", f"{n} {what}", "dataset")
        return data

    def _file_issue(self, scope: str, code: str, message: str, where: str) -> None:
        """One of the reader's findings as a counted issue: per scan and code, not per file, so a site of thousands of workbooks
        cannot write thousands of lines. The text of the first is kept as the example."""
        with self._lock:
            n, first = self._file_findings.get(code, (0, None))
            self._file_findings[code] = (n + 1, first or f"{scope}: {message}" + (f" ({where})" if where else ""))

    def _file_view_kinds(self, workbook_id: str) -> dict[str, str] | None:
        rows = self._files().workbooks.get(workbook_id)
        return rows.kinds if rows else None

    # -- extract refresh tasks ---------------------------------------------------------------------------------

    def _tasks(self) -> dict[str, list[dict]] | None:
        """``{workbook or data source id: [task summaries]}`` from ``GET /tasks/extractRefreshes`` [C R12 for the path;
        U: the JSON shape, ``{"tasks": {"task": [{"extractRefresh": {...}}]}}`` from the XML]. None when the list could not be
        read (an issue says why): "no tasks" and "could not ask" are different facts. Every value is copied through
        ``_plain`` so a hostile answer cannot put a deep or huge structure into the database. ``self._tasks_whole`` says whether the
        list was read whole; a list that was not marks the workbooks and data sources (``extractRefreshTasksRead`` = false)."""
        if self._tasks_read:
            return self._task_index
        self._tasks_read = True
        found = self._read_tasks("/tasks/extractRefreshes", "extractRefresh", ("datasource", "workbook"), "extract refresh tasks",
                                 "dataset", "the refresh schedules are missing from this scan", "workbook or data source")
        self._task_index = found.index if found else None
        self._tasks_whole = bool(found and found.whole)
        return self._task_index

    def _read_tasks(self, suffix: str, wrapper: str, targets: tuple[str, ...], label: str, phase: str, lost: str, target_words: str, *,
                    strict: bool = False, hint403: str | None = None) -> "_Tasks | None":
        """One task list (``{"tasks": {"task": [{<wrapper>: {...}}]}}``) as ``{target id: [summaries]}`` and whether it was read whole (no page
        failed or was cut, and every entry named its target), or None when it could not be read. Of 3 or more entries none of which names a target,
        the answer is probably shaped differently and the list counts as not read whole."""
        try:
            paged = self._http.list_paged(self._http.site_path(suffix), "tasks", "task", page_size=self._page_size, tolerate_page_errors=True,
                                          strict=strict, max_pages=MAX_LIST_PAGES if strict else None, empty_unpaged=True)
        except ApiError as exc:
            self._issue(label, f"{exc}; {lost}", phase, exc.status)
            return None
        self._report_failed_pages(label, paged, phase, lost if strict else None, hint403)
        if paged.truncated_at:
            self._issue(label, f"Listing stopped after {paged.truncated_at} pages (the page cap) while rows were still arriving; the rest are missing from this scan", phase)
        if paged.stopped:
            self._issue(label, f"Listing stopped early: {paged.stopped}; the pages that never answered were not read, so the rest are missing from this scan", phase)
        if paged.failed_pages and not paged.items:
            return None
        whole = not (paged.failed_pages or paged.truncated_at or paged.missing)
        index: dict[str, list[dict]] = {}
        bad = 0
        for row in paged.items:
            task = row.get(wrapper) if isinstance(row, dict) else None
            if not isinstance(task, dict):
                bad += 1
                continue
            target_kind, target = next(((k, t) for k in targets if isinstance((t := task.get(k)), dict) and _usable_id(t.get("id"))), (None, None))
            if target is None:
                bad += 1
                continue
            summary = {"id": self._plain(task.get("id")), "type": self._plain(task.get("type")), "priority": self._plain(task.get("priority")),
                       "consecutiveFailedCount": self._plain(task.get("consecutiveFailedCount")), "schedule": self._plain(task.get("schedule")),
                       "targetKind": target_kind, "targetId": _usable_id(target.get("id"))}
            index.setdefault(summary["targetId"], []).append(summary)
        if bad:
            whole = False
            if len(paged.items) >= MIN_ROWS_FOR_SHAPE_CHECK and bad == len(paged.items):
                self._issue(label, f"none of the {len(paged.items)} tasks names a {target_words} in the way this scan reads it: the answer is probably shaped "
                                   "differently from what this scan reads [U: the JSON rendering of the task list]", phase)
            else:
                self._issue(label, f"{_plural(bad, 'task')} had no {target_words} or were not in the documented shape; skipped", phase)
        return _Tasks(index, whole)

    # -- subscriptions, custom views, flows, refresh history (3.8; documented shape only) -----------------------------

    def _subscriptions(self) -> _Listing:
        return self._list("subscriptions", "/subscriptions", "subscriptions", "subscription", "alert", "subscriptions", strict=True,
                          lost="subscriptions are missing from this scan", max_pages=MAX_LIST_PAGES)

    def _custom_views(self) -> _Listing:
        return self._list("customviews", "/customviews", "customViews", "customView", "card", "custom views", strict=True,
                          lost="custom views are missing from this scan", max_pages=MAX_LIST_PAGES)

    def _flows(self) -> _Listing:
        return self._list("flows", "/flows", "flows", "flow", "dataflow", "flows", strict=True, lost="flows are missing from this scan",
                          max_pages=MAX_LIST_PAGES)

    def _clean(self, text: str, budget: list[int] | None = None) -> str:
        """Free text that is about to be stored (a subject, a name, a status, a raw row's strings), with no credential in it, in the way #103 does it for an
        error: (1) every secret this client holds is replaced where it stands, in every form a server writes it, and if one still shows in a decoded view
        (percent, entities, JSON escapes, base64, hex, three layers, any case or spacing) the whole text is withheld; (2) a secret-looking ``key=value`` is
        redacted by pattern; (3) the result is searched decoded and with disguises undone (zero-width characters, look-alike letters): a pair that shows only
        there cannot be redacted in the form it was written, so the whole text is withheld. Ordinary text is returned as it came.

        The work on a text's decoded views is charged to ``budget`` (the row's, see ``_plain``) and to the scan's ``CLEAN_VIEW_CHARS_PER_SCAN``: a hostile server's
        rows may be made of text that decodes 48 ways, and the search of each costs as much as the text is long."""
        cached = self._cleaned.get(text)
        if cached is not None:
            return cached
        if getattr(self, "_view_chars_left", CLEAN_VIEW_CHARS_PER_SCAN) <= 0 and _DECODABLE.search(text):
            self._note_view_allowance_spent()
            return WITHHELD_SCAN_BUDGET_TEXT
        result = self._clean_once(text) if budget is None else self._clean_once(text, budget)
        if self._cleaned_chars < CLEAN_CACHE_CHARS:
            self._cleaned[text] = result
            self._cleaned_chars += len(text) + len(result)
        return result

    def _note_view_allowance_spent(self) -> None:
        if not getattr(self, "_view_allowance_noted", False):
            self._view_allowance_noted = True
            self._issue("text checks", f"This scan has searched {CLEAN_VIEW_CHARS_PER_SCAN} characters of decoded text (percent-encoded, escaped or base64 text is searched in every "
                                       "decoded form for a credential) and has spent its allowance: text that would need that search from here on is withheld, not stored", "scan")

    def _clean_once(self, text: str, budget: list[int] | None = None) -> str:
        searched = getattr(self._http, "view_chars_searched", 0)
        text, withheld = self._http.scrub_known(text)
        # (the secret search made views of its own, before redact_inline could shorten the text to '***': they are charged as well)
        spent = getattr(self._http, "view_chars_searched", 0) - searched
        if withheld:
            self._charge_views(spent, budget)
            return WITHHELD_TEXT
        text = redact_inline(clean_text(text))
        views = _views(text)
        spent += sum(len(view) for view in views if view != text)
        self._charge_views(spent, budget)
        for view in (views | {fold_for_search(v) for v in views} | {fold_keeping_case(v) for v in views}) - {text}:
            if redact_inline(clean_text(view)) != view:
                return WITHHELD_TEXT
        return text

    def _charge_views(self, spent: int, budget: list[int] | None) -> None:
        self._view_chars_left = getattr(self, "_view_chars_left", CLEAN_VIEW_CHARS_PER_SCAN) - spent  # (threads may lose a count to each other: the budget is a bound, not a ledger)
        if budget is not None:
            budget[0] -= spent

    def _plain(self, value: Any) -> Any:
        """``_plain`` with this client's ``_clean`` on every string."""
        return _plain(value, clean=self._clean)

    def _repeats_credential(self, text: str) -> bool:
        """Whether ``text`` holds a secret this client holds, in any form: one that is replaced where it stands, or one that survives in a decoded view."""
        return self._http.scrub_known(text) != (text, False)  # (a withheld text comes back as ("", True): never equal)

    def _safe_id(self, value: Any) -> str | None:
        """``_usable_id``, and None for an id that repeats a credential (it is a key: it cannot be shown as something else, so the row is not made)."""
        found = _usable_id(value)
        if found is None:
            return None
        return None if self._repeats_credential(found) else found

    def _label(self, value: Any, phase: str) -> str | None:
        """A name for a row: ``_text``, cut to ``MAX_NAME_CHARS`` (a subject or a name is a person's text, and a hostile server's may be megabytes), with no credential in it."""
        return self._text(value, phase, MAX_NAME_CHARS)

    def _status(self, value: Any, phase: str) -> str | None:
        return self._text(value, phase, MAX_STATUS_CHARS)

    def _note_if_not_admin(self, key: str, scope: str, phase: str, sees: str) -> None:
        """One issue per kind, when the signed-in user's own site role says it is not an administrator: what Tableau shows such a user of this list
        is only ``sees`` [U: not read in the documentation; the fake assumes it], so other people's rows are missing from this scan. Nothing is said when the
        role is unknown (a user list this account cannot read), and the user's name is never in the message."""
        if key in self._admin_noted:
            return
        self._admin_noted.add(key)
        admin, role = self._is_site_admin()
        if admin is False:
            self._issue(scope, f"The signed-in user's site role is {_clip(_usable_label(role, ''), 60)}, not a site administrator. Tableau shows such a user "
                               f"{sees} [U], so what other people own is missing from this scan: scan with a site administrator's token to see all of it", phase)

    def fetch_alerts(self) -> Iterator[Alert]:
        """Each subscription as an alert: ``rule`` is the schedule's frequency (Cloud gives it inline) or its name (a Server schedule is an object), the
        owner is the subscriber, and ``watched_by`` runs from the view (a dashboard or a worksheet card) or the workbook (``app``) it sends. A subscription whose
        target this scan did not list keeps its row and has no edge."""
        listing = self._subscriptions()
        rows = listing.items
        if not listing.failed:
            self._note_if_not_admin("subscriptions", "subscriptions", "alert", "only their own subscriptions")
        targets: dict[str, tuple[str, str] | None] = {}
        for row in rows:
            content = row.get("content")
            kind = content.get("type").strip().lower() if isinstance(content, dict) and isinstance(content.get("type"), str) else None
            cid = self._safe_id(content.get("id")) if isinstance(content, dict) else None
            targets[row["id"]] = (kind, cid) if cid is not None and kind in ("view", "workbook", "customview") else None
        # What every subscription should carry and some do not. A field that none of 3 or more rows has is a probable change of shape (one issue for the
        # list); a field some rows lack is counted.
        owners = {r["id"]: self._qref(r, "user") for r in rows}
        rules = {r["id"]: self._rule(r) for r in rows}
        lacks = {"a view or workbook reference": sum(1 for t in targets.values() if t is None), "a subscriber (user)": sum(1 for o in owners.values() if o is None),
                 "a schedule frequency or name": sum(1 for r in rules.values() if r is None)}
        everywhere = [what for what, n in lacks.items() if n and n == len(rows) and len(rows) >= MIN_ROWS_FOR_SHAPE_CHECK]
        if everywhere:
            self._issue("subscriptions", f"none of the {len(rows)} subscriptions has {' or '.join(everywhere)} in the way this scan reads it, so none could be tied "
                                         "to what it needs: the answer is probably shaped differently from what this scan reads [U: the JSON rendering of a "
                                         "subscription]. The rows are stored with those fields empty", "alert")
        for what, n in lacks.items():
            if n and what not in everywhere:
                self._issue("alert rows", f"{_plural(n, 'subscription')} without {what} (stored with the field empty; the raw row is kept)", "alert")
        views = self._view_kind_table() if any(t and t[0] == "view" for t in targets.values()) else {}
        workbooks = {r["id"] for r in self._workbooks().items} if any(t and t[0] == "workbook" for t in targets.values()) else set()
        custom_views = {r["id"] for r in self._custom_views().items} if any(t and t[0] == "customview" for t in targets.values()) else set()
        unlisted = {"view": 0, "workbook": 0, "custom view": 0}

        def make(row: dict) -> Alert:
            target = targets[row["id"]]
            watched = None
            if target and target[0] == "view":
                known = views.get(target[1])
                if known is None:
                    unlisted["view"] += 1
                else:
                    watched = ObjectRef("dashboard" if known[0] in (KIND_DASHBOARD, KIND_STORY) else "card", target[1])
            elif target and target[0] == "workbook":
                if target[1] in workbooks:
                    watched = ObjectRef("app", target[1])
                else:
                    unlisted["workbook"] += 1
            elif target:
                if target[1] in custom_views:
                    watched = ObjectRef("card", target[1])
                else:
                    unlisted["custom view"] += 1
            return Alert(id=row["id"], name=self._label(row.get("subject"), "alert"), owner_id=owners[row["id"]], rule=rules[row["id"]], watched_object=watched,
                         disabled=_flag(row.get("suspended")) is True, raw_payload=self._plain(row))

        yield from self._build(rows, "alert", make)
        lists = {"view": self._views, "workbook": self._workbooks, "custom view": self._custom_views}
        for noun, n in unlisted.items():
            if n:
                why = "" if lists[noun]().complete else f" (the {noun} list was not read completely, so this may not mean it is gone)"
                self._issue("subscriptions", f"{_plural(n, 'subscription')} {'watches' if n == 1 else 'watch'} a {noun} that is not in the {noun} list; "
                                             f"the row is stored without an edge{why}", "alert")

    def _rule(self, row: dict) -> str | None:
        """A subscription's schedule as text: its ``frequency`` (Cloud gives it inline), else its ``name`` (a Server schedule is an object)."""
        schedule = row.get("schedule")
        if not isinstance(schedule, dict):
            return None
        return next((self._label(schedule[k], "alert") for k in ("frequency", "name") if isinstance(schedule.get(k), str) and schedule[k]), None)

    def _custom_view_cards(self) -> Iterator[Card]:
        """Each custom view as a card of type ``custom_view``. It has **no** edge to the view or workbook it was saved from: ``part_of`` would make
        BIMControl count it as a visual of that dashboard. The view and the workbook are in its ``definition``."""
        listing = self._custom_views()
        if listing.failed:
            return
        self._note_if_not_admin("customviews", "custom views", "card", "only the custom views they own or that are shared with them")
        without = [0]

        def make(row: dict) -> Card:
            view, workbook = self._qref(row, "view"), self._qref(row, "workbook")
            if view is None or workbook is None:
                without[0] += 1
            return Card(
                id=row["id"], name=self._label(row.get("name"), "card"), card_type="custom_view", owner_id=self._ref(row, "owner", "card"),
                created_at=_when(row.get("createdAt")), updated_at=_when(row.get("updatedAt")),
                definition={"kind": "custom_view", "viewId": view, "workbookId": workbook, "shared": _flag(row.get("shared")),
                            "lastAccessedAt": self._text(row.get("lastAccessedAt"), "card")},
                raw_payload=self._plain(row))

        yield from self._build(listing.items, "card", make)
        if without[0]:
            self._issue("card rows", f"{_plural(without[0], 'custom view')} without a view or workbook reference (stored with an empty reference; the raw row is kept)", "card")

    # Prep flows

    def _flow_info(self) -> "_FlowData":
        """The flows and, when there are any, their runs and schedules: each asked once, none per flow. Runs and schedules are administrator-only lists
        [C R12, R13], so a token that is not one gets a refusal for each, named in an issue and marked on the flows."""
        if self._flow_data is not None:
            return self._flow_data
        listing = self._flows()
        data = self._flow_data = _FlowData(listing)
        if not listing.items:
            return data
        data.runs, data.runs_complete = self._read_flow_runs({r["id"] for r in listing.items})
        found = self._read_tasks(
            "/tasks/runFlow", "flowRun", ("flow",), "flow run tasks", "dataflow", "the flows' schedules are missing from this scan", "flow", strict=True,
            hint403="Tableau lets only administrators list flow run tasks [C R12]: scan with a site administrator's token to see them.")
        data.tasks = found.index if found else None
        data.tasks_whole = bool(found and found.whole)
        return data

    def _read_flow_runs(self, flow_ids: set[str]) -> tuple[dict[str, list[dict]] | None, bool]:
        """``({flow id: [runs]} or None when the answer could not be read, whether it was read whole)``. One answer, not paged here: the page for it
        documents no paging [C R13], and it is read to at most ``MAX_FLOW_RUNS_BYTES``. An answer that is not ``{"flowRuns": {"flowRun": [...]}}`` is unread, not
        empty. It is not whole when it says more runs exist than arrived (a ``pagination`` block, if one is there), when it was cut at ``MAX_FLOW_RUNS``, or when
        a run cannot be attached for a reason other than "that flow was not listed" (no id, no flow id, not an object): that run may be any flow's. Of 3 or more
        runs none of which names a flow the answer is probably shaped differently."""
        label = "flow runs"
        try:
            body = self._http.get_capped(self._http.site_path("/flows/runs"), max_bytes=MAX_FLOW_RUNS_BYTES)
        except ApiError as exc:  # (DownloadTooLarge is one: the answer was not parsed)
            hint = (" Tableau lets only administrators list flow runs [C R12]: scan with a site administrator's token to see them."
                    if exc.status == 403 else "")
            self._issue(label, f"{exc}; the flows' run history is missing from this scan.{hint}", "dataflow", exc.status)
            return None, False
        rows = _unpaged_rows(body, "flowRuns", "flowRun")
        if rows is None:
            self._issue(label, "The answer was not in the documented shape ({\"flowRuns\": {\"flowRun\": [...]}}) [U: the JSON rendering of Get Flow Runs]; "
                               "the flows' run history is missing from this scan", "dataflow")
            return None, False
        whole = True
        said = _stated_total(body)
        if said is not None and said > len(rows):
            whole = False
            self._issue(label, f"The answer says {said} flow runs exist and holds {len(rows)}; the rest are missing from this scan (the page for this list "
                               "documents no paging [C R13], so whether a second page can be asked for is not known) [U]", "dataflow")
        if len(rows) > MAX_FLOW_RUNS:
            self._issue(label, f"{len(rows)} flow runs were listed and only the first {MAX_FLOW_RUNS} were kept; the flows are marked as not fully read", "dataflow")
            rows, whole = rows[:MAX_FLOW_RUNS], False
        by_flow: dict[str, list[dict]] = {}
        foreign = malformed = 0
        for row in rows:
            rid = self._safe_id(row.get("id")) if isinstance(row, dict) else None
            fid = self._safe_id(row.get("flowId")) if isinstance(row, dict) else None
            if rid is None or fid is None:
                malformed += 1
            elif fid not in flow_ids:
                foreign += 1
            else:
                by_flow.setdefault(fid, []).append({**row, "id": rid})
        if malformed:
            whole = False  # a run with no id or no flow id may belong to any flow
        if malformed and len(rows) >= MIN_ROWS_FOR_SHAPE_CHECK and malformed == len(rows):
            self._issue(label, f"none of the {len(rows)} flow runs names a flow (flowId) in the way this scan reads it: the answer is probably shaped differently from "
                               "what this scan reads [U: the JSON rendering of Get Flow Runs]; no run is stored", "dataflow")
        elif malformed or foreign:
            self._issue(label, f"{_plural(malformed + foreign, 'flow run')} could not be attached to a listed flow (no id, no flow id, a flow this scan did not list, or "
                               "not an object); they are not stored", "dataflow")
        return by_flow, whole

    def fetch_dataflows(self) -> Iterator[Dataflow]:
        """Each Prep flow as a dataflow in its project, with its schedules (``definition.runFlowTasks``) and its runs as ``refreshes``. The runs and the
        schedules are marked unread on the flow's raw row (``flowRunsRead`` / ``flowTasksRead`` = false; the schedules also as ``runFlowTasksRead`` in the definition) when their list could not be read whole."""
        data = self._flow_info()
        if data.listing.failed:
            return
        self._note_if_not_admin("flows", "flows", "dataflow", "only the flows they own")

        def make(row: dict) -> Dataflow:
            fid = row["id"]
            runs = None if data.runs is None else data.runs.get(fid, [])
            refreshes = None if runs is None else [
                Refresh(id=run["id"], status=self._status(run.get("status"), "dataflow"), started_at=_when(run.get("startedAt")),
                        ended_at=_when(run.get("completedAt")), raw_payload=self._plain(run),
                        adopt_placeholder=False) for run in runs]
            newest = max(runs or [], key=lambda r: (_utc(_when(r.get("startedAt"))), str(r["id"])), default=None)
            status = self._status(newest.get("status"), "dataflow") if newest else None
            definition: dict[str, Any] = {"kind": "prep_flow", "graphRead": False, "fileType": self._text(row.get("fileType"), "dataflow"),
                                          "webpageUrl": self._plain(row.get("webpageUrl")), "description": self._label(row.get("description"), "dataflow")}
            raw = self._plain(row)
            if data.tasks is not None:
                definition["runFlowTasks"] = data.tasks.get(fid, [])
            if not data.tasks_whole:
                raw["flowTasksRead"] = False
                definition["runFlowTasksRead"] = False  # (also here, where a consumer of the definition looks: a task list read in part holds fewer tasks than the flow has,
                # and a stored schedule is not resurrected from an earlier scan for it: a task may have been deleted, so what is stored is what this scan read)
            unread_columns: list[str] = []
            only_if_newer = False
            if runs is None or not data.runs_complete:
                raw["flowRunsRead"] = False
                if not runs:  # nothing of this flow was read this scan: an earlier scan's values stay (a flow that has a run now takes this scan's)
                    unread_columns = ["last_execution_state", "last_execution_failed", "modified_at"]
                else:  # some of its runs were read, but a run left out may be newer: this scan's values stand only if they are newer than the stored ones
                    only_if_newer = True
            return Dataflow(
                id=fid, name=self._label(row.get("name"), "dataflow"), engine="prep", owner_id=self._ref(row, "owner", "dataflow"),
                workspace_id=self._ref(row, "project", "dataflow"), created_at=_when(row.get("createdAt")), updated_at=_when(row.get("updatedAt")),
                last_run_state=status, last_run_failed=None if newest is None else status == "Failed",
                last_run_at=(_when(newest.get("completedAt")) or _when(newest.get("startedAt"))) if newest else _when(row.get("updatedAt")),
                definition=definition, refreshes=refreshes, raw_payload=raw, unread_columns=unread_columns, columns_only_if_newer=only_if_newer,
                unread_definition_keys=[] if data.tasks_whole or (data.tasks and data.tasks.get(fid)) else ["runFlowTasks"])

        yield from self._build(data.listing.items, "dataflow", make)

    # Extract refresh history

    def _refresh_history(self) -> "_History":
        """The extract refresh jobs of the site, tied to the workbook or data source each refreshed, read once.

        A list row is ``id, status, createdAt, startedAt, endedAt, priority, jobType`` and names no workbook or data source [C R12], so each job is asked
        about on its own (``GET /jobs/{id}``, whose ``extractRefreshJob`` holds a ``workbook`` or a ``datasource`` [U: the JSON rendering]): the newest
        ``MAX_JOB_DETAILS`` of them, ``PERMISSION_WORKERS`` at a time, with the permission lookups' breaker and counters. How far back the list goes is
        the server's [U]. ``read_whole`` is False whenever a job of this list could not be tied to an object (not listed, refused, cut, unnamed), because
        then any workbook's or data source's history may have a hole."""
        if self._history is not None:
            return self._history
        history = self._history = _History()
        listing = self._list(
            "jobs", "/jobs", "backgroundJobs", "backgroundJob", "dataset", "extract refresh jobs", params={"filter": f"jobType:eq:{EXTRACT_JOB_TYPES[0]}"},
            strict=True, lost="refresh history is missing from this scan", max_pages=MAX_LIST_PAGES,
            hint403="Tableau lets only administrators list background jobs [C R12]: scan with a site administrator's token to see them.")
        lost = not listing.complete or listing.dropped > 0
        # the server was asked for refresh_extracts; one that ignores the filter is filtered here (an unnamed type is kept: the filter was asked)
        jobs = [r for r in listing.items if not (isinstance(r.get("jobType"), str) and r["jobType"] not in EXTRACT_JOB_TYPES)]
        jobs.sort(key=lambda r: (_utc(_when(r.get("createdAt"))), str(r["id"])), reverse=True)
        asked = jobs[:MAX_JOB_DETAILS]
        if len(asked) < len(jobs):
            lost = True
            self._issue("extract refresh jobs", f"Only the newest {len(asked)} of {len(jobs)} extract refresh jobs were asked about (one request each); the other "
                                                f"{len(jobs) - len(asked)} are not stored, so refresh history before them is missing from this scan", "dataset")
        lookups = [_PermissionJob("job", r["id"], r["id"], self._http.site_path(f"/jobs/{r['id']}")) for r in asked]
        read = self._lookup_calls(lookups, "dataset", self._job_state, lambda body: _parse_job(body, self._plain), "job_requests", "job")
        known = {"workbook": {r["id"] for r in self._workbooks().items}, "datasource": {r["id"] for r in self._datasources().items}}
        unnamed = unlisted = 0
        for row in asked:
            answer = read.get(("job", row["id"]))
            if answer is None:
                lost = True  # refused, failed or not asked: said in the job-details issue
            elif answer.target is None:
                unnamed += 1
            elif answer.target[1] not in known[answer.target[0]]:
                unlisted += 1
            else:
                kind, oid = answer.target
                refresh = Refresh(id=row["id"], status=self._status(row.get("status"), "dataset"), refresh_type=self._text(row.get("jobType"), "dataset"),
                                  started_at=_when(row.get("startedAt")), ended_at=_when(row.get("endedAt")), raw_payload=self._plain({**row, "detail": answer.detail}),
                                  adopt_placeholder=False)
                (history.by_workbook if kind == "workbook" else history.by_datasource).setdefault(oid, []).append(refresh)
        if unnamed:
            lost = True
            self._issue("extract refresh jobs", f"{unnamed} of {len(asked)} extract refresh jobs named no workbook or data source in their detail "
                                                "[U: the JSON rendering of Query Job], so they are not stored", "dataset")
        if unlisted:
            self._issue("extract refresh jobs", f"{_plural(unlisted, 'job')} {'names' if unlisted == 1 else 'name'} a workbook or data source that is not in this scan "
                                                f"(deleted, or not visible to this account); {'it is' if unlisted == 1 else 'they are'} not stored", "dataset")
        history.read_whole = not lost
        return history

    # -- permissions (3.7) ----------------------------------------------------------------------------------

    def _is_site_admin(self) -> tuple[bool | None, str | None]:
        """Whether the signed-in user is a site (or server) administrator, from its own row in the user list, and its site role.
        ``(None, None)`` when that row is not there (a user list this account cannot read, or a PAT whose user the list omits)."""
        me = self._http.user_id
        for row in self._users().items:
            if row["id"] == me:
                role = row.get("siteRole")
                if isinstance(role, str) and role:
                    return role.startswith(("SiteAdministrator", "ServerAdministrator")), role
        return None, None

    def _check_admin_once(self, phase: str) -> None:
        """One issue, before the first permission call, if the signed-in user's own site role is not an administrator."""
        if self._admin_checked:
            return
        self._admin_checked = True
        admin, role = self._is_site_admin()
        if admin is False:
            self._issue("permissions", f"The signed-in user's site role is {_clip(_usable_label(role, ''), 60)}, not a site administrator. Tableau lets only administrators list "
                                       "a workbook's or project's permissions [C R10], so expect grants to be missing from this scan; what could not "
                                       "be read is counted below by kind", phase)

    def _permission_calls(self, jobs: list["_PermissionJob"], phase: str) -> dict[tuple[str, str], Parsed]:
        """Ask for every permission list in ``jobs`` and return ``{(kind, object id): the grants}`` for the lists that were read (see
        ``_lookup_calls`` for what is counted, stopped and reported). Called once per chunk of objects (``_read_in_chunks``).

        The request count is the number of jobs, one GET each, none paged [U: a permission list is not documented to be]; it is
        counted in ``permission_requests``."""
        st = self._perm

        def pooled(job: "_PermissionJob", parsed: Parsed) -> None:  # under the lock
            if job.kind in POOLED_KINDS:
                st.pool_lists += 1
                st.pool_grants += bool(parsed.grants)
                st.pool_unknown += bool(parsed.unknown_shape or parsed.bad_grantees)
                st.last_phase = phase

        def counted(job: "_PermissionJob", parsed: Parsed) -> None:
            if parsed.bad_grantees:
                self._bad(phase, f"permission entries that are not a user or group with capabilities ({job.kind})")
            if parsed.bad_capabilities:
                self._bad(phase, f"capabilities without a name or with a mode other than Allow or Deny ({job.kind})")
            if parsed.dropped_capabilities:
                self._bad(phase, f"capabilities beyond the {MAX_CAPABILITIES} kept for one grantee ({job.kind})")

        def parse(body: Any) -> Parsed | None:
            parsed = parse_permissions(body)
            return parsed if parsed.shape_ok else None

        return self._lookup_calls(jobs, phase, st, parse, "permission_requests", "permission list", locked=pooled, unlocked=counted)

    def _lookup_calls(self, jobs: list["_PermissionJob"], phase: str, st: "_PermState", parse: Callable[[Any], Any], counter: str, not_a: str, *,
                      locked: Callable[[Any, Any], None] | None = None, unlocked: Callable[[Any, Any], None] | None = None) -> dict[tuple[str, str], Any]:
        """Ask for every GET in ``jobs`` with ``PERMISSION_WORKERS`` threads and return ``{(kind, key): parse(its answer)}`` for the ones that were read
        (``parse`` returns None for an answer that is not the shape it expects: ``not_a`` names it). What it learns accumulates in ``st`` and is turned
        into issues by ``_lookup_issues`` at ``take_issues``, so an interrupted phase still reports what it had seen; ``counter`` names the attribute
        that counts the requests.

        Nothing is dropped quietly: per kind, the calls that were refused or failed are counted in one issue that names the kind, the reason
        and the first few objects. A kind stops being asked when its calls keep failing in a row (``_Breaker``: a server that is down or
        throttling). A refusal (403) is a fact about one object, and a token that is not an administrator may still read some (a dashboard or
        data source it has Read on), so refusals alone stop a kind only when not one call of that kind has been read and ``MAX_ALL_REFUSED``
        have been refused. ``locked`` runs under the state's lock for each answer read, ``unlocked`` right after it."""
        read: dict[tuple[str, str], Any] = {}
        if not jobs:
            return read
        lock = st.lock
        for job in jobs:
            st.total[job.kind] = st.total.get(job.kind, 0) + 1
            st.breakers.setdefault(job.kind, _Breaker())
            st.phases.setdefault(job.kind, phase)

        def fail(job: "_PermissionJob", reason: str, status: int | None) -> None:
            with lock:
                st.failures.setdefault((job.kind, reason, status), []).append(job.name)

        def work(job: "_PermissionJob") -> None:
            if st.signed_out.is_set():
                return  # the scan is ending; the one worker that lost the sign-in raises it
            if job.kind in st.stopped:
                with lock:
                    st.skipped[job.kind] = st.skipped.get(job.kind, 0) + 1
                return
            with lock:
                setattr(self, counter, getattr(self, counter) + 1)
            try:
                body = self._http.get(job.path)
            except ApiError as exc:
                fail(job, f"HTTP {exc.status}" if exc.status else "no answer", exc.status)
                with lock:
                    st.last[job.kind] = exc
                    if exc.status is not None and 400 <= exc.status < 500 and exc.status not in (401, 408, 429):
                        # A refusal, or a request this object cannot be answered (404, 400 ...): a fact about it, not about the server. An
                        # object may be gone between the listing and the call, and a token may read some objects and not others.
                        st.refusals[job.kind] = st.refusals.get(job.kind, 0) + 1
                        if not st.successes.get(job.kind) and st.refusals[job.kind] >= MAX_ALL_REFUSED:
                            st.stopped.add(job.kind)
                    elif st.breakers[job.kind].failed(exc):
                        st.stopped.add(job.kind)
                return
            except TableauAuthError:
                st.signed_out.set()  # a lost sign-in ends the scan: the other workers stop taking new lookups
                raise
            except Exception as exc:  # noqa: BLE001 -- whatever one call raises costs that object's answer, never the scan
                fail(job, f"{type(exc).__name__} while asking", None)
                with lock:
                    st.last[job.kind] = ApiError(f"{type(exc).__name__} while asking")
                    if st.breakers[job.kind].failed(st.last[job.kind]):  # the same call failing the same way for every object is a fault, not 5,000 facts
                        st.stopped.add(job.kind)
                return
            parsed = parse(body)
            if parsed is None:
                fail(job, f"the answer was not a {not_a}", None)
                with lock:
                    st.last[job.kind] = ApiError(f"the answer was not a {not_a}")
                    if st.breakers[job.kind].failed(st.last[job.kind]):  # a server that answers every call with something else is not worth 5,000 more
                        st.stopped.add(job.kind)
                return
            with lock:
                st.breakers[job.kind].ok()
                st.successes[job.kind] = st.successes.get(job.kind, 0) + 1
                if locked:
                    locked(job, parsed)
                read[(job.kind, job.key)] = parsed
            if unlocked:
                unlocked(job, parsed)

        pool = ThreadPoolExecutor(max_workers=min(PERMISSION_WORKERS, len(jobs)), thread_name_prefix="tableau-lookups")
        try:
            list(pool.map(work, jobs))
        finally:
            pool.shutdown(wait=True, cancel_futures=True)
        return read

    def _lookup_issues(self, st: "_PermState", w: "_Wording") -> list[ScanIssue]:
        """The issues for the lookups asked about since the last call, one per kind and reason, and the state cleared. ``w`` is the wording."""
        with st.lock:
            failures, st.failures = st.failures, {}
            skipped, st.skipped = st.skipped, {}
            total, st.total = st.total, {}
            last = dict(st.last)
            refused = dict(st.refusals)
            phases = dict(st.phases)
        out: list[ScanIssue] = []
        for (kind, reason, status), names in sorted(failures.items(), key=lambda item: (item[0][0], item[0][1])):
            names = sorted(names)  # the threads finish in any order; the issue should read the same on every scan
            shown = ", ".join(self._clean(_clip(n)) for n in names[:MAX_NAMES_LISTED]) + (f" and {len(names) - MAX_NAMES_LISTED} more" if len(names) > MAX_NAMES_LISTED else "")
            why = w.why403 if status == 403 else ""
            out.append(ScanIssue(scope=w.scope(kind), phase=phases[kind], status=status, message=(
                f"{len(names)} of {total[kind]} {w.noun(kind)}: {w.could_not} ({reason}), {w.lost}.{why} First: {shown}")))
        for kind, n in sorted(skipped.items()):
            exc = last.get(kind)
            if exc is not None and exc.status is not None and 400 <= exc.status < 500 and refused.get(kind, 0) >= MAX_ALL_REFUSED:
                cause = f"the first {refused[kind]} {w.asked} were all refused or rejected and none could be read ({exc})"
            else:
                cause = f"repeated failures in a row ({exc})"
            out.append(ScanIssue(scope=w.scope(kind), phase=phases[kind], status=exc.status if exc else None, message=(
                f"Stopped asking after {cause}; {n} of {total[kind]} {w.noun(kind)} were not asked, {w.lost}")))
        return out

    def _permission_issues(self) -> list[ScanIssue]:
        """The issues for the permission lists asked about since the last call, and the pooled shape check."""
        st = self._perm
        with st.lock:
            check_shape = not st.shape_reported and st.pool_lists >= MIN_LISTS_FOR_SHAPE_CHECK and not st.pool_grants and st.pool_unknown > 0
            st.shape_reported = st.shape_reported or check_shape
            pooled, shape_phase = st.pool_lists, st.last_phase
        out = self._lookup_issues(st, _PERMISSION_WORDING)
        if check_shape:
            out.append(ScanIssue(scope="permissions", phase=shape_phase, message=(
                f"{pooled} permission lists of projects, workbooks and data sources were read and none named a grantee, and at least one answer "
                "was not shaped the way this scan reads it: either nobody is granted anything on them or the answer is shaped differently than "
                "this scan reads it [U: the JSON rendering of a permission list]. No has_role edges were made for them")))
        return out

    def _job_issues(self) -> list[ScanIssue]:
        return self._lookup_issues(self._job_state, _JOB_WORDING)

    def _read_in_chunks(self, rows: list[dict], jobs_of: Callable[[dict], list["_PermissionJob"]], phase: str, size: int = PERMISSION_CHUNK
                        ) -> Iterator[tuple[dict, dict[tuple[str, str], Parsed]]]:
        """``(row, the lists read for its chunk)`` for each row, asking ``size`` rows' permission lists at a time. The rows of a chunk are
        yielded (and so written) before the next chunk is asked: an interrupted phase keeps what had been written, and the progress a
        scan reports moves while the lists are read instead of standing still for all of them."""
        self._check_admin_once(phase)
        for start in range(0, len(rows), size):
            chunk = rows[start:start + size]
            read = self._permission_calls([job for row in chunk for job in jobs_of(row)], phase)
            for row in chunk:
                yield row, read

    def _job(self, kind: str, row: dict) -> "_PermissionJob":
        collection = {"project": "projects", "workbook": "workbooks", "datasource": "datasources", "view": "views"}[kind]
        return _PermissionJob(kind, row["id"], _usable_label(row.get("name"), row["id"]), self._http.site_path(f"/{collection}/{row['id']}/permissions"))

    def _jobs_for(self, kind: str) -> Callable[[dict], list["_PermissionJob"]]:
        """The permission job for one object of ``kind``. A view's needs REST 3.2; on an older server none is made (once, in an issue) and the
        dashboards are marked as not read."""
        if kind == "view" and not self._http.supports("3.2"):
            self._issue("dashboards / permissions", "This server's REST version is older than 3.2, which is the first to list a view's permissions; "
                                                    "dashboard grants are missing from this scan", "dashboard")
            return lambda row: []
        return lambda row: [self._job(kind, row)]

    @staticmethod
    def _holders_of(kind: str, row: dict, read: dict[tuple[str, str], Parsed]) -> tuple[list[RoleAssignment], dict]:
        """``(who holds what on this object, the marker for its row)``. The marker is ``{"permissionsRead": False}`` when its list was not
        read (refused, failed, never asked, or read with an entry or a capability left out) and ``{}`` when it was read whole: an object nobody holds a grant on and an object whose list we could
        not see are different facts, and the first must not look like the second."""
        parsed = read.get((kind, row["id"]))
        if parsed is None:
            return [], {"permissionsRead": False}
        partial = parsed.bad_grantees or parsed.bad_capabilities or parsed.dropped_capabilities  # an entry or a capability was left out: not fully read
        return [RoleAssignment(target=ObjectRef(g.grantee_type, g.grantee_id), role=template_name(kind, g.capabilities), capabilities=dict(g.capabilities))
                for g in parsed.grants], ({"permissionsRead": False} if partial else {})

    # -- progress ------------------------------------------------------------------

    def estimate_total(self, object_type: str) -> int | None:
        """The count the phase should yield, for the progress bar: the REST listing's ``totalAvailable`` when it
        gave one, else the rows received. None where it cannot be known (a listing that failed outright, connections that
        could not all be read, or a type this adapter does not scan). Called right before the phase, so what it reads is
        cached for the phase itself."""
        if object_type == "workspace":
            return self._projects().estimate
        if object_type == "user":
            return self._users().estimate
        if object_type == "group":
            return self._groups().estimate
        if object_type == "app":
            return self._workbooks().estimate
        if object_type == "dataset":
            published = self._datasources().estimate
            if not self._read_files or published is None:
                return published
            files = self._files()
            return None if files.failed else published + sum(len(r.datasets) for r in files.workbooks.values())
        if object_type == "calculated_field":
            if not self._read_files:
                return None
            files = self._files()
            if files.failed:
                return None
            return sum(len(r.calculated_fields) for r in (*files.workbooks.values(), *files.datasources.values()))
        if object_type == "account":
            read = self._read_connections()
            return len(read["accounts"]) if read["complete"] else None
        if object_type in ("dashboard", "card"):
            views = self._views()
            if views.failed:
                return None
            kinds = [kind for kind, _ in self._view_kind_table().values()]
            if object_type == "dashboard":
                return sum(1 for kind in kinds if kind in (KIND_DASHBOARD, KIND_STORY))
            worksheets = sum(1 for kind in kinds if kind not in (KIND_DASHBOARD, KIND_STORY))
            custom = self._custom_views().estimate  # the custom views are cards too
            files = self._files() if self._read_files else None  # and so is a worksheet that only the workbook file has
            if files is not None and files.failed & {w["id"] for w in self._workbooks().items}:  # a workbook file that failed: its worksheets are unknown, not none
                return None
            from_files = sum(len(r.file_cards) for r in files.workbooks.values()) if files is not None else 0
            return None if custom is None else worksheets + custom + from_files
        if object_type == "alert":
            return self._subscriptions().estimate
        if object_type == "dataflow":
            return self._flows().estimate
        return None

    # -- phases --------------------------------------------------------------------

    def fetch_workspaces(self) -> Iterator[Workspace]:
        rows = self._projects().items
        self._check_owners("projects", rows, "project", "workspace")
        parents = self._project_parents(rows)
        odd = sum(1 for r in rows if isinstance(r.get("contentPermissions"), str) and r["contentPermissions"] and r["contentPermissions"] not in LOCK_MODES)
        if odd:
            self._issue("projects", f"{_plural(odd, 'project')} gave a permission lock mode other than {', '.join(LOCK_MODES)}; it is kept as given", "workspace")

        def jobs_of(row: dict) -> list[_PermissionJob]:
            # the project's own list, and what it hands to new content (three GETs): flows are asked for although a site may have no Prep
            name = _usable_label(row.get("name"), row["id"])
            return [self._job("project", row), *(_PermissionJob(f"default:{t}", row["id"], name, self._http.site_path(
                f"/projects/{row['id']}/default-permissions/{t}")) for t in DEFAULT_TYPES)]

        def make(row: dict, read: dict) -> Workspace:
            """The lock mode is the row's own ``contentPermissions`` [C R11]; ``defaults`` holds the content types that were read (absent = unknown,
            an empty list = none)."""
            holders, marker = self._holders_of("project", row, read)
            mode = row.get("contentPermissions")
            defaults = {t: [g.as_json(t) for g in read[(f"default:{t}", row["id"])].grants] for t in DEFAULT_TYPES if (f"default:{t}", row["id"]) in read}
            return Workspace(
                id=row["id"], name=self._text(row.get("name"), "workspace"), workspace_type="project", owner_id=self._ref(row, "owner", "workspace"),
                created_at=_when(row.get("createdAt")), updated_at=_when(row.get("updatedAt")),
                workspace_id=parents.get(row["id"]), role_holders=holders,
                raw_payload={**row, **marker, "permissionSettings": {"lockMode": mode if isinstance(mode, str) and mode else None, "defaults": defaults}},
            )

        for row, read in self._read_in_chunks(rows, jobs_of, "workspace", size=PERMISSION_CHUNK // 4):
            yield from self._build([row], "workspace", lambda r, read=read: make(r, read))

    def fetch_users(self) -> Iterator[User]:
        memberships = self._group_memberships()

        def make(row: dict) -> User:
            name = self._text(row.get("name"), "user")
            # Cloud names a user by e-mail address; a Server user may have only a login name [U: the list does not
            # always carry ``email``], and then there is no address to give.
            email = self._text(row.get("email"), "user") or (name if name and "@" in name else None)
            return User(id=row["id"], name=name, email=email, role=self._text(row.get("siteRole"), "user"),
                        group_ids=list(memberships.get(row["id"], [])), raw_payload=row)

        yield from self._build(self._users().items, "user", make)

    def fetch_groups(self) -> Iterator[Group]:
        yield from self._build(self._groups().items, "group", lambda row: Group(id=row["id"], name=self._text(row.get("name"), "group"), raw_payload=row))

    def fetch_accounts(self) -> Iterator[Account]:
        yield from self._read_connections()["accounts"].values()

    def fetch_datasets(self) -> Iterator[Dataset]:
        connections = self._read_connections()["by_datasource"]
        rows = self._datasources().items
        self._check_owners("datasources", rows, "data source", "dataset")
        files = self._files()
        tasks = self._tasks() if self._read_files else None
        history = self._refresh_history()

        def make(row: dict, read_lists: dict) -> Dataset:
            holders, marker = self._holders_of("datasource", row, read_lists)
            definition = {"kind": "published", "hasExtracts": _flag(row.get("hasExtracts")), "isCertified": _flag(row.get("isCertified")),
                          "contentUrl": self._text(row.get("contentUrl"), "dataset")}
            dataset = Dataset(
                id=row["id"], name=self._text(row.get("name"), "dataset"), provider_type=self._text(row.get("type"), "dataset"),
                owner_id=self._ref(row, "owner", "dataset"), workspace_id=self._ref(row, "project", "dataset"),
                created_at=_when(row.get("createdAt")), updated_at=_when(row.get("updatedAt")),
                account_ids=list(connections.get(row["id"], [])), role_holders=holders, definition=definition,
                refreshes=list(history.by_datasource.get(row["id"], [])), raw_payload={**row, **marker, **history.marker},
            )
            read = files.datasources.get(row["id"])
            if read is not None:  # the file was read: the columns, the filters and the row-level security evidence are known
                dataset.schema_columns, dataset.column_count = read.schema_columns, len(read.schema_columns or [])
                dataset.pdp_policies = read.pdp_policies
                definition.update(read.definition)
                definition["file"] = read.file_meta
            if tasks is not None:
                definition["extractRefreshTasks"] = tasks.get(row["id"], [])
            if tasks is not None and not self._tasks_whole:
                dataset.raw_payload["extractRefreshTasksRead"] = False
            return dataset

        jobs_of = self._jobs_for("datasource")
        for row, read_lists in self._read_in_chunks(rows, jobs_of, "dataset"):
            yield from self._build([row], "dataset", lambda r, read_lists=read_lists: make(r, read_lists))
        for workbook in self._workbooks().items:  # embedded data sources exist only inside a workbook file
            read = files.workbooks.get(workbook["id"])
            for dataset in (read.datasets if read else []):
                if tasks is not None:
                    dataset.definition["extractRefreshTasks"] = tasks.get(workbook["id"], []) if dataset.definition.get("hasExtracts") else []
                    if not self._tasks_whole:
                        dataset.raw_payload["extractRefreshTasksRead"] = False
                yield dataset

    def fetch_calculated_fields(self) -> Iterator[CalculatedField]:
        """Calculations and parameters of every file read. Without files (``read_files=False``) there is nothing to read from."""
        if not self._read_files:
            raise NotImplementedError  # raised at the call, not on first iteration: the orchestrator skips the phase on it
        return self._calculated_fields()

    def _calculated_fields(self) -> Iterator[CalculatedField]:
        files = self._files()
        for workbook in self._workbooks().items:
            read = files.workbooks.get(workbook["id"])
            yield from (read.calculated_fields if read else [])
        for source in self._datasources().items:
            read = files.datasources.get(source["id"])
            yield from (read.calculated_fields if read else [])

    def fetch_apps(self) -> Iterator[App]:
        rows = self._workbooks().items
        self._check_owners("workbooks", rows, "workbook", "app")
        files = self._files()
        tasks = self._tasks() if self._read_files else None
        history = self._refresh_history()

        def make(row: dict, read_lists: dict) -> App:
            holders, marker = self._holders_of("workbook", row, read_lists)
            dashboards = self._dashboards_of(row["id"])
            ids = [d["id"] for d in dashboards]
            default_view = _usable_id(row.get("defaultViewId"))  # [U: the field may be absent, or name a sheet]
            read = files.workbooks.get(row["id"])
            extra = {**marker, **history.marker}
            if read is not None:
                extra["file"] = read.file_meta
            if tasks is not None:
                extra["extractRefreshTasks"] = tasks.get(row["id"], [])
                if not self._tasks_whole:
                    extra["extractRefreshTasksRead"] = False
            return App(
                id=row["id"], name=self._text(row.get("name"), "app"), app_type="workbook", owner_id=self._ref(row, "owner", "app"),
                workspace_id=self._ref(row, "project", "app"), created_at=_when(row.get("createdAt")), updated_at=_when(row.get("updatedAt")),
                landing_dashboard_id=default_view if default_view in ids else None, role_holders=holders,
                views=[AppView(view_id=d["id"], title=self._text(d.get("name"), "app"), view_order=i) for i, d in enumerate(dashboards, 1)],
                refreshes=list(history.by_workbook.get(row["id"], [])), raw_payload={**row, **extra},
            )

        for row, read_lists in self._read_in_chunks(rows, self._jobs_for("workbook"), "app"):
            yield from self._build([row], "app", lambda r, read_lists=read_lists: make(r, read_lists))

    def fetch_dashboards(self) -> Iterator[Dashboard]:
        rows = [(kind, row) for kind, row in self._view_kind_table().values() if kind in (KIND_DASHBOARD, KIND_STORY)]
        kinds = {row["id"]: kind for kind, row in rows}
        files = self._files()
        found = {vid: info for read in files.workbooks.values() for vid, info in read.dashboards.items()}

        def make(row: dict, read_lists: dict) -> Dashboard:
            holders, marker = self._holders_of("view", row, read_lists)
            info = found.get(row["id"], {})
            return Dashboard(
                id=row["id"], name=self._text(row.get("name"), "dashboard"), owner_id=self._ref(row, "owner", "dashboard"),
                created_at=_when(row.get("createdAt")), updated_at=_when(row.get("updatedAt")),
                card_ids=list(info.get("card_ids", [])), dataset_ids=list(info.get("dataset_ids", [])), filters=list(info.get("filters", [])),
                layout=info.get("layout"), role_holders=holders, raw_payload={**row, **marker, "dashboardType": kinds[row["id"]]})

        for row, read_lists in self._read_in_chunks([row for _, row in rows], self._jobs_for("view"), "dashboard"):
            yield from self._build([row], "dashboard", lambda r, read_lists=read_lists: make(r, read_lists))

    def fetch_cards(self) -> Iterator[Card]:
        rows = [(kind, row) for kind, row in self._view_kind_table().values() if kind not in (KIND_DASHBOARD, KIND_STORY)]
        kinds = {row["id"]: kind for kind, row in rows}
        files = self._files()
        found = {vid: info for read in files.workbooks.values() for vid, info in read.cards.items()}

        def make(row: dict) -> Card:
            info = found.get(row["id"])
            # The mark type, the data sources and the shelves are in the workbook file, not in REST: without it (or for a view the
            # file does not hold) the card is the bare REST row.
            return Card(
                id=row["id"], name=self._text(row.get("name"), "card"), card_type=info["card_type"] if info else None,
                owner_id=self._ref(row, "owner", "card"), created_at=_when(row.get("createdAt")), updated_at=_when(row.get("updatedAt")),
                dataset_ids=list(info["dataset_ids"]) if info else [],
                definition=info["definition"] if info else {"workbook_id": self._ref(row, "workbook", "card"), "kind_known": kinds[row["id"]] is not None},
                raw_payload=row)

        yield from self._build([row for _, row in rows], "card", make)
        yield from self._file_only_cards(files)
        yield from self._custom_view_cards()

    def _file_only_cards(self, files: "_FileData") -> Iterator[Card]:
        """A worksheet the workbook file holds and the REST view list does not (used only on a dashboard, hidden, or not visible to this account) is a card
        with the id ``<workbook id>:<sheet name>`` and ``definition.source = "workbook file"``. The dashboards that hold it list it in ``card_ids``."""
        pending = [{"id": cid, "workbook": workbook, "info": info}
                   for workbook in self._workbooks().items for cid, info in (files.workbooks[workbook["id"]].file_cards.items() if workbook["id"] in files.workbooks else [])]

        def make(item: dict) -> Card:
            workbook, info = item["workbook"], item["info"]
            return Card(
                id=item["id"], name=self._text(info["name"], "card"), card_type=info["card_type"], owner_id=self._ref(workbook, "owner", "card"),
                created_at=_when(workbook.get("createdAt")), updated_at=_when(workbook.get("updatedAt")), dataset_ids=list(info["dataset_ids"]),
                definition=info["definition"], raw_payload={"source": "workbook file", "workbookId": workbook["id"]})

        yield from self._build(pending, "card", make)


@dataclass
class _PermissionJob:
    """One permission list to ask for: ``kind`` is the object kind (``default:workbooks`` for a project's default permissions for that
    content type), ``key`` its id, ``name`` what the issue calls it."""

    kind: str
    key: str
    name: str
    path: str


@dataclass
class _PermState:
    """What the permission calls have learned, per job kind, since the issues were last taken (see ``TableauClient._permission_issues``)."""

    lock: threading.Lock = field(default_factory=threading.Lock)
    signed_out: threading.Event = field(default_factory=threading.Event)
    breakers: dict[str, _Breaker] = field(default_factory=dict)
    stopped: set[str] = field(default_factory=set)
    total: dict[str, int] = field(default_factory=dict)
    failures: dict[tuple[str, str, int | None], list[str]] = field(default_factory=dict)
    skipped: dict[str, int] = field(default_factory=dict)
    last: dict[str, ApiError] = field(default_factory=dict)
    successes: dict[str, int] = field(default_factory=dict)
    refusals: dict[str, int] = field(default_factory=dict)
    pool_lists: int = 0  # lists read of POOLED_KINDS, all phases, since the client was made
    pool_grants: int = 0  # of those, how many held a grantee
    pool_unknown: int = 0  # of those, how many had a shape this reader does not know
    shape_reported: bool = False
    last_phase: str = "user"
    phases: dict[str, str] = field(default_factory=dict)


def _clip(text: str, limit: int = 80) -> str:
    """A name for an issue's text: a hostile or merely long name does not get to make a long line."""
    return text if len(text) <= limit else text[:limit - 1] + "\u2026"


# What each job kind is called in an issue (plural: "N of M workbooks").
_PERMISSION_LABELS = {"project": "projects", "workbook": "workbooks", "datasource": "data sources", "view": "dashboards",
                      **{f"default:{t}": f"projects' default permissions for {t}" for t in DEFAULT_TYPES}}


@dataclass(frozen=True)
class _Wording:
    """What an issue about one family of per-object lookups says (``TableauClient._lookup_issues``): the scope and the counted noun per kind, what
    could not be read, what that leaves out of the scan, what the lookups are called, and why a refusal is to be expected."""

    scope: Callable[[str], str]
    noun: Callable[[str], str]
    could_not: str
    lost: str
    asked: str
    why403: str


_PERMISSION_WORDING = _Wording(
    scope=lambda kind: f"{_PERMISSION_LABELS[kind]} / permissions", noun=lambda kind: _PERMISSION_LABELS[kind],
    could_not="the permission list could not be read", lost="so their grants are missing from this scan", asked="lists asked",
    why403=(" Tableau lets only site administrators list these (a user with Read on a dashboard or data source may list theirs) "
            "[C R10]: scan with a site administrator's token to see them."))
_JOB_WORDING = _Wording(
    scope=lambda kind: "job details", noun=lambda kind: "job details",
    could_not="the job's detail could not be read", lost="so which workbook or data source each one refreshed is unknown and it is not stored from this scan",
    asked="job details asked",
    why403=" Tableau lets only administrators ask about a job [C R12]: scan with a site administrator's token to see them.")


@dataclass
class _Tasks:
    """A task list as read: ``{target id: [summaries]}``, and whether it was read whole."""

    index: dict[str, list[dict]]
    whole: bool


@dataclass
class _FlowData:
    """The flows and what was read about them (``TableauClient._flow_info``). ``runs`` / ``tasks`` are None when their list could not be read."""

    listing: _Listing
    runs: dict[str, list[dict]] | None = None
    runs_complete: bool = True  # False when the runs were cut at ``MAX_FLOW_RUNS``
    tasks: dict[str, list[dict]] | None = None
    tasks_whole: bool = False  # False when the schedules were not read, or read with a page failed or cut, or an entry that named no flow


@dataclass
class _History:
    """Extract refresh jobs tied to what they refreshed (``TableauClient._refresh_history``). ``read_whole`` is False when a job could not be tied to
    an object: any workbook's or data source's history may then have a hole, which its raw row says (``refreshJobsRead`` = false)."""

    by_workbook: dict[str, list[Refresh]] = field(default_factory=dict)
    by_datasource: dict[str, list[Refresh]] = field(default_factory=dict)
    read_whole: bool = False

    @property
    def marker(self) -> dict:
        return {} if self.read_whole else {"refreshJobsRead": False}


@dataclass
class _JobAnswer:
    """One ``GET /jobs/{id}`` answer: the (kind, id) of the workbook or data source it names, or None, and the job object, bounded for storage."""

    target: tuple[str, str] | None
    detail: Any


def _parse_job(body: Any, plain: Callable[[Any], Any]) -> _JobAnswer | None:
    """``{"job": {..., "extractRefreshJob": {"workbook" | "datasource": {"id"}}}}`` [U: the JSON rendering of Query Job; the XML is documented]. None when the
    answer holds no ``job`` object (not the shape); an answer with a job that names nothing is a ``_JobAnswer`` with no target."""
    job = body.get("job") if isinstance(body, dict) else None
    if not isinstance(job, dict):
        return None
    inner = job.get("extractRefreshJob")
    target = None
    if isinstance(inner, dict):
        for kind in ("datasource", "workbook"):
            ref = inner.get(kind)
            oid = _usable_id(ref.get("id")) if isinstance(ref, dict) else None
            if oid is not None:
                target = (kind, oid)
                break
    return _JobAnswer(target, plain(job))


def _unpaged_rows(body: Any, collection: str, item: str) -> list | None:
    """The rows of an answer that is ``{collection: {item: [...]}}`` and not paged, or None if it is not that shape. A collection that is empty (``{}``)
    is no rows; a missing collection, a collection that is not an object, or one that holds anything but ``item`` is not the shape."""
    if not isinstance(body, dict):
        return None
    group = body.get(collection)
    if not isinstance(group, dict):
        return None
    if not group:
        return []
    rows = group.get(item)
    if isinstance(rows, dict):  # a one-row collection is not always rendered as a list [U]
        rows = [rows]
    return rows if isinstance(rows, list) else None


def _stated_total(body: Any) -> int | None:
    """``pagination.totalAvailable`` of an answer as a count, when it has one that is a whole number of at least 0; anything else is no statement."""
    pagination = body.get("pagination") if isinstance(body, dict) else None
    value = pagination.get("totalAvailable") if isinstance(pagination, dict) else None
    if isinstance(value, bool) or not isinstance(value, (int, str)):
        return None
    try:
        total = int(value)
    except ValueError:
        return None
    return total if total >= 0 else None


def _utc(when: _dt.datetime | None) -> _dt.datetime:
    """``when`` as an aware time, for sorting: a missing one is the oldest, a naive one is taken as UTC (an aware and a naive time cannot be compared)."""
    if when is None:
        return _dt.datetime.min.replace(tzinfo=_dt.timezone.utc)
    return when if when.tzinfo else when.replace(tzinfo=_dt.timezone.utc)


@dataclass
class _FileData:
    """What the downloaded files gave, by workbook / data source id. ``failed`` holds the ids of files that could not be
    downloaded or read: what they would have added is unknown, not zero (the estimates say so)."""

    workbooks: dict[str, WorkbookRows] = field(default_factory=dict)
    datasources: dict[str, DatasourceRows] = field(default_factory=dict)
    failed: set[str] = field(default_factory=set)


_PLAIN_DEPTH = 6
_PLAIN_NODES = 200
_PLAIN_TEXT = 500


def _plain(value: Any, _depth: int = 0, _budget: list[int] | None = None, clean: Callable[[str], str] | None = None, _chars: list[int] | None = None) -> Any:
    """A copy of a JSON value that is safe to store: scalars, lists and dicts only, nested at most ``_PLAIN_DEPTH`` deep, at most
    ``_PLAIN_NODES`` values in all, text cut to ``_PLAIN_TEXT`` characters. What is beyond a bound is dropped, not raised: the answer
    is a server's, and a hostile one may be as deep or as wide as it likes."""
    budget = _budget if _budget is not None else [_PLAIN_NODES]
    chars = _chars if _chars is not None else [CLEAN_CHARS_PER_ROW]
    budget[0] -= 1
    if budget[0] < 0 or _depth > _PLAIN_DEPTH:
        return None
    if isinstance(value, str):
        text = value if _encodable(value) else value.encode("utf-8", "replace").decode("utf-8")
        text = text[:_PLAIN_TEXT]
        chars[0] -= len(text)
        if chars[0] < 0:
            return WITHHELD_BUDGET_TEXT  # the row has more text than is searched in full
        return clean(text, chars) if clean else redact_inline(clean_text(text))
    if isinstance(value, (bool, int, float)) or value is None:
        return value
    if isinstance(value, list):
        return [_plain(v, _depth + 1, budget, clean, chars) for v in value[:50]]
    if isinstance(value, dict):
        # A value under a secret-looking key name is dropped whatever it looks like (the key rule of scrub.py), not only by pattern.
        return {(clean(str(k)[:100]) if clean else str(k)[:100]): ("***" if is_secret_name(str(k)) else _plain(v, _depth + 1, budget, clean, chars))
                for k, v in list(value.items())[:50]}
    return None


def _usable_label(name: Any, fallback: str) -> str:
    """A name for an issue's scope: the text if it is text, else the id (a dict name must not make a message of its repr)."""
    if isinstance(name, str) and name:
        return name if _encodable(name) else name.encode("utf-8", "replace").decode("utf-8")  # a lone surrogate would fail the insert of the issue
    return fallback

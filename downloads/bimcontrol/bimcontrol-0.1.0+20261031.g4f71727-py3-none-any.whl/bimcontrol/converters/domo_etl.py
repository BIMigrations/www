"""Client for the Domo Magic ETL converter.

That service turns a Domo dataflow's tile graph into Amazon Redshift SQL.
It runs as a local process (`localhost:8822` by default), pulls dataflows
live from Domo by numeric id using a browser session, and has no
authentication of its own -- it relies on binding to localhost.

The division of labour matters. The converter **translates**; it does not
move data. When a dataflow input is a manual upload with no warehouse
copy, the converter can only emit `__TODO_TABLE__`. BIMControl lands that
data (see pipelines/data_plan.py) and then tells the converter where it
went through `POST /api/resolutions`. This client is that conversation.

Two things about the service shape the code here:

- **Resolutions are global to the service, not per dataflow.** They are
  keyed by Domo dataSourceId alone, so setting one affects every flow
  that reads that dataset. Fine while one migration runs at a time;
  something to revisit when a swarm shares a converter.
- **Its SQL cache does not notice a resolution change.** After setting
  resolutions you must regenerate with `force=true` or you get the
  previous answer back, placeholders and all.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

import requests

DEFAULT_BASE_URL = "http://localhost:8822"
# The service takes a `waitSeconds` on long calls and hands back a job if
# it runs over; 50 is its documented ceiling.
MAX_INLINE_WAIT = 50
REQUEST_TIMEOUT = 120


class ConverterError(Exception):
    pass


class ConverterUnavailable(ConverterError):
    """The service is not running, or not reachable on this host."""


class ConverterSessionError(ConverterError):
    """The converter has no usable Domo session."""


@dataclass
class OutputScript:
    """One output dataset's SQL: a chain of CTEs ending in a SELECT."""

    cte_name: str
    destination_name: str
    sql: str
    data_source_id: str | None = None


@dataclass
class ConversionResult:
    dataflow_id: int
    outputs: list[OutputScript] = field(default_factory=list)
    unsupported_tile_types: list[str] = field(default_factory=list)
    tile_warnings: dict[str, list[str]] = field(default_factory=dict)
    unresolved_sources: list[dict[str, Any]] = field(default_factory=list)
    cached: bool = False


class DomoEtlConverterClient:
    def __init__(self, base_url: str = DEFAULT_BASE_URL, timeout: int = REQUEST_TIMEOUT):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        # What the service already has, so a batch of dataflows sharing the
        # same inputs sends each location once rather than once per dataflow
        # (152 POSTs, about 85 s, before each 2 s conversion).
        self._known_resolutions: dict[str, str] | None = None
        self._resend: set[str] = set()
        self.http = requests.Session()

    # ---- plumbing -------------------------------------------------------

    def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        url = f"{self.base_url}{path}"
        kwargs.setdefault("timeout", self.timeout)  # a caller may need longer
        try:
            response = self.http.request(method, url, **kwargs)
        except requests.ConnectionError as exc:
            raise ConverterUnavailable(
                f"No Domo ETL converter at {self.base_url}. Start it with:\n"
                "  dotnet run --project src/DomoEtlConverter.Cli -- "
                "--port 8822 --domo-instance <instance>"
            ) from exc

        if response.status_code == 401:
            raise ConverterSessionError(
                "The converter's Domo session has expired. Sign it in again."
            )
        if response.status_code >= 400:
            raise ConverterError(f"{method} {path} -> {response.status_code}: {response.text[:300]}")
        if not response.content:
            return None
        try:
            return response.json()
        except ValueError:
            return response.text

    # ---- health and session ---------------------------------------------

    def status(self) -> dict[str, Any]:
        return self._request("GET", "/api/auth/status")

    def health(self) -> dict[str, Any]:
        """For the Converters screen: is it up, and can it reach Domo."""
        try:
            status = self.status()
        except ConverterError as exc:
            return {"ok": False, "base_url": self.base_url, "error": str(exc)}
        return {
            "ok": status.get("status") == "Ready",
            "base_url": self.base_url,
            "instance": status.get("instance"),
            "status": status.get("status"),
            "error": status.get("error"),
        }

    def sign_in_with_cookies(self, cookies: dict[str, str]) -> dict[str, Any]:
        """Hand the converter the same Domo session BIMControl is using."""
        payload = {
            "cookies": [{"name": name, "value": value} for name, value in cookies.items()],
            "resumePausedRuns": False,
        }
        return self._request("POST", "/api/auth/session", json=payload)

    # ---- dataflows ------------------------------------------------------

    def get_dataflow(self, dataflow_id: int | str, view: str = "summary") -> dict[str, Any]:
        return self._request("GET", f"/api/dataflows/{dataflow_id}", params={"view": view})

    def detect_source(self, data_source_id: str) -> dict[str, Any]:
        return self._request("GET", f"/api/datasources/{data_source_id}/detect-source")

    def list_resolutions(self) -> dict[str, Any]:
        return self._request("GET", "/api/resolutions") or {}

    def set_resolution(self, data_source_id: str, resolved_table: str, note: str | None = None) -> Any:
        return self._request(
            "POST", "/api/resolutions",
            json={"dataSourceId": data_source_id, "resolvedTable": resolved_table, "note": note or ""},
        )

    def resend_resolutions(self, data_source_ids: set[str]) -> None:
        """Send these inputs' locations again with the next conversion, though the service already has them.

        Setting a resolution is what makes the service read the table's columns again; a table landed anew has a
        column the service's cached schema lacks (the row-order column, bimcontrol#361), and the ranking of Remove
        Duplicates only sees it through that schema."""
        self._resend |= set(data_source_ids)

    def generate_sql(self, dataflow_id: int | str, force: bool = False) -> dict[str, Any]:
        """Generate the SQL, waiting out the job if it takes one.

        `force` is not optional after changing resolutions: the service
        caches per dataflow and will otherwise hand back the previous
        answer with its placeholders still in it.
        """
        result = self._request(
            "GET", f"/api/dataflows/{dataflow_id}/sql",
            params={"force": str(bool(force)).lower(), "async": "true"},
        )
        if isinstance(result, dict) and result.get("jobId"):
            result = self.wait_for_job(result["jobId"])
        return result or {}

    def final_sql(self, dataflow_id: int | str) -> list[OutputScript]:
        payload = self._request("GET", f"/api/dataflows/{dataflow_id}/final-sql") or []
        return [
            OutputScript(
                cte_name=item.get("cteName"),
                destination_name=item.get("destinationName"),
                sql=item.get("sql") or "",
                data_source_id=item.get("dataSourceId"),
            )
            for item in payload
        ]

    def tile_status(self, dataflow_id: int | str) -> dict[str, Any]:
        return self._request("GET", f"/api/dataflows/{dataflow_id}/tile-status") or {}

    # ---- repair ---------------------------------------------------------

    def tile_action_ids(self, dataflow_id: int | str) -> dict[str, str]:
        """The last 8 characters of each tile's id -> the id, the key the CTE names carry
        (`tile_expressionevaluator_4af070bc`)."""
        flow = self._request("GET", f"/api/dataflows/{dataflow_id}") or {}
        return {str(a["id"])[-8:]: a["id"] for a in flow.get("actions") or [] if a.get("id")}

    def fix_tile(self, dataflow_id: int | str, action_id: str, max_seconds: int = 600) -> dict[str, Any]:
        """Run the converter's single-tile `Fix with AI` and wait for it. The fix is kept by the
        converter, so the next `convert` returns it."""
        started = self._request("POST", f"/api/dataflows/{dataflow_id}/tiles/{action_id}/fix-with-ai")
        run_id = (started or {}).get("runId")
        if not run_id:
            raise ConverterError(f"fix-with-ai on {action_id} returned no run id")
        deadline = time.monotonic() + max_seconds
        while True:
            status = self._request(
                "GET", f"/api/dataflows/{dataflow_id}/auto-convert/{run_id}/status",
                params={"afterSeq": 0, "waitSeconds": 30}, timeout=60,
            ) or {}
            if status.get("status") in ("Completed", "Failed", "Cancelled"):
                return {"status": status.get("status"), "resolved": bool(status.get("resolved")),
                        "error": status.get("error")}
            if time.monotonic() > deadline:
                raise ConverterError(f"fix-with-ai on {action_id} did not finish in {max_seconds} s")

    # ---- jobs -----------------------------------------------------------

    def wait_for_job(self, job_id: str, poll_seconds: int = MAX_INLINE_WAIT) -> Any:
        """Long-poll a job to completion.

        The service holds the request open for up to `waitSeconds`, so this
        loops rather than sleeping: each call is a wait, not a poll.
        """
        while True:
            job = self._request(
                "GET", f"/api/jobs/{job_id}",
                params={"waitSeconds": min(poll_seconds, 60)},
                timeout=min(poll_seconds, 60) + 30,
            )
            status = (job or {}).get("status")
            if status == "Succeeded":
                return job.get("result")
            if status in ("Failed", "Cancelled"):
                raise ConverterError(
                    f"Converter job {job_id} {status.lower()}: {job.get('error') or 'no detail given'}"
                )
            time.sleep(0.5)

    # ---- the whole conversation ------------------------------------------

    def convert(
        self,
        dataflow_id: int | str,
        resolutions: dict[str, str] | None = None,
        force: bool = True,
        on_progress=None,
    ) -> ConversionResult:
        """Set resolutions, regenerate, and collect the output SQL."""
        def say(message: str) -> None:
            if on_progress:
                on_progress(message)

        if resolutions and self._known_resolutions is None:
            try:
                self._known_resolutions = {
                    key: value for key, value in self.list_resolutions().items()
                    if isinstance(value, str)
                }
            except ConverterError:
                self._known_resolutions = {}
        for data_source_id, table in (resolutions or {}).items():
            if (self._known_resolutions or {}).get(data_source_id) == table and data_source_id not in self._resend:
                continue
            self.set_resolution(data_source_id, table, note="landed by BIMControl")
            self._resend.discard(data_source_id)
            if self._known_resolutions is not None:
                self._known_resolutions[data_source_id] = table
        if resolutions:
            say(f"told the converter where {len(resolutions)} input(s) live")

        generated = self.generate_sql(dataflow_id, force=force)
        tiles = generated.get("tiles") or []
        unsupported = generated.get("unsupportedTileTypes") or []
        say(f"generated SQL for {len(tiles)} tile(s)")

        tile_warnings = {
            tile.get("cteName") or tile.get("actionId"): tile.get("warnings") or []
            for tile in tiles
            if tile.get("warnings")
        }
        outputs = self.final_sql(dataflow_id)

        # A placeholder means an input the converter had nowhere to read
        # from. Better caught here than by Redshift at run time.
        unresolved = [
            {"cte_name": tile.get("cteName"), "data_source_id": tile.get("dataSourceId"),
             "name": tile.get("name")}
            for tile in tiles
            if "__TODO_TABLE__" in (tile.get("sql") or "")
        ]

        return ConversionResult(
            dataflow_id=int(dataflow_id),
            outputs=outputs,
            unsupported_tile_types=unsupported,
            tile_warnings=tile_warnings,
            unresolved_sources=unresolved,
            cached=bool(generated.get("cached")),
        )

import React from 'react';

// Customer batch controls (bimcontrol#255): choose which dashboards a batch
// takes, see them cheapest first before anything runs, start the batch, and
// stop it.
//
// Stop is a request, not a kill: "Stop after this dashboard" lets the one in
// flight finish; "Stop now" also cancels it at its next stage, and the next
// batch resumes it. The batch runs inside this app, so closing the app ends
// it; the dashboard it was on is resumed by the next start.

// One value per line: a dashboard name may hold a comma.
export function linesOf(text) {
  return String(text || '').split('\n').map(function (l) { return l.trim(); }).filter(Boolean);
}

export function manifestFromForm(form) {
  return {
    customer: String(form.customer || '').trim(),
    include: {
      name_suffixes: linesOf(form.suffixes), name_prefixes: linesOf(form.prefixes),
      name_contains: linesOf(form.contains), name_regexes: linesOf(form.regexes), ids: linesOf(form.ids),
    },
    exclude: { names: linesOf(form.excludeNames), ids: linesOf(form.excludeIds) },
  };
}

export function formFromManifest(manifest, customer) {
  const include = (manifest && manifest.include) || {};
  const exclude = (manifest && manifest.exclude) || {};
  const join = function (list) { return (list || []).join('\n'); };
  return {
    customer: (manifest && manifest.customer) || customer || '',
    suffixes: join(include.name_suffixes), prefixes: join(include.name_prefixes), contains: join(include.name_contains),
    regexes: join(include.name_regexes), ids: join(include.ids),
    excludeNames: join(exclude.names), excludeIds: join(exclude.ids),
  };
}

const FIELDS = [
  { key: 'suffixes', label: 'Name ends with', hint: '-SW' },
  { key: 'prefixes', label: 'Name starts with', hint: 'Acme' },
  { key: 'contains', label: 'Name contains', hint: '' },
  { key: 'regexes', label: 'Name matches (regular expression)', hint: 'SW\\s*$' },
  { key: 'ids', label: 'Dashboard ids', hint: '' },
  { key: 'excludeNames', label: 'Leave out these names', hint: '' },
  { key: 'excludeIds', label: 'Leave out these ids', hint: '' },
];

const boxStyle = {
  width: '100%', boxSizing: 'border-box', padding: '6px 8px', resize: 'vertical',
  border: '1px solid var(--border-hairline)', borderRadius: 'var(--radius-card)',
  background: 'var(--surface-card)', color: 'var(--text-primary)',
  fontFamily: 'var(--font-mono)', fontSize: 'var(--text-sm)',
};

const labelStyle = { fontSize: 'var(--text-xs)', color: 'var(--text-secondary)', display: 'block', marginBottom: 4 };

// The form: manifest fields, options, a preview of what they select, and Start.
export function NewBatchForm({ initial, customer, slot, running, onStarted }) {
  const [form, setForm] = React.useState(formFromManifest(initial, customer));
  const [options, setOptions] = React.useState({ limit: '', rerun_unproven: false, retry_failed: true, force: false });
  const [preview, setPreview] = React.useState(null);
  const [busy, setBusy] = React.useState(false);
  const [error, setError] = React.useState(null);

  // Filled from the saved manifest when it arrives, and again for another customer; never over what is being typed.
  const edited = React.useRef(false);
  React.useEffect(function () { edited.current = false; }, [slot]);
  React.useEffect(function () {
    if (edited.current) return;
    setForm(formFromManifest(initial, customer));
    setPreview(null);
  }, [slot, initial && initial.customer]);

  function set(key, value) {
    edited.current = true;
    setForm(function (prev) { return Object.assign({}, prev, { [key]: value }); });
    setPreview(null);
  }

  function run(promise, then) {
    setBusy(true);
    setError(null);
    promise.then(function (body) { setBusy(false); then(body); },
      function (e) { setBusy(false); setError(e.message); });
  }

  const manifest = manifestFromForm(form);
  const limit = options.limit === '' ? null : parseInt(options.limit, 10);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-5)' }}>
      <div style={{ maxWidth: 360 }}>
        <label style={labelStyle}>Customer</label>
        <Input size="sm" value={form.customer} placeholder="Acme"
          onChange={function (e) { set('customer', e.target.value); }} />
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: 'var(--space-5)' }}>
        {FIELDS.map(function (f) {
          return (
            <div key={f.key}>
              <label style={labelStyle}>{f.label}</label>
              <textarea rows={2} style={boxStyle} placeholder={f.hint} value={form[f.key]}
                onChange={function (e) { set(f.key, e.target.value); }} />
            </div>
          );
        })}
      </div>
      <div style={{ fontSize: 'var(--text-xs)', color: 'var(--text-tertiary)' }}>
        One value per line. A dashboard is taken when any "starts with / ends with / contains / matches / id" line fits and no "leave out" line does.
      </div>

      <div style={{ display: 'flex', gap: 'var(--space-7)', alignItems: 'center', flexWrap: 'wrap', fontSize: 'var(--text-sm)' }}>
        <label>Start at most{' '}
          <input type="number" min="1" style={Object.assign({}, boxStyle, { width: 70, resize: 'none' })} value={options.limit}
            onChange={function (e) { setOptions(function (prev) { return Object.assign({}, prev, { limit: e.target.value }); }); }} /> dashboards</label>
        <label><input type="checkbox" checked={options.rerun_unproven}
          onChange={function (e) { setOptions(function (prev) { return Object.assign({}, prev, { rerun_unproven: e.target.checked }); }); }} />
          {' '}Run again those that finished but are not proven</label>
        <label><input type="checkbox" checked={options.retry_failed}
          onChange={function (e) { setOptions(function (prev) { return Object.assign({}, prev, { retry_failed: e.target.checked }); }); }} />
          {' '}Resume failed ones</label>
        <label><input type="checkbox" checked={options.force}
          onChange={function (e) { setOptions(function (prev) { return Object.assign({}, prev, { force: e.target.checked }); }); }} />
          {' '}Run proven ones again too</label>
      </div>

      <ErrorBanner error={error} title="Could not do that" />

      <div style={{ display: 'flex', gap: 'var(--space-5)', alignItems: 'center' }}>
        <Button size="sm" variant="secondary" loading={busy} disabled={!form.customer.trim()}
          onClick={function () { run(previewBatch(manifest), setPreview); }}>Preview the dashboards</Button>
        <Button size="sm" variant="accent" disabled={busy || running || !form.customer.trim()}
          onClick={function () {
            run(startBatch(manifest, { limit: limit, rerun_unproven: options.rerun_unproven, retry_failed: options.retry_failed, force: options.force }),
              function (batch) { onStarted(batch); });
          }}>Start the batch</Button>
        {running ? <span style={{ fontSize: 'var(--text-sm)', color: 'var(--text-tertiary)' }}>A batch of this customer is already running.</span> : null}
      </div>

      {preview ? <PreviewList preview={preview} /> : null}
    </div>
  );
}

function PreviewList({ preview }) {
  const rows = preview.dashboards || [];
  return (
    <div style={{ border: '1px solid var(--border-hairline)', borderRadius: 'var(--radius-card)', background: 'var(--surface-card)', maxHeight: 260, overflow: 'auto' }}>
      <div style={{ padding: '8px 12px', fontSize: 'var(--text-sm)', borderBottom: '1px solid var(--border-hairline)' }}>
        <span className="bit-num">{formatCount(preview.total)}</span> dashboards, cheapest first (fewest dataflows, then fewest rows to land)
      </div>
      {rows.map(function (d) {
        return (
          <div key={d.id} style={{ display: 'flex', gap: 12, padding: '4px 12px', fontSize: 'var(--text-sm)' }}>
            <span style={{ flex: 1 }}>{d.name || d.id}</span>
            <span className="bit-num" style={{ color: 'var(--text-tertiary)' }}>
              {formatCount(d.cards)} cards · {formatCount(d.dataflows)} dataflows · {formatCount(d.source_rows)} rows
            </span>
          </div>
        );
      })}
    </div>
  );
}

// Progress of the batch started from this screen, and its Stop buttons.
export function BatchStatus({ batch, name, onChange }) {
  const [error, setError] = React.useState(null);
  const [busy, setBusy] = React.useState(false);
  if (!batch) return null;

  function stop(now) {
    setBusy(true);
    setError(null);
    stopBatch(name, now).then(function () { setBusy(false); onChange(); },
      function (e) { setBusy(false); setError(e.message); onChange(); });      // 409: it had ended; show how
  }

  const current = batch.current;
  const log = batch.log || [];
  return (
    <div style={{ border: '1px solid var(--border-hairline)', borderRadius: 'var(--radius-card)', background: 'var(--surface-card)', padding: '10px 14px', display: 'flex', flexDirection: 'column', gap: 8 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
        {batch.running
          ? <Badge tone="warn" dot>{batch.stopping ? 'Stopping' : 'Running'}</Badge>
          : <Badge tone="neutral" dot>Ended</Badge>}
        <span style={{ fontSize: 'var(--text-sm)' }}>
          {batch.running
            ? (current ? <span>{current.name || current.id} <span className="bit-num" style={{ color: 'var(--text-tertiary)' }}>
              ({formatCount(batch.started)} started of {formatCount(batch.dashboards)} selected)</span></span> : (batch.dashboards === null ? 'Reading the dashboards of the manifest' : 'Starting'))
            : (batch.result || '')}
        </span>
        <div style={{ flex: 1 }} />
        {batch.running ? (
          <span style={{ display: 'inline-flex', gap: 8 }}>
            <Button size="sm" variant="secondary" disabled={busy || batch.stopping} onClick={function () { stop(false); }}>Stop after this dashboard</Button>
            <Button size="sm" variant="secondary" disabled={busy} onClick={function () { stop(true); }}>Stop now</Button>
          </span>
        ) : null}
      </div>
      <ErrorBanner error={error} title="Could not stop the batch" />
      {log.length ? (
        <details>
          <summary style={{ cursor: 'pointer', fontSize: 'var(--text-xs)', color: 'var(--text-secondary)' }}>Last {log.length} lines</summary>
          <pre className="bit-num" style={{ margin: '6px 0 0', fontSize: 'var(--text-xs)', whiteSpace: 'pre-wrap', maxHeight: 200, overflow: 'auto' }}>{log.join('\n')}</pre>
        </details>
      ) : null}
    </div>
  );
}

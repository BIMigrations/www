import React from 'react';

// Mirrors the backend's per-object-type sortable-column allow-list in
// webapp/routes/estate.py -- a column not listed here is display-only, so
// its header shouldn't claim to be clickable. Filtering happens inside
// DataGrid itself, against whatever page of rows is currently loaded.
const COLUMNS = {
  dataset: [
    { key: 'name', header: 'Name', sortable: true, filterable: true },
    { key: 'provider_type', header: 'Provider', muted: true, sortable: true, filterable: true },
    { key: 'policy_count', header: 'Row-level policy', sortable: true, width: 150, render: function (r) { return policyCountLabel(r.policy_count); } },
    { key: 'row_count', header: 'Rows', mono: true, align: 'right', sortable: true, filterable: true, width: 100 },
    { key: 'column_count', header: 'Cols', mono: true, align: 'right', sortable: true, filterable: true, width: 90 },
    { key: 'downstream_card_count', header: 'Downstream cards', mono: true, align: 'right', sortable: true, filterable: true, width: 150 },
  ],
  dataflow: [
    { key: 'name', header: 'Name', sortable: true, filterable: true },
    { key: 'engine', header: 'Engine', muted: true, sortable: true, filterable: true },
    { key: 'num_inputs', header: 'In', mono: true, align: 'right', sortable: true, filterable: true, width: 70 },
    { key: 'num_outputs', header: 'Out', mono: true, align: 'right', sortable: true, filterable: true, width: 70 },
    { key: 'last_execution_state', header: 'Last run', muted: true, sortable: true, filterable: true },
  ],
  card: [
    { key: 'name', header: 'Name', sortable: true, filterable: true },
    { key: 'type', header: 'Type', muted: true, sortable: true, filterable: true },
    { key: 'dataset_id', header: 'Primary dataset', mono: true, muted: true, sortable: true, filterable: true },
  ],
  dashboard: [
    { key: 'name', header: 'Name', sortable: true, filterable: true },
    { key: 'parent_dashboard_id', header: 'Parent', mono: true, muted: true, sortable: true, filterable: true },
  ],
  calculated_field: [
    { key: 'name', header: 'Name', sortable: true, filterable: true },
    { key: 'formula_language', header: 'Language', muted: true, sortable: true, filterable: true },
    { key: 'status', header: 'Status', muted: true, sortable: true, filterable: true },
  ],
  user: [
    { key: 'name', header: 'Name', sortable: true, filterable: true },
    { key: 'email', header: 'Email', mono: true, sortable: true, filterable: true },
    { key: 'role', header: 'Role', muted: true, sortable: true, filterable: true },
  ],
  group: [{ key: 'name', header: 'Name', sortable: true, filterable: true }],
  account: [
    { key: 'name', header: 'Name', sortable: true, filterable: true },
    { key: 'connector_type', header: 'Connector', muted: true, sortable: true, filterable: true },
  ],
  alert: [
    { key: 'name', header: 'Name', sortable: true, filterable: true },
    { key: 'resource_type', header: 'Watches', muted: true, sortable: true, filterable: true },
    { key: 'disabled', header: 'Disabled', sortable: true, render: function (r) { return r.disabled ? 'yes' : 'no'; } },
  ],
  app: [
    { key: 'name', header: 'Name', sortable: true, filterable: true },
    { key: 'type', header: 'Type', muted: true, sortable: true, filterable: true },
  ],
  workspace: [
    { key: 'name', header: 'Name', sortable: true, filterable: true },
    { key: 'type', header: 'Type', muted: true, sortable: true, filterable: true },
    { key: 'state', header: 'State', muted: true, sortable: true, filterable: true },
    { key: 'capacity_id', header: 'Capacity', mono: true, muted: true, sortable: true, filterable: true },
  ],
  gateway: [
    { key: 'name', header: 'Name', sortable: true, filterable: true },
    { key: 'type', header: 'Type', muted: true, sortable: true, filterable: true },
    { key: 'status', header: 'Status', muted: true, sortable: true, filterable: true },
    { key: 'machine', header: 'Machine', mono: true, muted: true, sortable: true, filterable: true },
    { key: 'version', header: 'Version', mono: true, muted: true, sortable: true, filterable: true },
  ],
};

const PAGE_SIZE = 50;
const HIDDEN_DETAIL_KEYS = ['upstream', 'downstream', 'access', 'holds', 'refreshes', 'name', 'policies', 'policy_status', 'not_seen_in_latest_scan'];
const POLICY_FILTERS = [
  { value: '', label: 'Any row-level policy' },
  { value: 'any', label: 'With a policy' },
  { value: 'none', label: 'No policy' },
  { value: 'not_captured', label: 'Policy not captured' },
];
const POLICIES_SHOWN = 25;

// null = the scan did not capture policies for this dataset, 0 = the platform answered with none.
function policyCountLabel(count) {
  if (count === null || count === undefined) return <span style={{ color: 'var(--text-tertiary)' }}>not captured</span>;
  if (count === 0) return 'none';
  return String(count);
}

function describeAppliesTo(a) {
  if (a.kind === 'member') return a.label;
  const label = a.name || a.id;
  return a.kind === 'user' ? label : a.kind === 'group' ? 'group ' + label : a.kind.replace('_', ' ') + ' ' + label;
}

// One block per policy: who it applies to (only what the scan stored) and the filters it puts on the rows.
export function PolicyList({ detail }) {
  const [all, setAll] = React.useState(false);
  if (detail.policy_status === 'not_captured') {
    return (
      <div>
        <div className="bit-eyebrow" style={{ marginBottom: 8 }}>Row-level policies</div>
        <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-tertiary)' }}>Not captured by the scan, so unknown (this is not the same as none).</div>
      </div>
    );
  }
  if (detail.policy_status === 'none') {
    return (
      <div>
        <div className="bit-eyebrow" style={{ marginBottom: 8 }}>Row-level policies</div>
        <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-tertiary)' }}>None: the platform reported no policies on this dataset.</div>
      </div>
    );
  }
  const shown = all ? detail.policies : detail.policies.slice(0, POLICIES_SHOWN);
  return (
    <div>
      <div className="bit-eyebrow" style={{ marginBottom: 8 }}>Row-level policies ({detail.policies.length})</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {shown.map(function (p, i) {
          const items = [
            { label: 'Applies to', value: p.applies_to.length ? p.applies_to.map(describeAppliesTo).join(', ') : 'not stated in the scan' },
            { label: 'Filters', mono: true, value: p.filters.length ? p.filters.map(function (f, j) { return <div key={j}>{f}</div>; }) : 'none stored' },
          ];
          if (p.access) items.splice(1, 0, { label: 'Access', value: p.access });
          return (
            <div key={i} style={{ border: '1px solid var(--border-hairline)', borderRadius: 'var(--radius-md)', padding: 10 }}>
              <div style={{ fontWeight: 'var(--weight-semibold)', marginBottom: 6 }}>{p.name || '(unnamed policy)'}</div>
              <KeyValueList labelWidth={84} items={items} />
            </div>
          );
        })}
      </div>
      {!all && detail.policies.length > POLICIES_SHOWN && (
        <div style={{ marginTop: 8 }}>
          <Button size="sm" variant="secondary" onClick={function () { setAll(true); }}>Show all {detail.policies.length}</Button>
        </div>
      )}
    </div>
  );
}

// The column that says which objects the newest completed scan of their instance did not return.
const NOT_SEEN_COLUMN = {
  key: 'not_seen_in_latest_scan', header: 'Latest scan', width: 150, muted: true,
  render: function (r) { return r.not_seen_in_latest_scan ? 'not seen' : ''; },
};

export function DetailBlobs({ detail }) {
  // pdp_json is shown as PolicyList when the scan could read it; raw only when it could not be read as a list.
  const jsonKeys = Object.keys(detail).filter(function (k) {
    return k.endsWith('_json') && detail[k] != null && !(k === 'pdp_json' && detail.policy_status === 'policies');
  });
  if (jsonKeys.length === 0) return null;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      {jsonKeys.map(function (k) {
        return (
          <div key={k}>
            <div className="bit-eyebrow" style={{ marginBottom: 8 }}>{humanizeFieldKey(k)}</div>
            <CodeBlock code={prettyJson(detail[k])} language="json" maxHeight={220} />
          </div>
        );
      })}
    </div>
  );
}

export function EstateScreen({ onGoToScan, scope }) {
  const [summary, setSummary] = React.useState(null);
  const [activeType, setActiveType] = React.useState('dataset');
  const [page, setPage] = React.useState(1);
  const [sort, setSort] = React.useState(null);
  const [query, setQuery] = React.useState('');
  const [policy, setPolicy] = React.useState('');
  const [listing, setListing] = React.useState(null);
  const [selected, setSelected] = React.useState(null);
  const [detail, setDetail] = React.useState(null);
  const [onlyNotSeen, setOnlyNotSeen] = React.useState(false);
  const scopeKey = scope ? scope.platform + '|' + scope.instance : '';

  React.useEffect(function () {
    setPage(1); setSelected(null); setOnlyNotSeen(false);
    fetchEstateSummary(scope).then(setSummary);
  }, [scopeKey]); // eslint-disable-line

  React.useEffect(function () {
    fetchEstateObjects(activeType, {
      page, page_size: PAGE_SIZE,
      sort: sort ? sort.key : undefined, dir: sort ? sort.dir : undefined,
      q: query || undefined, not_seen: onlyNotSeen || undefined,
      policy: activeType === 'dataset' ? policy || undefined : undefined,
    }, scope).then(setListing);
  }, [activeType, page, sort, query, policy, onlyNotSeen, scopeKey]); // eslint-disable-line

  React.useEffect(function () {
    if (!selected) { setDetail(null); return; }
    // the row's own instance, so an id two instances share opens the object that was clicked
    fetchEstateObject(activeType, selected.id, { platform: selected.platform, instance: selected.instance }).then(setDetail);
  }, [activeType, selected]);

  function selectType(type) {
    setActiveType(type);
    setPolicy('');
    setPage(1);
    setSort(null);
    setSelected(null);
    setOnlyNotSeen(false);
  }

  function onSort(key) {
    setSort(function (prev) {
      if (!prev || prev.key !== key) return { key, dir: 'asc' };
      return { key, dir: prev.dir === 'asc' ? 'desc' : 'asc' };
    });
  }

  const totalObjects = summary ? Object.values(summary.counts).reduce(function (a, b) { return a + b; }, 0) : null;

  if (summary && totalObjects === 0) {
    return (
      <EmptyState
        tone="source" headline="No estate" accent="yet."
        body="Connect a platform and run a scan to inventory it."
        action={<Button variant="accent" onClick={onGoToScan}>Go to Scan</Button>}
      />
    );
  }

  const notSeenTotal = listing ? listing.not_seen_total : 0;
  const baseColumns = COLUMNS[activeType] || [{ key: 'name', header: 'Name' }];
  const columns = notSeenTotal > 0 ? baseColumns.concat([NOT_SEEN_COLUMN]) : baseColumns;
  const shown = summary ? summary.instances.filter(function (i) { return i.selected; }) : [];

  return (
    <div style={{ display: 'flex', height: '100%' }}>
      <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
        <div style={{ padding: '20px 24px 0', minWidth: 0 }}>
          <div style={{ fontSize: 'var(--text-3xl)', fontWeight: 'var(--weight-semibold)', letterSpacing: 'var(--tracking-heading)', marginBottom: 14 }}>Estate</div>
          {shown.length > 0 && summary.instances.length > 1 && (
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-xs)', color: 'var(--text-tertiary)', margin: '-8px 0 12px' }}>
              {shown.map(function (i) { return i.platform + ' · ' + i.instance; }).join(', ')}
            </div>
          )}
          <div style={{ overflowX: 'auto', overflowY: 'hidden', minWidth: 0 }}>
            <Tabs
              value={activeType}
              onChange={selectType}
              tabs={getObjectTypes().map(function (t) {
                return { value: t.value, label: t.label, count: summary ? summary.counts[t.value] : undefined };
              })}
            />
          </div>
        </div>

        <div style={{ padding: '14px 24px', display: 'flex', gap: 8 }}>
          <div style={{ width: 260 }}>
            <Input
              placeholder={'Search ' + (columns[0].header || 'name').toLowerCase() + '…'}
              value={query} iconLeft={<Icon name="search" size={14} />}
              onChange={function (e) { setPage(1); setQuery(e.target.value); }} />
          </div>
          {activeType === 'dataset' && (
            <Select value={policy} onChange={function (e) { setPage(1); setPolicy(e.target.value); }} options={POLICY_FILTERS} />
          )}
          {listing && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-xs)', color: 'var(--text-tertiary)', alignSelf: 'center' }}>
            {listing.total.toLocaleString()} total
          </span>}
          {notSeenTotal > 0 && (
            <div style={{ alignSelf: 'center', marginLeft: 8 }}>
              <Checkbox
                checked={onlyNotSeen}
                onChange={function (e) { setPage(1); setOnlyNotSeen(e.target.checked); }}
                label={'Only the ' + notSeenTotal.toLocaleString() + ' not seen in the latest scan'}
              />
            </div>
          )}
        </div>

        <div style={{ flex: 1, minHeight: 0, overflow: 'hidden', padding: '0 24px' }}>
          <DataGrid
            columns={columns}
            rows={listing ? listing.rows : []}
            selectedId={selected ? selected.id : null}
            sort={sort ? { key: sort.key, dir: sort.dir } : undefined}
            onSort={onSort}
            onRowClick={function (r) { setSelected({ id: r.id, platform: r.platform, instance: r.instance }); }}
          />
        </div>

        {listing && listing.total > PAGE_SIZE && (
          <div style={{ padding: '10px 24px', display: 'flex', gap: 8, alignItems: 'center' }}>
            <Button size="sm" variant="secondary" disabled={page <= 1} onClick={function () { setPage(page - 1); }}>Previous</Button>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 'var(--text-xs)', color: 'var(--text-tertiary)' }}>
              Page {page} of {Math.ceil(listing.total / PAGE_SIZE)}
            </span>
            <Button size="sm" variant="secondary" disabled={page >= Math.ceil(listing.total / PAGE_SIZE)} onClick={function () { setPage(page + 1); }}>Next</Button>
          </div>
        )}
      </div>

      {selected && (
        <div style={{ width: 380, flex: 'none', borderLeft: '1px solid var(--border-hairline)', background: 'var(--surface-panel)', overflow: 'auto', padding: 16 }}>
          {!detail ? <Spinner /> : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div style={{ fontSize: 'var(--text-2xl)', fontWeight: 'var(--weight-semibold)', letterSpacing: 'var(--tracking-heading)' }}>{detail.name || detail.id}</div>
              {activeType === 'dataset' && detail.policy_status && <PolicyList detail={detail} key={detail.id} />}

              {detail.not_seen_in_latest_scan && (
                <Banner tone="warn" title="Not seen in the latest scan">
                  The newest completed scan of this instance did not return this object. It may have been removed at the source,
                  or the signed-in account may no longer be able to read it.
                </Banner>
              )}
              <KeyValueList labelWidth={168} items={Object.keys(detail)
                .filter(function (k) { return !HIDDEN_DETAIL_KEYS.includes(k) && !k.endsWith('_json') && detail[k] != null; })
                .map(function (k) { return { label: humanizeFieldKey(k), value: String(detail[k]), mono: true }; })} />

              <DetailBlobs detail={detail} />

              <div>
                <div className="bit-eyebrow" style={{ marginBottom: 8 }}>Upstream ({detail.upstream.length})</div>
                {detail.upstream.length === 0
                  ? <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-tertiary)' }}>Nothing feeds into this.</div>
                  : detail.upstream.slice(0, 25).map(function (n, i) {
                    return <TreeNode key={i} depth={0} label={n.name || n.id} meta={n.type} />;
                  })}
              </div>

              <div>
                <div className="bit-eyebrow" style={{ marginBottom: 8 }}>Downstream -- what breaks if this is retired ({detail.downstream.length})</div>
                {detail.downstream.length === 0
                  ? <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-tertiary)' }}>Nothing depends on this.</div>
                  : detail.downstream.slice(0, 25).map(function (n, i) {
                    return <TreeNode key={i} depth={0} label={n.name || n.id} meta={n.type} />;
                  })}
              </div>

              {detail.access && detail.access.length > 0 && (
                <div>
                  <div className="bit-eyebrow" style={{ marginBottom: 8 }}>Who holds a role ({detail.access.length})</div>
                  {detail.access.slice(0, 25).map(function (n, i) {
                    return <TreeNode key={i} depth={0} label={n.name || n.id} meta={n.type + (n.role ? ' · ' + n.role : '')} />;
                  })}
                </div>
              )}

              {detail.refreshes && detail.refreshes.length > 0 && (
                <div>
                  <div className="bit-eyebrow" style={{ marginBottom: 8 }}>Refreshes ({detail.refreshes.length}, newest first)</div>
                  {detail.refreshes.slice(0, 25).map(function (r, i) {
                    return <TreeNode key={i} depth={0} label={(r.started_at || r.id) + ' · ' + (r.status || 'unknown')}
                      meta={(r.refresh_type || '') + (r.error ? ' · ' + r.error.slice(0, 120) : '')} />;
                  })}
                </div>
              )}

              {detail.holds && detail.holds.length > 0 && (
                <div>
                  <div className="bit-eyebrow" style={{ marginBottom: 8 }}>Holds a role on ({detail.holds.length})</div>
                  {detail.holds.slice(0, 25).map(function (n, i) {
                    return <TreeNode key={i} depth={0} label={n.name || n.id} meta={n.type + (n.role ? ' · ' + n.role : '')} />;
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

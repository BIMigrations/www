"""Airbyte Protocol extract definitions, built from the scan alone.

For every connector account (and, where the scan does not hold the account, every
connector type) that feeds datasets, this writes what an Airbyte replacement would need:

- the **source** it maps to (an Airbyte source connector name) and a **connection
  specification template**: the property names that connector asks for, with a
  placeholder for each value and secrets marked, never filled in. The scan holds no
  host, bucket or credential, so none is invented.
- an **AirbyteCatalog**: one stream per dataset, ``json_schema`` from the dataset's
  columns, ``supported_sync_modes``.
- a **ConfiguredAirbyteCatalog** for those streams (full refresh, overwrite).

Datasets with nothing to extract are listed with the reason, not given a stream:
files uploaded by hand, web forms, results of a transformation, platform-internal data,
data pushed in by an API, and connectors with no Airbyte source we can name.

Nothing here has been run on Airbyte. The shapes follow the Airbyte Protocol's
``AirbyteCatalog`` / ``ConfiguredAirbyteCatalog`` messages (docs.airbyte.com, protocol
reference read 2026-10-22) and are checked against their required fields by
``spec.SCHEMAS['extract']``; the connection templates list property names taken from
each connector's documented configuration and are **not** validated against the
connector's own spec.
"""

from __future__ import annotations

import re
from typing import Any

# Domo / Power BI column type -> JSON Schema fragment (Airbyte's catalog types).
_TYPE_SCHEMA: dict[str, dict[str, Any]] = {
    "STRING": {"type": ["null", "string"]},
    "LONG": {"type": ["null", "integer"]},
    "INTEGER": {"type": ["null", "integer"]},
    "DOUBLE": {"type": ["null", "number"]},
    "DECIMAL": {"type": ["null", "number"]},
    "BOOLEAN": {"type": ["null", "boolean"]},
    "DATE": {"type": ["null", "string"], "format": "date"},
    "DATETIME": {"type": ["null", "string"], "format": "date-time", "airbyte_type": "timestamp_without_timezone"},
    "TIMESTAMP": {"type": ["null", "string"], "format": "date-time", "airbyte_type": "timestamp_without_timezone"},
}
_SECRET = "<secret: set at deployment>"
_SET = "<set at deployment>"


def _norm(text: str | None) -> str:
    return re.sub(r"[^a-z0-9]", "", (text or "").lower())


def _tmpl(**props: Any) -> dict[str, Any]:
    return props


# normalised connector name -> Airbyte source and the configuration it asks for.
SOURCES: dict[str, dict[str, Any]] = {}


def _register(names: list[str], source: str, config: dict[str, Any], notes: str | None = None) -> None:
    entry = {"source": source, "docker_repository": f"airbyte/{source}", "config": config, "notes": notes}
    for name in names:
        SOURCES[_norm(name)] = entry


_register(["Amazon Redshift", "amazon-redshift", "AmazonRedshift"], "source-redshift",
          _tmpl(host=_SET, port=5439, database=_SET, username=_SET, password=_SECRET, schemas=[_SET]))
_register(["PostgreSQL", "postgresql", "Postgres"], "source-postgres",
          _tmpl(host=_SET, port=5432, database=_SET, username=_SET, password=_SECRET, schemas=[_SET], ssl_mode={"mode": _SET}))
_register(["Amazon S3", "amazon-s3", "AmazonS3 Advanced", "amazons3-advanced"], "source-s3",
          _tmpl(bucket=_SET, aws_access_key_id=_SECRET, aws_secret_access_key=_SECRET,
                streams=[{"name": _SET, "format": {"filetype": "csv"}, "globs": [_SET]}]),
          "Domo's S3 connectors read files by prefix; the globs and file format are not in the scan.")
_register(["SFTP", "CSV-SFTP", "sftp"], "source-sftp-bulk",
          _tmpl(host=_SET, port=22, username=_SET, password=_SECRET, folder_path=_SET,
                streams=[{"name": _SET, "format": {"filetype": "csv"}, "globs": [_SET]}]),
          "Remote files read as CSV; path and file pattern are not in the scan.")
_register(["Google Cloud Storage Service", "google-cloud-storage-service"], "source-gcs",
          _tmpl(service_account=_SECRET, gcs_bucket=_SET, gcs_path=_SET))
_register(["Google BigQuery Service", "google-bigquery-service"], "source-bigquery",
          _tmpl(project_id=_SET, dataset_id=_SET, credentials_json=_SECRET))
_register(["Github", "GitHub"], "source-github",
          _tmpl(credentials={"personal_access_token": _SECRET}, repositories=[_SET]))
_register(["Google Spreadsheets", "google-spreadsheets", "Google Sheets"], "source-google-sheets",
          _tmpl(spreadsheet_id=_SET, credentials={"auth_type": "Service", "service_account_info": _SECRET}))
_register(["Salesforce", "salesforce"], "source-salesforce",
          _tmpl(client_id=_SECRET, client_secret=_SECRET, refresh_token=_SECRET, is_sandbox=False))
# Power BI datasource types (scan of a Power BI tenant).
_register(["Sql", "SQL Server"], "source-mssql",
          _tmpl(host=_SET, port=1433, database=_SET, username=_SET, password=_SECRET))
_register(["Snowflake"], "source-snowflake",
          _tmpl(host=_SET, role=_SET, warehouse=_SET, database=_SET, schema=_SET, credentials={"username": _SET, "password": _SECRET}))

# Provider types with nothing to extract, and why.
_NOT_EXTRACTED: dict[str, tuple[str, str]] = {}


def _reason(names: list[str], category: str, why: str) -> None:
    for name in names:
        _NOT_EXTRACTED[_norm(name)] = (category, why)


_reason(["file-upload", "file-upload-new", "large-file-upload", "csv-upload", "csv3", "CSV"], "manual_upload",
        "Uploaded to the platform by hand; there is no remote source to extract from.")
_reason(["webform"], "manual_entry", "Rows typed into a web form on the platform.")
_reason(["DataFlow", "dataflow", "dataset-view", "ExternalDataflow"], "derived",
        "Produced by a transformation or view inside the platform; its inputs are what to extract.")
_reason(["domostats", "ObservabilityMetrics", "modovault", "sample-data"], "platform_internal",
        "Generated by the platform about itself.")
_reason(["api"], "pushed", "Pushed into the platform by an API client; the producer, not the platform, is the source.")
_reason(["twitter", "X", "quandl-l1", "Facebook", "Box", "Microsoft SQL Server Reporting Service with SharePoint"],
        "no_airbyte_source", "No Airbyte source connector for this connector was identified; map it by hand.")


def classify(provider: str | None, connector: str | None) -> dict[str, Any]:
    """Where a dataset's data comes from, as far as the scan says.

    ``{"extract": "airbyte"|"none", "source": ..., "category": ..., "reason": ...}``. The
    account's connector type wins over the dataset's provider type when both are known."""
    for name in (connector, provider):
        key = _norm(name)
        if key in SOURCES:
            return {"extract": "airbyte", "source": SOURCES[key]["source"], "category": "extractable", "reason": None}
    for name in (connector, provider):
        key = _norm(name)
        if key in _NOT_EXTRACTED:
            category, why = _NOT_EXTRACTED[key]
            return {"extract": "none", "source": None, "category": category, "reason": why}
        if (name or "").startswith("domo-governance"):
            return {"extract": "none", "source": None, "category": "platform_internal",
                    "reason": _NOT_EXTRACTED[_norm("domostats")][1]}
    label = connector or provider
    return {"extract": "none", "source": None, "category": "unclassified",
            "reason": f"The scan does not say how {label!r} data arrives." if label else "The scan names no provider."}


def column_schema(columns: list[dict[str, Any]]) -> dict[str, Any]:
    """JSON Schema of one stream's records. A column type the table does not know is a
    plain nullable string, flagged in ``source_type`` so the guess is visible."""
    properties: dict[str, Any] = {}
    for col in columns:
        name = col.get("name")
        if not name:
            continue
        kind = str(col.get("type") or "").upper()
        fragment = dict(_TYPE_SCHEMA.get(kind) or {"type": ["null", "string"]})
        if kind not in _TYPE_SCHEMA:
            fragment["source_type"] = col.get("type")
        properties[name] = fragment
    return {"$schema": "http://json-schema.org/draft-07/schema#", "type": "object", "properties": properties}


def stream_for(dataset_id: str, name: str | None, columns: list[dict[str, Any]]) -> dict[str, Any]:
    """One ``AirbyteStream``. Streams are named by dataset id and name so two datasets with
    the same title cannot collide."""
    return {
        "name": f"{dataset_id}" if not name else f"{name} [{dataset_id}]",
        "json_schema": column_schema(columns),
        "supported_sync_modes": ["full_refresh"],
        "source_defined_cursor": False,
    }


def configured_catalog(streams: list[dict[str, Any]]) -> dict[str, Any]:
    return {"streams": [{"stream": s, "sync_mode": "full_refresh", "destination_sync_mode": "overwrite"} for s in streams]}


def extract_document(spec_id: str, unit: dict[str, Any], datasets: list[dict[str, Any]]) -> dict[str, Any]:
    """One extract unit (an account, or a connector type without a scanned account) and the
    datasets it feeds. ``unit``: ``{id, name, connector, account_id}``."""
    entry = SOURCES[_norm(unit["connector"])]
    streams = [stream_for(d["id"], d["name"], d["columns"]) for d in datasets]
    return {
        "spec": spec_id, "kind": "extract", "id": unit["id"], "name": unit["name"],
        "source": unit["source"],
        "connector": unit["connector"], "account_id": unit.get("account_id"),
        "airbyte": {
            "source_connector": entry["source"], "docker_repository": entry["docker_repository"],
            "connection_specification": {"template": entry["config"], "values_in_scan": False,
                                         "validated_against_connector_spec": False},
            "catalog": {"streams": streams},
            "configured_catalog": configured_catalog(streams),
        },
        "datasets": [{"id": d["id"], "name": d["name"], "stream": s["name"], "columns": len(d["columns"])}
                     for d, s in zip(datasets, streams)],
        "notes": entry["notes"],
    }


def index_document(spec_id: str, rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Every dataset in scope: the extract unit it belongs to, or why it has none."""
    summary: dict[str, int] = {}
    for row in rows:
        summary[row["category"]] = summary.get(row["category"], 0) + 1
    return {"spec": spec_id, "kind": "extract_index", "datasets": rows, "summary": dict(sorted(summary.items()))}

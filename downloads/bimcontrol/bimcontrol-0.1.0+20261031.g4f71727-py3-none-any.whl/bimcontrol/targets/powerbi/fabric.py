"""Publishing a PBIP into a Fabric workspace.

Does what `fabric-cicd` does for the two item types we produce, in
process. Written rather than depended on for a practical reason: that
library supports Python up to 3.13, this tool runs on 3.14, and shelling
out to a second interpreter to publish is a worse seam than ~150 lines of
REST calls.

The part that is not obvious is the rebind. On disk a report points at
its model by relative path (`definition.pbir` -> `byPath`), because that
is what Power BI Desktop understands. In a workspace there are no paths,
so the same file has to point at the published model by id
(`byConnection`). Publishing the model first and rewriting that one file
is the whole trick.
"""

from __future__ import annotations

import base64
import json
import time
from pathlib import Path
from typing import Any

import requests

from .auth import FABRIC_SCOPE, token
from .description import source_of

API = "https://api.fabric.microsoft.com/v1"
# Item creation is asynchronous: a 202 means "accepted", and the result
# arrives at the Location header some seconds later.
POLL_SECONDS = 2
POLL_TIMEOUT = 300
CONNECTION_TRIES = 3

# Files that describe the project to Power BI Desktop but are not part of
# a Fabric item definition.
SKIP_FILES = {".pbip", ".py", ".pyc", ".DS_Store"}


class FabricError(Exception):
    pass


class FabricClient:
    def __init__(self, access_token: str | None = None, allow_prompt: bool = True):
        self._token = access_token or token(FABRIC_SCOPE, allow_prompt=allow_prompt)
        self.http = requests.Session()
        self.http.headers.update({"Authorization": f"Bearer {self._token}"})

    # ---- plumbing -------------------------------------------------------

    def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        response = self._send(method, f"{API}{path}", **kwargs)
        if response.status_code == 202:
            return self._wait(response)
        if response.status_code >= 400:
            raise FabricError(f"{method} {path} -> {response.status_code}: {response.text[:500]}")
        return response.json() if response.content else None

    def _send(self, method: str, url: str, **kwargs: Any) -> requests.Response:
        """One request, tried again when the connection drops before an answer.

        Fabric reset a connection mid-publish (Medicare Cost Report-SW, 2026-10-17) and the run
        failed at the last stage after 25 minutes of work. A reset leaves no answer to act on; a
        create that did reach the service shows up as a name conflict on the retry, which fails
        loudly and is picked up as an update by the next resume.
        """
        for attempt in range(1, CONNECTION_TRIES + 1):
            try:
                return self.http.request(method, url, timeout=120, **kwargs)
            except (requests.ConnectionError, requests.exceptions.ChunkedEncodingError):
                if attempt == CONNECTION_TRIES:
                    raise
                time.sleep(5 * attempt)
        raise AssertionError("unreachable")

    def _wait(self, response: requests.Response) -> Any:
        """Follow a long-running operation to its result."""
        location = response.headers.get("Location")
        if not location:
            return None
        deadline = time.monotonic() + POLL_TIMEOUT
        while time.monotonic() < deadline:
            time.sleep(POLL_SECONDS)
            poll = self.http.get(location, timeout=60)
            if poll.status_code >= 400:
                raise FabricError(f"operation poll failed: {poll.status_code}: {poll.text[:300]}")
            body = poll.json() if poll.content else {}
            status = (body.get("status") or "").lower()
            if status in ("succeeded", "completed"):
                result = self.http.get(f"{location}/result", timeout=60)
                return result.json() if result.content and result.ok else body
            if status in ("failed", "cancelled"):
                error = body.get("error") or body
                raise FabricError(f"Fabric operation {status}: {json.dumps(error)[:500]}")
        raise FabricError("Fabric operation did not finish within the timeout")

    # ---- workspace ------------------------------------------------------

    def workspace(self, workspace_id: str) -> dict[str, Any]:
        return self._request("GET", f"/workspaces/{workspace_id}")

    def find_workspace(self, name: str) -> dict[str, Any] | None:
        for workspace in (self._request("GET", "/workspaces") or {}).get("value", []):
            if workspace.get("displayName") == name:
                return workspace
        return None

    def resolve_workspace(self, workspace: str) -> str:
        """Accept a name or an id, return an id."""
        if "-" in workspace and len(workspace) >= 32:
            return workspace
        found = self.find_workspace(workspace)
        if not found:
            raise FabricError(f"No workspace called {workspace!r} that this account can see")
        return found["id"]

    def items(self, workspace_id: str) -> list[dict[str, Any]]:
        return (self._request("GET", f"/workspaces/{workspace_id}/items") or {}).get("value", [])

    def find_item(self, workspace_id: str, name: str, item_type: str) -> dict[str, Any] | None:
        for item in self.items(workspace_id):
            if item.get("displayName") == name and item.get("type") == item_type:
                return item
        return None

    def delete_item(self, workspace_id: str, item_id: str) -> None:
        self._request("DELETE", f"/workspaces/{workspace_id}/items/{item_id}")

    # ---- publishing -----------------------------------------------------

    def publish_item(
        self, workspace_id: str, name: str, item_type: str, parts: list[dict[str, str]]
    ) -> dict[str, Any]:
        """Create the item, or replace the definition of the existing one."""
        existing = self.find_item(workspace_id, name, item_type)
        definition = {"parts": parts}

        if existing:
            self._request(
                "POST",
                f"/workspaces/{workspace_id}/items/{existing['id']}/updateDefinition",
                params={"updateMetadata": "true"},
                json={"definition": definition},
            )
            return {**existing, "action": "updated"}

        created = self._request(
            "POST", f"/workspaces/{workspace_id}/items",
            json={"displayName": name, "type": item_type, "definition": definition},
        )
        return {**(created or {}), "action": "created"}


# ---- turning a folder into definition parts ------------------------------


def _part(path: str, payload: bytes) -> dict[str, str]:
    return {
        "path": path,
        "payload": base64.b64encode(payload).decode("ascii"),
        "payloadType": "InlineBase64",
    }


def collect_parts(item_dir: Path, rewrite: dict[str, bytes] | None = None) -> list[dict[str, str]]:
    """Every file under an item folder, as base64 definition parts.

    `rewrite` replaces a file's bytes by its relative path, which is how
    the report's `definition.pbir` gets repointed at the published model
    without editing the project on disk.
    """
    rewrite = rewrite or {}
    parts: list[dict[str, str]] = []
    for path in sorted(item_dir.rglob("*")):
        if not path.is_file() or path.suffix in SKIP_FILES or path.name in SKIP_FILES:
            continue
        relative = str(path.relative_to(item_dir))
        # `.platform` is part of the definition, not metadata to strip:
        # an update with updateMetadata=true is rejected without it
        # ("UpdateMetadata is true but .platform file was not provided").
        parts.append(_part(relative, rewrite.get(relative, path.read_bytes())))
    return parts


def by_connection_pbir(semantic_model_id: str) -> bytes:
    """A `definition.pbir` bound to a model in the workspace, not on disk."""
    return json.dumps({
        "$schema": "https://developer.microsoft.com/json-schemas/fabric/item/report/"
                   "definitionProperties/2.0.0/schema.json",
        "version": "4.0",
        "datasetReference": {
            "byConnection": {"connectionString": f"semanticmodelid={semantic_model_id}"}
        },
    }, indent=2).encode()


def _stamped_source(item_dir: Path) -> str | None:
    platform = item_dir / ".platform"
    if not platform.is_file():
        return None
    return source_of(((json.loads(platform.read_text()).get("metadata") or {}).get("description")))


def _renamed_platform(item_dir: Path, display_name: str) -> bytes:
    platform = json.loads((item_dir / ".platform").read_text())
    platform["metadata"]["displayName"] = display_name
    return json.dumps(platform, indent=2).encode()


def collision_name(client: FabricClient, workspace_id: str, name: str, source: str | None) -> str:
    """The name to publish under: `name`, unless another dashboard already owns it.

    Items are matched by display name, so two dashboards called the same
    thing (Revenue Impact exists nine times in one estate) would keep
    overwriting one report. An existing item stamped with a different
    source dashboard is left alone and this one gets its id appended.
    Items with no stamp (published before the stamp existed) are treated
    as ours.
    """
    if not source:
        return name
    for item in client.items(workspace_id):
        if item.get("displayName") != name or item.get("type") not in ("SemanticModel", "Report"):
            continue
        owner = source_of(item.get("description"))
        if owner and owner != source:
            return f"{name} ({source})"
    return name


def renamed_report_name(name: str, published: dict[str, Any], model_name: str) -> str:
    """The name a report is published under: the model's new name when the model was renamed for a collision."""
    return model_name if published.get("renamed_from") == name else name


def _queried_live(model_dir: Path) -> bool:
    """Whether any table of the model is read live (DirectQuery)."""
    return any("mode: directQuery" in path.read_text(encoding="utf-8", errors="replace")
               for path in model_dir.glob("definition/tables/*.tmdl"))


def _recreate(client: Any, workspace_id: str, model_name: str, report_names: list[str], source: str | None, say) -> None:
    """Delete this dashboard's published report(s) and model so the service reads the tables' schema afresh.

    A DirectQuery model remembers the column types it first saw; updating its definition keeps them, and a column the
    warehouse now returns as a number but the service remembers as text fails every query with "couldn't fold the
    expression to the data source" (Worked RVU's by Service Date-SW: 5 of 11 cards, until the model was republished
    as a new item). Replacing the items changes their ids, not their names."""
    for kind, name in [("Report", n) for n in report_names] + [("SemanticModel", model_name)]:
        existing = client.find_item(workspace_id, name, kind)
        # Only what this tool stamped for this dashboard (collision_name has already renamed another dashboard's
        # item out of the way). An item with no stamp is somebody's hand-made one, or from before stamping: it is
        # updated in place, as before, never deleted.
        if existing and existing.get("id") and source and source_of(existing.get("description")) == source:
            say(f"replacing the published {kind} {name!r} so the service reads the schema afresh")
            try:
                client.delete_item(workspace_id, existing["id"])
            except FabricError as exc:
                if "-> 404" not in str(exc):       # already gone (a retried DELETE): the publish will create it
                    # (not a bare "404": the message holds the workspace and item ids, which can contain it)
                    raise


def publish_pbip(
    project_dir: Path, workspace: str, client: FabricClient | None = None, on_progress=None,
) -> dict[str, Any]:
    """Publish a PBIP folder: semantic model first, then the report bound to it."""
    def say(message: str) -> None:
        if on_progress:
            on_progress(message)

    client = client or FabricClient()
    workspace_id = client.resolve_workspace(workspace)

    model_dirs = sorted(project_dir.glob("*.SemanticModel"))
    report_dirs = sorted(project_dir.glob("*.Report"))
    if not model_dirs:
        raise FabricError(f"No .SemanticModel folder in {project_dir}")

    published: dict[str, Any] = {"workspace_id": workspace_id, "items": []}

    model_dir = model_dirs[0]
    model_name = model_dir.name.removesuffix(".SemanticModel")
    source = _stamped_source(model_dir)
    renamed = collision_name(client, workspace_id, model_name, source)
    model_rewrite: dict[str, bytes] = {}
    report_rewrite: dict[str, bytes] = {}
    if renamed != model_name:
        say(f"{model_name!r} in the workspace belongs to another dashboard; publishing as {renamed!r}")
        published["renamed_from"] = model_name
        model_rewrite[".platform"] = _renamed_platform(model_dir, renamed)
        model_name = renamed
    if _queried_live(model_dir) and hasattr(client, "delete_item"):
        _recreate(client, workspace_id, model_name, [
            renamed_report_name(d.name.removesuffix(".Report"), published, model_name) for d in report_dirs], source, say)
    say(f"publishing semantic model {model_name!r}")
    model = client.publish_item(
        workspace_id, model_name, "SemanticModel", collect_parts(model_dir, model_rewrite)
    )
    published["semantic_model_id"] = model.get("id")
    published["items"].append({"type": "SemanticModel", "name": model_name,
                               "id": model.get("id"), "action": model.get("action")})

    for report_dir in report_dirs:
        report_name = renamed_report_name(report_dir.name.removesuffix(".Report"), published, model_name)
        if report_name != report_dir.name.removesuffix(".Report"):
            report_rewrite[".platform"] = _renamed_platform(report_dir, report_name)
        say(f"publishing report {report_name!r}")
        parts = collect_parts(
            report_dir,
            # On disk the report points at ../X.SemanticModel; in a
            # workspace it has to point at the model's id.
            rewrite={**report_rewrite, "definition.pbir": by_connection_pbir(model.get("id"))},
        )
        report = client.publish_item(workspace_id, report_name, "Report", parts)
        published["items"].append({"type": "Report", "name": report_name,
                                   "id": report.get("id"), "action": report.get("action")})
        published["report_id"] = report.get("id")
        published["report_url"] = (
            f"https://app.fabric.microsoft.com/groups/{workspace_id}/reports/{report.get('id')}"
        )

    return published

"""SQLite connection, schema management, and the typed upsert layer.

Platform-agnostic: every function here takes a `platform` string and never
imports anything from estate_scanner.adapters.*. The explicit
`_upsert_<type>` functions (kept explicit rather than reflection-driven --
each type has genuinely different columns) are the only place a
core.models dataclass gets turned into SQL.
"""

from __future__ import annotations

import datetime as _dt
import importlib.resources
import json
import os
import re
import sqlite3
import sys
from pathlib import Path

from estate_scanner.core.instances import AmbiguousInstance, normalise_instance

from estate_scanner.core.registry import all_object_types

from . import migrate

DEFAULT_DB_PATH = Path.home() / ".estate-scanner" / "estate.db"


def connect(db_path: Path | str | None = None) -> sqlite3.Connection:
    # Resolved here, not in the signature: a default argument is bound when the
    # module loads, so a test (or anything) that moves DEFAULT_DB_PATH would be ignored.
    db_path = Path(DEFAULT_DB_PATH if db_path is None else db_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    # A file made before `instance` joined the key is rebuilt first (copy, then one transaction):
    # init_schema's indexes name the new column, so it cannot run against the old tables.
    migrate.ensure_current(db_path, schema_statements=schema_statements())
    # check_same_thread=False: FastAPI's sync dependencies and sync endpoint
    # functions each get dispatched to anyio's worker threadpool
    # independently, with no guaranteed thread affinity between a
    # generator dependency (e.g. webapp/deps.py's get_conn) and the
    # endpoint that consumes what it yields -- even within one request.
    # Safe here because each request/background job still gets its own
    # fresh connection, opened and closed within that one request/job, and
    # is never shared across concurrent requests.
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    # A scan holds write locks for as long as it takes to process a batch of
    # objects (see orchestrator.py's periodic commit) -- without this, any
    # other connection opened while that's in flight (e.g. the webapp
    # starting up to show scan progress) fails immediately with "database
    # is locked" instead of just waiting the brief moment it actually needs.
    conn.execute("PRAGMA busy_timeout = 10000")
    # Foreign keys are intentionally NOT enforced: schema.sql's REFERENCES
    # clauses are documentation of intent, not hard constraints. Real BI
    # platform data has dangling references (deleted owners, objects outside
    # the scan's permission scope, etc.) that would otherwise abort a scan.
    init_schema(conn)
    _migrate_schema(conn)
    if conn.execute("PRAGMA user_version").fetchone()[0] < migrate.LAYOUT_VERSION:
        conn.execute(f"PRAGMA user_version = {migrate.LAYOUT_VERSION}")
        conn.commit()
    return conn


def _schema_sql() -> str:
    return importlib.resources.files("estate_scanner.storage").joinpath("schema.sql").read_text()


def init_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(_schema_sql())
    conn.commit()


def schema_statements() -> list[str]:
    """schema.sql one statement at a time, for a caller that holds its own transaction
    (`executescript` would commit it)."""
    statements, buffer = [], ""
    for line in _schema_sql().splitlines(keepends=True):
        buffer += line
        if sqlite3.complete_statement(buffer):
            if any(not part.strip().startswith("--") for part in buffer.splitlines() if part.strip()):
                statements.append(buffer.strip())
            buffer = ""
    return statements


# Columns added to a table after its first release. "CREATE TABLE IF NOT
# EXISTS" in schema.sql is a no-op against a database file created by an
# older version, so a returning customer's db needs these added by hand,
# once, here -- otherwise the very next scan crashes on the first upsert
# into that table.
_ADDED_COLUMNS: list[tuple[str, str, str]] = [
    ("dataflows", "definition_json", "TEXT"),
    ("cards", "definition_json", "TEXT"),
    ("datasets", "pdp_json", "TEXT"),
    ("datasets", "definition_json", "TEXT"),
    ("dashboards", "layout_json", "TEXT"),
    ("calculated_fields", "definition_json", "TEXT"),
    ("apps", "views_json", "TEXT"),
    ("apps", "navigations_json", "TEXT"),
    ("apps", "theme_json", "TEXT"),
]


def _migrate_schema(conn: sqlite3.Connection) -> None:
    for table, column, coltype in _ADDED_COLUMNS:
        existing = {row[1] for row in conn.execute(f"PRAGMA table_info({table})")}
        if column not in existing:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {coltype}")
    # "CREATE VIEW IF NOT EXISTS" keeps an older database's view as it was, so a
    # view that predates the workspaces or gateways table would list everything but them.
    # Only that stale view is rebuilt: a view holds no data, and leaving a
    # current one alone avoids a write lock on every connection during a scan.
    view = conn.execute("SELECT sql FROM sqlite_master WHERE type = 'view' AND name = 'estate_objects'").fetchone()
    if view is not None and not all(table in view[0] for table in ("workspaces", "gateways")):
        conn.execute("DROP VIEW estate_objects")
        init_schema(conn)
    conn.commit()


def _iso(value) -> str | None:
    if value is None:
        return None
    if isinstance(value, _dt.datetime):
        return value.isoformat()
    return str(value)


def _json(value) -> str | None:
    return None if value is None else json.dumps(value, default=str)


# -- Scan lifecycle -----------------------------------------------------------


_OWNER = re.compile(r"started by pid (\d+)(?:;|$)")


def scan_owner_note(pid: int | None = None) -> str:
    """The note every scan starts with: which process runs it (a number, not the machine's name: the file goes to others). A process
    that is killed cannot say it has stopped, so the next scan of the same instance reads this to tell a scan that ended without a
    word from one that is still going."""
    return f"started by pid {os.getpid() if pid is None else pid}"


def _process_ended(pid: int) -> bool:
    """True only when it is certain the process is gone. Where that cannot be told (Windows: ``os.kill(pid, 0)`` would end the
    process), or the answer is unclear, the scan is left as it is."""
    if sys.platform == "win32":
        return False
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return True
    except OSError:  # PermissionError: it exists, under another user
        return False
    return False


def _mark_abandoned(conn: sqlite3.Connection, platform: str, instance: str) -> None:
    """A scan left 'running' by a process that has since ended (killed, crashed, power cut) is 'failed', and says why. The rows it
    wrote stay: a scan upserts by object id, so the scan that follows replaces them. Scans of other instances, scans whose owner
    is unknown or still alive (this very process included) are not touched."""
    for scan_id, notes in conn.execute("SELECT id, notes FROM scans WHERE platform = ? AND instance = ? AND status = 'running'", (platform, instance)).fetchall():
        owner = _OWNER.match(notes or "")
        if not owner or not _process_ended(int(owner.group(1))):
            continue
        conn.execute(
            "UPDATE scans SET status = 'failed', finished_at = ?, notes = ? WHERE id = ? AND status = 'running'",
            (_dt.datetime.now(_dt.timezone.utc).isoformat(),
             f"{notes}; interrupted: the process that ran this scan (pid {owner.group(1)}) ended before it finished. What it had read is kept; the next scan replaces it.", scan_id),
        )


# The tables a "not seen by the latest scan" question reads (the reader's OBJECT_TABLES) and edges.
SEEN_TABLES = ("users", "groups_", "accounts", "datasets", "dataflows", "cards", "dashboards", "apps", "workspaces", "gateways", "calculated_fields", "alerts", "edges")


# A 'running' row older than this, whose process id still exists, is not taken as a scan that is going (a process id is reused).
OVERLAP_HOURS = 12


class ScanAlreadyRunning(RuntimeError):
    """Another process is scanning the same instance. Two scans writing one instance would each leave rows the other has seen."""


def _refuse_if_scanning(conn: sqlite3.Connection, platform: str, instance: str) -> None:
    """Raise `ScanAlreadyRunning` when a scan of this (platform, instance), started by another process that still exists and less than
    OVERLAP_HOURS ago, has not finished. A scan of this very process, one with no owner recorded, one whose process ended (marked failed
    before this is called), and every scan on Windows (where a process id cannot be checked) are left alone, as `_mark_abandoned` leaves them."""
    cutoff = (_dt.datetime.now(_dt.timezone.utc) - _dt.timedelta(hours=OVERLAP_HOURS)).isoformat()
    for notes in (r[0] for r in conn.execute(
            "SELECT notes FROM scans WHERE platform = ? AND instance = ? AND status = 'running' AND started_at > ?", (platform, instance, cutoff))):
        owner = _OWNER.match(notes or "")
        if owner and int(owner.group(1)) != os.getpid() and sys.platform != "win32" and not _process_ended(int(owner.group(1))):
            raise ScanAlreadyRunning(
                f"A scan of {platform}/{instance} is already running in another process (pid {owner.group(1)}). Wait for it to finish, then scan again. "
                f"If nothing is scanning (a restart can give that process id to another program), the block ends by itself {OVERLAP_HOURS} hours after the scan "
                f"started, or now with: estate-scanner delete-scan <that scan's number> --abandoned --confirm <the words it prints>.")


def start_scan(conn: sqlite3.Connection, platform: str, instance: str, notes: str | None = None) -> int:
    instance = normalise_instance(platform, instance)
    conn.commit()
    conn.execute("BEGIN IMMEDIATE")  # the check and the insert are one step: two processes starting together cannot both pass it
    try:
        _mark_abandoned(conn, platform, instance)
        _refuse_if_scanning(conn, platform, instance)
        cur = conn.execute(
            "INSERT INTO scans (platform, instance, started_at, status, notes) VALUES (?, ?, ?, 'running', ?)",
            (platform, instance, _dt.datetime.now(_dt.timezone.utc).isoformat(), scan_owner_note() if notes is None else notes),
        )
    except ScanAlreadyRunning:
        conn.commit()  # what _mark_abandoned found is kept; the refused scan writes nothing
        raise
    except BaseException:
        conn.rollback()
        raise
    conn.commit()
    return cur.lastrowid


def _scan_instance(conn: sqlite3.Connection, scan_id: int) -> str:
    """The instance a scan ran against: every row it writes carries it, so no adapter or caller names it twice."""
    row = conn.execute("SELECT instance FROM scans WHERE id = ?", (scan_id,)).fetchone()
    return "" if row is None else row[0]


def list_instances(conn: sqlite3.Connection, platform: str) -> list[str]:
    """The instances of `platform` the database was scanned against, sorted. Every row takes its instance
    from a scan, so the scans table answers without reading the object tables; a file with objects but no
    scan row (made by hand) is read from the tables instead."""
    names = {row[0] for row in conn.execute("SELECT DISTINCT instance FROM scans WHERE platform = ?", (platform,))}
    if not names:
        for descriptor in all_object_types():
            names.update(row[0] for row in conn.execute(f"SELECT DISTINCT instance FROM {descriptor.table} WHERE platform = ?", (platform,)))  # noqa: S608 -- registry table names
    return sorted(names)


def list_platforms(conn: sqlite3.Connection) -> list[str]:
    names = {row[0] for row in conn.execute("SELECT DISTINCT platform FROM scans")}
    if not names:
        for descriptor in all_object_types():
            names.update(row[0] for row in conn.execute(f"SELECT DISTINCT platform FROM {descriptor.table}"))  # noqa: S608 -- registry table names
    return sorted(names)


def resolve_instance(conn: sqlite3.Connection, platform: str, instance: str | None) -> str:
    """The instance to read. A name is normalised and returned as given. None is accepted only while the
    database holds one instance of the platform (or none yet); with several it raises and lists them,
    it never mixes them."""
    if instance is not None:
        return normalise_instance(platform, instance)
    found = list_instances(conn, platform)
    if len(found) > 1:
        raise AmbiguousInstance(platform, found)
    return found[0] if found else ""


def scope(conn: sqlite3.Connection, platform: str | None = None, instance: str | None = None, *, latest: bool = False) -> list[tuple[str, str]]:
    """The (platform, instance) pairs a read covers. A platform with one instance contributes that one.
    With several and no name: `latest=False` raises (AmbiguousInstance), `latest=True` takes the instance
    of the platform's newest scan (what the screens show until they let the user pick)."""
    platforms = [platform] if platform else list_platforms(conn)
    pairs = []
    for p in platforms:
        if instance is not None or not latest:
            pairs.append((p, resolve_instance(conn, p, instance)))
            continue
        found = list_instances(conn, p)
        pairs.append((p, _newest_instance(conn, p, found) if len(found) > 1 else (found[0] if found else "")))
    return pairs


def _newest_instance(conn: sqlite3.Connection, platform: str, found: list[str]) -> str:
    """The instance a screen shows until the user picks one: that of the newest COMPLETED scan, so a failed
    or still running scan of another instance does not empty the view. With no completed scan, the newest
    scan that wrote objects; failing that, the newest scan. A file with objects and no scan rows (`found` came from the
    object tables) has nothing to order by: the last name, the same every time."""
    row = conn.execute(
        "SELECT instance FROM scans WHERE platform = ? AND status = 'completed' ORDER BY id DESC LIMIT 1", (platform,)
    ).fetchone()
    if row:
        return row[0]
    scans = conn.execute("SELECT id, instance FROM scans WHERE platform = ? ORDER BY id DESC", (platform,)).fetchall()
    for scan_id, instance in scans:
        for descriptor in all_object_types():
            if conn.execute(f"SELECT 1 FROM {descriptor.table} WHERE last_seen_scan_id = ? LIMIT 1", (scan_id,)).fetchone():  # noqa: S608 -- registry table names
                return instance
    return scans[0][1] if scans else found[-1]


def scope_sql(pairs: list[tuple[str, str]], column_prefix: str = "") -> tuple[str, list[str]]:
    """`(platform = ? AND instance = ?) OR ...` for the pairs, and its parameters."""
    if not pairs:
        return "0", []
    c = column_prefix
    return "(" + " OR ".join(f"({c}platform = ? AND {c}instance = ?)" for _ in pairs) + ")", [v for pair in pairs for v in pair]


def latest_completed_scans(conn: sqlite3.Connection, pairs: list[tuple[str, str]]) -> dict[tuple[str, str], sqlite3.Row]:
    """For each (platform, instance) that has one, its newest scan with status 'completed' (id, finished_at).
    A failed or running scan is not the reference for "seen": it stopped before it had read everything."""
    found = {}
    for platform, instance in pairs:
        row = conn.execute(
            "SELECT id, finished_at FROM scans WHERE platform = ? AND instance = ? AND status = 'completed' ORDER BY id DESC LIMIT 1",
            (platform, instance),
        ).fetchone()
        if row is not None:
            found[(platform, instance)] = row
    return found


def not_seen_sql(conn: sqlite3.Connection, pairs: list[tuple[str, str]]) -> tuple[str, list]:
    """SQL for the rows of `pairs` whose last_seen_scan_id is older than their instance's latest completed
    scan: the objects that scan did not return. They may have been removed at the source, or be ones the
    account could no longer read; a row with no last_seen_scan_id (a database from before) is never listed."""
    latest = latest_completed_scans(conn, pairs)
    parts = [("(platform = ? AND instance = ? AND last_seen_scan_id < ?)", [p, i, row["id"]]) for (p, i), row in latest.items()]
    if not parts:
        return "0", []
    return "(" + " OR ".join(sql for sql, _ in parts) + ")", [v for _, params in parts for v in params]


def finish_scan(conn: sqlite3.Connection, scan_id: int, status: str = "completed", note: str | None = None) -> None:
    conn.execute(
        "UPDATE scans SET finished_at = ?, status = ?, notes = CASE WHEN ? IS NULL THEN notes ELSE COALESCE(notes || '; ', '') || ? END WHERE id = ?",
        (_dt.datetime.now(_dt.timezone.utc).isoformat(), status, note, note, scan_id),
    )
    conn.commit()
    if status == "completed":
        ensure_seen_indexes(conn, scan_id)


def ensure_seen_indexes(conn: sqlite3.Connection, scan_id: int) -> list[str]:
    """Index what BIMControl's reader asks about a re-scanned estate ("which rows did the latest completed scan not see": ``WHERE platform = ? AND
    instance = ? AND last_seen_scan_id < ?``, and ``scan_id`` for edges). ``last_seen_scan_id`` is the last column of each object table, behind
    ``raw_json``, so without an index that question walks the overflow pages of the whole table: 23 s on an 860 MB file with three scans (estatescanner#111).
    Built here, when a scan of an instance that already had a completed scan finishes, and not in ``schema.sql`` (which runs on every connect: the
    first launch of a big existing file would look hung while it built them) and not for a first scan (the reader asks nothing of an estate with one
    scan). Idempotent, additive, and it touches no row. Returns the names of the indexes it made."""
    row = conn.execute("SELECT platform, instance FROM scans WHERE id = ?", (scan_id,)).fetchone()
    if row is None or conn.execute("SELECT COUNT(*) FROM scans WHERE platform = ? AND instance = ? AND status = 'completed'", tuple(row)).fetchone()[0] < 2:
        return []
    made = []
    for table in SEEN_TABLES:
        column = "scan_id" if table == "edges" else "last_seen_scan_id"
        have = {r[1] for r in conn.execute(f"PRAGMA table_info({table})")}  # noqa: S608 -- fixed names
        name = "idx_edges_scan" if table == "edges" else f"idx_{table}_seen"
        if {"platform", "instance", column} <= have and conn.execute("SELECT 1 FROM sqlite_master WHERE type = 'index' AND name = ?", (name,)).fetchone() is None:
            conn.execute(f"CREATE INDEX IF NOT EXISTS {name} ON {table}(platform, instance, {column})")  # noqa: S608
            made.append(name)
    conn.commit()
    return made


def record_issue(conn: sqlite3.Connection, scan_id: int, phase: str, issue) -> None:
    """One thing the scan could not read (see core.models.ScanIssue)."""
    conn.execute(
        "INSERT INTO scan_issues (scan_id, phase, scope, message, http_status, recorded_at) VALUES (?, ?, ?, ?, ?, ?)",
        (scan_id, phase, issue.scope, issue.message, issue.status, _dt.datetime.now(_dt.timezone.utc).isoformat()),
    )


# -- Session persistence -------------------------------------------------
# The platform_sessions table is platform-agnostic (a bare (platform,
# instance) -> opaque credentials_json blob); only the serialization inside
# that blob is adapter-specific, via PlatformSession.to/from_persisted_dict.


def persist_session(conn: sqlite3.Connection, session) -> None:
    instance = normalise_instance(session.platform, session.instance)
    conn.execute(
        """INSERT INTO platform_sessions (platform, instance, credentials_json, updated_at)
           VALUES (?, ?, ?, ?)
           ON CONFLICT(platform, instance) DO UPDATE SET
             credentials_json = excluded.credentials_json, updated_at = excluded.updated_at""",
        (session.platform, instance, _json(session.to_persisted_dict()), _dt.datetime.now(_dt.timezone.utc).isoformat()),
    )
    conn.commit()


def load_persisted_credentials(conn: sqlite3.Connection, platform: str, instance: str) -> dict | None:
    """Returns the raw persisted credentials dict, or None. Reconstructing
    an actual PlatformSession from it is the authenticator's job (via
    `authenticator.restore_session(instance, credentials)`) -- storage
    shouldn't need to know about any specific Session subclass."""
    instance = normalise_instance(platform, instance)
    row = conn.execute(
        "SELECT credentials_json FROM platform_sessions WHERE platform = ? AND instance = ?", (platform, instance)
    ).fetchone()
    return None if row is None else json.loads(row["credentials_json"])


def drop_persisted_session(conn: sqlite3.Connection, platform: str, instance: str) -> None:
    conn.execute("DELETE FROM platform_sessions WHERE platform = ? AND instance = ?", (platform, normalise_instance(platform, instance)))
    conn.commit()


def record_raw(
    conn: sqlite3.Connection,
    scan_id: int,
    platform: str,
    object_type: str,
    object_id: str | None,
    endpoint: str,
    body_json: str,
) -> None:
    conn.execute(
        """INSERT INTO raw_objects (platform, scan_id, object_type, object_id, endpoint, fetched_at, body_json)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (platform, scan_id, object_type, object_id, endpoint, _dt.datetime.now(_dt.timezone.utc).isoformat(), body_json),
    )


def upsert_edge(
    conn: sqlite3.Connection,
    platform: str,
    src_type: str,
    src_id: str,
    dst_type: str,
    dst_id: str,
    edge_type: str,
    scan_id: int,
    weight: float = 1.0,
    raw_json: str | None = None,
) -> None:
    conn.execute(
        """INSERT INTO edges (platform, instance, src_type, src_id, dst_type, dst_id, edge_type, weight, raw_json, scan_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(platform, instance, src_type, src_id, dst_type, dst_id, edge_type)
           DO UPDATE SET weight = excluded.weight, raw_json = excluded.raw_json, scan_id = MAX(COALESCE(edges.scan_id, 0), excluded.scan_id) WHERE COALESCE(edges.scan_id, 0) <= excluded.scan_id""",
        (platform, _scan_instance(conn, scan_id), src_type, src_id, dst_type, dst_id, edge_type, weight, raw_json, scan_id),
    )


# -- Typed object upserts ------------------------------------------------------


def _upsert_user(conn, platform, instance, obj, scan_id) -> None:
    conn.execute(
        """INSERT INTO users (platform, instance, id, name, email, role, title, raw_json, first_seen_scan_id, last_seen_scan_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(platform, instance, id) DO UPDATE SET
             name = excluded.name, email = excluded.email, role = excluded.role, title = excluded.title,
             raw_json = excluded.raw_json, last_seen_scan_id = MAX(COALESCE(last_seen_scan_id, 0), excluded.last_seen_scan_id) WHERE COALESCE(users.last_seen_scan_id, 0) <= excluded.last_seen_scan_id""",
        (platform, instance, obj.id, obj.name, obj.email, obj.role, obj.title, _json(obj.raw_payload), scan_id, scan_id),
    )


def _upsert_group(conn, platform, instance, obj, scan_id) -> None:
    conn.execute(
        """INSERT INTO groups_ (platform, instance, id, name, raw_json, first_seen_scan_id, last_seen_scan_id)
           VALUES (?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(platform, instance, id) DO UPDATE SET
             name = excluded.name, raw_json = excluded.raw_json, last_seen_scan_id = MAX(COALESCE(last_seen_scan_id, 0), excluded.last_seen_scan_id) WHERE COALESCE(groups_.last_seen_scan_id, 0) <= excluded.last_seen_scan_id""",
        (platform, instance, obj.id, obj.name, _json(obj.raw_payload), scan_id, scan_id),
    )


def _upsert_account(conn, platform, instance, obj, scan_id) -> None:
    conn.execute(
        """INSERT INTO accounts (platform, instance, id, name, connector_type, owner_id, raw_json, first_seen_scan_id, last_seen_scan_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(platform, instance, id) DO UPDATE SET
             name = excluded.name, connector_type = excluded.connector_type, owner_id = excluded.owner_id,
             raw_json = excluded.raw_json, last_seen_scan_id = MAX(COALESCE(last_seen_scan_id, 0), excluded.last_seen_scan_id) WHERE COALESCE(accounts.last_seen_scan_id, 0) <= excluded.last_seen_scan_id""",
        (platform, instance, obj.id, obj.name, obj.connector_type, obj.owner_id, _json(obj.raw_payload), scan_id, scan_id),
    )


def _upsert_dataset(conn, platform, instance, obj, scan_id) -> None:
    conn.execute(
        """INSERT INTO datasets
             (platform, instance, id, name, provider_type, stream_id, schema_columns_json, row_count, column_count,
              owner_id, created_at, updated_at, is_deleted,
              downstream_card_count, downstream_dataflow_count, downstream_dataset_count, downstream_alert_count,
              pdp_json, definition_json, raw_json, first_seen_scan_id, last_seen_scan_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(platform, instance, id) DO UPDATE SET
             name = excluded.name, provider_type = excluded.provider_type, stream_id = excluded.stream_id,
             schema_columns_json = excluded.schema_columns_json, row_count = excluded.row_count,
             column_count = excluded.column_count, owner_id = excluded.owner_id,
             created_at = excluded.created_at, updated_at = excluded.updated_at, is_deleted = excluded.is_deleted,
             downstream_card_count = excluded.downstream_card_count,
             downstream_dataflow_count = excluded.downstream_dataflow_count,
             downstream_dataset_count = excluded.downstream_dataset_count,
             downstream_alert_count = excluded.downstream_alert_count,
             pdp_json = excluded.pdp_json, definition_json = excluded.definition_json,
             raw_json = excluded.raw_json, last_seen_scan_id = MAX(COALESCE(last_seen_scan_id, 0), excluded.last_seen_scan_id) WHERE COALESCE(datasets.last_seen_scan_id, 0) <= excluded.last_seen_scan_id""",
        (
            platform, instance, obj.id, obj.name, obj.provider_type, obj.stream_id, _json(obj.schema_columns),
            obj.row_count, obj.column_count, obj.owner_id, _iso(obj.created_at), _iso(obj.updated_at),
            int(obj.is_deleted), obj.downstream_card_count, obj.downstream_dataflow_count,
            obj.downstream_dataset_count, obj.downstream_alert_count, _json(obj.pdp_policies),
            _json(obj.definition), _json(obj.raw_payload), scan_id, scan_id,
        ),
    )
    _upsert_refreshes(conn, platform, instance, "dataset", obj, scan_id)


def _upsert_refreshes(conn, platform, instance, object_type, obj, scan_id) -> None:
    """The object's refresh history as rows. None (not captured) writes nothing; rows already stored
    that the platform no longer returns stay. A run first seen going (no request id) is stored under its
    start time; when a later scan returns it with the id, that row takes the id (and keeps when it was
    first seen) instead of leaving a second row behind."""
    for r in obj.refreshes or []:
        if r.adopt_placeholder:
            _adopt_request_id(conn, platform, instance, object_type, obj.id, r)
        conn.execute(
            """INSERT INTO refreshes
                 (platform, instance, object_type, object_id, id, refresh_type, status, started_at, ended_at, error, raw_json,
                  first_seen_scan_id, last_seen_scan_id)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(platform, instance, object_type, object_id, id) DO UPDATE SET
                 refresh_type = excluded.refresh_type, status = excluded.status, started_at = excluded.started_at,
                 ended_at = excluded.ended_at, error = excluded.error, raw_json = excluded.raw_json,
                 last_seen_scan_id = MAX(COALESCE(last_seen_scan_id, 0), excluded.last_seen_scan_id) WHERE COALESCE(refreshes.last_seen_scan_id, 0) <= excluded.last_seen_scan_id""",
            (platform, instance, object_type, obj.id, r.id, r.refresh_type, r.status, _iso(r.started_at), _iso(r.ended_at), r.error,
             _json(r.raw_payload), scan_id, scan_id),
        )


def _adopt_request_id(conn, platform, instance, object_type, object_id, r) -> None:
    placeholder = (r.raw_payload or {}).get("startTime") if isinstance(r.raw_payload, dict) else None
    if not placeholder or placeholder == r.id:
        return
    key = (platform, instance, object_type, object_id)
    where = "platform = ? AND instance = ? AND object_type = ? AND object_id = ? AND id = ?"
    conn.execute(f"UPDATE OR IGNORE refreshes SET id = ? WHERE {where}", (r.id, *key, str(placeholder)))  # noqa: S608
    conn.execute(f"DELETE FROM refreshes WHERE {where}", (*key, str(placeholder)))  # noqa: S608 -- when the id row already existed


def _later(stored: str | None, new: str | None) -> bool:
    """Whether what an earlier scan stored is later than this scan's value, or this scan's cannot be told apart from it (none, or not comparable): then the
    stored one stands."""
    if stored is None:
        return False
    if new is None:
        return True
    try:
        return _dt.datetime.fromisoformat(stored) > _dt.datetime.fromisoformat(new)
    except (ValueError, TypeError):  # (an unreadable time, or one with an offset against one without)
        return True


def _carry_over(conn, platform, instance, obj) -> tuple[tuple, dict | None]:
    """``((last state, failed, modified_at), definition)`` to store for a dataflow: this scan's, except where it says it could not read something for this flow
    (``unread_columns``, ``unread_definition_keys``) and an earlier scan stored something there, which is kept. What was kept is said in the definition
    (``carriedOver``: the columns, the definition keys, ``scans`` = the scan each of them was read in - the scan that last wrote the row, or the one an earlier carry named for it - and ``fromScan`` = the oldest of those)."""
    columns = (obj.last_run_state, None if obj.last_run_failed is None else int(obj.last_run_failed), _iso(obj.last_run_at))
    definition = obj.definition
    if not (obj.unread_columns or obj.unread_definition_keys or obj.columns_only_if_newer):
        return columns, definition
    prior = conn.execute(
        "SELECT last_execution_state, last_execution_failed, modified_at, definition_json, last_seen_scan_id FROM dataflows WHERE platform = ? AND instance = ? AND id = ?",
        (platform, instance, obj.id)).fetchone()
    if prior is None:
        return columns, definition
    names = ("last_execution_state", "last_execution_failed", "modified_at")
    # The stored time is a run's only when a run is stored with it: a flow with no runs stores (None, None, <its own update time>), and that time is no
    # evidence that a run read now is older. Compared against it, the run's state would be kept with the flow's time (a mixed row), so nothing is compared.
    stored_run = prior["last_execution_state"] is not None or prior["last_execution_failed"] is not None
    unread = names if obj.columns_only_if_newer and stored_run and _later(prior["modified_at"], columns[2]) else obj.unread_columns
    kept_columns = [n for n, value in zip(names, columns) if n in unread and prior[n] is not None]
    columns = tuple(prior[n] if n in kept_columns else value for n, value in zip(names, columns))
    kept_keys: list[str] = []
    earlier = None
    if prior["definition_json"]:
        try:
            earlier = json.loads(prior["definition_json"])
        except ValueError:
            earlier = None
    if obj.unread_definition_keys and isinstance(definition, dict) and isinstance(earlier, dict):
        kept_keys = [k for k in obj.unread_definition_keys if k in earlier]
        definition = {**definition, **{k: earlier[k] for k in kept_keys}}
    if (kept_columns or kept_keys) and isinstance(definition, dict):
        before = earlier.get("carriedOver") if isinstance(earlier, dict) else None
        before = before if isinstance(before, dict) else {}
        recorded = before.get("scans") if isinstance(before.get("scans"), dict) else {}
        listed = set(before.get("columns") or []) | set(before.get("definitionKeys") or [])

        def origin(name: str):
            if name in recorded:
                return recorded[name]  # carried before, and the scan it was read in was written down for it
            if name in listed and before.get("fromScan") is not None:
                return before["fromScan"]  # carried before by a row that wrote one scan for all it carried
            return prior["last_seen_scan_id"]  # read by the scan that last wrote the row

        scans = {name: origin(name) for name in (*kept_columns, *kept_keys)}
        definition = {**definition, "carriedOver": {"fromScan": min((v for v in scans.values() if v is not None), default=None), "columns": kept_columns, "definitionKeys": kept_keys, "scans": scans}}
    return columns, definition


def _upsert_dataflow(conn, platform, instance, obj, scan_id) -> None:
    (state, failed, modified), definition = _carry_over(conn, platform, instance, obj)
    conn.execute(
        """INSERT INTO dataflows
             (platform, instance, id, name, engine, is_deleted, num_inputs, num_outputs,
              last_execution_state, last_execution_failed, modified_at, owner_id, definition_json, raw_json,
              first_seen_scan_id, last_seen_scan_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(platform, instance, id) DO UPDATE SET
             name = excluded.name, engine = excluded.engine, is_deleted = excluded.is_deleted,
             num_inputs = excluded.num_inputs, num_outputs = excluded.num_outputs,
             last_execution_state = excluded.last_execution_state,
             last_execution_failed = excluded.last_execution_failed,
             modified_at = excluded.modified_at, owner_id = excluded.owner_id,
             definition_json = excluded.definition_json, raw_json = excluded.raw_json,
             last_seen_scan_id = MAX(COALESCE(last_seen_scan_id, 0), excluded.last_seen_scan_id) WHERE COALESCE(dataflows.last_seen_scan_id, 0) <= excluded.last_seen_scan_id""",
        (
            platform, instance, obj.id, obj.name, obj.engine, int(obj.is_deleted),
            len(obj.input_dataset_ids) + len(obj.account_ids) + len(obj.upstream_dataflow_ids), len(obj.output_dataset_ids),
            state, failed, modified, obj.owner_id, _json(definition), _json(obj.raw_payload), scan_id, scan_id,
        ),
    )
    _upsert_refreshes(conn, platform, instance, "dataflow", obj, scan_id)


def _upsert_card(conn, platform, instance, obj, scan_id) -> None:
    conn.execute(
        """INSERT INTO cards (platform, instance, id, name, type, owner_id, dataset_id, definition_json, raw_json, first_seen_scan_id, last_seen_scan_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(platform, instance, id) DO UPDATE SET
             name = excluded.name, type = excluded.type, owner_id = excluded.owner_id,
             dataset_id = excluded.dataset_id, definition_json = excluded.definition_json, raw_json = excluded.raw_json,
             last_seen_scan_id = MAX(COALESCE(last_seen_scan_id, 0), excluded.last_seen_scan_id) WHERE COALESCE(cards.last_seen_scan_id, 0) <= excluded.last_seen_scan_id""",
        (
            platform, instance, obj.id, obj.name, obj.card_type, obj.owner_id,
            obj.dataset_ids[0] if obj.dataset_ids else None, _json(obj.definition), _json(obj.raw_payload), scan_id, scan_id,
        ),
    )


def _upsert_dashboard(conn, platform, instance, obj, scan_id) -> None:
    filters = [
        {"field": f.field, "label": f.label, "filterType": f.filter_type, "raw": f.raw_payload}
        for f in obj.filters
    ]
    conn.execute(
        """INSERT INTO dashboards (platform, instance, id, name, parent_dashboard_id, owner_id, filters_json, layout_json, raw_json, first_seen_scan_id, last_seen_scan_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(platform, instance, id) DO UPDATE SET
             name = excluded.name, parent_dashboard_id = excluded.parent_dashboard_id, owner_id = excluded.owner_id,
             filters_json = excluded.filters_json, layout_json = excluded.layout_json, raw_json = excluded.raw_json,
             last_seen_scan_id = MAX(COALESCE(last_seen_scan_id, 0), excluded.last_seen_scan_id) WHERE COALESCE(dashboards.last_seen_scan_id, 0) <= excluded.last_seen_scan_id""",
        (platform, instance, obj.id, obj.name, obj.parent_id, obj.owner_id, _json(filters), _json(obj.layout), _json(obj.raw_payload), scan_id, scan_id),
    )


def _upsert_app(conn, platform, instance, obj, scan_id) -> None:
    views = [
        {"viewId": v.view_id, "title": v.title, "parentViewId": v.parent_view_id, "viewOrder": v.view_order, "visible": v.visible}
        for v in obj.views
    ]
    conn.execute(
        """INSERT INTO apps (platform, instance, id, name, type, owner_id, landing_dashboard_id, views_json, navigations_json, theme_json, raw_json, first_seen_scan_id, last_seen_scan_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(platform, instance, id) DO UPDATE SET
             name = excluded.name, type = excluded.type, owner_id = excluded.owner_id,
             landing_dashboard_id = excluded.landing_dashboard_id, views_json = excluded.views_json,
             navigations_json = excluded.navigations_json, theme_json = excluded.theme_json, raw_json = excluded.raw_json,
             last_seen_scan_id = MAX(COALESCE(last_seen_scan_id, 0), excluded.last_seen_scan_id) WHERE COALESCE(apps.last_seen_scan_id, 0) <= excluded.last_seen_scan_id""",
        (
            platform, instance, obj.id, obj.name, obj.app_type, obj.owner_id, obj.landing_dashboard_id,
            _json(views), _json(obj.navigations), _json(obj.theme), _json(obj.raw_payload), scan_id, scan_id,
        ),
    )
    _upsert_refreshes(conn, platform, instance, "app", obj, scan_id)


def _upsert_calculated_field(conn, platform, instance, obj, scan_id) -> None:
    conn.execute(
        """INSERT INTO calculated_fields
             (platform, instance, id, name, owner_id, status, formula_language, formula, data_type, is_global, is_locked,
              definition_json, raw_json, first_seen_scan_id, last_seen_scan_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(platform, instance, id) DO UPDATE SET
             name = excluded.name, owner_id = excluded.owner_id, status = excluded.status,
             formula_language = excluded.formula_language, formula = excluded.formula,
             data_type = excluded.data_type, is_global = excluded.is_global, is_locked = excluded.is_locked,
             definition_json = excluded.definition_json, raw_json = excluded.raw_json, last_seen_scan_id = MAX(COALESCE(last_seen_scan_id, 0), excluded.last_seen_scan_id) WHERE COALESCE(calculated_fields.last_seen_scan_id, 0) <= excluded.last_seen_scan_id""",
        (
            platform, instance, obj.id, obj.name, obj.owner_id, obj.status, obj.formula_language, obj.formula,
            obj.data_type, int(obj.is_global), int(obj.is_locked), _json(obj.definition), _json(obj.raw_payload), scan_id, scan_id,
        ),
    )


def _upsert_workspace(conn, platform, instance, obj, scan_id) -> None:
    conn.execute(
        """INSERT INTO workspaces (platform, instance, id, name, type, state, capacity_id, is_on_dedicated_capacity, raw_json, first_seen_scan_id, last_seen_scan_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(platform, instance, id) DO UPDATE SET
             name = excluded.name, type = excluded.type, state = excluded.state, capacity_id = excluded.capacity_id,
             is_on_dedicated_capacity = excluded.is_on_dedicated_capacity, raw_json = excluded.raw_json,
             last_seen_scan_id = MAX(COALESCE(last_seen_scan_id, 0), excluded.last_seen_scan_id) WHERE COALESCE(workspaces.last_seen_scan_id, 0) <= excluded.last_seen_scan_id""",
        (
            platform, instance, obj.id, obj.name, obj.workspace_type, obj.state, obj.capacity_id,
            None if obj.is_on_dedicated_capacity is None else int(obj.is_on_dedicated_capacity),
            _json(obj.raw_payload), scan_id, scan_id,
        ),
    )


def _upsert_gateway(conn, platform, instance, obj, scan_id) -> None:
    conn.execute(
        """INSERT INTO gateways (platform, instance, id, name, type, status, machine, version, raw_json, first_seen_scan_id, last_seen_scan_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(platform, instance, id) DO UPDATE SET
             name = excluded.name, type = excluded.type, status = excluded.status, machine = excluded.machine,
             version = excluded.version, raw_json = excluded.raw_json, last_seen_scan_id = MAX(COALESCE(last_seen_scan_id, 0), excluded.last_seen_scan_id) WHERE COALESCE(gateways.last_seen_scan_id, 0) <= excluded.last_seen_scan_id""",
        (platform, instance, obj.id, obj.name, obj.gateway_type, obj.status, obj.machine, obj.version, _json(obj.raw_payload), scan_id, scan_id),
    )


def _upsert_alert(conn, platform, instance, obj, scan_id) -> None:
    resource_type = obj.watched_object.object_type if obj.watched_object else None
    resource_id = obj.watched_object.id if obj.watched_object else None
    conn.execute(
        """INSERT INTO alerts (platform, instance, id, name, rule, owner_id, resource_id, resource_type, disabled, raw_json, first_seen_scan_id, last_seen_scan_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(platform, instance, id) DO UPDATE SET
             name = excluded.name, rule = excluded.rule, owner_id = excluded.owner_id,
             resource_id = excluded.resource_id, resource_type = excluded.resource_type,
             disabled = excluded.disabled, raw_json = excluded.raw_json, last_seen_scan_id = MAX(COALESCE(last_seen_scan_id, 0), excluded.last_seen_scan_id) WHERE COALESCE(alerts.last_seen_scan_id, 0) <= excluded.last_seen_scan_id""",
        (platform, instance, obj.id, obj.name, obj.rule, obj.owner_id, resource_id, resource_type, int(obj.disabled), _json(obj.raw_payload), scan_id, scan_id),
    )
    if obj.watched_object:
        # An alert watches one thing, and its row now says which. An edge to what it watched in an earlier scan would say two: it goes. An alert whose target
        # this scan did not resolve (no watched object) keeps its earlier edge, marked by its older scan id: the target may only be missing from a cut listing.
        conn.execute(
            "DELETE FROM edges WHERE platform = ? AND instance = ? AND edge_type = 'watched_by' AND dst_type = 'alert' AND dst_id = ? "
            "AND NOT (src_type = ? AND src_id = ?)",
            (platform, instance, obj.id, obj.watched_object.object_type, obj.watched_object.id))


_UPSERTERS = {
    "user": _upsert_user,
    "group": _upsert_group,
    "account": _upsert_account,
    "dataset": _upsert_dataset,
    "dataflow": _upsert_dataflow,
    "card": _upsert_card,
    "dashboard": _upsert_dashboard,
    "app": _upsert_app,
    "calculated_field": _upsert_calculated_field,
    "alert": _upsert_alert,
    "workspace": _upsert_workspace,
    "gateway": _upsert_gateway,
}


def upsert_object(conn: sqlite3.Connection, platform: str, object_type: str, obj, scan_id: int) -> None:
    try:
        upserter = _UPSERTERS[object_type]
    except KeyError:
        raise KeyError(f"No upsert function registered for object_type={object_type!r}") from None
    upserter(conn, platform, _scan_instance(conn, scan_id), obj, scan_id)

"""Tableau (Server and Cloud). Sign-in (M3 3.2), the structure phases (3.5) and the workbook and data-source files
(3.4, 3.6: calculations, parameters, row-level security evidence, extracts) exist and are the platform's scan; permissions,
subscriptions, flows and refresh history (3.7, 3.8) do not. The platform is ``available`` (3.11) so the Connect and Scan
screens offer it. **Nothing here has run against a real Tableau site** (3.3 does that): every test is against a fake that
serves the documented shapes, and the notice below says so on screen. See docs/tableau-scan-decisions.md."""

from estate_scanner.core.registry import ConnectField, PlatformDescriptor, register_platform

from .auth import TableauAuthenticator, TableauAuthError, TableauSession
from .files import DEFAULT_LIMITS, Limits, TableauFileError
from .client import TableauClient
from .http import ApiError, TableauHttp
from .workbook import FileSummary, read_summary


register_platform(
    PlatformDescriptor(
        key="tableau", display_name="Tableau", status="available",
        authenticator_cls=TableauAuthenticator, client_cls=TableauClient, auth_mode="api_token",
        instance_hint="Server and site, e.g. 10ax.online.tableau.com/mysite",
        # A personal access token: no browser window, so the form is the sign-in. The secret box is a password
        # input; the route keeps it out of the database, out of every message and out of the answer.
        connect_fields=(
            ConnectField("server", "Server address", "https://10ax.online.tableau.com",
                         "The address of your Tableau Cloud (e.g. https://10ax.online.tableau.com) or Tableau Server. A page address pasted from your browser works; if it has /site/<name> or /t/<name> in it, the site box can stay empty."),
            ConnectField("site", "Site name", "mysite",
                         "The part after /site/ in the address bar. Leave empty for a Tableau Server's default site.", required=False),
            ConnectField("token_name", "Token name", "scanner",
                         "The name of a personal access token you created in your Tableau account settings."),
            ConnectField("secret", "Token secret", "", "The token's secret. It is saved in a separate file next to the scan database, not in the database.", secret=True),
        ),
        notice=(
            "This has been tried against a simulated Tableau site only, not against a real Tableau Server or Tableau Cloud. "
            "Treat the first scan as a trial and check it against what you see in Tableau. "
            "Tableau ends a token's earlier session when the same token signs in again, so give this tool a token of its own."
        ),
    )
)

__all__ = ["DEFAULT_LIMITS", "FileSummary", "Limits", "TableauFileError", "read_summary", "ApiError", "TableauAuthError", "TableauAuthenticator", "TableauClient", "TableauHttp", "TableauSession"]

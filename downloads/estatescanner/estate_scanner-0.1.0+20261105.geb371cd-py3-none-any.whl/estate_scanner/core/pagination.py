"""Generic bisection pagination for search-style APIs that hard-cap total
results per query (a common Elasticsearch/Solr default: offset+count <=
10000, and exactly what Domo's /api/search/v1/query enforces).

No platform import here: callers supply count_fn/fetch_page_fn closures over
some monotonic sort key (typically a create-date epoch). The (frm, to)
convention throughout is a half-open interval [frm, to) -- None means
unbounded on that side. This was proven live against a real Domo instance
(zero truncation fetching 24,809 CARD rows and 30,928 BEAST_MODE rows, both
over the 10,000 cap, in ~86 requests each) before being ported here.
"""

from __future__ import annotations

from collections.abc import Callable, Iterator
from dataclasses import dataclass, field

CountFn = Callable[[int | None, int | None], int]
FetchPageFn = Callable[[int | None, int | None, int, int], list[dict]]


class PaginationBudgetExceededError(RuntimeError):
    """Raised when bisection can't finish within the call/depth budget.
    Fails loudly instead of hanging -- this happened once already with a
    naive offset-only pagination loop and shouldn't happen silently again.
    """


@dataclass
class _Budget:
    max_calls: int
    max_depth: int
    calls_made: int = 0
    stuck_leaves: list[tuple[int | None, int | None, int]] = field(default_factory=list)

    def spend(self) -> None:
        self.calls_made += 1
        if self.calls_made > self.max_calls:
            raise PaginationBudgetExceededError(
                f"exceeded max_calls={self.max_calls} while bisecting "
                f"({len(self.stuck_leaves)} stuck leaf range(s) already accepted)"
            )


def bisect_paginate(
    *,
    count_fn: CountFn,
    fetch_page_fn: FetchPageFn,
    lo_bound: int | None,
    hi_bound: int | None,
    safe_threshold: int = 8000,
    page_size: int = 2000,
    max_calls: int = 500,
    max_depth: int = 40,
    stuck_fallback_limit: int = 9500,
) -> Iterator[dict]:
    """Yields every row in [lo_bound, hi_bound), recursively bisecting any
    sub-range whose count exceeds `safe_threshold` so no single query ever
    asks for more than the API's hard cap.

    If a sub-range's count can't actually be split further (e.g. a cluster
    of rows sharing one sort-key value at the finest resolution we can
    probe), that leaf is fetched up to `stuck_fallback_limit` instead of
    recursing forever -- recorded, not silently dropped: inspect
    `PaginationBudgetExceededError` or wrap this generator to observe
    `_Budget.stuck_leaves` if you need to know whether any range was
    truncated this way.
    """
    budget = _Budget(max_calls=max_calls, max_depth=max_depth)
    yield from _fetch_range(
        count_fn, fetch_page_fn, lo_bound, hi_bound,
        safe_threshold, page_size, budget, stuck_fallback_limit, depth=0,
    )


def _fetch_range(count_fn, fetch_page_fn, frm, to, safe_threshold, page_size, budget, stuck_fallback_limit, depth):
    budget.spend()
    total = count_fn(frm, to)
    if total == 0:
        return

    if total <= safe_threshold:
        yield from _fetch_all_offset(fetch_page_fn, frm, to, total, page_size, budget)
        return

    if depth >= budget.max_depth:
        budget.stuck_leaves.append((frm, to, total))
        yield from _fetch_all_offset(fetch_page_fn, frm, to, min(total, stuck_fallback_limit), page_size, budget)
        return

    pivot = _find_pivot(count_fn, frm, to, total, budget)
    left_count = count_fn(frm, pivot) if pivot is not None else 0
    budget.spend()

    if pivot is None or left_count == 0 or left_count == total:
        # Bisection couldn't actually split this range -- accept the cap
        # rather than recurse on an unchanged (frm, to).
        budget.stuck_leaves.append((frm, to, total))
        yield from _fetch_all_offset(fetch_page_fn, frm, to, min(total, stuck_fallback_limit), page_size, budget)
        return

    yield from _fetch_range(count_fn, fetch_page_fn, frm, pivot, safe_threshold, page_size, budget, stuck_fallback_limit, depth + 1)
    yield from _fetch_range(count_fn, fetch_page_fn, pivot, to, safe_threshold, page_size, budget, stuck_fallback_limit, depth + 1)


def _find_pivot(count_fn, frm, to, total, budget, probes: int = 50) -> int | None:
    lo = frm if frm is not None else 0
    if to is not None:
        hi = to
    else:
        # Unbounded above: a fixed sentinel would either be too tight (real
        # data outlives it) or -- as originally shipped -- so much larger
        # than the actual data that every probe in the fixed probe budget
        # lands past all of it, count_fn always returns `total`, and the
        # search never finds a pivot at all (silently falls back as
        # "stuck" even though the data bisects fine). Grow a candidate
        # bound geometrically, scaled to the current lower bound so a
        # still-unbounded recursive branch (common: only the left half of
        # each split gets a concrete `to`) doesn't restart from scratch,
        # until it provably covers every remaining row.
        step = max(1, lo)
        hi = lo + step
        for _ in range(probes):
            budget.spend()
            if count_fn(frm, hi) >= total:
                break
            step *= 2
            hi = lo + step

    target = total // 2
    pivot: int | None = None
    for _ in range(probes):
        if hi - lo <= 1:
            break
        mid = lo + (hi - lo) // 2
        budget.spend()
        count = count_fn(frm, mid)
        if count <= target:
            pivot, lo = mid, mid
        else:
            hi = mid
    return pivot


def _fetch_all_offset(fetch_page_fn, frm, to, cap, page_size, budget):
    offset = 0
    while offset < cap:
        budget.spend()
        limit = min(page_size, cap - offset)
        rows = fetch_page_fn(frm, to, offset, limit)
        if not rows:
            return
        yield from rows
        offset += len(rows)

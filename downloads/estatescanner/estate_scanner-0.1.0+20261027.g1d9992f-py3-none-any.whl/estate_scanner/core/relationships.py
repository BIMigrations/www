"""Derives graph edges from a domain object's own relationship fields.

Pure function, no DB/HTTP -- every edge in the estate graph traces back to
exactly one branch here, regardless of which platform the object came from.
"""

from __future__ import annotations

from collections.abc import Iterator

from .models import (
    Alert,
    App,
    CalculatedField,
    Card,
    Dashboard,
    Dataflow,
    Dataset,
    ObjectRef,
    Relationship,
    User,
)


def derive_relationships(object_type: str, obj) -> Iterator[Relationship]:
    oid = ObjectRef(object_type, obj.id)

    owner_id = getattr(obj, "owner_id", None)
    if owner_id:
        yield Relationship(ObjectRef("user", owner_id), oid, "owns")

    if object_type == "dataflow" and isinstance(obj, Dataflow):
        for ds_id in obj.input_dataset_ids:
            yield Relationship(ObjectRef("dataset", ds_id), oid, "consumed_by")
        for ds_id in obj.output_dataset_ids:
            yield Relationship(oid, ObjectRef("dataset", ds_id), "produces")

    elif object_type == "dataset" and isinstance(obj, Dataset):
        for account_id in obj.account_ids:
            yield Relationship(ObjectRef("account", account_id), oid, "feeds")

    elif object_type == "card" and isinstance(obj, Card):
        for ds_id in obj.dataset_ids:
            yield Relationship(ObjectRef("dataset", ds_id), oid, "visualized_by")
        for dashboard_id in obj.source_dashboard_ids:
            yield Relationship(ObjectRef("dashboard", dashboard_id), oid, "source_of")

    elif object_type == "dashboard" and isinstance(obj, Dashboard):
        for card_id in obj.card_ids:
            yield Relationship(ObjectRef("card", card_id), oid, "part_of")
        for ds_id in obj.dataset_ids:
            yield Relationship(ObjectRef("dataset", ds_id), oid, "visualized_by")
        if obj.parent_id:
            yield Relationship(ObjectRef("dashboard", obj.parent_id), oid, "parent_of")

    elif object_type == "calculated_field" and isinstance(obj, CalculatedField):
        for ref in obj.linked_object_refs:
            yield Relationship(ref, oid, "used_by_calculated_field")

    elif object_type == "alert" and isinstance(obj, Alert):
        if obj.watched_object:
            yield Relationship(obj.watched_object, oid, "watched_by")

    elif object_type == "app" and isinstance(obj, App):
        view_ids = {v.view_id for v in obj.views if v.view_id}
        if obj.landing_dashboard_id:
            view_ids.add(obj.landing_dashboard_id)
        for view_id in view_ids:
            yield Relationship(ObjectRef("dashboard", view_id), oid, "opened_by")

    elif object_type == "user" and isinstance(obj, User):
        for group_id in obj.group_ids:
            yield Relationship(ObjectRef("user", obj.id), ObjectRef("group", group_id), "member_of")

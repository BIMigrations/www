from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from estate_scanner.core import registry
from estate_scanner.core.orchestrator import run_full_scan
from estate_scanner.storage import db

from ..deps import get_conn
from ..graph_cache import invalidate as invalidate_graph_cache
from ..jobs import jobs

router = APIRouter()


class ScanRequest(BaseModel):
    platform: str = "domo"
    instance: str
    skip_group_membership: bool = False


@router.post("")
def start_scan(body: ScanRequest, request: Request):
    try:
        descriptor = registry.get_platform(body.platform)
    except KeyError:
        raise HTTPException(404, f"Unknown platform: {body.platform}") from None
    db_path = request.app.state.db_path

    def do_scan(job):
        conn = db.connect(db_path)
        try:
            authenticator = descriptor.authenticator_cls()
            persisted = db.load_persisted_credentials(conn, body.platform, body.instance)
            if persisted is None:
                raise RuntimeError(f"No saved session for {body.platform}/{body.instance} -- connect first")
            session = authenticator.restore_session(body.instance, persisted)
            client = descriptor.client_cls(session)
            if not client.verify_session():
                raise RuntimeError("Session expired -- reconnect")
            if body.skip_group_membership and hasattr(client, "fetch_group_memberships"):
                client.fetch_group_memberships = False

            def on_progress(event):
                job.progress = {
                    "phase": event.phase, "completed": event.completed,
                    "total": event.total, "elapsed_s": event.elapsed_s, "message": event.message,
                }

            def on_scan_started(scan_id):
                job.result = {"scan_id": scan_id}  # also read when the scan fails: its issues explain how far it got

            scan_id = run_full_scan(conn, client, body.platform, body.instance, on_progress=on_progress, on_scan_started=on_scan_started)
            return {"scan_id": scan_id}
        finally:
            conn.close()
            invalidate_graph_cache()

    job = jobs.start("scan", do_scan)
    return {"job_id": job.id}


@router.get("/jobs/{job_id}/progress")
def scan_job_progress(job_id: str):
    job = jobs.get(job_id)
    if job is None:
        raise HTTPException(404, "Unknown job")
    return {"status": job.status, "progress": job.progress, "result": job.result, "error": job.error}


@router.get("")
def list_scans(conn=Depends(get_conn)):
    rows = conn.execute(
        "SELECT id, platform, instance, started_at, finished_at, status,"
        " (SELECT COUNT(*) FROM scan_issues WHERE scan_id = scans.id) AS issue_count"
        " FROM scans ORDER BY id DESC"
    ).fetchall()
    return [dict(r) for r in rows]


@router.get("/{scan_id}")
def get_scan(scan_id: int, conn=Depends(get_conn)):
    row = conn.execute(
        "SELECT id, platform, instance, started_at, finished_at, status, notes FROM scans WHERE id = ?", (scan_id,)
    ).fetchone()
    if row is None:
        raise HTTPException(404, "Unknown scan")
    issues = conn.execute(
        "SELECT phase, scope, message, http_status FROM scan_issues WHERE scan_id = ? ORDER BY id", (scan_id,)
    ).fetchall()
    return {**dict(row), "issues": [dict(i) for i in issues]}

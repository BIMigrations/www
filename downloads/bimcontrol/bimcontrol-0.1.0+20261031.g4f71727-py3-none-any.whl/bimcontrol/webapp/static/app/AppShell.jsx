import React from 'react';

// The window chrome, on the BITransition Console's shell contract: a 56px
// rail that is the only top-level navigation, a 48px app bar, and then
// each module's own sidebar / main / inspector. Modules never nest, so a
// user always knows where they are from the rail alone.
//
// The modules follow the method rather than the architecture: find
// what is there, see how it was rewritten, run it, prove it, then see the
// whole customer batch. Connections sits at the foot of the rail where the
// kit puts settings, because it is where you go when something cannot be
// reached, not part of the flow.
//
// Loaded last, because ds-preview.js only pre-declares the exports of
// files that came before it.

const MODULES = [
  { key: 'estate', label: 'Estate', glyph: 'glyph-scan' },
  { key: 'translate', label: 'Translate', glyph: 'glyph-translate' },
  { key: 'migrate', label: 'Migrate', glyph: 'glyph-regenerate' },
  { key: 'parity', label: 'Parity', glyph: 'glyph-parity' },
  { key: 'customer', label: 'Customer', glyph: 'glyph-lineage' },
];

const CRUMBS = {
  estate: ['Estate', 'Dashboards'],
  translate: ['Migrations', 'Translate'],
  migrate: ['Migrations', 'Run'],
  parity: ['Migrations', 'Parity'],
  customer: ['Migrations', 'Customer'],
  connections: ['This node', 'Connections'],
};

export function AppShell() {
  const [module, setModule] = React.useState('estate');
  const [runId, setRunId] = React.useState(null);
  const [theme, setTheme] = React.useState('light');
  const [starting, setStarting] = React.useState(null);
  const [error, setError] = React.useState(null);

  React.useEffect(function () {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  // Starting a migration is the one action that crosses modules: it is
  // taken on Estate and watched on Migrate, so it belongs here rather than
  // in either screen.
  function startMigration(dashboard) {
    setStarting(dashboard.id);
    setError(null);
    startRun(dashboard.id).then(function (body) {
      setStarting(null);
      setRunId(body.run.id);
      setModule('migrate');
    }, function (e) { setStarting(null); setError(e.message); });
  }

  function openRun(id, where) {
    setRunId(id);
    setModule(where || 'migrate');
  }

  return (
    <div style={{ display: 'flex', height: '100vh', minHeight: 0, background: 'var(--surface-canvas)', color: 'var(--text-primary)', fontFamily: 'var(--font-ui)' }}>
      <nav style={{
        width: 'var(--rail-w)', flex: 'none', background: 'var(--surface-chrome)',
        borderRight: '1px solid var(--border-hairline)',
        display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '12px 8px', gap: 6,
      }}>
        <div style={{ marginBottom: 10 }}><Logo variant="mark" size={24} /></div>
        {MODULES.map(function (m) {
          return (
            <RailItem
              key={m.key}
              label={m.label}
              active={module === m.key}
              onClick={function () { setModule(m.key); }}
              icon={<img src={'vendor/assets/' + m.glyph + '.svg'} width="20" height="20" alt=""
                style={{ display: 'block', opacity: module === m.key ? 1 : 0.75 }} />}
            />
          );
        })}
        <div style={{ flex: 1 }} />
        <RailItem label="Connections" active={module === 'connections'}
          icon={<Icon name="link" size={18} />}
          onClick={function () { setModule('connections'); }} />
      </nav>

      <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
        <header style={{
          height: 'var(--app-bar-h)', flex: 'none', display: 'flex', alignItems: 'center',
          gap: 14, padding: '0 16px', background: 'var(--surface-chrome)',
          borderBottom: '1px solid var(--border-hairline)',
        }}>
          <Breadcrumbs items={CRUMBS[module] || []} />
          <div style={{ flex: 1 }} />
          {runId ? (
            <div style={{
              display: 'flex', alignItems: 'center', gap: 8, height: 26, padding: '0 10px',
              border: '1px solid var(--border-hairline)', borderRadius: 'var(--radius-pill)',
              background: 'var(--surface-card)', cursor: 'pointer',
            }} onClick={function () { setModule('migrate'); }}>
              <span className="bit-num" style={{ fontSize: 'var(--text-xs)', color: 'var(--text-tertiary)' }}>
                {runId}
              </span>
            </div>
          ) : null}
          <ProvenanceChip side="source" platform="Domo" size="sm" />
          <Icon name="arrowRight" size={13} color="var(--text-disabled)" />
          <ProvenanceChip side="target" platform="Power BI" size="sm" />
          <IconButton
            icon={<Icon name={theme === 'dark' ? 'eye' : 'layers'} />}
            label={theme === 'dark' ? 'Light theme' : 'Dark theme'}
            onClick={function () { setTheme(theme === 'dark' ? 'light' : 'dark'); }}
          />
        </header>

        <ErrorBanner error={error} title="Could not start that migration" />

        <div style={{ flex: 1, minHeight: 0, display: 'flex' }}>
          {module === 'estate' && <EstateScreen onSelectDashboard={startMigration} starting={starting} />}
          {module === 'translate' && <TranslateScreen runId={runId} onSelectRun={function (id) { openRun(id, 'translate'); }} />}
          {module === 'migrate' && <MigrateScreen runId={runId} onSelectRun={openRun}
            onOpenParity={function (id) { openRun(id, 'parity'); }} />}
          {module === 'parity' && <ParityScreen runId={runId} onSelectRun={function (id) { openRun(id, 'parity'); }} />}
          {module === 'customer' && <CustomerScreen onOpenRun={function (id) { openRun(id, 'parity'); }} />}
          {module === 'connections' && <ConnectionsScreen />}
        </div>
      </div>
    </div>
  );
}

"""Power BI as a migration target.

Produces a PBIP -- the text form of a Power BI project (TMDL semantic
model plus PBIR report JSON). Text because it can be generated, diffed
and reviewed without Power BI Desktop, which runs only on Windows.
"""

from . import chart_map, dax, model, writer

__all__ = ["chart_map", "dax", "model", "writer"]

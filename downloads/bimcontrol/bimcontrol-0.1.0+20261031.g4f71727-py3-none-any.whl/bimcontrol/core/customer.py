"""Migrating a whole customer: a manifest of dashboards, run one after another.

A customer is not a field in the scan, so a *manifest* says which dashboards
belong to them: name suffixes and prefixes, explicit ids, and exclusions.
The batch runs each selected dashboard through the same pipeline a single
`bimcontrol run` uses and writes one rollup (migrated / needs review / failed
per dashboard), updated after every dashboard so a stopped batch loses
nothing and `--status` can show it at any time.

What it shares between dashboards comes from the pipeline itself: source
datasets that are already landed in the warehouse are not landed again
(`land_source_data` checks), and a dashboard that is already proven is
skipped. Converting each shared dataflow once is the converter work in #86.

Failure of one dashboard never stops the batch. Only a session that cannot
be refreshed does, because every following dashboard would fail the same way.
"""

from __future__ import annotations

import json
import re
import subprocess
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from bimcontrol import paths
from bimcontrol.core import parity_causes, provenance, runner
from bimcontrol.estate.closure import resolve_dashboard
from bimcontrol.estate.reader import EstateReader
from bimcontrol.pipelines.verify_parity import data_visuals
from bimcontrol.storage import db

ROLLUP_FILE = "rollup.json"

# A dashboard's outcome in the rollup, best first. `proven` is the only one
# that counts toward "migrated": published, refreshed, every data visual
# compared against Domo's own filtered figures and every figure matches.
# `proven_partial`: nothing compared differs, but some data visuals were not
# compared (or were compared without the dashboard filters); the coverage
# says how many (bimcontrol#164).
# A `figures_differ` row also carries `causes` (parity_causes): how many differing values sit on a card whose
# data demonstrably moved since Domo's figures were made. That is evidence for triage, not a verdict, so it
# never changes the outcome (a stale input can hide a conversion fault); the status line counts the
# dashboards with nothing left unexplained.
OUTCOMES = ("proven", "proven_partial", "figures_differ", "unverified", "failed", "incomplete", "no_cards", "no_data", "pending")
_PROVEN_VERDICTS = {"verified"}


@dataclass
class Manifest:
    name: str
    name_suffixes: list[str] = field(default_factory=list)
    name_prefixes: list[str] = field(default_factory=list)
    name_contains: list[str] = field(default_factory=list)
    name_regexes: list[str] = field(default_factory=list)
    ids: list[str] = field(default_factory=list)
    exclude_ids: list[str] = field(default_factory=list)
    exclude_names: list[str] = field(default_factory=list)
    # Ids run before the rest, in this order (the rest stay cheapest first): a pass whose first hours must answer the demonstration set.
    first: list[str] = field(default_factory=list)
    # Ids that are run again although their latest run is proven: once per pass (--pass-start still applies), as a new run
    # (`--force` does the same without the once-per-pass check, so it cannot go into a loop that starts one dashboard at a time).
    rerun_proven: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {"customer": self.name,
                "include": {"name_suffixes": self.name_suffixes, "name_prefixes": self.name_prefixes,
                            "name_contains": self.name_contains, "name_regexes": self.name_regexes,
                            "ids": self.ids},
                "exclude": {"ids": self.exclude_ids, "names": self.exclude_names},
                "first": self.first, "rerun_proven": self.rerun_proven}

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Manifest":
        include = data.get("include") or {}
        exclude = data.get("exclude") or {}
        if not data.get("customer"):
            raise ValueError("a manifest needs a \"customer\" name")
        return cls(
            name=str(data["customer"]),
            name_suffixes=list(include.get("name_suffixes") or []),
            name_prefixes=list(include.get("name_prefixes") or []),
            name_contains=list(include.get("name_contains") or []),
            name_regexes=list(include.get("name_regexes") or []),
            ids=[str(i) for i in include.get("ids") or []],
            exclude_ids=[str(i) for i in exclude.get("ids") or []],
            exclude_names=list(exclude.get("names") or []),
            first=[str(i) for i in data.get("first") or []],
            rerun_proven=[str(i) for i in data.get("rerun_proven") or []],
        )

    @classmethod
    def load(cls, path: str | Path) -> "Manifest":
        data = json.loads(Path(path).expanduser().read_text(encoding="utf-8"))
        try:
            return cls.from_dict(data)
        except ValueError as exc:
            raise ValueError(f"{path}: {exc}") from None

    def matches(self, dashboard_id: str, name: str | None) -> bool:
        name = name or ""
        if dashboard_id in self.exclude_ids or name in self.exclude_names:
            return False
        return (
            dashboard_id in self.ids
            or any(name.endswith(s) for s in self.name_suffixes)
            or any(name.startswith(p) for p in self.name_prefixes)
            or any(c in name for c in self.name_contains)
            or any(re.search(r, name) for r in self.name_regexes)
        )


@dataclass
class Selected:
    id: str
    name: str | None
    cards: int
    dataflows: int
    source_rows: int
    data_cards: int = 0     # cards that read at least one dataset; text/notebook cards read none

    @property
    def cost(self) -> tuple[int, int, int]:
        """Cheapest first: fewer dataflows to convert, then fewer rows to land."""
        return (self.dataflows, self.source_rows, self.cards)


def select_dashboards(reader: EstateReader, manifest: Manifest) -> list[Selected]:
    """The manifest's dashboards: those it lists under `first` in that order, then the rest cheapest first (a dashboard with no cards last)."""
    chosen: list[Selected] = []
    for row in reader.list_dashboards(limit=100000, order="name"):
        if not manifest.matches(str(row["id"]), row["name"]):
            continue
        closure = resolve_dashboard(reader, str(row["id"]))
        roots = [d for d in closure.datasets if d.id in set(closure.root_dataset_ids)]
        rows = sum(int(d.row.get("row_count") or 0) for d in roots)
        data_cards = sum(1 for ids in closure.card_datasets.values() if ids)
        chosen.append(Selected(str(row["id"]), row["name"], len(closure.cards), len(closure.dataflows), rows,
                               data_cards))
    position = {i: n for n, i in enumerate(manifest.first)}
    return sorted(chosen, key=lambda s: (position.get(s.id, len(position)), s.data_cards == 0, s.cost, s.id))


def _report_of(run: dict[str, Any]) -> dict[str, Any] | None:
    path = Path(run["run_dir"]) / "report" / "migration_report.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except ValueError:
        return None


def coverage_of(run: dict[str, Any]) -> dict[str, Any] | None:
    """How much of the dashboard's data visuals parity compared (None: no report to count from).

    Runs from before 2026-10-18 did not record why a card was skipped; those are counted from the
    compared cards' rows and every other data visual is `not_compared`.
    """
    run_dir = Path(run["run_dir"])
    try:
        report = json.loads((run_dir / "build_report" / "report.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    try:
        parity = json.loads((run_dir / "verify_parity" / "parity.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        parity = {}
    visuals = data_visuals(report)
    compared = set(parity.get("compared_cards") or {r["card_id"] for r in parity.get("rows") or []})
    unfiltered = [c for c in parity.get("unfiltered_cards") or [] if c in compared]
    reasons = {str(s["card_id"]): s["reason"] for s in parity.get("skipped") or []}
    skipped = [{"card_id": v["origin"], "title": v["title"], "visual_type": v.get("visual_type"),
                "reason": reasons.get(str(v["origin"]), "not_compared")}
               for v in visuals if v["origin"] not in compared]
    return {"data_visuals": len(visuals), "compared": len(visuals) - len(skipped),
            "compared_unfiltered": len(unfiltered), "skipped": skipped}


def drift_of(run: dict[str, Any]) -> list[dict[str, Any]]:
    """The model tables whose row count differs from Domo's dataset (parity's `table_rows`), each with the
    difference as a share of Domo's rows: a figure that differs on such a table may be the data moving on."""
    try:
        parity = json.loads((Path(run["run_dir"]) / "verify_parity" / "parity.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    return [{"table": t["table"], "domo_rows": t["domo_rows"], "model_rows": t["model_rows"],
             "percent": round(100 * (t["model_rows"] - t["domo_rows"]) / t["domo_rows"], 3) if t["domo_rows"] else None}
            for t in parity.get("table_rows") or [] if t.get("differs")]


def stale_of(run: dict[str, Any]) -> dict[str, Any] | None:
    """The dataset Domo built furthest before one of its inputs was updated (parity's `stale_inputs`): Domo's figures
    are those of the older input, so a live source that moved since explains a difference no conversion fault does."""
    try:
        parity = json.loads((Path(run["run_dir"]) / "verify_parity" / "parity.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    stale = parity.get("stale_inputs") or []
    return {**stale[0], "count": len(stale)} if stale else None


def summarise_run(run: dict[str, Any] | None, cards_in_scan: int, data_cards: int | None = None) -> dict[str, Any]:
    """One dashboard's rollup row, from its latest run."""
    if cards_in_scan == 0:
        return {"outcome": "no_cards", "note": "the dashboard has no cards in the scan"}
    if data_cards == 0:
        return {"outcome": "no_data", "note": "only text/notebook cards: no data to model, nothing to build in Power BI "
                                              "(the text is kept in the open-spec export)"}
    if run is None:
        return {"outcome": "pending"}
    base = {"run_id": run["id"], "run_status": run["status"]}
    report = _report_of(run)
    if run["status"] == "failed":
        return {**base, "outcome": "failed", "error_stage": run.get("error_stage"),
                "error": (run.get("error") or "")[:300]}
    if run["status"] != "succeeded" or report is None:
        return {**base, "outcome": "incomplete", "note": run.get("stopped_reason")}
    verdict = report["verdict"]["key"]
    totals = (report.get("parity") or {}).get("totals") or {}
    counts = report.get("counts") or {}
    # A report written before 2026-10-17 could say verified having compared no figure; proven needs one.
    compared = totals.get("ok") or totals.get("warn") or totals.get("error")
    coverage = coverage_of(run)
    outcome = "proven" if verdict in _PROVEN_VERDICTS and compared else (
        "figures_differ" if verdict == "figures_differ" else "unverified")
    causes = parity_causes.explain_differences(run["run_dir"]) if outcome == "figures_differ" else None
    if outcome == "proven" and ((coverage and (coverage["skipped"] or coverage["compared_unfiltered"]))
                                or counts.get("visual_errors")):
        outcome = "proven_partial"
    return {**base, "outcome": outcome, "verdict": verdict, "coverage": coverage,
            "cards": counts.get("cards"), "visuals": counts.get("visuals"),
            "open_reviews": counts.get("open_reviews"), "review_errors": counts.get("review_errors"),
            "visual_errors": counts.get("visual_errors"), "row_drift": drift_of(run), "stale": stale_of(run),
            "causes": {k: v for k, v in (causes or {}).items() if k != "by_card"} or None,
            "parity": {k: totals.get(k) for k in ("ok", "warn", "error")} if report.get("parity", {}).get("checked") else None,
            # Matches / differs / not compared / not migrated for every element (a report written before 2026-10-22 has none).
            "elements": (report.get("element_tally") or {}).get("by_status")}


def rollup_path(customer: str) -> Path:
    safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in customer)
    return paths.home() / "customers" / safe / ROLLUP_FILE


def build_rollup(conn, estate_db_path: str | Path, manifest: Manifest, selected: list[Selected]) -> dict[str, Any]:
    """The rollup as the control database currently knows it (no running)."""
    project = runner.resolve_project(conn, estate_db_path)
    units = {u["source_object_id"]: u for u in db.list_units(conn, project_id=project["id"], limit=100000)}
    rows = []
    for s in selected:
        unit = units.get(s.id)
        run = db.get_run(conn, unit["latest_run_id"]) if unit and unit.get("latest_run_id") else None
        rows.append({"dashboard_id": s.id, "name": s.name, "cards_in_scan": s.cards, "data_cards": s.data_cards,
                     "dataflows": s.dataflows, "source_rows": s.source_rows,
                     **summarise_run(run, s.cards, s.data_cards)})
    tally = {o: sum(1 for r in rows if r["outcome"] == o) for o in OUTCOMES}
    statuses = ("matches", "differs", "not_compared", "not_migrated")
    with_status = [r["elements"] for r in rows if r.get("elements")]
    element_tally = {
        "dashboards": len(with_status), "by_status": {s: sum(e.get(s, 0) for e in with_status) for s in statuses},
    } if with_status else None
    return {
        "customer": manifest.name, "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "dashboards": len(rows), "tally": tally, "element_tally": element_tally, "rows": rows,
    }


def write_rollup(rollup: dict[str, Any]) -> Path:
    path = rollup_path(rollup["customer"])
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(rollup, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    tmp.replace(path)
    return path


def format_rollup(rollup: dict[str, Any]) -> str:
    lines = [f"{rollup['customer']}: {rollup['dashboards']} dashboard(s)  " + "  ".join(
        f"{k} {v}" for k, v in rollup["tally"].items() if v)]
    elements = rollup.get("element_tally")
    if elements:
        by = elements["by_status"]
        lines.append(f"  elements ({elements['dashboards']} dashboard(s) with a status): {by['matches']:,} match, {by['differs']:,} differ, "
                     f"{by['not_compared']:,} not compared, {by['not_migrated']:,} not migrated")
    differing = [r for r in rollup["rows"] if r.get("outcome") == "figures_differ" and r.get("causes")]
    explained = [r for r in differing if not r["causes"]["values"][parity_causes.UNEXPLAINED]]
    if differing:
        lines.append(f"  figures_differ: {len(explained)} of {len(differing)} have every differing value on data that "
                     f"moved since Domo's figures were made or on letter case Power BI folds (row_count, stale_input, source_moved, run_date, case_collapse); the other {len(differing) - len(explained)} "
                     "have unexplained values: triage those first")
    for r in rollup["rows"]:
        detail = ""
        if r["outcome"] == "failed":
            detail = f"{r.get('error_stage')}: {r.get('error', '')[:90]}"
        elif r.get("parity"):
            detail = f"parity {r['parity']['ok']} ok / {r['parity']['error']} differ; {r.get('visuals')}/{r.get('cards')} cards"
            cov = r.get("coverage")
            if cov and cov["data_visuals"]:
                detail += f"; compared {cov['compared']}/{cov['data_visuals']} data visuals"
                if cov["compared_unfiltered"]:
                    detail += f" ({cov['compared_unfiltered']} without the dashboard filters)"
            if r.get("row_drift"):
                worst = max((d["percent"] for d in r["row_drift"] if d["percent"] is not None),
                            key=abs, default=None)
                detail += (f"; {len(r['row_drift'])} table(s) hold other row counts than Domo"
                           + (f" (largest {worst:+}%)" if worst is not None else ""))
            if r.get("stale"):
                detail += (f"; Domo's '{r['stale']['dataset'][:30]}' is {r['stale']['days']:g} days older than its input "
                           f"'{r['stale']['input'][:30]}'" + (f" (+{r['stale']['count'] - 1} more)" if r['stale']['count'] > 1 else ""))
            if r.get("causes"):
                detail += "; differing values: " + ", ".join(f"{n:,} {c}" for c, n in r["causes"]["values"].items() if n)
            if r.get("visual_errors"):
                detail += f"; {r['visual_errors']} visual(s) will not draw"
        elif r.get("cards") is not None:
            detail = f"{r.get('visuals')}/{r.get('cards')} cards, {r.get('open_reviews')} to review"
        elif r.get("note"):
            detail = r["note"]
        lines.append(f"  {r['outcome']:<15} {r['dashboard_id']:<12} {(r['name'] or '')[:42]:<42} {detail}")
    return "\n".join(lines)


def _built_from_this_scan(conn, run_id: str, estate_db_path: str | Path) -> bool:
    """Whether a stopped run can be carried on: it started after the estate scan was taken.

    A resume reuses the stages already done, so a run begun against an older scan carries that scan's
    dashboards, schemas and converted SQL forward (a 10-15 run failed at publish on a bug fixed since, and
    resuming it published the same files again).

    A run that recorded which scan it read (`stage.json` of its first stage) is compared with the scan the estate database
    holds now; one that did not is dated by the file's modification time."""
    row = db.get_run(conn, run_id)
    read = provenance.recorded(paths.runs_dir() / run_id, provenance.FIRST_STAGE).get("estate_scan")
    if read:                                    # a scan that cannot be read right now (being written) is not a different one
        now = provenance.estate_scan(estate_db_path)
        return now is None or read == now
    try:
        started = datetime.fromisoformat(row["started_at"])
        if started.tzinfo is None:
            started = started.replace(tzinfo=timezone.utc)
        scanned = datetime.fromtimestamp(Path(estate_db_path).stat().st_mtime, tz=timezone.utc)
    except (TypeError, KeyError, ValueError, OSError):
        return True
    return started >= scanned


def _restart_stage(conn, run_id: str, estate_db_path: str | Path, converter_redeployed: datetime | None) -> str | None:
    """The stage to carry an older run on from, or None to start the dashboard over (see `provenance.restart_stage`)."""
    if not _built_from_this_scan(conn, run_id, estate_db_path):
        return None
    try:
        project = db.get_project(conn, db.get_run(conn, run_id)["project_id"]) or {}
        return provenance.restart_stage(paths.runs_dir() / run_id, db.list_stages(conn, run_id), _started_at(conn, run_id),
                                        converter_changed_since=converter_redeployed,
                                        converter_now=provenance.converter_build(provenance.converter_url(project)))
    except (OSError, ValueError, KeyError, TypeError):
        return None


def _parse_time(text: str | None) -> datetime | None:
    if not text:
        return None
    moment = datetime.fromisoformat(text)
    return moment if moment.tzinfo else moment.replace(tzinfo=timezone.utc)


def _started_at(conn, run_id: str | None) -> datetime:
    """When a run began (UTC); the epoch when unknown."""
    try:
        started = datetime.fromisoformat(db.get_run(conn, run_id)["started_at"])
    except (TypeError, KeyError, ValueError):
        return datetime.fromtimestamp(0, tz=timezone.utc)
    return started if started.tzinfo else started.replace(tzinfo=timezone.utc)


def _handled_at(conn, run_id: str | None) -> datetime:
    """When a run was last worked on (UTC): when it finished, else when it began. A failed run resumed in this pass
    began long before the pass but finished in it, and must not be picked up again by the next process of the pass.
    The epoch when unknown, so a run we cannot date counts as older than any pass."""
    try:
        run = db.get_run(conn, run_id)
        stamps = [datetime.fromisoformat(run[key]) for key in ("started_at", "finished_at") if run.get(key)]
    except (TypeError, KeyError, ValueError, AttributeError):
        return datetime.fromtimestamp(0, tz=timezone.utc)
    if not stamps:
        return datetime.fromtimestamp(0, tz=timezone.utc)
    return max(s if s.tzinfo else s.replace(tzinfo=timezone.utc) for s in stamps)


def run_batch(
    conn,
    estate_db_path: str | Path,
    manifest: Manifest,
    selected: list[Selected],
    *,
    limit: int | None = None,
    force: bool = False,
    retry_failed: bool = True,
    rerun_unproven: bool = False,
    session_command: str | None = None,
    session_max_age_minutes: float = 120,
    max_minutes: float | None = None,
    pass_start: str | None = None,
    restart_from_change: bool = False,
    converter_redeployed: str | None = None,
    execute: Callable[..., dict[str, Any]] = runner.execute_run,
    say: Callable[[str], None] = print,
    should_stop: Callable[[], bool] | None = None,
    on_dashboard: Callable[[Selected, int], None] | None = None,
) -> dict[str, Any]:
    """Run the manifest's dashboards in order and return the final rollup.

    A dashboard whose latest run is proven is skipped (unless `force`), and so
    is one that finished unverified, partly proven or with differing figures (unless
    `rerun_unproven`: that is a fresh run, worth doing after fixes, not on every
    pass). One whose latest run stopped is resumed rather than started over; a
    failed one is resumed too when `retry_failed`. `limit` caps how many dashboards this
    call *starts*, `max_minutes` stops starting new ones after that long. `pass_start` (ISO time, UTC when it has no
    offset) marks a pass: a dashboard whose latest run began (or finished) at or after it was already handled in this pass,
    and is left alone whatever its outcome (a stopped run of this pass is still resumed; one from before it starts over,
    so it is built with the code of this pass). That lets a pass be run one dashboard per process.

    `restart_from_change` (with `pass_start`): a run from before the pass is not started over but resumed from the
    earliest stage that the code changed since it ran can affect (`provenance`, #274); `converter_redeployed` (ISO time)
    says the converter changed then, so a conversion older than that is redone too.

    `should_stop` is asked before each dashboard is started (the screen's Stop); `on_dashboard(selected, n)` is told which
    dashboard is being started as the n-th of this call.
    """
    pass_began = _parse_time(pass_start)
    started = time.monotonic()
    last_session = 0.0
    started_count = 0
    stopped: str | None = None

    def refresh_session(reason: str) -> bool:
        nonlocal last_session
        if not session_command:
            return True
        say(f"  refreshing the source session ({reason})")
        result = subprocess.run(session_command, shell=True, capture_output=True, text=True, timeout=600)  # noqa: S602 -- the operator's own command
        if result.returncode != 0:
            say(f"  session refresh failed (exit {result.returncode}): {(result.stderr or result.stdout)[-300:].strip()}")
            return False
        last_session = time.monotonic()
        return True

    for s in selected:
        if should_stop is not None and should_stop():       # before the skip checks: a stop is not held up by them
            stopped = "stopped on request"
            break
        rollup = build_rollup(conn, estate_db_path, manifest, selected)
        write_rollup(rollup)
        row = next(r for r in rollup["rows"] if r["dashboard_id"] == s.id)
        if row["outcome"] in ("no_cards", "no_data"):
            continue
        if pass_began is not None and row["outcome"] not in ("pending", "incomplete") and not force \
                and _handled_at(conn, row.get("run_id")) >= pass_began:
            continue
        # A proven dashboard the manifest wants run again in this pass, as a new run. Once per pass is the pass-start check: without
        # one a loop that starts one dashboard per call would start the first of them on every call and never reach the rest.
        again = s.id in manifest.rerun_proven and pass_began is not None
        if row["outcome"] == "proven" and not force and not again:
            continue
        if row["outcome"] == "failed" and not retry_failed and not force:
            continue
        if row["outcome"] in ("unverified", "figures_differ", "proven_partial") and not (rerun_unproven or force):
            continue
        if limit is not None and started_count >= limit:
            stopped = f"stopped after starting {limit} dashboard(s)"
            break
        if max_minutes is not None and (time.monotonic() - started) / 60 >= max_minutes:
            stopped = f"stopped: {max_minutes:g} minutes used"
            break
        if session_command and (last_session == 0.0 or (time.monotonic() - last_session) / 60 >= session_max_age_minutes):
            if not refresh_session("start" if last_session == 0.0 else "session is getting old"):
                stopped = "stopped: the source session could not be refreshed"
                break

        started_count += 1
        if on_dashboard is not None:
            on_dashboard(s, started_count)
        say(f"[{started_count}] {s.id} {s.name}  ({s.dataflows} dataflows, {s.source_rows:,} source rows)")
        try:
            # A run from before this pass carries the artefacts of older code (Hospital & Clinic Provider Profitability-SW
            # failed at publish on a measure/column clash that had been fixed since, and the resume rebuilt nothing).
            if row.get("run_id") and row["outcome"] in ("failed", "incomplete") and not force \
                    and (pass_began is None or _started_at(conn, row["run_id"]) >= pass_began) \
                    and _built_from_this_scan(conn, row["run_id"], estate_db_path):
                run_id = row["run_id"]
                say(f"  resuming {run_id}")
            elif restart_from_change and pass_began is not None and row.get("run_id") and not force and not again \
                    and (stage := _restart_stage(conn, row["run_id"], estate_db_path, _parse_time(converter_redeployed))):
                run_id = row["run_id"]
                db.reset_stages_from(conn, run_id, stage)
                say(f"  resuming {run_id} from {stage}")
            else:
                run_id = runner.prepare_run(conn, estate_db_path, s.id)["run_id"]
                say(f"  new run {run_id}")
            finished = execute(conn, run_id, estate_db_path)
            say(f"  -> {finished['status']}")
        except Exception as exc:  # noqa: BLE001 -- one dashboard must not stop the batch
            say(f"  -> crashed: {type(exc).__name__}: {exc}")

    rollup = build_rollup(conn, estate_db_path, manifest, selected)
    if stopped:
        rollup["stopped"] = stopped
    write_rollup(rollup)
    return rollup

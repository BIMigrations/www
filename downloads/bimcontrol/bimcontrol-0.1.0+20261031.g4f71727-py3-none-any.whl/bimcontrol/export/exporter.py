"""Writes an estate scan out as open specification files.

Reads only the scan (never the source platform), so it runs anywhere the
scan database does. The output is deterministic: lists are sorted by id and
object documents carry no timestamps, so re-exporting an unchanged estate
produces no diff. Only `manifest.json` records when it was generated.

Layout (see docs/pipeline/open-export.md for the contract):

    manifest.json              what was exported, counts, reconciliation
    schema/<kind>.schema.json  JSON Schema of every document kind
    dashboards/<id>-<slug>.json    pages, visuals (with fields, filters), dashboard filters
    cards/<id>-<slug>.json         visuals on no dashboard
    metrics/<dataset id>.json      Beast Modes, grouped by the dataset they belong to
    models/<id>-<slug>.json        datasets: columns, row-level access policies, lineage ids
    transformations/<id>-<slug>.json   dataflows: inputs, outputs, steps (and `sql`, with --sql-from)
    transformations/<id>-<slug>[.n].sql   the Redshift SQL of each output, with --sql-from
    access/principals.json     users and groups (no emails)
    catalog/{apps,alerts,accounts}.json
    lineage/objects.json       dashboard -> visual -> dataset -> transformation graph
    lineage/fields.jsonl       column -> metric -> visual edges, one per line

What it deliberately does not do yet: field-level lineage through a transformation's
steps. Both are listed under `limits` in the manifest.
"""

from __future__ import annotations

import json
import re
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from . import airbyte, coverage, portable_sql, powerbi_source
from ..estate.closure import card_chart_type, card_date_ranges, card_style, card_text, card_top_n, resolve_dashboard
from ..estate.reader import EstateObject, EstateReader
from .spec import FIELD_EDGE_SCHEMA, SCHEMAS, SPEC_ID, neutral_visual, validate

LIMITS = [
    "Transformations are exported as their steps (type, inputs, configuration). SQL is included for the dataflows a "
    "conversion run covered (`--sql-from`), written for Redshift and checked by it where the manifest says so.",
    "Lineage is field-level from dataset columns to metrics and visuals; it does not yet continue through a "
    "transformation's steps to the source columns.",
    "A metric's column dependencies are the backtick-quoted names in its expression, not a parsed syntax tree.",
    "Dashboard layout is in the source platform's grid units (x, y, w, h); it is not converted to pixels.",
    "User emails are left out of access/principals.json. A Power BI scan identifies people only by sign-in name (an e-mail "
    "address): their ids become a stable stand-in (`upn-` and a hash), the same person getting the same id everywhere, and the "
    "name shown is the display name the service gave. A person's name can itself identify them: review before publishing.",
    "SQL is also written in PostgreSQL syntax, the widely available dialect closest to ISO SQL (`*.portable.sql`, by sqlglot, optional "
    "extra `export`): the Redshift query parsed and re-written, parsed again to check it is a query, and not executed anywhere. "
    "ISO SQL itself does not cover dates or regular expressions, so each output lists the constructs outside a core ANSI set "
    "(`portable.not_portable`) and the manifest's `coverage.portable_sql` counts them. Each model also has a `CREATE TABLE` in ISO "
    "types (`models/*.sql`); Domo keeps no precision, so DECIMAL is a wide default.",
    "extract/ holds Airbyte Protocol definitions (source, connection-spec template, AirbyteCatalog, ConfiguredAirbyteCatalog) "
    "built from the scan. They have not been run on Airbyte; the scan holds no host, path or credential, so the templates "
    "carry placeholders, and their property names are not validated against each connector's own spec.",
]

_COLUMN_REF = re.compile(r"`([^`]+)`")
_METRIC_REF = re.compile(r"DOMO_BEAST_MODE\(\s*(\d+)\s*\)")
_STATIC_KINDS = {"HEADER": "text", "VARIABLE": "control", "BUTTON": "button"}
_LEAF_NOISE = {"object", "leaves"}


def slug(text: str | None) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9]+", "-", text or "").strip("-")[:60].strip("-")
    return cleaned.lower() or "unnamed"


def _file_stem(object_id: str, name: str | None) -> str:
    safe_id = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(object_id))
    return f"{safe_id}-{slug(name)}"


@dataclass
class ExportResult:
    out_dir: Path
    counts: dict[str, int] = field(default_factory=dict)
    reconciliation: dict[str, Any] = field(default_factory=dict)
    files: int = 0
    notes: list[str] = field(default_factory=list)      # things left out that the reader should know about

    @property
    def ok(self) -> bool:
        return bool(self.reconciliation.get("ok"))


def _source(platform: str, kind: str, object_id: str) -> dict[str, str]:
    return {"platform": platform, "type": kind, "id": str(object_id)}


class _Names:
    """Id -> display name for owners and cross references."""

    def __init__(self, reader: EstateReader):
        self.powerbi = reader.platform == "powerbi"
        self.users = {o.id: self.person(o.name) for o in reader.iter_objects("user")}
        self.datasets: dict[str, str | None] = {}

    def person(self, name: Any) -> Any:
        """A display name; on Power BI one that is an e-mail address (no display name was set) is the stand-in id."""
        if self.powerbi and isinstance(name, str) and "@" in name:
            return powerbi_source.principal_id(name)
        return name

    def principal(self, owner_id: Any) -> dict[str, Any] | None:
        if owner_id in (None, ""):
            return None
        return {"id": self.pid(owner_id), "name": self.users.get(str(owner_id))}

    def pid(self, user_id: Any) -> str | None:
        """The id a person carries in the export. Power BI identifies people by e-mail address, which is not
        published; those ids become a stable stand-in. Every other id is kept as it is."""
        return powerbi_source.principal_id(user_id) if self.powerbi else (None if user_id in (None, "") else str(user_id))


def _filter_doc(raw: dict[str, Any]) -> dict[str, Any]:
    return {
        "column": raw.get("column"), "operand": raw.get("operand"),
        "values": list(raw.get("values") or []), "data_type": raw.get("dataType"),
    }


def _visual_fields(card: EstateObject, metric_by_legacy: dict[str, str]) -> tuple[list, list, list, list, list[str]]:
    """`(fields, filters, sort, group_by, dataset ids)` from a card's saved query."""
    fields: list[dict[str, Any]] = []
    filters: list[dict[str, Any]] = []
    sort: list[dict[str, Any]] = []
    group_by: list[dict[str, Any]] = []
    datasets: list[str] = []

    def ref(entry: dict[str, Any]) -> dict[str, Any]:
        formula = entry.get("formulaId")
        return {"column": entry.get("column"), "metric": metric_by_legacy.get(formula) if formula else None,
                "metric_ref": formula}

    for entry in card.definition.get("subscriptions") or []:
        dataset = entry.get("dataSourceId")
        if dataset and str(dataset) not in datasets:
            datasets.append(str(dataset))
        sub = entry.get("subscription") or {}
        component = entry.get("componentName") or "main"
        for col in sub.get("columns") or []:
            fields.append({
                "role": str(col.get("mapping") or "").lower() or "value", "component": component,
                # Domo's own words: a column with no mapping is not a value (the role above says 'value' for it)
                "mapping": col.get("mapping") or None, "column_type": col.get("columnType") or None,
                **ref(col), "dataset": str(dataset) if dataset else None,
                "aggregation": col.get("aggregation") or None, "alias": col.get("alias") or None,
                "format": col.get("format") or None})
        for flt in sub.get("filters") or []:
            filters.append({**_filter_doc(flt), "label": None, "component": component})
        for item in sub.get("orderBy") or []:
            sort.append({**ref(item), "order": item.get("order"), "aggregation": item.get("aggregation") or None,
                         "component": component})
        for item in sub.get("groupBy") or []:
            group_by.append({**ref(item), "component": component})

    if not fields:  # the search-index shape, older scans
        for entry in card.raw.get("dataSubscriptions") or []:
            dataset = entry.get("dataSourceId")
            if dataset and str(dataset) not in datasets:
                datasets.append(str(dataset))
            for col in entry.get("columns") or []:
                if (col.get("columnType") or "SELECT").upper() != "SELECT" or not col.get("name"):
                    continue
                fields.append({
                    "role": str(col.get("mapping") or "").lower() or "value", "component": "main",
                    "column": col["name"], "metric": None, "metric_ref": None,
                    "dataset": str(dataset) if dataset else None,
                    "aggregation": col.get("aggregation") or None, "alias": col.get("alias") or None,
                    "format": None})
    return fields, filters, sort, group_by, datasets


def _date_range_doc(saved: dict[str, Any]) -> dict[str, Any]:
    """A card's saved date range in neutral keys: `type` is Domo's (ROLLING_PERIOD, INTERVAL_OFFSET, PERIOD_TO_DATE,
    FIXED_RANGE ...), `interval` the unit (DAY, MONTH, YEAR ...), `offset` and `count` how far back and how many."""
    window = saved.get("dateTimeRange") or {}
    return {"column": (saved.get("column") or {}).get("column"), "type": window.get("dateTimeRangeType"),
            "interval": window.get("interval"), "offset": window.get("offset"), "count": window.get("count"),
            "begin": window.get("beginDate"), "end": window.get("endDate"), "periods": saved.get("periods")}


def _card_calculations(card: EstateObject) -> list[dict[str, Any]]:
    """The calculations defined on the card itself (`calculation_<uuid>`) that its query reads: Domo keeps their
    formula in the card, not in a dataset, so without them a field named `calculation_...` means nothing."""
    formulas = card.definition.get("formulas") or {}
    used = json.dumps(card.definition.get("subscriptions") or [])
    return [{"id": key, "name": value.get("name"), "language": "domo_beast_mode", "expression": value.get("formula"),
             "data_type": value.get("dataType"), "persisted_on_dataset": bool(value.get("persistedOnDataSource"))}
            for key, value in sorted(formulas.items())
            if key.startswith("calculation_") and isinstance(value, dict) and key in used]


def _time_grains(card: EstateObject) -> list[dict[str, Any]]:
    """The date columns the card cuts by period, one entry per `DATE_GRAIN` column of a component.

    A calendar field the card groups by (Domo's `CalendarMonth` is not a column of the dataset: it is the month of the date
    column named beside it) names that date column in `calendar_field`; a date grain with no calendar field beside it has
    `calendar_field` null, and the migration says it does not apply it. `grain` is the period Domo saved (`extras[0]`)."""
    from ..targets.powerbi import calendar  # noqa: PLC0415 -- the one table of Domo's calendar fields

    found: list[dict[str, Any]] = []
    for subscription in card.raw.get("dataSubscriptions") or []:
        component = subscription.get("name") or "main"
        grains = [c for c in subscription.get("columns") or []
                  if (c.get("columnType") or "").upper() == "DATE_GRAIN" and c.get("name")]
        if not grains:
            continue
        extras: dict[str, Any] = {}
        for column in grains:
            extras.setdefault(column["name"], (column.get("extras") or [None])[0])
        cut = calendar.calendar_columns({"data_subscriptions": [subscription]})
        found += [{"date_column": item.date_column, "calendar_field": item.field, "grain": extras.get(item.date_column),
                   "component": component} for item in cut]
        used = {item.date_column for item in cut}
        found += [{"date_column": name, "calendar_field": None, "grain": grain, "component": component}
                  for name, grain in extras.items() if name not in used]
    return found


def build_powerbi_visual(card: EstateObject, platform: str, names: _Names, metric_ids: set[str],
                         dataset_ids: list[str]) -> dict[str, Any]:
    """A Power BI visual (one PBIR visual file, or a pinned dashboard tile) as the export's visual."""
    definition = card.definition
    visual_file = definition.get("visual") or {}
    visual_type = card.row.get("type")
    kind, variant = powerbi_source.neutral_visual(visual_type)
    dataset = dataset_ids[0] if dataset_ids else None
    return {
        "id": card.id, "title": card.name if card.name != visual_type else None, "description": None,
        "type": kind, "variant": variant,
        "source": {**_source(platform, "card", card.id), "chart_type": visual_type, "card_type": None},
        "owner": names.principal(card.row.get("owner_id")),
        "datasets": list(dataset_ids),
        "fields": powerbi_source.visual_fields(definition, dataset, metric_ids),
        "filters": powerbi_source.visual_filters(visual_file), "sort": [], "group_by": [], "drill": [],
        "text": powerbi_source.text_of_textbox(visual_file) if kind == "text" else None,
    }


def build_visual(card: EstateObject, platform: str, names: _Names, metric_by_legacy: dict[str, str],
                 dataset_ids: list[str], drill: list[dict[str, Any]]) -> dict[str, Any]:
    chart_type = card_chart_type(card)
    card_type = card.row.get("type")
    kind, variant = neutral_visual(chart_type, card_type)
    fields, filters, sort, group_by, sub_datasets = _visual_fields(card, metric_by_legacy)
    datasets = list(dict.fromkeys([*dataset_ids, *sub_datasets]))
    definition = card.definition
    return {
        "id": card.id,
        "title": definition.get("title") or card.name,
        "description": definition.get("description") or None,
        "type": kind, "variant": variant,
        "source": {**_source(platform, "card", card.id), "chart_type": chart_type, "card_type": card_type},
        "owner": names.principal(card.row.get("owner_id")),
        "datasets": datasets,
        "fields": fields, "filters": filters, "sort": sort, "group_by": group_by,
        "drill": drill,
        "text": (card_text(card) or None) if kind == "text" else None,
        "date_ranges": [_date_range_doc(r) for r in card_date_ranges(card)],
        "row_limit": card_top_n(card),
        "calculations": _card_calculations(card),
        "time_grains": _time_grains(card),
        "style": card_style(card),
    }


def build_pages(layout: dict[str, Any] | None, title: str | None, card_ids: list[str]) -> list[dict[str, Any]]:
    """The dashboard's pages in neutral terms: tabs become pages, items carry
    the source grid. Cards the layout never places are appended to the first
    page without a grid so no visual is lost."""
    layout = layout or {}
    template = (layout.get("standard") or {}).get("template")
    content = layout.get("content") or []
    card_by_key = {c.get("contentKey"): str(c["cardId"]) for c in content if c.get("cardId") is not None}
    text_by_key = {c.get("contentKey"): c.get("text") for c in content if c.get("text")}

    def grid(item: dict[str, Any]) -> dict[str, Any]:
        return {"x": item.get("x") or 0, "y": item.get("y") or 0,
                "w": item.get("width") or 0, "h": item.get("height") or 0}

    def items_of(entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for entry in entries:
            kind = entry.get("type")
            key = entry.get("contentKey")
            if kind == "CARD" and card_by_key.get(key):
                out.append({"kind": "visual", "visual": card_by_key[key], "grid": grid(entry)})
            elif kind in _STATIC_KINDS:
                out.append({"kind": _STATIC_KINDS[kind], "text": text_by_key.get(key), "grid": grid(entry)})
        return out

    def tab_pages(entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
        pages: list[dict[str, Any]] = []
        for entry in entries:
            if entry.get("type") != "TABS":
                continue
            for tab in entry.get("children") or []:
                if tab.get("type") != "TAB_CONTENT":
                    continue
                pages.append({"title": text_by_key.get(tab.get("contentKey")) or "Tab",
                              "items": items_of(tab.get("children") or [])})
                pages += tab_pages(tab.get("children") or [])
        return pages

    pages: list[dict[str, Any]]
    if isinstance(template, list):
        main = items_of(template)
        tabs = tab_pages(template)
        pages = ([{"title": title or "Dashboard", "items": main}] if main or not tabs else []) + tabs
    else:
        pages = [{"title": title or "Dashboard", "items": [
            {"kind": "visual", "visual": card_by_key[k]} for k in card_by_key]}]

    placed = {i["visual"] for p in pages for i in p["items"] if i["kind"] == "visual"}
    leftover = [c for c in card_ids if c not in placed]
    if leftover:
        pages[0]["items"] += [{"kind": "visual", "visual": c} for c in leftover]
    return pages


def build_app(app: EstateObject, platform: str, names: _Names, exported_dashboards: set[str]) -> dict[str, Any]:
    """An app as a small product: its screens (each a dashboard), its navigation menu and its theme."""
    views = [{"id": str(v.get("viewId")), "title": v.get("title"),
              "parent_id": str(v["parentViewId"]) if v.get("parentViewId") is not None else None,
              "order": v.get("viewOrder"), "visible": v.get("visible"),
              "dashboard_exported": str(v.get("viewId")) in exported_dashboards}
             for v in app.json_column("views_json") or [] if v.get("viewId") is not None]
    navigation = [{"entity": n.get("entity"), "entity_id": str(n["entityId"]) if n.get("entityId") is not None else None,
                   "title": n.get("title"), "description": n.get("description"), "order": n.get("navOrder"),
                   "visible": n.get("visible"), "icon": n.get("icon"), "icon_position": n.get("iconPosition"),
                   "interaction": n.get("interaction"), "style": n.get("style")}
                  for n in app.json_column("navigations_json") or []]
    return {
        "spec": SPEC_ID, "kind": "app", "id": app.id, "name": app.name, "source": _source(platform, "app", app.id),
        "app_type": app.row.get("type"), "owner": names.principal(app.row.get("owner_id")),
        "landing_dashboard": app.row.get("landing_dashboard_id") or None,
        "views": views, "navigation": navigation, "theme": app.json_column("theme_json"),
    }


def build_metric(cf: EstateObject, platform: str, used_by: dict[str, list[str]],
                 also_datasets: list[str], scope: str) -> dict[str, Any]:
    expression = cf.row.get("formula") or cf.definition.get("expression")
    columns = list(dict.fromkeys(_COLUMN_REF.findall(expression or "")))
    metrics = list(dict.fromkeys(_METRIC_REF.findall(expression or "")))
    return {
        "id": cf.id, "name": cf.name,
        "language": cf.row.get("formula_language"), "expression": expression,
        "data_type": cf.row.get("data_type"), "scope": scope,
        "status": cf.row.get("status"),
        "locked": bool(cf.row["is_locked"]) if cf.row.get("is_locked") is not None else None,
        "depends_on": {"columns": columns, "metrics": metrics},
        "used_by": used_by, "also_datasets": also_datasets,
        "source": _source(platform, "calculated_field", cf.id),
    }


def build_dataset(ds: EstateObject, platform: str, names: _Names, producer: str | None,
                  consumers: list[str], visuals: list[str]) -> dict[str, Any]:
    columns = ds.json_column("schema_columns_json") or []
    policies = []
    if names.powerbi:
        policies = powerbi_source.policies(ds.json_column("pdp_json"))
    for policy in [] if names.powerbi else ds.json_column("pdp_json") or []:
        policies.append({
            "id": policy.get("filterGroupId"), "name": policy.get("name"), "type": policy.get("type"),
            "user_ids": [str(u) for u in policy.get("userIds") or []],
            "group_ids": [str(g) for g in policy.get("groupIds") or []],
            "parameters": [{"column": p.get("name"), "type": p.get("type"), "operator": p.get("operator"),
                            "values": list(p.get("values") or []), "negated": bool(p.get("not"))}
                           for p in policy.get("parameters") or []],
        })
    return {
        "spec": SPEC_ID, "kind": "dataset", "id": ds.id, "name": ds.name,
        "source": _source(platform, "dataset", ds.id),
        "provider": ds.row.get("provider_type"), "rows": ds.row.get("row_count"),
        "deleted": bool(ds.row["is_deleted"]) if ds.row.get("is_deleted") is not None else None,
        "created_at": ds.row.get("created_at"), "updated_at": ds.row.get("updated_at"),
        "owner": names.principal(ds.row.get("owner_id")),
        "columns": [{"name": c.get("name"), "type": c.get("type"), "visible": c.get("visible")}
                    for c in columns if c.get("name")],
        "access": {"policies": policies},
        "lineage": {"produced_by": producer, "consumed_by": sorted(consumers),
                    "used_by_visuals": sorted(visuals)},
    }


def build_transformation(flow: EstateObject, platform: str, names: _Names,
                         dataset_names: dict[str, str | None], input_ids: list[str],
                         output_ids: list[str]) -> dict[str, Any]:
    definition = flow.definition
    steps = powerbi_source.dataflow_steps(definition) if names.powerbi else []
    for action in [] if names.powerbi else definition.get("actions") or []:
        if not isinstance(action, dict) or not action.get("id"):
            continue
        depends = list(action.get("dependsOn") or [])
        for key in ("input", "inputs"):
            value = action.get(key)
            depends += [value] if isinstance(value, str) else [v for v in value or [] if isinstance(v, str)]
        known = {"id", "type", "name", "dependsOn", "input", "inputs", "gui"}
        steps.append({
            "id": str(action["id"]), "type": str(action.get("type") or "unknown"), "name": action.get("name"),
            "depends_on": list(dict.fromkeys(depends)),
            "config": {k: v for k, v in action.items() if k not in known},
        })
    execution = definition.get("lastExecution") or {}
    return {
        "spec": SPEC_ID, "kind": "transformation", "id": flow.id, "name": flow.name,
        "source": _source(platform, "dataflow", flow.id), "engine": flow.row.get("engine"),
        "owner": names.principal(flow.row.get("owner_id")),
        "deleted": bool(flow.row["is_deleted"]) if flow.row.get("is_deleted") is not None else None,
        "modified_at": flow.row.get("modified_at"),
        "last_execution": {"state": flow.row.get("last_execution_state"),
                           "failed": bool(flow.row["last_execution_failed"])
                           if flow.row.get("last_execution_failed") is not None else None,
                           "begin": execution.get("beginTime"), "end": execution.get("endTime")}
        if flow.row.get("last_execution_state") else None,
        "inputs": [{"dataset": i, "name": dataset_names.get(i)} for i in input_ids],
        "outputs": [{"dataset": o, "name": dataset_names.get(o)} for o in output_ids],
        "steps": steps,
    }


def _drill_for(card: EstateObject) -> list[dict[str, Any]]:
    from ..estate.closure import card_drill_views  # noqa: PLC0415 -- only cards with drill paths need it
    if not card.definition.get("drillPath"):
        return []
    return card_drill_views(card)


class SqlConversions:
    """The SQL converter runs (`convert_dataflows` artefacts) produced, by dataflow id.

    Each directory holds `conversion.json` and the `dataflow_<id>_<output>.sql` files it names. Nothing else is read.
    With several directories (oldest first) a dataflow takes the best conversion found: one with outputs that all passed
    the warehouse's check beats one that did not, and between equals the later directory wins. A customer's dataflows are
    converted by the dashboards that read them, so the runs of a pass together cover what a convert-all run would.
    """

    def __init__(self, directories: str | Path | Iterable[str | Path]):
        if isinstance(directories, (str, Path)):
            directories = [directories]
        self.flows: dict[str, tuple[Path, dict[str, Any]]] = {}
        self.tables: dict[Path, dict[str, str]] = {}      # directory -> {source dataset id (uuid): warehouse table}
        self.skipped: list[tuple[Path, str]] = []         # directories whose conversion.json could not be read
        self.portable_results: list[dict[str, Any]] = []  # one per rendered query, for the manifest's coverage
        for directory in directories:
            directory = Path(directory).expanduser()
            try:
                payload = json.loads((directory / "conversion.json").read_text(encoding="utf-8"))
                flows = [(str(flow["dataflow_id"]), flow) for flow in payload.get("dataflows") or []]
            except (OSError, ValueError, KeyError, TypeError, AttributeError) as exc:
                # a half-written file (an export overlapping a convert stage) or one of an older format
                self.skipped.append((directory, f"{type(exc).__name__}: {exc}"))
                continue
            for key, flow in flows:
                kept = self.flows.get(key)
                if kept is None or self._rank(flow) >= self._rank(kept[1]):
                    self.flows[key] = (directory, flow)
            self.tables[directory] = payload.get("resolutions") or {}

    @staticmethod
    def _rank(flow: dict[str, Any]) -> tuple[int, int, int]:
        outputs = flow.get("outputs") or []
        # SQL written by the converter alone (never run against data) ranks below any run's conversion of the dataflow
        return (1 if outputs else 0, 1 if outputs and all(o.get("validated") for o in outputs) else 0,
                0 if flow.get("converter_only") else 1)

    def _portable(self, sql_text: str, rel: str, write_sql: Any) -> dict[str, Any]:
        """The neutral rendering of one converted query, written beside the Redshift original."""
        result = portable_sql.render(sql_text)
        file = None
        if result["rendered"] is not None:
            file = rel[: -len(".sql")] + ".portable.sql"
            write_sql(file, result["rendered"])
        self.portable_results.append(result)
        return {"file": file, "dialect": portable_sql.RENDERED_DIALECT, "parsed": result["parsed"],
                "roundtrip_ok": result["roundtrip_ok"], "not_portable": result["not_portable"], "error": result["error"]}

    def sql_doc(self, flow_id: str, stem: str, dataset_names: dict[str, str | None],
                write_sql: Any) -> dict[str, Any] | None:
        """The `sql` part of a transformation, and the files written through `write_sql(rel, text)`."""
        found = self.flows.get(flow_id)
        if found is None:
            return None
        directory, flow = found
        outputs = []
        many = len(flow.get("outputs") or []) > 1
        for index, output in enumerate(flow.get("outputs") or [], start=1):
            artefact = directory / str(output.get("artefact") or "")
            rel = None
            if output.get("artefact") and artefact.is_file():
                rel = f"transformations/{stem}{'.' + str(index) if many else ''}.sql"
                sql_text = artefact.read_text(encoding="utf-8")
                write_sql(rel, sql_text)
                portable = self._portable(sql_text, rel, write_sql)
            else:
                portable = None
            outputs.append({
                "dataset": output.get("data_source_id"), "name": output.get("destination_name"), "file": rel,
                "checked_by_warehouse": None if flow.get("converter_only") else output.get("validated"), "check_error": output.get("validation_error"),
                "columns": [{"name": c.get("name"), "type": c.get("type")} for c in output.get("columns") or []],
                "portable": portable,
            })
        text = "\n".join((directory / o["artefact"]).read_text(encoding="utf-8")
                         for o in flow.get("outputs") or []
                         if o.get("artefact") and (directory / o["artefact"]).is_file())
        table_map = {table: {"dataset": source, "name": dataset_names.get(source)}
                     for source, table in sorted(self.tables.get(directory, {}).items()) if table and table in text}
        return {
            "dialect": "redshift", "basis": "converter_only" if flow.get("converter_only") else "converted_run",
            "outputs": outputs, "table_map": table_map,
            "unsupported_steps": flow.get("unsupported_tile_types") or [],
            "unresolved_inputs": [{"dataset": u.get("data_source_id"), "name": u.get("name"), "reason": u.get("reason")}
                                  for u in flow.get("unresolved_sources") or []],
        }


class Exporter:
    """One export run. Construct, call `run()`."""

    def __init__(self, reader: EstateReader, out_dir: str | Path, dashboard_ids: Iterable[str] | None = None,
                 sql_from: str | Path | list[str | Path] | None = None):
        self.reader = reader
        self.conversions = SqlConversions(sql_from) if sql_from else None
        self.platform = reader.platform
        self.out = Path(out_dir).expanduser()
        self.only = [str(d) for d in dashboard_ids] if dashboard_ids is not None else None
        self.files = 0
        self.written: dict[str, int] = defaultdict(int)

    # ---- file helpers ----
    def _write(self, rel: str, doc: Any) -> None:
        path = self.out / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(doc, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        self.files += 1

    def _write_text(self, rel: str, text: str) -> None:
        path = self.out / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text if text.endswith("\n") else text + "\n", encoding="utf-8")
        self.files += 1

    def _write_kind(self, kind: str, rel: str, doc: dict[str, Any]) -> None:
        self._write(rel, doc)
        self.written[kind] += 1

    # ---- scope ----
    def _scope(self) -> dict[str, set[str]] | None:
        """Ids in scope when exporting a subset of dashboards; None = everything."""
        if self.only is None:
            return None
        scope: dict[str, set[str]] = {k: set() for k in ("dashboard", "card", "dataset", "dataflow", "calculated_field")}
        for dashboard_id in self.only:
            closure = resolve_dashboard(self.reader, dashboard_id)
            scope["dashboard"].add(closure.dashboard.id)
            scope["card"].update(c.id for c in closure.cards)
            scope["dataset"].update(d.id for d in closure.datasets)
            scope["dataflow"].update(f.id for f in closure.dataflows)
            scope["calculated_field"].update(c.id for c in closure.calculated_fields)
        return scope

    def run(self) -> ExportResult:
        reader = self.reader
        platform = self.platform
        scope = self._scope()
        names = _Names(reader)

        def keep(kind: str, object_id: str) -> bool:
            return scope is None or object_id in scope[kind]

        dashboards = [d for d in reader.iter_objects("dashboard") if keep("dashboard", d.id)]
        cards = {c.id: c for c in reader.iter_objects("card") if keep("card", c.id)}
        datasets = {d.id: d for d in reader.iter_objects("dataset") if keep("dataset", d.id)}
        flows = {f.id: f for f in reader.iter_objects("dataflow") if keep("dataflow", f.id)}
        metrics = {m.id: m for m in reader.iter_objects("calculated_field") if keep("calculated_field", m.id)}
        names.datasets = {i: d.name for i, d in datasets.items()}

        metric_by_legacy = {m.definition["legacyId"]: m.id for m in metrics.values() if m.definition.get("legacyId")}

        # ---- edges, indexed once ----
        card_dashboards: dict[str, list[str]] = defaultdict(list)
        dashboard_cards: dict[str, list[str]] = defaultdict(list)
        dataset_cards: dict[str, list[str]] = defaultdict(list)
        card_datasets: dict[str, list[str]] = defaultdict(list)
        producer: dict[str, str] = {}
        consumers: dict[str, list[str]] = defaultdict(list)
        flow_inputs: dict[str, list[str]] = defaultdict(list)
        flow_outputs: dict[str, list[str]] = defaultdict(list)
        metric_cards: dict[str, list[str]] = defaultdict(list)
        metric_datasets: dict[str, list[str]] = defaultdict(list)
        metric_refs: dict[str, set[str]] = defaultdict(set)      # metric -> metrics its expression uses
        metric_used_by: dict[str, set[str]] = defaultdict(set)   # metric -> metrics that use it
        dashboard_apps: dict[str, list[str]] = defaultdict(list)
        graph_edges: list[tuple[str, str, str, str, str]] = []
        for e in reader.iter_edges(exclude_types=("owns",)):
            if e.edge_type == "part_of" and e.src_type == "card":
                card_dashboards[e.src_id].append(e.dst_id)
                dashboard_cards[e.dst_id].append(e.src_id)
            elif e.edge_type == "visualized_by" and e.dst_type == "card":
                dataset_cards[e.src_id].append(e.dst_id)
                card_datasets[e.dst_id].append(e.src_id)
            elif e.edge_type == "produces":
                producer[e.dst_id] = e.src_id
                flow_outputs[e.src_id].append(e.dst_id)
            elif e.edge_type == "consumed_by":
                consumers[e.src_id].append(e.dst_id)
                flow_inputs[e.dst_id].append(e.src_id)
            elif e.edge_type == "used_by_calculated_field":
                if e.src_type == "card":
                    metric_cards[e.dst_id].append(e.src_id)
                elif e.src_type == "dataset":
                    metric_datasets[e.dst_id].append(e.src_id)
                elif e.src_type == "beast_mode":
                    metric_refs[e.dst_id].add(e.src_id)
                    metric_used_by[e.src_id].add(e.dst_id)
            elif e.edge_type == "opened_by" and e.src_type == "dashboard":
                dashboard_apps[e.src_id].append(e.dst_id)
            if e.edge_type != "used_by_calculated_field":
                graph_edges.append((e.src_type, e.src_id, e.dst_type, e.dst_id, e.edge_type))

        def visual_of(card: EstateObject) -> dict[str, Any]:
            if names.powerbi:
                return build_powerbi_visual(card, platform, names, set(metrics), sorted(card_datasets.get(card.id, [])))
            return build_visual(card, platform, names, metric_by_legacy, sorted(card_datasets.get(card.id, [])), _drill_for(card))

        # ---- dashboards (with their visuals) ----
        on_dashboard: set[str] = set()
        visual_docs: list[dict[str, Any]] = []
        for dash in dashboards:
            card_ids = sorted(c for c in dashboard_cards.get(dash.id, []) if c in cards)
            on_dashboard.update(card_ids)
            visuals = [visual_of(cards[c]) for c in card_ids]
            # The order the scan lists the dashboard's cards in is the order the migration builds them in (it decides
            # which card's sort a shared column takes and where the slicers go). The files are sorted by id; this keeps it.
            rank = {e.src_id: n for n, e in enumerate(
                e for e in reader.edges_to("dashboard", dash.id, edge_type="part_of") if e.src_type == "card")}
            for visual in visuals:
                visual["order"] = rank.get(visual["id"])
            visual_docs += visuals
            children = [e.dst_id for e in reader.edges_from("dashboard", dash.id, edge_type="parent_of")]
            doc = {
                "spec": SPEC_ID, "kind": "dashboard", "id": dash.id, "name": dash.name,
                "source": _source(platform, "dashboard", dash.id),
                "owner": names.principal(dash.row.get("owner_id")),
                "parent_id": dash.row.get("parent_dashboard_id") or None,
                "children": sorted(children), "apps": sorted(dashboard_apps.get(dash.id, [])),
                "pages": (powerbi_source.pages(dash.json_column("layout_json"), dash.name, card_ids, {})
                          if names.powerbi else build_pages(dash.json_column("layout_json"), dash.name, card_ids)),
                "filters": [({"column": f.get("field"), "operand": f.get("filterType") or "unknown", "values": [],
                              "data_type": None, "label": f.get("label"), "type": f.get("filterType")}
                             if names.powerbi else
                             {**_filter_doc(f.get("raw") or {"column": f.get("field")}),
                              "label": f.get("label"), "type": f.get("filterType")})
                            for f in dash.json_column("filters_json") or []],
                "visuals": visuals,
            }
            self._write_kind("dashboards", f"dashboards/{_file_stem(dash.id, dash.name)}.json", doc)

        # ---- cards on no dashboard ----
        for card_id in sorted(cards):
            if card_id in on_dashboard:
                continue
            visual = visual_of(cards[card_id])
            visual_docs.append(visual)
            self._write_kind("standalone_cards", f"cards/{_file_stem(card_id, visual['title'])}.json",
                             {"spec": SPEC_ID, "kind": "visual", **visual})

        # ---- metrics, grouped by dataset ----
        by_dataset: dict[str | None, list[dict[str, Any]]] = defaultdict(list)
        for metric_id in sorted(metrics):
            cf = metrics[metric_id]
            homes = sorted(d for d in metric_datasets.get(metric_id, []) if d in datasets)
            home = homes[0] if homes else None
            scope_name = "dataset" if home else ("card" if metric_cards.get(metric_id) else "unattached")
            used_by = {"cards": sorted(c for c in metric_cards.get(metric_id, []) if c in cards),
                       "metrics": sorted(metric_used_by.get(metric_id, ()))}
            built = build_metric(cf, platform, used_by, homes[1:], scope_name)
            if names.powerbi:  # DAX, not a Beast Mode: its references are Table[Column] and [Measure]
                own = {m.name: m.id for m in metrics.values() if home and m.id.startswith(f"{home}:")
                       and m.definition.get("kind") == "measure"}
                built["depends_on"] = powerbi_source.dax_dependencies(built["expression"], own)
            built["depends_on"]["metrics"] = sorted(set(built["depends_on"]["metrics"]) | metric_refs.get(metric_id, set()))
            by_dataset[home].append(built)
        for home in sorted(by_dataset, key=lambda h: (h is None, h or "")):
            doc = {"spec": SPEC_ID, "kind": "metrics",
                   "dataset": {"id": home, "name": names.datasets.get(home)} if home else None,
                   "metrics": by_dataset[home]}
            self._write("metrics/" + (f"{_file_stem(home, names.datasets.get(home))}.json" if home else "_unattached.json"), doc)
            self.written["metrics"] += len(doc["metrics"])
            self.written["metric_files"] += 1

        # ---- models and transformations ----
        for ds_id in sorted(datasets):
            ds = datasets[ds_id]
            doc = build_dataset(ds, platform, names, producer.get(ds_id), consumers.get(ds_id, []),
                                dataset_cards.get(ds_id, []))
            stem = _file_stem(ds_id, ds.name)
            ddl = portable_sql.create_table(ds.name or ds_id, ds.json_column("schema_columns_json") or [])
            doc["schema_sql"] = {"file": f"models/{stem}.sql" if ddl["sql"] else None, "dialect": "iso",
                                 "guessed_types": ddl["guessed"]}
            if ddl["sql"]:
                self._write_text(f"models/{stem}.sql", ddl["sql"])
                self.written["model_ddl"] += 1
            self._write_kind("datasets", f"models/{stem}.json", doc)
        self._write_extracts(datasets)
        all_dataset_names = {d.id: d.name for d in reader.iter_objects("dataset")}
        for flow_id in sorted(flows):
            flow = flows[flow_id]
            doc = build_transformation(flow, platform, names, all_dataset_names,
                                       sorted(flow_inputs.get(flow_id, [])), sorted(flow_outputs.get(flow_id, [])))
            stem = _file_stem(flow_id, flow.name)
            if self.conversions is not None:
                doc["sql"] = self.conversions.sql_doc(flow_id, stem, all_dataset_names, self._write_text)
                if doc["sql"] is not None:
                    self.written["transformation_sql"] += sum(1 for o in doc["sql"]["outputs"] if o["file"])
            self._write_kind("transformations", f"transformations/{stem}.json", doc)

        # ---- access and catalog ----
        if scope is None:
            self._write_kind("principals", "access/principals.json", {
                "spec": SPEC_ID, "kind": "principals",
                "users": [{"id": names.pid(u.id), "name": names.person(u.name), "role": u.row.get("role"), "title": u.row.get("title")}
                          for u in reader.iter_objects("user")],
                "groups": [{"id": g.id, "name": g.name} for g in reader.iter_objects("group")]})
            apps = [{"id": a.id, "name": a.name, "type": a.row.get("type"),
                     "owner": names.principal(a.row.get("owner_id")),
                     "landing_dashboard": a.row.get("landing_dashboard_id") or None}
                    for a in reader.iter_objects("app")]
            alerts = [{"id": a.id, "name": a.name, "rule": a.row.get("rule"), "resource_type": a.row.get("resource_type"),
                       "resource_id": a.row.get("resource_id"), "disabled": bool(a.row.get("disabled")),
                       "owner": names.principal(a.row.get("owner_id"))} for a in reader.iter_objects("alert")]
            accounts = [{"id": a.id, "name": a.name, "connector_type": a.row.get("connector_type"),
                         "owner": names.principal(a.row.get("owner_id"))} for a in reader.iter_objects("account")]
            for kind, items in (("apps", apps), ("alerts", alerts), ("accounts", accounts)):
                self._write_kind(kind, f"catalog/{kind}.json", {"spec": SPEC_ID, "kind": kind, "items": items})
            exported_dashboards = {d.id for d in dashboards}
            for app in reader.iter_objects("app"):
                self._write_kind("app_documents", f"apps/{_file_stem(app.id, app.name)}.json",
                                 build_app(app, platform, names, exported_dashboards))

        # ---- lineage ----
        node_types: dict[str, str | None] = {}
        for dash in dashboards:
            node_types[f"dashboard:{dash.id}"] = dash.name
        for c in cards.values():
            node_types[f"card:{c.id}"] = c.name
        for d in datasets.values():
            node_types[f"dataset:{d.id}"] = d.name
        for f in flows.values():
            node_types[f"dataflow:{f.id}"] = f.name
        edges_out = sorted({(f"{st}:{si}", f"{dt}:{di}", et) for st, si, dt, di, et in graph_edges
                            if f"{st}:{si}" in node_types and f"{dt}:{di}" in node_types})
        self._write("lineage/objects.json", {
            "spec": SPEC_ID, "kind": "lineage",
            "nodes": [{"id": n, "type": n.split(":", 1)[0], "name": node_types[n]} for n in sorted(node_types)],
            "edges": [{"from": a, "to": b, "type": t} for a, b, t in edges_out]})
        self.written["lineage_edges"] = len(edges_out)
        self.written["lineage_nodes"] = len(node_types)

        field_edges: set[tuple[str, str, str]] = set()

        def add_visual_edges(visual: dict[str, Any]) -> None:
            target = f"visual:{visual['id']}"
            for fld in visual["fields"] + visual["sort"] + visual["group_by"]:
                if fld.get("metric"):
                    field_edges.add((f"metric:{fld['metric']}", target, "metric_in_visual"))
                elif fld.get("column"):
                    dataset = fld.get("dataset") or (visual["datasets"][0] if len(visual["datasets"]) == 1 else None)
                    if dataset:
                        field_edges.add((f"column:{dataset}.{fld['column']}", target, "column_in_visual"))
        for visual in visual_docs:
            add_visual_edges(visual)
        for home, items in by_dataset.items():
            for m in items:
                for dataset in ([home] if home else []) + m["also_datasets"]:
                    for col in m["depends_on"]["columns"]:
                        field_edges.add((f"column:{dataset}.{col}", f"metric:{m['id']}", "column_in_metric"))
                for other in m["depends_on"]["metrics"]:
                    field_edges.add((f"metric:{other}", f"metric:{m['id']}", "metric_in_metric"))
        lines = [json.dumps({"from": a, "to": b, "type": t}, ensure_ascii=False) for a, b, t in sorted(field_edges)]
        path = self.out / "lineage" / "fields.jsonl"
        path.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")
        self.files += 1
        self.written["field_edges"] = len(lines)

        # ---- schemas, manifest ----
        for kind, schema in SCHEMAS.items():
            self._write(f"schema/{kind}.schema.json", {"$schema": "https://json-schema.org/draft/2020-12/schema",
                                                       "title": f"{SPEC_ID} {kind}", **schema})
        self._write("schema/field-edge.schema.json", {"$schema": "https://json-schema.org/draft/2020-12/schema",
                                                      "title": f"{SPEC_ID} field edge", **FIELD_EDGE_SCHEMA})
        return self._finish(scope)

    def _write_extracts(self, datasets: dict[str, EstateObject]) -> None:
        """extract/<unit>.json per connector account (or connector type), extract/index.json for all."""
        reader, platform = self.reader, self.platform
        accounts = {a.id: a for a in reader.iter_objects("account")}
        feeding: dict[str, list[str]] = defaultdict(list)  # dataset -> accounts an edge says feed it
        for e in reader.iter_edges(exclude_types=("owns",)):
            if e.edge_type == "feeds" and e.src_type == "account":
                feeding[e.dst_id].append(e.src_id)
        units: dict[str, dict[str, Any]] = {}
        members: dict[str, list[dict[str, Any]]] = defaultdict(list)
        rows: list[dict[str, Any]] = []
        consumer = platform == "powerbi"  # a semantic model reads its sources; it is not one
        if consumer:
            used = {a for accounts_of in feeding.values() for a in accounts_of}
            for account_id in sorted(used):
                account = accounts.get(account_id)
                connector = account.row.get("connector_type") if account else None
                if account and airbyte.classify(None, connector)["extract"] == "airbyte":
                    units[f"account-{account_id}"] = {
                        "id": f"account-{account_id}", "name": account.name, "connector": connector,
                        "account_id": account_id, "source": _source(platform, "account", account_id)}
        for ds_id in sorted(datasets):
            ds = datasets[ds_id]
            if consumer:
                feeds = sorted(a for a in feeding.get(ds_id, []) if f"account-{a}" in units)
                rows.append({"dataset": ds_id, "name": ds.name, "provider": ds.row.get("provider_type"),
                             "account": feeds[0] if feeds else None, "category": "consumer_model",
                             "airbyte_source": None, "unit": None,
                             "reason": "A Power BI semantic model reads its sources through Power Query; the sources are the "
                                       "datasource accounts in extract/. The scan does not list the tables a model imports "
                                       "from them, so those extract documents carry no streams yet."})
                continue
            raw_account = ds.raw.get("accountId")
            account_id = str(raw_account) if raw_account is not None else (sorted(feeding.get(ds_id, [])) or [None])[0]
            account = accounts.get(account_id) if account_id else None
            connector = account.row.get("connector_type") if account else None
            provider = ds.row.get("provider_type") or ds.raw.get("dataProviderType")
            verdict = airbyte.classify(provider, connector)
            row = {"dataset": ds_id, "name": ds.name, "provider": provider, "account": account_id,
                   "category": verdict["category"], "airbyte_source": verdict["source"], "reason": verdict["reason"],
                   "unit": None}
            if verdict["extract"] == "airbyte":
                connector_name = connector if airbyte._norm(connector) in airbyte.SOURCES else provider
                unit_id = f"account-{account_id}" if account_id else f"connector-{airbyte._norm(connector_name)}"
                if unit_id not in units:
                    if account:
                        label = account.name
                    elif account_id:
                        label = f"{connector_name} (account {account_id} is not in the scan)"
                    else:
                        label = f"{connector_name} (no account in the scan)"
                    units[unit_id] = {"id": unit_id, "name": label, "connector": connector_name,
                                      "account_id": account_id if account else None,
                                      "source": _source(platform, "account", account_id) if account else
                                      {"platform": platform, "kind": "connector", "id": airbyte._norm(connector_name)}}
                row["unit"] = unit_id
                members[unit_id].append({"id": ds_id, "name": ds.name,
                                         "columns": [c for c in ds.json_column("schema_columns_json") or [] if c.get("name")]})
            rows.append(row)
        for unit_id, unit in sorted(units.items()):
            self._write_kind("extracts", f"extract/{_file_stem(unit_id, unit['name'])}.json",
                             airbyte.extract_document(SPEC_ID, unit, members[unit_id]))
        self._write("extract/index.json", airbyte.index_document(SPEC_ID, rows))
        self.written["extract_units_without_streams"] = sum(1 for u in units if not members.get(u))
        self.written["extract_datasets_with_a_stream"] = sum(len(v) for v in members.values())
        self.written["extract_datasets_without"] = len(rows) - self.written["extract_datasets_with_a_stream"]

    def _finish(self, scope: dict[str, set[str]] | None) -> ExportResult:
        scan = self.reader.latest_completed_scan()
        expected = self._expected(scope)
        checks = verify_export(self.out, expected)
        ok = all(c["ok"] for c in checks)
        counts = {k: v for k, v in sorted(self.written.items())}
        manifest = {
            "spec": SPEC_ID, "kind": "manifest",
            "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "source": {"platform": self.platform, "database": self.reader.db_path.name,
                       "scan": {"id": scan["id"], "instance": scan["instance"], "finished_at": scan["finished_at"]}
                       if scan else None},
            "scope": {"dashboards": self.only} if self.only is not None else {"estate": "all"},
            "counts": counts,
            "reconciliation": {"ok": ok, "checks": checks},
            "coverage": self._coverage(),
            "limits": LIMITS,
        }
        self._write("manifest.json", manifest)
        table = coverage.build(self.out)
        manifest["coverage"] = {**manifest["coverage"], "table": table["rows"]}
        self._write("manifest.json", manifest)
        self._write_text("COVERAGE.md", coverage.markdown(table, manifest))
        notes = [f"conversion.json not read, its SQL is not in the export: {d} ({why})"
                 for d, why in (self.conversions.skipped if self.conversions else [])]
        return ExportResult(self.out, counts, manifest["reconciliation"], self.files, notes)

    def _coverage(self) -> dict[str, Any]:
        """What share of each kind was converted, and why the rest was not (the part this module can count)."""
        out: dict[str, Any] = {}
        if self.conversions is not None:
            results = self.conversions.portable_results
            constructs: Counter = Counter()
            for r in results:
                for c in r["not_portable"]:
                    constructs[c["construct"]] += c["count"]
            out["portable_sql"] = {
                "queries": len(results),
                "rendered": sum(1 for r in results if r["rendered"] is not None),
                "roundtrip_ok": sum(1 for r in results if r["roundtrip_ok"]),
                "with_non_portable_constructs": sum(1 for r in results if r["not_portable"]),
                "not_rendered": sorted({r["error"] for r in results if r["error"]})[:10],
                "most_common_non_portable": [{"construct": c, "count": n} for c, n in constructs.most_common(15)],
                "rendered_by": "sqlglot" if portable_sql.available() else None,
            }
        return out

    def _expected(self, scope: dict[str, set[str]] | None) -> dict[str, int]:
        """What the scan says should be on disk."""
        if scope is not None:
            return {"dashboards": len(scope["dashboard"]), "datasets": len(scope["dataset"]),
                    "transformations": len(scope["dataflow"]), "metrics": len(scope["calculated_field"]),
                    "cards": len(scope["card"])}
        counts = self.reader.counts()
        return {"dashboards": counts["dashboard"], "datasets": counts["dataset"],
                "transformations": counts["dataflow"], "metrics": counts["calculated_field"],
                "cards": counts["card"], "users": counts["user"], "groups": counts["group"],
                "apps": counts["app"], "alerts": counts["alert"], "accounts": counts["account"],
                "app_documents": counts["app"]}


def verify_export(out: Path, expected: dict[str, int] | None = None) -> list[dict[str, Any]]:
    """Check an export directory against its own schemas and, when given, the
    scan's counts. Reads only the files, so it works on a checked-out export.

    Returns a list of checks `{name, ok, expected, actual, problems}`.
    """
    checks: list[dict[str, Any]] = []

    def check(name: str, ok: bool, expected_value: Any = None, actual: Any = None, problems: list[str] | None = None):
        checks.append({"name": name, "ok": ok, "expected": expected_value, "actual": actual,
                       "problems": (problems or [])[:20]})

    def load(path: Path) -> Any:
        return json.loads(path.read_text(encoding="utf-8"))

    schema_problems: dict[str, list[str]] = defaultdict(list)
    docs: dict[str, list[Any]] = defaultdict(list)
    layout = {"dashboards": "dashboard", "cards": "visual", "models": "dataset",
              "transformations": "transformation", "metrics": "metrics"}
    for folder, kind in layout.items():
        for path in sorted((out / folder).glob("*.json")) if (out / folder).exists() else []:
            doc = load(path)
            docs[folder].append(doc)
            schema_problems[folder] += [f"{path.name}: {p}" for p in validate(doc, SCHEMAS[kind])]
    for path in sorted((out / "extract").glob("*.json")) if (out / "extract").exists() else []:
        doc = load(path)
        kind = "extract_index" if path.name == "index.json" else "extract"
        docs["extract_index" if kind == "extract_index" else "extract"].append(doc)
        schema_problems["extract"] += [f"{path.name}: {p}" for p in validate(doc, SCHEMAS[kind])]
    for rel, kind in (("access/principals.json", "principals"), ("lineage/objects.json", "lineage")):
        if (out / rel).exists():
            doc = load(out / rel)
            docs[rel].append(doc)
            schema_problems[rel] += [f"{rel}: {p}" for p in validate(doc, SCHEMAS[kind])]
    for path in sorted((out / "apps").glob("*.json")) if (out / "apps").exists() else []:
        doc = load(path)
        docs["app_documents"].append(doc)
        schema_problems["app_documents"] += [f"{path.name}: {p}" for p in validate(doc, SCHEMAS["app"])]
    for name in ("apps", "alerts", "accounts"):
        if (out / "catalog" / f"{name}.json").exists():
            doc = load(out / "catalog" / f"{name}.json")
            docs[name].append(doc)
            schema_problems[name] += [f"{name}: {p}" for p in validate(doc, SCHEMAS["catalog"])]
    field_edges = []
    if (out / "lineage" / "fields.jsonl").exists():
        for n, line in enumerate((out / "lineage" / "fields.jsonl").read_text(encoding="utf-8").splitlines(), 1):
            edge = json.loads(line)
            field_edges.append(edge)
            for p in validate(edge, FIELD_EDGE_SCHEMA):
                schema_problems["field_edges"].append(f"fields.jsonl:{n}: {p}")

    all_problems = [p for ps in schema_problems.values() for p in ps]
    check("schema: every document conforms", not all_problems, 0, len(all_problems), all_problems)

    dash_visuals = [v for d in docs["dashboards"] for v in d["visuals"]]
    actual = {
        "dashboards": len(docs["dashboards"]),
        "cards": len({v["id"] for v in dash_visuals} | {d["id"] for d in docs["cards"]}),
        "datasets": len(docs["models"]),
        "transformations": len(docs["transformations"]),
        "metrics": sum(len(d["metrics"]) for d in docs["metrics"]),
        "users": sum(len(d["users"]) for d in docs["access/principals.json"]),
        "groups": sum(len(d["groups"]) for d in docs["access/principals.json"]),
        "apps": sum(len(d["items"]) for d in docs["apps"]),
        "alerts": sum(len(d["items"]) for d in docs["alerts"]),
        "accounts": sum(len(d["items"]) for d in docs["accounts"]),
        "app_documents": len(docs["app_documents"]),
    }
    for key, want in (expected or {}).items():
        check(f"count: {key} match the scan", actual.get(key) == want, want, actual.get(key))

    if docs["extract_index"]:
        indexed = {r["dataset"] for d in docs["extract_index"] for r in d["datasets"]}
        streamed = {x["id"] for d in docs["extract"] for x in d["datasets"]}
        stray = sorted(streamed - indexed)
        check("extract: every dataset with a stream is in the index, and the index covers every model",
              not stray and indexed == {d["id"] for d in docs["models"]}, len(docs["models"]), len(indexed),
              [f"stream for unindexed dataset {s}" for s in stray])

    # Every id that a document points at must exist in the export.
    dataset_ids = {d["id"] for d in docs["models"]}
    visual_ids = {v["id"] for v in dash_visuals} | {d["id"] for d in docs["cards"]}
    metric_ids = {m["id"] for d in docs["metrics"] for m in d["metrics"]}
    dangling_datasets = sorted({ds for v in dash_visuals + docs["cards"] for ds in v["datasets"]} - dataset_ids)
    check("references: visual datasets that are not in the export (deleted or hidden in the scan)",
          True, 0, len(dangling_datasets), [f"dataset {d}" for d in dangling_datasets])
    unresolved = sorted({f["metric_ref"] for v in dash_visuals + docs["cards"] for f in v["fields"]
                         if f.get("metric_ref") and not f.get("metric")})
    check("references: visual fields whose metric is not in the export", True, 0, len(unresolved),
          [f"formula {u}" for u in unresolved])
    nodes = {n["id"] for d in docs["lineage/objects.json"] for n in d["nodes"]}
    bad_edges = [e for d in docs["lineage/objects.json"] for e in d["edges"]
                 if e["from"] not in nodes or e["to"] not in nodes]
    check("lineage: every edge joins two nodes", not bad_edges, 0, len(bad_edges),
          [f"{e['from']} -> {e['to']}" for e in bad_edges])
    bad_fields = [e for e in field_edges
                  if (e["to"].startswith("visual:") and e["to"][7:] not in visual_ids)
                  or (e["to"].startswith("metric:") and e["to"][7:] not in metric_ids)]
    check("lineage: every field edge ends at an exported visual or metric", not bad_fields, 0, len(bad_fields),
          [f"{e['from']} -> {e['to']}" for e in bad_fields])
    return checks


def export_estate(reader: EstateReader, out_dir: str | Path, dashboard_ids: Iterable[str] | None = None,
                  sql_from: str | Path | list[str | Path] | None = None) -> ExportResult:
    return Exporter(reader, out_dir, dashboard_ids, sql_from).run()

"""Has a dataflow been edited in Domo since the estate was scanned?

The converter reads a dataflow's live definition while BIMControl reads the
scan, so a flow edited after the scan converts to SQL the model was not built
for (Revenue Impact, dataflow 1951: a renamed column, a refresh that failed
hours into a run). Domo's own `modified` stamp is one cheap GET per dataflow
and equals the `lastModified` the scan recorded, so a difference is drift.

Best effort: no Domo session, or a failed request, never stops a run.
"""

from __future__ import annotations

import datetime as _dt
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from typing import Any

from bimcontrol.core.engine import ReviewItem, RunContext

LIVE_PATH = "/api/dataprocessing/v2/dataflows/{id}"
WORKERS = 6
TOLERANCE_MS = 60_000      # flow 734 shows the scan and Domo disagreeing by a few seconds with no edit between


def live_modified_fetcher(ctx: RunContext) -> Callable[[str], int | None] | None:
    """A function giving a dataflow's live `modified` (epoch ms), or None without a session."""
    override = ctx.options.get("dataflow_modified")
    if override is not None:
        return override
    from bimcontrol.sources.domo import login  # noqa: PLC0415

    try:
        session = login.get_session(ctx.project.get("source_instance"), allow_prompt=False)
    except Exception:  # noqa: BLE001 -- the check is optional
        return None
    http = session.requests_session()

    def fetch(flow_id: str) -> int | None:
        response = http.get(session.base_url + LIVE_PATH.format(id=flow_id), timeout=60)
        response.raise_for_status()
        modified = response.json().get("modified")
        return int(modified) if modified is not None else None

    return fetch


def when(milliseconds: int) -> str:
    return _dt.datetime.fromtimestamp(milliseconds / 1000, _dt.timezone.utc).strftime("%Y-%m-%d %H:%M UTC")


DATASET_PATH = "/api/data/v3/datasources/{id}"


class ScanOutOfDate(RuntimeError):
    """The live tenant holds something the scan does not: converting or migrating on can only give a wrong model."""


def live_dataset_lookup(ctx: RunContext) -> Callable[[str], dict[str, Any] | None] | None:
    """A function giving `{"name", "created"}` (created: epoch ms) for a dataset that exists in Domo now, None for
    one that does not (deleted, or out of the session's reach), or None without a session.

    the customer's Daily Charge flow was edited to read an upload made after the scan: the converter followed the
    live flow and the model got an empty table."""
    override = ctx.options.get("dataset_lookup")
    if override is not None:
        return override
    from bimcontrol.sources.domo import login  # noqa: PLC0415

    try:
        session = login.get_session(ctx.project.get("source_instance"), allow_prompt=False)
    except Exception:  # noqa: BLE001 -- the check is optional
        return None
    http = session.requests_session()

    def lookup(dataset_id: str) -> dict[str, Any] | None:
        try:
            response = http.get(session.base_url + DATASET_PATH.format(id=dataset_id), timeout=60)
            if response.status_code != 200:
                if response.status_code not in (403, 404, 410):    # gone or out of reach is an answer; anything else is a failure
                    ctx.progress(f"could not ask Domo about dataset {dataset_id}: HTTP {response.status_code}")
                return None
            body = response.json()
            created = body.get("created")
            return {"name": body.get("name"), "created": int(created) if isinstance(created, (int, float)) else None}
        except Exception as exc:  # noqa: BLE001 -- the check is optional
            ctx.progress(f"could not ask Domo about dataset {dataset_id}: {type(exc).__name__}")
            return None

    return lookup


def dataflow_drift(ctx: RunContext, flows: list[dict[str, Any]]) -> list[ReviewItem]:
    """Review items for closure dataflows whose live `modified` differs from the scan's.

    `flows` are closure dataflow entries; each carries `scan_modified`, the
    `lastModified` the scan recorded (epoch ms, absent for old scans: skipped).
    """
    checkable = [f for f in flows if f.get("scan_modified")]
    if not checkable:
        return []
    fetch = live_modified_fetcher(ctx)
    if fetch is None:
        ctx.progress("no Domo session, so the scan was not compared with the live dataflows")
        return []

    def live(flow: dict[str, Any]) -> int | None:
        try:
            return fetch(str(flow["id"]))
        except Exception:  # noqa: BLE001 -- the check is optional
            return None

    with ThreadPoolExecutor(max_workers=WORKERS) as pool:
        stamps = list(pool.map(live, checkable))

    items: list[ReviewItem] = []
    for flow, stamp in zip(checkable, stamps):
        if stamp is None or int(stamp) - int(flow["scan_modified"]) <= TOLERANCE_MS:
            continue
        items.append(ReviewItem(
            kind="dataflow_edited_since_scan", severity="warn",
            title=f"Dataflow {flow['name']!r} ({flow['id']}) was edited in Domo on {when(int(stamp))}, after the "
                  f"scan ({when(int(flow['scan_modified']))}): the converted SQL follows the live flow, the model "
                  "the scan. Rescan before migrating",
            source_type="dataflow", source_id=str(flow["id"]),
            detail={"scan_modified": int(flow["scan_modified"]), "live_modified": int(stamp)},
        ))
    answered = sum(1 for s in stamps if s is not None)
    ctx.progress(f"compared {answered}/{len(checkable)} dataflows with Domo: {len(items)} edited since the scan")
    return items

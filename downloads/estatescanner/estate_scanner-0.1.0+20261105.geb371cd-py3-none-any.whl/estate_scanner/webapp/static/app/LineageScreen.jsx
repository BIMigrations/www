import React from 'react';

export function LineageScreen({ scope }) {
  const [stats, setStats] = React.useState(null);
  const [ranked, setRanked] = React.useState(null);
  const [selected, setSelected] = React.useState(null);
  const [detail, setDetail] = React.useState(null);

  const scopeKey = scope ? scope.platform + '|' + scope.instance : '';

  React.useEffect(function () {
    setStats(null); setRanked(null); setSelected(null);
    fetchGraphStats(scope).then(setStats);
    fetchMostConnected(scope, 30).then(setRanked);
  }, [scopeKey]); // eslint-disable-line

  React.useEffect(function () {
    if (!selected) { setDetail(null); return; }
    fetchEstateObject(selected.type, selected.id, { platform: selected.platform, instance: selected.instance }).then(setDetail);
  }, [selected]);

  return (
    <div style={{ display: 'flex', height: '100%' }}>
      <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', padding: '20px 24px', gap: 16 }}>
        <div>
          <div style={{ fontSize: 'var(--text-3xl)', fontWeight: 'var(--weight-semibold)', letterSpacing: 'var(--tracking-heading)' }}>Lineage</div>
          <div style={{ fontSize: 'var(--text-md)', color: 'var(--text-secondary)', marginTop: 4 }}>
            The most-connected objects in the estate -- structural hubs where a change has the widest reach.
          </div>
        </div>

        {stats && (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,minmax(0,1fr))', gap: 24 }}>
            <StatTile value={stats.node_count.toLocaleString()} label="Objects" />
            <StatTile value={stats.edge_count.toLocaleString()} label="Relationships" />
            <StatTile value={Object.keys(stats.by_type).length} label="Object types" />
          </div>
        )}

        <div style={{ flex: 1, minHeight: 0 }}>
          {!ranked ? <Spinner /> : (
            <DataGrid
              selectedId={selected ? selected.id : null}
              onRowClick={function (r) { setSelected({ type: r.type, id: r.id, platform: r.platform, instance: r.instance }); }}
              columns={[
                { key: 'degree', header: 'Connections', mono: true, align: 'right', width: 120, sortable: true },
                { key: 'type', header: 'Type', width: 150, muted: true, sortable: true, filterable: true },
                { key: 'name', header: 'Name', sortable: true, filterable: true, render: function (r) { return r.name || r.id; } },
              ]}
              rows={ranked}
            />
          )}
        </div>
      </div>

      {selected && (
        <div style={{ width: 380, flex: 'none', borderLeft: '1px solid var(--border-hairline)', background: 'var(--surface-panel)', overflow: 'auto', padding: 16 }}>
          {!detail ? <Spinner /> : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div>
                <Tag tone="source">{selected.type}</Tag>
                <div style={{ fontSize: 'var(--text-2xl)', fontWeight: 'var(--weight-semibold)', letterSpacing: 'var(--tracking-heading)', marginTop: 8 }}>{detail.name || detail.id}</div>
              </div>
              <DetailBlobs detail={detail} />
              <div>
                <div className="bit-eyebrow" style={{ marginBottom: 8 }}>Upstream ({detail.upstream.length})</div>
                {detail.upstream.slice(0, 20).map(function (n, i) { return <TreeNode key={i} depth={0} label={n.name || n.id} meta={n.type} />; })}
              </div>
              <div>
                <div className="bit-eyebrow" style={{ marginBottom: 8 }}>Downstream ({detail.downstream.length})</div>
                {detail.downstream.slice(0, 20).map(function (n, i) { return <TreeNode key={i} depth={0} label={n.name || n.id} meta={n.type} />; })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

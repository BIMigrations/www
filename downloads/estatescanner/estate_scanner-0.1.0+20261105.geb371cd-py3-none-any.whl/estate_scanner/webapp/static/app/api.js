// Thin fetch() wrappers for the FastAPI backend. Loaded through the same
// zero-build ds-preview.js mechanism as the JSX files (Babel's react preset
// passes plain JS through unchanged), so every exported function here is
// available as a plain call inside any component via window.BITDS.

export function apiGet(path) {
  return fetch(path).then((r) => {
    if (!r.ok) return r.json().catch(() => ({})).then((b) => { throw new Error(b.detail || ('GET ' + path + ' -> ' + r.status)); });
    return r.json();
  });
}

export function apiPost(path, body) {
  return fetch(path, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body || {}),
  }).then((r) => {
    if (!r.ok) return r.json().then((b) => { throw new Error(b.detail || ('POST ' + path + ' -> ' + r.status)); });
    return r.json();
  });
}

export function fetchPlatforms() {
  return apiGet('/api/platforms');
}

export function fetchPlatformSessions(key) {
  return apiGet('/api/platforms/' + key + '/sessions');
}

// `what` is the instance name (Domo, Power BI) or an object of the platform's form fields (Tableau:
// server, site, token_name, secret). The secret travels in the request body only, never in a URL.
export function connectPlatform(key, what) {
  return apiPost('/api/platforms/' + key + '/connect', typeof what === 'string' ? { instance: what } : what);
}

export function fetchConnectStatus(key, jobId) {
  return apiGet('/api/platforms/' + key + '/connect/' + jobId);
}

export function startScan(platform, instance, skipGroupMembership) {
  return apiPost('/api/scans', { platform, instance, skip_group_membership: !!skipGroupMembership });
}

export function fetchScanProgress(jobId) {
  return apiGet('/api/scans/jobs/' + jobId + '/progress');
}

export function fetchScan(scanId) {
  return apiGet('/api/scans/' + scanId);
}

export function fetchScans() {
  return apiGet('/api/scans');
}

export function fetchDeletePreview(scanId) {
  return apiGet('/api/scans/' + scanId + '/delete-preview');
}

export function deleteScan(scanId, confirm) {
  return apiPost('/api/scans/' + scanId + '/delete', { confirm });
}

export function fetchStartFreshPreview(platform, instance) {
  return apiGet('/api/scans/start-fresh-preview?platform=' + encodeURIComponent(platform) + '&instance=' + encodeURIComponent(instance));
}

export function startFresh(platform, instance, confirm) {
  return apiPost('/api/scans/start-fresh', { platform, instance, confirm });
}

// `scope` is { platform, instance } or null: null lets the server pick the newest scan of each platform.
function scopeParams(scope) {
  return scope ? { platform: scope.platform, instance: scope.instance } : {};
}

function withParams(path, params) {
  const qs = new URLSearchParams(
    Object.fromEntries(Object.entries(params || {}).filter(([, v]) => v !== undefined && v !== null && v !== '' && v !== false))
  ).toString();
  return path + (qs ? '?' + qs : '');
}

export function fetchEstateSummary(scope) {
  return apiGet(withParams('/api/estate/summary', scopeParams(scope)));
}

export function fetchEstateInstances() {
  return apiGet('/api/estate/instances');
}

export function fetchEstateObjects(objectType, params, scope) {
  return apiGet(withParams('/api/estate/' + objectType, Object.assign({}, params, scopeParams(scope))));
}

export function fetchEstateObject(objectType, id, scope) {
  return apiGet(withParams('/api/estate/' + objectType + '/' + encodeURIComponent(id), scopeParams(scope)));
}

export function fetchGraphStats(scope) {
  return apiGet(withParams('/api/graph/stats', scopeParams(scope)));
}

export function fetchMostConnected(scope, top) {
  return apiGet(withParams('/api/graph/most-connected', Object.assign({ top: top }, scopeParams(scope))));
}

// Every "*_json" column in schema.sql (dataflows.definition_json,
// dashboards.layout_json, apps.views_json, ...) comes back from
// /api/estate/{type}/{id} as a JSON-encoded string, not a parsed object --
// pretty-print it for display, falling back to the raw string if a value
// somehow isn't valid JSON.
export function prettyJson(raw) {
  if (raw == null) return '';
  try {
    return JSON.stringify(JSON.parse(raw), null, 2);
  } catch (e) {
    return String(raw);
  }
}

// Turns a raw snake_case column name into an Inspector-friendly label, e.g.
// "definition_json" -> "Definition", "downstream_dataflow_count" ->
// "Downstream dataflow count". Stripping the "_json" suffix specifically
// covers the dedicated blob-section titles; every other column just gets
// spaces where a fixed-width KeyValueList label needs a wrap point that an
// unbroken snake_case string wouldn't otherwise get.
export function humanizeFieldKey(key) {
  const base = key.replace(/_json$/, '').replace(/_/g, ' ');
  return base.charAt(0).toUpperCase() + base.slice(1);
}

// ds-preview.js's loader only recognizes a named function export (it
// regexes the source text for that exact shape, comments included, to know
// what to merge into window.BITDS) -- a const array export is never used
// anywhere in this design system for that reason, so this stays a
// function rather than a const array.
export function getObjectTypes() {
  return [
    { value: 'dataset', label: 'Datasets' },
    { value: 'dataflow', label: 'Dataflows' },
    { value: 'card', label: 'Cards' },
    { value: 'dashboard', label: 'Dashboards' },
    { value: 'calculated_field', label: 'Calculated fields' },
    { value: 'user', label: 'Users' },
    { value: 'group', label: 'Groups' },
    { value: 'account', label: 'Accounts' },
    { value: 'alert', label: 'Alerts' },
    { value: 'app', label: 'Apps' },
    { value: 'workspace', label: 'Workspaces' },
    { value: 'gateway', label: 'Gateways' },
  ];
}

export function fetchExportEstates() {
  return apiGet('/api/export/estates');
}

// estate: { platform, instance } to export that one; omitted, the latest completed scan's.
export function exportScan(estate) {
  return apiPost('/api/export', estate ? { platform: estate.platform, instance: estate.instance } : undefined);
}

export function revealExport(path) {
  return apiPost('/api/export/reveal', { path });
}

// BimDash pairing. The answer is names and dates only: the device token stays on this machine, in a private file.
export function fetchBimdash() {
  return apiGet('/api/bimdash');
}

export function connectBimdash(code, deviceName) {
  return apiPost('/api/bimdash/connect', { code, device_name: deviceName });
}

export function disconnectBimdash() {
  return fetch('/api/bimdash', { method: 'DELETE' }).then((r) => {
    if (!r.ok) return r.json().catch(() => ({})).then((b) => { throw new Error(b.detail || ('DELETE /api/bimdash -> ' + r.status)); });
    return r.json();
  });
}

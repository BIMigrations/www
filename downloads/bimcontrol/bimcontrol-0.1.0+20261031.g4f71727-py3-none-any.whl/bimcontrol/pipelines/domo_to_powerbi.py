"""The Domo dashboard to Power BI pipeline.

The whole line, in order: resolve what a dashboard depends on, get its data
into the customer's warehouse, rebuild its transformations as SQL, build a
semantic model and a report, publish them, and prove the figures match. A
stage that is declared but not built raises `StageNotImplemented`, which
ends a run as `incomplete` rather than failed -- that is how this list grew,
and how it will grow again for a new source or target.

Stages hand work to each other through artefacts on disk, never through
memory, because a resumed run skips the stages that already succeeded.
"""

from __future__ import annotations

from bimcontrol.core.engine import (
    Pipeline,
    ReviewItem,
    RunContext,
    Stage,
    StageResult,
)
from bimcontrol.estate.closure import (
    card_chart_type, card_text, card_date_ranges, card_drill_views, card_filters_named, card_formula_columns, card_sort, card_style, card_top_n,
    resolve_dashboard,
)
from bimcontrol.pipelines.build_powerbi import (
    build_model,
    build_report,
    publish_powerbi,
    write_pbip,
)
from bimcontrol.pipelines.convert_etl import convert_dataflows
from bimcontrol.pipelines.drift import dataflow_drift
from bimcontrol.pipelines.migration_report import report_fingerprint, stamp_final_run, write_report
from bimcontrol.pipelines.verify_parity import verify_parity
from bimcontrol.pipelines.data_plan import land_source_data, plan_data

CLOSURE_FILE = "closure.json"


def missing_input_ids(reader, flow) -> list[str]:
    """Datasets a Magic ETL flow loads (LoadFromVault tiles) that the scan does not hold.

    The scan links a flow only to datasets it has, so a deleted input leaves `num_inputs` 0 and no
    edge; the tile still names it (customer Cost by Patient Acct and Charge Code reads a deleted
    'Daily Charge and Cost v2', and Domo's own copy of its output is a frozen 12.5M-row snapshot).
    """
    named = [str(action["dataSourceId"]) for action in flow.definition.get("actions") or []
             if action.get("type") == "LoadFromVault" and action.get("dataSourceId")]
    if not named:
        return []
    found = {d.id for d in reader.get_many("dataset", named)}
    return sorted({dataset_id for dataset_id in named if dataset_id not in found})


def _appending_outputs(actions: list[dict]) -> list[str] | None:
    appending = [a for a in actions if a.get("type") == "PublishToVault" and a.get("versionChainType") == "APPEND"]
    ids = [str((a.get("dataSource") or {}).get("guid")) for a in appending if (a.get("dataSource") or {}).get("guid")]
    return ids if len(ids) == len(appending) and ids else None


def closure_payload(reader, closure) -> dict:
    """The closure as the plain, JSON-ready dict every later stage reads."""
    summary = closure.summary()
    card_columns = {card.id: card_formula_columns(card) for card in closure.cards}
    # A card-level calculation is a calculated field of its own, named by the card.
    local_fields: dict[str, dict] = {}
    for _, found in card_columns.values():
        for entry in found:
            local_fields.setdefault(entry["id"], entry)
    return {
        "dashboard": {
            "id": closure.dashboard.id,
            "name": closure.dashboard.name,
            "filters": closure.dashboard.json_column("filters_json"),
            "layout": closure.dashboard.json_column("layout_json"),
        },
        "cards": [
            {
                "id": card.id,
                "name": card.name,
                "card_type": card.row.get("type"),
                "chart_type": card_chart_type(card),
                # A Notebook card holds words, not a query: they are carried (additive; only Text cards have it).
                **({"text": card_text(card)} if (card.row.get("type") or "").lower() == "text" else {}),
                "dataset_ids": closure.card_datasets.get(card.id, []),
                # Where Domo records what sits on each axis. Carried
                # verbatim: interpreting it is build_report's job.
                "data_subscriptions": card_columns[card.id][0],
                # Saved filter values live only in the card detail's
                # `subscriptions` (EstateScanner captures them).
                "filters": card_filters_named(card),
                "date_ranges": card_date_ranges(card),
                "top_n": card_top_n(card),
                "style": card_style(card),
                "sort": card_sort(card),
                "drill_views": card_drill_views(card),
                # The beast modes this card itself uses. Cards copied around Domo carry same-named
                # beast modes with different formulas ('IP Revenue' has five), so a name is not enough.
                # The card's own calculations first, so its formula wins over a same-named saved beast mode.
                "calculated_field_ids": [entry["id"] for entry in card_columns[card.id][1]]
                                        + [cf.id for cf in reader.calculated_fields_for("card", card.id)],
            }
            for card in closure.cards
        ],
        "datasets": [
            {
                "id": dataset.id,
                "name": dataset.name,
                "provider_type": dataset.row.get("provider_type"),
                "row_count": dataset.row.get("row_count"),
                "updated_at": dataset.row.get("updated_at"),       # when Domo last changed it (the scan's reading)
                "columns": dataset.json_column("schema_columns_json"),
                # Domo's row-level security (PDP): filter groups per dataset.
                "pdp": dataset.json_column("pdp_json"),
                "produced_by": closure.dataset_producer.get(dataset.id),
                "is_root": dataset.id in closure.root_dataset_ids,
            }
            for dataset in closure.datasets
        ],
        "dataflows": [
            {
                "id": flow.id,
                "name": flow.name,
                "engine": flow.row.get("engine"),
                "num_inputs": flow.row.get("num_inputs"),
                "num_outputs": flow.row.get("num_outputs"),
                "input_dataset_ids": reader.input_datasets_for_dataflow(flow.id),
                # Inputs the flow's tiles name that the scan has no dataset for (deleted since, or out of
                # the scanning user's reach): the flow cannot run in the warehouse either.
                "missing_input_ids": missing_input_ids(reader, flow),
                # A flow Domo no longer runs: its output is a frozen snapshot, and that is what the cards show.
                "disabled_in_domo": flow.row.get("last_execution_state") == "DISABLED",
                # An output tile whose update method is APPEND: every run adds its rows to the dataset (customer Monthly
                # SnapShot: 24 runs, 23.7M rows in Domo; the flow's SQL rebuilds one run, 1.7M).
                "appends_history": any(a.get("type") == "PublishToVault" and a.get("versionChainType") == "APPEND"
                                       for a in flow.definition.get("actions") or []),
                # ... and which outputs (the tile's dataSource.guid is the output dataset's id: 8 of 8 on the 2026-10-21 scan);
                # None: an APPEND tile that names none, so every output of the flow counts.
                "appending_dataset_ids": _appending_outputs(flow.definition.get("actions") or []),
                # Domo's `lastModified` at scan time (epoch ms): pipelines.drift compares it with the live flow.
                "scan_modified": flow.raw.get("lastModified"),
            }
            for flow in closure.dataflows
        ],
        "calculated_fields": [
            {
                "id": cf.id,
                "name": cf.name,
                "formula": cf.row.get("formula"),
                "data_type": cf.row.get("data_type"),
            }
            for cf in closure.calculated_fields
        ] + list(local_fields.values()),
        "missing": [{"object_type": t, "id": i} for t, i in closure.missing],
        "summary": summary,
    }


def resolve_closure(ctx: RunContext) -> StageResult:
    """Work out everything this dashboard needs, and write it down.

    The closure is the run's foundation: every later stage reads it rather
    than querying the estate again, so the whole run is consistent even if
    a new scan lands mid-migration.
    """
    with ctx.estate() as reader:
        closure = resolve_dashboard(reader, ctx.source_object_id)
        payload = closure_payload(reader, closure)
        summary = payload["summary"]

    ctx.write_json(CLOSURE_FILE, payload, kind="closure", label="Dependency closure")
    ctx.progress(
        f"{summary['cards']} cards, {summary['datasets']} datasets, "
        f"{summary['dataflows']} dataflows, {summary['calculated_fields']} beast modes"
    )

    review_items = [
        ReviewItem(
            kind="missing_object",
            title=f"{object_type} {object_id} is referenced but not in the scan",
            source_type=object_type,
            source_id=object_id,
            detail={"reason": "deleted, or outside the scanning user's permissions"},
        )
        for object_type, object_id in closure.missing
    ]
    review_items += [
        ReviewItem(
            kind="card_without_dataset",
            title=f"Card {card['id']} ({card['name']!r}) has no dataset to read from",
            source_type="card",
            source_id=card["id"],
        )
        for card in payload["cards"]
        if not card["dataset_ids"]
    ]
    review_items += dataflow_drift(ctx, payload["dataflows"])

    return StageResult(summary=summary, warnings=list(closure.warnings), review_items=review_items)


PIPELINE = Pipeline(
    name="domo_to_powerbi",
    stages=[
        Stage("resolve_closure", "Resolve the dependency closure", resolve_closure),
        Stage("plan_data", "Decide where each dataset's data comes from", plan_data, version="2"),
        Stage("land_source_data", "Land manual uploads and feeds in the warehouse", land_source_data),
        Stage("convert_dataflows", "Convert Magic ETL to warehouse SQL", convert_dataflows),
        Stage("build_model", "Build the semantic model", build_model),
        Stage("build_report", "Build the report pages and visuals", build_report),
        Stage("write_pbip", "Write the Power BI project", write_pbip),
        Stage("publish_powerbi", "Publish to the Power BI workspace", publish_powerbi),
        Stage("verify_parity", "Check the figures against Domo", verify_parity, version="2"),
        # The report is a view over every other stage, so its fingerprint is
        # theirs: a resume that re-ran any of them must rewrite the report.
        Stage("report", "Write the migration report", write_report,
              fingerprint=report_fingerprint),
    ],
    finish=stamp_final_run,
)

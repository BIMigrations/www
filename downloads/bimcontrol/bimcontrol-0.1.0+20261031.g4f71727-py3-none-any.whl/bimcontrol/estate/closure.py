"""Resolves a migration unit's dependency closure.

A migration unit is one dashboard plus everything needed to rebuild it:
its cards, the datasets those cards read, the dataflows that produce those
datasets, the datasets *those* dataflows read (transitively, up to the raw
inputs), and every beast mode involved. That closure is what a pipeline
converts and what the planner uses to size and order the work.

Traversal is upstream-only and breadth-first from the dashboard. It stops
at datasets no dataflow produces -- those are the estate's raw inputs, and
where a migration's data has to come from some other route (a warehouse
table it already lands in, or a snapshot).

Ids that the scan references but doesn't contain are recorded in `missing`
rather than raising: a scan only sees what the scanning user could see, so
a card pointing at a dataset in someone else's permission scope is a
routine gap to report, not a failure.
"""

from __future__ import annotations

import copy
import html
import json
import re

from dataclasses import dataclass, field
from typing import Any

from .reader import EstateObject, EstateReader

# How deep to follow dataflow -> input dataset -> dataflow chains. Domo
# estates routinely stack a dozen flows; this is a runaway guard, not a
# real limit, and hitting it is reported as a warning.
MAX_DEPTH = 25


@dataclass
class Closure:
    dashboard: EstateObject
    cards: list[EstateObject] = field(default_factory=list)
    datasets: list[EstateObject] = field(default_factory=list)
    dataflows: list[EstateObject] = field(default_factory=list)
    calculated_fields: list[EstateObject] = field(default_factory=list)
    # Datasets with no producing dataflow: where data enters the estate.
    root_dataset_ids: list[str] = field(default_factory=list)
    # (object_type, id) referenced by the scan but not present in it.
    missing: list[tuple[str, str]] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    # card id -> dataset ids it reads, in the order the card lists them.
    card_datasets: dict[str, list[str]] = field(default_factory=dict)
    # dataset id -> dataflow id that produces it.
    dataset_producer: dict[str, str] = field(default_factory=dict)

    def summary(self) -> dict[str, Any]:
        """The counts the unit picker and migration report both show."""
        chart_types: dict[str, int] = {}
        for card in self.cards:
            chart_type = card_chart_type(card) or "unknown"
            chart_types[chart_type] = chart_types.get(chart_type, 0) + 1
        return {
            "dashboard_id": self.dashboard.id,
            "dashboard_name": self.dashboard.name,
            "cards": len(self.cards),
            "datasets": len(self.datasets),
            "dataflows": len(self.dataflows),
            "calculated_fields": len(self.calculated_fields),
            "root_datasets": len(self.root_dataset_ids),
            "chart_types": dict(sorted(chart_types.items(), key=lambda kv: -kv[1])),
            "missing": len(self.missing),
            "warnings": list(self.warnings),
        }


def card_chart_type(card: EstateObject) -> str | None:
    """Domo's chart type for a card, e.g. `badge_vert_stackedbar`.

    `cards.type` is only the coarse kind (kpi, Text, document), so the
    chart type lives in the definition's metadata, with the search index's
    copy in raw_json as the fallback.
    """
    metadata = (card.definition or {}).get("metadata") or {}
    return metadata.get("chartType") or card.raw.get("chartType")


def slate_paragraphs(markup: Any) -> list[str]:
    """The paragraphs of a Notebook (Text) card's rich-text document (a Slate value, as a dict or as the JSON string
    Domo stores it in). One entry per block that holds text, in order, empty ones kept (they are the blank lines between
    paragraphs); a block that holds other blocks (a list) contributes its children. Zero-width padding (`\ufeff`) is
    removed, leading and trailing empty paragraphs are dropped. Nothing parseable gives `[]`."""
    if isinstance(markup, str):
        try:
            markup = json.loads(markup)
        except ValueError:
            return _trim_empty(markup.replace("\ufeff", "").split("\n"))
    document = markup.get("document") if isinstance(markup, dict) else None
    if not isinstance(document, dict):
        return []

    def text_of(node: Any) -> str:
        if isinstance(node, list):
            return "".join(text_of(n) for n in node)
        if not isinstance(node, dict):
            return ""
        if isinstance(node.get("text"), str):
            return node["text"]
        return text_of(node.get("leaves")) + text_of(node.get("nodes"))

    def blocks(nodes: Any) -> list[str]:
        out: list[str] = []
        for node in nodes if isinstance(nodes, list) else []:
            if not isinstance(node, dict):
                continue
            children = node.get("nodes")
            if node.get("object") == "block" and any(isinstance(c, dict) and c.get("object") == "block" for c in children or []):
                out.extend(blocks(children))
            elif node.get("object") == "block":
                out.append(text_of(children))
        return out

    return _trim_empty([p.replace("\ufeff", "") for p in blocks(document.get("nodes"))])


def _trim_empty(paragraphs: list[str]) -> list[str]:
    lines = [p.rstrip() for p in paragraphs]
    while lines and not lines[0].strip():
        lines.pop(0)
    while lines and not lines[-1].strip():
        lines.pop()
    return lines


def html_paragraphs(markup: Any) -> list[str]:
    """The paragraphs of a card's `textHtml` (a wrapper div holding one div per paragraph; `<br>` also breaks a line), for
    the Text cards that carry no Slate document. Tags dropped, entities decoded, padding removed."""
    if not isinstance(markup, str):
        return []
    inner = re.findall(r"<div[^>]*>((?:(?!<div).)*?)</div>", markup, flags=re.S) or [markup]
    lines: list[str] = []
    for chunk in inner:
        for line in re.split(r"<br\s*/?>", chunk, flags=re.I):
            lines.append(html.unescape(re.sub(r"<[^>]+>", "", line)).replace("\ufeff", "").replace("\xa0", " "))
    return _trim_empty(lines)


def card_text(card: EstateObject) -> str:
    """The words of a Notebook (Text) card: its paragraphs joined by a newline (see `slate_paragraphs`), from the `textHtml`
    when the card has no Slate document; empty when there are none."""
    metadata = (card.definition or {}).get("metadata") or {}
    # The Slate document first; the HTML when there is none or it holds no words (a `markup` without `document`).
    paragraphs = (slate_paragraphs(metadata.get("markup")) if metadata.get("markup") else []) or html_paragraphs(metadata.get("textHtml"))
    # One blank line at most between paragraphs, so the closure and the export's spec (which keeps the same text) agree.
    return re.sub(r"\n{3,}", "\n\n", "\n".join(paragraphs)).strip()


def card_filters(card: EstateObject) -> list[dict]:
    """The filters saved on a card, with their values.

    They sit in the card detail under `subscriptions[].subscription.filters`
    (column, operand, values, dataType). Empty when the scan predates their
    capture.
    """
    found: list[dict] = []
    for entry in (card.definition or {}).get("subscriptions") or []:
        found.extend((entry.get("subscription") or {}).get("filters") or [])
    return found


_BEAST_MODE_REF = re.compile(r"DOMO_BEAST_MODE\(\s*(\d+)\s*\)", re.IGNORECASE)


def card_formula_columns(card: EstateObject) -> tuple[list[dict] | None, list[dict]]:
    """The card's `dataSubscriptions` with its card-level calculations named, and those calculations.

    The search result Domo's `dataSubscriptions` come from leaves `name` empty on a column that
    is a calculation defined for the card (a `formulaId` of "calculation_<uuid>"), and often lists
    fewer columns than the card shows, so the report builder dropped them: 14 of the 18 columns of
    a table on Dept Analytics Prior Year were missing. The card detail has every column in order
    with its `formulaId`, and its `formulas` part (which EstateScanner needs to capture; a scan
    without it changes nothing) holds each calculation's name and formula. A component with an
    unnamed column is rebuilt from the detail; the scan's other columns (filters, grain) are kept.
    Returns (subscriptions, the calculations as calculated fields `{id, name, formula, data_type}`
    with the card's own formula text).
    """
    raw = card.raw.get("dataSubscriptions")
    definition = card.definition
    formulas = definition.get("formulas") or {}
    if not raw or not formulas:
        return raw, []
    found: dict[str, dict] = {}
    # A card filtered on its own calculation (column "calculation_<uuid>") needs that calculation too.
    for entry in card_filters(card):
        formula = formulas.get(entry.get("column") or "")
        if formula and formula.get("name") and formula.get("formula"):
            found[entry["column"]] = {
                "id": entry["column"], "name": formula["name"],
                "formula": formula["formula"], "data_type": formula.get("dataType")}
    detail_by_component = {
        entry.get("componentName"): (entry.get("subscription") or {}).get("columns") or []
        for entry in definition.get("subscriptions") or []}
    subscriptions = copy.deepcopy(raw)
    for subscription in subscriptions:
        for column in subscription.get("columns") or []:
            if column.get("name") in found:                # a FILTER column on a card calculation
                column["name"] = found[column["name"]]["name"]
                column["formula"] = True                     # so the model builds it, filtered on or not
    for subscription in subscriptions:
        columns = subscription.get("columns") or []
        selected = [c for c in columns if (c.get("columnType") or "SELECT").upper() == "SELECT"]
        detail = detail_by_component.get(subscription.get("name")) or []
        # Rebuilt from the detail when a column has no name, and also when a column is one of the card's own
        # calculations: the search result's name for it is the saved beast mode's name at indexing time, and
        # a renamed or overridden one made the card read the wrong formula (Clinic Collections - SW showed
        # 'TOS  Amt' = -1 * sum(...) while the scan said 'Cash Collections Amt' = sum(...)).
        own_calculations = any(
            not source.get("column") and (formulas.get(source.get("formulaId") or "") or {}).get("formula")
            for source in detail)
        if not detail or (all(c.get("name") for c in selected) and not own_calculations):
            continue
        scanned = {c["name"]: c for c in selected if c.get("name")}
        rebuilt: list[dict] = []
        for source in detail:
            formula = formulas.get(source.get("formulaId") or "")
            usable = bool(formula and formula.get("name") and formula.get("formula"))
            name = source.get("column") or (formula["name"] if usable else None)
            if not name:
                continue
            column = dict(scanned.get(name) or {})
            column.update(
                name=name, columnType="SELECT",
                mapping=source.get("mapping") or column.get("mapping"),
                alias=source.get("alias") or column.get("alias"),
                aggregation=source.get("aggregation") or column.get("aggregation"))
            if usable and not source.get("column"):
                column["formula"] = True
                found[source["formulaId"]] = {
                    "id": source["formulaId"], "name": name,
                    "formula": formula["formula"], "data_type": formula.get("dataType")}
            rebuilt.append(column)
        subscription["columns"] = rebuilt + [c for c in columns if c not in selected]
    return subscriptions, list(found.values())


def card_filters_named(card: EstateObject) -> list[dict]:
    """`card_filters` with a filter on a card-level calculation ("calculation_<uuid>") renamed to the
    calculation's name, which is the name of the column the model gets for it."""
    formulas = (card.definition or {}).get("formulas") or {}
    named = []
    for entry in card_filters(card):
        formula = formulas.get(entry.get("column") or "")
        if formula and formula.get("name") and formula.get("formula"):
            entry = {**entry, "column": formula["name"]}
        named.append(entry)
    return named


def card_date_ranges(card: EstateObject) -> list[dict]:
    """The date ranges saved on a card (`subscriptions[].subscription.dateRangeFilter`: the column and a
    `dateTimeRange` such as a rolling 14 months or the current year), as Domo stores them, with a
    card-level calculation named like `card_filters_named` does."""
    formulas = (card.definition or {}).get("formulas") or {}
    found = []
    for entry in (card.definition or {}).get("subscriptions") or []:
        saved = (entry.get("subscription") or {}).get("dateRangeFilter")
        if not saved:
            continue
        column = (saved.get("column") or {}).get("column") or ""
        formula = formulas.get(column)
        if formula and formula.get("name") and formula.get("formula"):
            saved = {**saved, "column": {**saved["column"], "column": formula["name"]}}
        found.append(saved)
    return found


def card_style(card: EstateObject) -> dict[str, Any]:
    """How Domo draws the card's main chart, from `metadataOverrides` (2026-10-19, customer Imaging by Modality):
    `legend`: Domo's legend position ('Bottom', 'Right', 'Hide', 'Default'; None when unsaved); `data_labels`: whether the
    values are drawn on the marks (Domo draws them unless `datalabel_text` is saved empty, also on cards that save no
    override at all); `subtotal_label`: the label of the "Percent of Total" rows a table card draws under each group
    (`subtotal_rows` and `subtotal_rows_percent_of_total` saved true), else None: those rows are Domo's, not data."""
    for component in ((card.definition or {}).get("metadataOverrides") or {}).get("components") or []:
        if component.get("component") == "main":
            overrides = component.get("overrides") or {}
            text = overrides.get("datalabel_text")
            percent_rows = str(overrides.get("subtotal_rows")).lower() == "true" \
                and str(overrides.get("subtotal_rows_percent_of_total")).lower() == "true"
            return {"legend": overrides.get("details_legend_position"),
                    "data_labels": not (text is not None and not str(text).strip()),
                    "subtotal_label": (str(overrides.get("subtotal_rows_label") or "").strip() or None) if percent_rows else None}
    return {"legend": None, "data_labels": True, "subtotal_label": None}


def card_top_n(card: EstateObject) -> dict | None:
    """The card's row limit (`main` subscription: `limit` with `orderBy`, "Top 15 by Price Impact"), as Domo stores it:
    `{limit, order_by: [{column, aggregation, order}], group_by: [column...]}`, with a card-level calculation named
    like `card_filters_named` does. None when the card shows every row. The `big_number` component's limit of 1
    and the 100,000 row ceiling are not a top N."""
    formulas = (card.definition or {}).get("formulas") or {}

    def named(column: str) -> str:
        formula = formulas.get(column)
        return formula["name"] if formula and formula.get("name") and formula.get("formula") else column

    for entry in (card.definition or {}).get("subscriptions") or []:
        sub = entry.get("subscription") or {}
        limit = sub.get("limit")
        if (entry.get("componentName") or sub.get("name")) != "main" or not isinstance(limit, int) or not 1 < limit < 100_000:
            continue
        return {"limit": limit,
                "order_by": [{"column": named(o.get("column") or o.get("formulaId") or ""), "aggregation": o.get("aggregation"),
                              "order": (o.get("order") or "ASCENDING").upper()} for o in sub.get("orderBy") or []],
                "group_by": [named(g.get("column") or g.get("formulaId") or "") for g in sub.get("groupBy") or []]}
    return None


def card_sort(card: EstateObject) -> dict | None:
    """How Domo orders the card's rows (`main` subscription): `{order_by: [{column, aggregation, order}], group_by:
    [column...], items: [column...]}`; `items` are the columns on the category axis (mapping ITEM). None when the card
    saves no order. Calculations are named as in `card_top_n`."""
    formulas = (card.definition or {}).get("formulas") or {}

    def named(column: str) -> str:
        formula = formulas.get(column)
        return formula["name"] if formula and formula.get("name") and formula.get("formula") else column

    for entry in (card.definition or {}).get("subscriptions") or []:
        sub = entry.get("subscription") or {}
        if (entry.get("componentName") or sub.get("name")) != "main" or not sub.get("orderBy"):
            continue
        return {"order_by": [{"column": named(o.get("column") or o.get("formulaId") or ""), "aggregation": o.get("aggregation"),
                              "order": (o.get("order") or "ASCENDING").upper()} for o in sub["orderBy"]],
                "group_by": [named(g.get("column") or g.get("formulaId") or "") for g in sub.get("groupBy") or []],
                "items": [named(c.get("column") or c.get("formulaId") or "")
                          for c in sub.get("columns") or [] if c.get("mapping") == "ITEM"]}
    return None


def card_drill_views(card: EstateObject) -> list[dict]:
    """The drill views of a card (EstateScanner captures them under
    `definition.drillViews`), flattened with their place in the drill tree.

    Each view is `{id, title, chart_type, level, parent, columns}`; `level`
    1 is a view reached straight from the card, `parent` the view it drills
    from (None at level 1). Columns are the view's `main` component:
    `{name, formula_id, aggregation, alias}`. Empty when the card has no
    drill path or the scan predates their capture.
    """
    definition = card.definition or {}
    views = definition.get("drillViews") or {}
    out: list[dict] = []

    def walk(paths: dict, level: int, parent: str | None) -> None:
        for view_id, child in (paths or {}).items():
            view = views.get(str(view_id))
            if view is not None:
                columns: list[dict] = []
                for entry in view.get("subscriptions") or []:
                    if entry.get("componentName") != "main":
                        continue
                    for column in (entry.get("subscription") or {}).get("columns") or []:
                        columns.append({
                            "name": column.get("column"), "formula_id": column.get("formulaId"),
                            "aggregation": column.get("aggregation"), "alias": column.get("alias")})
                out.append({
                    "id": str(view_id), "title": view.get("title") or "",
                    "chart_type": (view.get("metadata") or {}).get("chartType"),
                    "level": level, "parent": parent, "columns": columns})
            else:
                out.append({"id": str(view_id), "title": "", "chart_type": None,
                            "level": level, "parent": parent, "columns": []})
            walk((child or {}).get("paths") or {}, level + 1, str(view_id))

    walk((definition.get("drillPath") or {}).get("paths") or {}, 1, None)
    return out


def resolve_dashboard(reader: EstateReader, dashboard_id: str, max_depth: int = MAX_DEPTH) -> Closure:
    dashboard = reader.get("dashboard", dashboard_id)
    closure = Closure(dashboard=dashboard)

    closure.cards = reader.cards_on_dashboard(dashboard_id)
    if not closure.cards:
        closure.warnings.append("Dashboard has no cards in this scan.")

    # Datasets: union over the cards, keeping first-seen order so the
    # generated model's table order matches the dashboard's reading order.
    dataset_ids: list[str] = []
    for card in closure.cards:
        ids = reader.datasets_for_card(card)
        closure.card_datasets[card.id] = ids
        if not ids:
            closure.warnings.append(f"Card {card.id} ({card.name!r}) has no dataset in this scan.")
        for dataset_id in ids:
            if dataset_id not in dataset_ids:
                dataset_ids.append(dataset_id)

    # Walk upstream: dataset -> producing dataflow -> its input datasets.
    seen_datasets: set[str] = set()
    seen_dataflows: set[str] = set()
    dataflow_ids: list[str] = []
    frontier = list(dataset_ids)
    depth = 0
    while frontier:
        if depth > max_depth:
            closure.warnings.append(
                f"Stopped following upstream lineage at depth {max_depth}; "
                f"{len(frontier)} dataset(s) beyond it were not resolved."
            )
            break
        next_frontier: list[str] = []
        for dataset_id in frontier:
            if dataset_id in seen_datasets:
                continue
            seen_datasets.add(dataset_id)
            if dataset_id not in dataset_ids:
                dataset_ids.append(dataset_id)

            dataflow_id = reader.producing_dataflow(dataset_id)
            if dataflow_id is None:
                closure.root_dataset_ids.append(dataset_id)
                continue
            closure.dataset_producer[dataset_id] = dataflow_id
            if dataflow_id in seen_dataflows:
                continue
            seen_dataflows.add(dataflow_id)
            dataflow_ids.append(dataflow_id)
            next_frontier += reader.input_datasets_for_dataflow(dataflow_id)
        frontier = next_frontier
        depth += 1

    closure.datasets = reader.get_many("dataset", dataset_ids)
    closure.dataflows = reader.get_many("dataflow", dataflow_ids)

    # Beast modes attached to any card or dataset in the closure.
    calculated_field_ids: list[str] = []
    for card in closure.cards:
        for cf in reader.calculated_fields_for("card", card.id):
            if cf.id not in calculated_field_ids:
                calculated_field_ids.append(cf.id)
    for dataset in closure.datasets:
        for cf in reader.calculated_fields_for("dataset", dataset.id):
            if cf.id not in calculated_field_ids:
                calculated_field_ids.append(cf.id)
    closure.calculated_fields = reader.get_many("calculated_field", calculated_field_ids)

    # A beast mode can call another by id (`DOMO_BEAST_MODE(38756)`) that no card or dataset in the
    # closure links to; without it the caller cannot be translated ("beast mode 38756 is not in the scan").
    known = set(calculated_field_ids)
    pending = list(closure.calculated_fields)
    while pending:
        wanted = []
        for cf in pending:
            for ref in _BEAST_MODE_REF.findall(str(cf.row.get("formula") or "")):
                if ref not in known and ref not in wanted:
                    wanted.append(ref)
        known.update(wanted)
        pending = reader.get_many("calculated_field", wanted) if wanted else []
        closure.calculated_fields += pending

    closure.missing = _missing(dataset_ids, closure.datasets, "dataset") + _missing(
        dataflow_ids, closure.dataflows, "dataflow"
    )
    if closure.missing:
        closure.warnings.append(
            f"{len(closure.missing)} referenced object(s) are not in this scan "
            "(deleted, or outside the scanning user's permissions)."
        )
    return closure


def _missing(wanted: list[str], found: list[EstateObject], object_type: str) -> list[tuple[str, str]]:
    found_ids = {obj.id for obj in found}
    return [(object_type, i) for i in wanted if i not in found_ids]

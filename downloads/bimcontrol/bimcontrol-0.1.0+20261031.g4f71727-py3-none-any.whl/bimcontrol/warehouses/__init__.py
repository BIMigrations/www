"""Warehouse adapters: where migrated data lands.

Every migration BIMControl runs assumes the customer owns a warehouse
(Redshift, Snowflake, BigQuery). Data that exists only inside the source
BI platform -- a spreadsheet uploaded into Domo, a Tableau extract -- has
to be landed there before the target platform can read it.

Only Redshift is built. The other two are registered stubs that fail with
an explanation and carry notes on what implementing them involves, so
picking one in the UI says "not built yet" rather than raising a KeyError
somewhere three layers down.
"""

from __future__ import annotations

from typing import Any

from .base import (
    ROW_ORDER_COLUMN,
    ColumnSpec,
    LoadResult,
    TableSpec,
    WarehouseAdapter,
    WarehouseError,
    WarehouseNotConfigured,
    number_csv_rows,
    safe_table_name,
    scan_csv_widths,
)
from .bigquery import BigQueryAdapter
from .redshift import RedshiftAdapter
from .snowflake import SnowflakeAdapter

ADAPTERS: dict[str, type[WarehouseAdapter]] = {
    RedshiftAdapter.key: RedshiftAdapter,
    SnowflakeAdapter.key: SnowflakeAdapter,
    BigQueryAdapter.key: BigQueryAdapter,
}


def get_adapter(key: str, settings: dict[str, Any] | None = None) -> WarehouseAdapter:
    try:
        adapter_cls = ADAPTERS[key]
    except KeyError:
        raise WarehouseError(
            f"Unknown warehouse {key!r}. Known: {', '.join(sorted(ADAPTERS))}"
        ) from None
    return adapter_cls(settings or {})


def list_warehouses() -> list[dict[str, Any]]:
    """For the Connections screen: what can be picked, and what works."""
    return [
        {
            "key": key,
            "display_name": cls.display_name,
            "implemented": getattr(cls, "implemented", True),
        }
        for key, cls in ADAPTERS.items()
    ]


__all__ = [
    "ADAPTERS", "get_adapter", "list_warehouses",
    "WarehouseAdapter", "WarehouseError", "WarehouseNotConfigured",
    "TableSpec", "ColumnSpec", "LoadResult", "safe_table_name", "scan_csv_widths", "number_csv_rows", "ROW_ORDER_COLUMN",
]

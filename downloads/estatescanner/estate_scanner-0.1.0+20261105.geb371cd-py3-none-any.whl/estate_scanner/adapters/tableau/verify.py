"""Checks of a Tableau scan against the site itself (read-only; M3 3.12).

A scan is only worth what an independent reading of the site says about it. ``ids`` asks the site for every list the scan was built from
(projects, workbooks, published data sources, views, users, groups, flows, custom views, subscriptions, and the connections of every
workbook and data source) and compares the **ids** with the rows of the instance's latest completed scan, then the names of the ids both
sides hold. Equal counts with different ids (an object deleted and another created between the scan and the check) are a difference.

An endpoint that does not answer, or whose list did not arrive whole, is listed as such, never counted as matching. Nothing here writes to
the database or the site; run it through ``scripts/verify_tableau_scan.py``.

``languages`` reads only the scan: a bin, group or cluster is never stored as a formula (#82).

Not compared here: calculation text and workbook-file contents (the Metadata API is the independent path for those: task 3.9, #85) and
permissions. The row sets are the scan's **latest completed** one.
"""

from __future__ import annotations

import collections
import sqlite3
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Any

from estate_scanner.core.platform import PlatformError

from .content import CLASS_BIN, CLASS_GROUP, CLUSTER_SUFFIX, LANG_BIN, LANG_CALC, LANG_CLUSTER, LANG_GROUP, LANG_PARAMETER
from .http import ApiError, TableauHttp

WORKERS = 4
LABELLED = frozenset({"custom views", "subscriptions", "flows"})  # the kinds whose names the scan stores through ``_label`` (cut at 1,000); the rest through ``_text`` (2,000)
SHOWN_NAME_DIFFERENCES = 20

# label, REST path, collection, item, (table, extra where) of the scan. ``views`` is the union of dashboards and the cards that are REST views (not the custom
# views, and not the worksheets only the workbook file has: those are no view of the site).
LISTS: list[tuple[str, str, str, str, tuple[str, str]]] = [
    ("projects", "/projects", "projects", "project", ("workspaces", "type = 'project'")),
    ("workbooks", "/workbooks", "workbooks", "workbook", ("apps", "type = 'workbook'")),
    ("data sources", "/datasources", "datasources", "datasource", ("datasets", "json_extract(definition_json, '$.kind') = 'published'")),
    ("users", "/users", "users", "user", ("users", "1")),
    ("groups", "/groups", "groups", "group", ("groups_", "1")),
    ("flows", "/flows", "flows", "flow", ("dataflows", "1")),
    ("custom views", "/customviews", "customViews", "customView", ("cards", "type = 'custom_view'")),
    ("subscriptions", "/subscriptions", "subscriptions", "subscription", ("alerts", "1")),
]


@dataclass
class CheckResult:
    name: str
    totals: collections.Counter = field(default_factory=collections.Counter)
    differences: list[str] = field(default_factory=list)  # the scan and the site disagree
    unanswered: list[str] = field(default_factory=list)  # the site did not answer (or not whole): nothing is proven for these

    @property
    def status(self) -> str:
        return "DIFFERS" if self.differences else "INCOMPLETE" if self.unanswered else "matches"


def latest_scan(conn: sqlite3.Connection, instance: str) -> int | None:
    row = conn.execute("SELECT id FROM scans WHERE platform = 'tableau' AND instance = ? AND status = 'completed' ORDER BY id DESC LIMIT 1", (instance,)).fetchone()
    return row[0] if row else None


def _scan_rows(conn: sqlite3.Connection, instance: str, scan_id: int, table: str, where: str) -> dict[str, str]:
    cur = conn.execute(f"SELECT id, name FROM {table} WHERE platform = 'tableau' AND instance = ? AND last_seen_scan_id = ? AND {where}", (instance, scan_id))  # noqa: S608 -- constants above
    return {str(r[0]): str(r[1] if r[1] is not None else "") for r in cur}


def _list(http: TableauHttp, path: str, collection: str, item: str, label: Callable[[Any], Any] | None = None) -> tuple[dict[str, str] | None, str | None]:
    """({id: name}, None), or (None, why it could not be read whole). ``label`` is what the scan applied to a name before it stored it."""
    try:
        paged = http.list_paged(http.site_path(path), collection, item, tolerate_page_errors=False)
    except (ApiError, PlatformError) as exc:  # (a sign-in that was lost is a PlatformError: the list is unanswered, the other lists are still compared)
        return None, str(exc)
    if paged.missing or paged.truncated_at or paged.failed_pages:
        return None, f"the list did not arrive whole ({paged.missing} of {paged.total_available} rows missing)"
    names = {str(r["id"]): r.get("name") or r.get("subject") or "" for r in paged.items if isinstance(r, dict) and r.get("id") is not None}
    return {i: str(label(n) if label else n or "") for i, n in names.items()}, None


def _compare(result: CheckResult, label: str, service: dict[str, str], scan: dict[str, str], names: bool = True) -> None:
    result.totals[f"{label} in the service"] += len(service)
    result.totals[f"{label} in the scan"] += len(scan)
    result.totals[f"{label} in both"] += len(service.keys() & scan.keys())
    for key in sorted(scan.keys() - service.keys()):
        result.differences.append(f"{label}: scan only {key} ({scan[key]!r})")
    for key in sorted(service.keys() - scan.keys()):
        result.differences.append(f"{label}: service only {key} ({service[key]!r})")
    if names:
        renamed = [k for k in service.keys() & scan.keys() if service[k] and scan[k] and service[k] != scan[k]]
        for key in sorted(renamed)[:SHOWN_NAME_DIFFERENCES]:
            result.differences.append(f"{label}: {key} is {service[key]!r} on the service and {scan[key]!r} in the scan")


def _cleaner(client: Any | None, kind: str) -> Callable[[Any], Any] | None:
    """The scan's own name cleaner for a kind (credentials redacted, long names cut, a lone surrogate replaced), so a name the scan changed on purpose is not
    reported as a rename. None without a client: names are then compared as the site gave them."""
    if client is None:
        return None
    clean = client._label if kind in LABELLED else client._text
    return lambda value: clean(value, "verify")


def check_ids(conn: sqlite3.Connection, http: TableauHttp, instance: str, client: Any | None = None) -> CheckResult:
    """``client``: the scan's ``TableauClient`` (only its name cleaners are used; the reads go through ``http``)."""
    result = CheckResult("ids")
    scan_id = latest_scan(conn, instance)
    if scan_id is None:
        result.unanswered.append(f"no completed scan of {instance} in this database")
        return result
    result.totals["scan compared"] = scan_id
    for kind, path, collection, item, (table, where) in LISTS:
        service, why = _list(http, path, collection, item, _cleaner(client, kind))
        if service is None:
            result.unanswered.append(f"{kind}: {why}")
            continue
        _compare(result, kind, service, _scan_rows(conn, instance, scan_id, table, where))
    # views: REST lists dashboards, stories and worksheets alike; the scan holds them in two tables
    views, why = _list(http, "/views", "views", "view", _cleaner(client, "views"))
    if views is None:
        result.unanswered.append(f"views: {why}")
    else:
        scan_views = _scan_rows(conn, instance, scan_id, "dashboards", "1") | _scan_rows(conn, instance, scan_id, "cards", "COALESCE(type, '') != 'custom_view' AND COALESCE(json_extract(definition_json, '$.source'), '') != 'workbook file'")
        _compare(result, "views", views, scan_views)
    # connections: one list per workbook and per data source
    workbooks, _ = _list(http, "/workbooks", "workbooks", "workbook")
    sources, _ = _list(http, "/datasources", "datasources", "datasource")
    if workbooks is None or sources is None:
        result.unanswered.append("connections: the workbook or data source list could not be read, so their connections were not asked")
        return result
    owners = [("workbooks", w) for w in workbooks] + [("datasources", d) for d in sources]

    def one(owner: tuple[str, str]) -> tuple[tuple[str, str], dict[str, str] | None, str | None]:
        kind, oid = owner
        got, problem = _list(http, f"/{kind}/{oid}/connections", "connections", "connection")
        return owner, got, problem

    with ThreadPoolExecutor(WORKERS) as pool:
        answers = list(pool.map(one, owners))
    connections: dict[str, str] = {}
    for (kind, oid), got, problem in answers:
        if got is None:
            result.unanswered.append(f"connections of {kind[:-1]} {oid}: {problem}")
        else:
            connections.update(got)
    if not any(got is None for _, got, _ in answers):
        _compare(result, "connections", connections, _scan_rows(conn, instance, scan_id, "accounts", "1"), names=False)
    return result


_CLASS_OF_LANGUAGE = {LANG_BIN: CLASS_BIN, LANG_GROUP: CLASS_GROUP, LANG_CLUSTER: CLASS_GROUP}


def check_languages(conn: sqlite3.Connection, http: TableauHttp | None, instance: str, client: Any | None = None) -> CheckResult:
    """Scan-only (no REST): no bin, group or cluster is stored as a formula, and no formula as one of them (estatescanner#82).

    A ``<calculation class='bin'>`` is ``tableau_bin``, ``class='categorical-bin'`` is ``tableau_group`` or ``tableau_cluster``, everything
    else is ``tableau_calc`` or ``tableau_parameter``; a row whose ``definition.calc_class`` and ``formula_language`` disagree would be
    handed to a translator as an expression (the 4 rows of the 2026-11-03 trial scan were exactly that). ``http`` and ``client`` are unused;
    the signature is the other checks'."""
    result = CheckResult("languages")
    scan_id = latest_scan(conn, instance)
    if scan_id is None:
        result.unanswered.append(f"no completed scan of {instance} in this database")
        return result
    result.totals["scan compared"] = scan_id
    cur = conn.execute(
        "SELECT id, name, formula_language, json_extract(definition_json, '$.calc_class'), json_extract(definition_json, '$.internal_name') "
        "FROM calculated_fields WHERE platform = 'tableau' AND instance = ? AND last_seen_scan_id = ?", (instance, scan_id))
    for cid, name, language, calc_class, internal_name in cur:
        result.totals["calculated fields"] += 1
        result.totals[str(language)] += 1
        if calc_class == CLASS_BIN:
            expected = LANG_BIN
        elif calc_class == CLASS_GROUP:  # a group and a cluster are the same element; the field's internal name says which (``formula_language``)
            expected = LANG_CLUSTER if (internal_name or "").endswith(CLUSTER_SUFFIX) else LANG_GROUP
        elif language in _CLASS_OF_LANGUAGE:
            result.differences.append(f"{cid} ({name!r}) is {language} but its class is {calc_class!r}")
            continue
        elif language in (LANG_CALC, LANG_PARAMETER):
            continue
        else:
            result.differences.append(f"{cid} ({name!r}) has the language {language!r}, which this check does not know")
            continue
        if language != expected:
            result.differences.append(f"{cid} ({name!r}) has class {calc_class!r} and is stored as {language}, not {expected}" + ("; it would be read as a formula" if language == LANG_CALC else ""))
    if not result.totals["calculated fields"]:  # nothing was compared: "matches" would be a pass that proved nothing (estatescanner#132 item 5)
        result.unanswered.append(f"scan {scan_id} holds no calculated field to compare (workbook files not read, or none read whole)")
    return result


CHECKS: dict[str, Callable[..., Any]] = {"ids": check_ids, "languages": check_languages}
SCAN_ONLY = frozenset({"languages"})  # the checks that never ask the site: the script needs no saved session for them

from estate_scanner.core.registry import PlatformDescriptor, register_platform

from .auth import DomoAuthenticator, DomoSession
from .client import DomoClient
from .http import DomoHttp, DomoSearchLimitExceededError, DomoSessionExpiredError
from .policies import describe_policies

register_platform(
    PlatformDescriptor(
        key="domo",
        display_name="Domo",
        status="available",
        authenticator_cls=DomoAuthenticator,
        client_cls=DomoClient,
        auth_mode="interactive_browser",
        instance_hint="Instance name, e.g. yourcompany",
        describe_policies=describe_policies,
    )
)

__all__ = [
    "DomoAuthenticator",
    "DomoSession",
    "DomoClient",
    "DomoHttp",
    "DomoSearchLimitExceededError",
    "DomoSessionExpiredError",
]

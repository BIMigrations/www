"""Calculated columns of a DirectQuery table are computed in the warehouse at query time, so the
expression has to be one Power BI can turn into SQL. FORMAT of a date cannot; the same text built
from YEAR/MONTH/DAY/WEEKDAY can (measured on a 20.7M-row table, bimcontrol#144)."""

from __future__ import annotations

import re

_MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September",
           "October", "November", "December"]
_DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
_TOKEN = re.compile(r"yyyy|yy|mmmm|mmm|mm|m|dddd|ddd|dd|d", re.IGNORECASE)
_LITERAL = re.compile(r"[-/ ,.:]+")
_FORMAT = re.compile(r"\bFORMAT\s*\(", re.IGNORECASE)


def _switch(value: str, names: list[str], first: int, width: int | None) -> str:
    cases = ", ".join(f'{i}, "{name[:width] if width else name}"' for i, name in enumerate(names, start=first))
    return f"SWITCH({value}, {cases})"


def _part(token: str, x: str) -> str | None:
    lower = token.lower()
    return {
        "yyyy": f"YEAR({x})",
        "yy": f"RIGHT(YEAR({x}), 2)",
        "mmmm": _switch(f"MONTH({x})", _MONTHS, 1, None),
        "mmm": _switch(f"MONTH({x})", _MONTHS, 1, 3),
        "mm": f'RIGHT("0" & MONTH({x}), 2)',
        "m": f"MONTH({x})",
        "dddd": _switch(f"WEEKDAY({x}, 1)", _DAYS, 1, None),
        "ddd": _switch(f"WEEKDAY({x}, 1)", _DAYS, 1, 3),
        "dd": f'RIGHT("0" & DAY({x}), 2)',
        "d": f"DAY({x})",
    }.get(lower)


def _date_format(x: str, fmt: str) -> str | None:
    """`fmt` (a FORMAT string made of date parts and separators) as foldable DAX, or None."""
    parts: list[str] = []
    position = 0
    while position < len(fmt):
        token = _TOKEN.match(fmt, position)
        if token:
            parts.append(_part(token.group(0), x))
            position = token.end()
            continue
        literal = _LITERAL.match(fmt, position)
        if not literal:
            return None
        parts.append('"' + literal.group(0).replace('"', '""') + '"')
        position = literal.end()
    return " & ".join(parts) if parts else None


def _split_arguments(text: str, start: int) -> tuple[list[str], int] | None:
    """The top-level arguments of the call whose '(' is just before `start`, and the index after ')'."""
    depth, quoted, begin, args = 1, False, start, []
    for i in range(start, len(text)):
        ch = text[i]
        if quoted:
            quoted = ch != '"'
        elif ch == '"':
            quoted = True
        elif ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth == 0:
                args.append(text[begin:i].strip())
                return args, i + 1
        elif ch == "," and depth == 1:
            args.append(text[begin:i].strip())
            begin = i + 1
    return None


def foldable_dates(expression: str) -> str:
    """`expression` with every FORMAT(date, "yyyy-MM-dd")-style call spelled with functions the
    warehouse can compute. Anything else is left as it was."""
    out, position = [], 0
    for match in _FORMAT.finditer(expression):
        if match.start() < position:
            continue                     # inside a call already rewritten
        parsed = _split_arguments(expression, match.end())
        if not parsed or len(parsed[0]) != 2:
            continue
        (x, fmt), end = parsed
        if not (len(fmt) >= 2 and fmt[0] == fmt[-1] == '"'):
            continue
        replacement = _date_format(foldable_dates(x), fmt[1:-1])
        if replacement is None:
            continue
        out += [expression[position:match.start()], f"({replacement})"]
        position = end
    out.append(expression[position:])
    return "".join(out)


_SWITCH = re.compile(r"\bSWITCH\s*\(", re.IGNORECASE)
_PART_OF_DATE = re.compile(r"^(MONTH|WEEKDAY|DAY)\s*\(", re.IGNORECASE)
# The keys a SWITCH must cover for the tree to be the same function: MONTH 1-12, DAY 1-31, WEEKDAY(x, 1) 1-7.
_FULL_RANGE = {"MONTH": (1, 12), "DAY": (1, 31), "WEEKDAY": (1, 7)}
_INTEGER = re.compile(r"^-?\d+$")


def _tree(subject: str, keys: list[int], values: list[str], lo: int, hi: int) -> str:
    if lo == hi:
        return values[lo]
    mid = (lo + hi) // 2
    return f"IF({subject} <= {keys[mid]}, {_tree(subject, keys, values, lo, mid)}, {_tree(subject, keys, values, mid + 1, hi)})"


def foldable_switch(expression: str) -> str:
    """`SWITCH(MONTH(x), 1, "Jan", ..., 12, "Dec")` as a balanced tree of IFs.

    The warehouse cannot compute a 12-way SWITCH once its result is concatenated with anything ("We
    couldn't fold the expression", HCC - SW and Clinic Collections - SW). Measured on a 20.7M-row
    DirectQuery probe: SWITCH & text fails, a 12-deep IF chain fails, a balanced tree (4 levels) folds.
    Only a SWITCH on a plain MONTH/WEEKDAY/DAY call whose keys cover the whole range (1-12, 1-7, 1-31) with no
    default is rewritten, so the tree needs no guard. Anything else is left as it was."""
    out, position = [], 0
    for match in _SWITCH.finditer(expression):
        if match.start() < position:
            continue
        parsed = _split_arguments(expression, match.end())
        if not parsed:
            continue
        args, end = parsed
        subject, rest = args[0], args[1:]
        part = _PART_OF_DATE.match(subject)
        if not part or len(rest) < 4 or len(rest) % 2:
            continue
        call = _split_arguments(subject, part.end())
        if call is None or call[1] != len(subject):
            continue                    # `MONTH(d) + 1` and the like are not a plain date part
        keys = [a for a in rest[0::2]]
        if not all(_INTEGER.match(k) for k in keys):
            continue
        numbers = [int(k) for k in keys]
        low, high = _FULL_RANGE[part.group(1).upper()]
        if numbers != list(range(low, high + 1)):
            continue                    # a partial SWITCH is BLANK for the keys it lacks; the tree would not be
        values = [foldable_switch(v) for v in rest[1::2]]
        out += [expression[position:match.start()], f"({_tree(subject, numbers, values, 0, len(values) - 1)})"]
        position = end
    out.append(expression[position:])
    return "".join(out)


def still_needs_the_engine(expression: str) -> bool:
    """True when `expression` still calls a function the warehouse cannot compute (FORMAT)."""
    return bool(_FORMAT.search(expression))


# A text column that a calculated column reads as a number: `IFERROR(VALUE(T[c]), 0)` (dax.text_columns_against_numbers). In an
# imported table that is fine; in a DirectQuery table IFERROR does not fold, and a plain VALUE folds into a cast that fails on the
# first text that is not a number ('J1234'). Measured 2026-10-21 (probe model over the Daily Charge output, bimcontrol#286):
# the number has to be made in the warehouse query, and `IF(ISBLANK(n), 0, n)` over that column folds and gives Domo's reading.
NUMBER_SUFFIX = " (number)"


def number_shadow_name(column: str) -> str:
    return column + NUMBER_SUFFIX


def _read_as_number(table_ref: str, column: str) -> "re.Pattern[str]":
    """`IFERROR(VALUE(T[column]), 0)`; DAX names are case-insensitive, and Domo's formula spells a column as the dataset does,
    which is not always how the model names it ('CPT Code 5' in the formula, 'cpt code 5' in the table)."""
    return re.compile(r"IFERROR\(VALUE\(" + re.escape(f"{table_ref}[{column.replace(']', ']]')}]") + r"\), 0\)", re.IGNORECASE)


def number_shadows(table_ref: str, text_columns: list[str], expressions: list[str]) -> list[str]:
    """The text columns that any of `expressions` reads with `IFERROR(VALUE(column), 0)`, in column order."""
    return [c for c in text_columns if any(_read_as_number(table_ref, c).search(e) for e in expressions)]


def use_number_shadows(expression: str, table_ref: str, columns: list[str]) -> str:
    """`expression` reading each of `columns` through its number column (made by the table's query)."""
    for column in columns:
        shadow = f"{table_ref}[{number_shadow_name(column).replace(']', ']]')}]"
        expression = _read_as_number(table_ref, column).sub(lambda _: f"IF(ISBLANK({shadow}), 0, {shadow})", expression)
    return expression

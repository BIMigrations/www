"""Thin REST client for Power BI and Microsoft Fabric.

Two API surfaces, one Entra sign-in, a different token audience for each:

- **Power BI REST** (api.powerbi.com/v1.0/myorg): per-workspace listings
  (``/groups/{id}/reports`` ...), refresh history, dashboards and tiles, and the
  tenant-wide admin surface (``/admin/...``) including the *scanner API*
  (``getInfo`` -> ``scanStatus`` -> ``scanResult``).
- **Fabric REST** (api.fabric.microsoft.com/v1): ``getDefinition`` returns an
  item's files (TMDL for a semantic model, PBIR for a report) as a long-running
  operation.

Every call raises ``PowerBiApiError`` with the HTTP status on failure; deciding
whether that ends the scan or becomes a reported issue is the caller's job
(``client.py``), so nothing here swallows an error.
"""

from __future__ import annotations

import time
import urllib.parse
from typing import Any

import requests

from estate_scanner.core.platform import PlatformError

from .auth import FABRIC_SCOPE, POWERBI_SCOPE, PowerBiSession, TokenProvider, provider_for

FABRIC_API = "https://api.fabric.microsoft.com/v1"
POWERBI_API = "https://api.powerbi.com/v1.0/myorg"

POLL_SECONDS = 2.0
POLL_TIMEOUT_S = 300
MAX_THROTTLE_RETRIES = 6
MAX_SERVER_RETRIES = 2
MAX_NETWORK_RETRIES = 3
REQUEST_TIMEOUT_S = 120
# The scanner API takes at most 100 workspaces per getInfo call.
SCAN_BATCH = 100


class PowerBiApiError(PlatformError):
    def __init__(self, message: str, status: int | None = None):
        super().__init__(message)
        self.status = status


def _short(text: str, limit: int = 300) -> str:
    return " ".join(text.split())[:limit]


class PowerBiHttp:
    def __init__(self, session: PowerBiSession, tokens: TokenProvider | None = None, http: requests.Session | None = None):
        self._tokens = tokens or provider_for(session)
        self._http = http or requests.Session()
        self._sleep = time.sleep

    # -- plumbing -------------------------------------------------------------

    def _send(self, method: str, url: str, scope: str, **kwargs: Any) -> requests.Response:
        throttled = 0
        server_errors = 0
        network_errors = 0
        extra_headers = dict(kwargs.pop("headers", None) or {})
        while True:
            headers = {**extra_headers, "Authorization": f"Bearer {self._tokens.token(scope)}"}
            try:
                resp = self._http.request(method, url, headers=headers, timeout=REQUEST_TIMEOUT_S, **kwargs)
            except requests.RequestException as exc:
                # A reset, timeout or broken stream is the network, not an answer: try again a few
                # times, then report it like any other failed call (the caller decides).
                network_errors += 1
                if network_errors > MAX_NETWORK_RETRIES:
                    raise PowerBiApiError(f"{method} {url.split('?')[0]} -> {type(exc).__name__}: {_short(str(exc))}") from exc
                self._sleep(2.0 * network_errors)
                continue
            if resp.status_code == 429 and throttled < MAX_THROTTLE_RETRIES:
                throttled += 1
                retry_after = resp.headers.get("Retry-After")
                try:
                    wait = float(retry_after) if retry_after else 5.0 * throttled
                except ValueError:
                    wait = 5.0 * throttled
                self._sleep(min(wait, 120.0))
                continue
            if resp.status_code in (500, 502, 503, 504) and server_errors < MAX_SERVER_RETRIES:
                server_errors += 1
                self._sleep(3.0 * server_errors)
                continue
            return resp

    def _request(self, method: str, base: str, path: str, scope: str, **kwargs: Any) -> Any:
        resp = self._send(method, base + path, scope, **kwargs)
        if resp.status_code == 202 and resp.headers.get("Location") and "/operations/" in resp.headers["Location"]:
            return self._wait_for(resp, scope)
        if resp.status_code >= 400:
            raise PowerBiApiError(f"{method} {path} -> {resp.status_code}: {_short(resp.text)}", resp.status_code)
        if not resp.content:
            return None
        return self._json(resp, f"{method} {path}")

    @staticmethod
    def _json(resp: requests.Response, what: str) -> Any:
        try:
            return resp.json()
        except ValueError as exc:
            raise PowerBiApiError(f"{what} -> {resp.status_code}: not JSON ({_short(resp.text, 120)})", resp.status_code) from exc

    def _wait_for(self, resp: requests.Response, scope: str) -> Any:
        """Follow a Fabric long-running operation (getDefinition) to its result."""
        location = resp.headers["Location"]
        deadline = time.monotonic() + POLL_TIMEOUT_S
        while time.monotonic() < deadline:
            try:
                wait = float(resp.headers.get("Retry-After") or POLL_SECONDS)
            except ValueError:
                wait = POLL_SECONDS
            self._sleep(max(0.5, min(wait, 10.0)))
            resp = self._send("GET", location, scope)
            if resp.status_code >= 400:
                raise PowerBiApiError(f"operation poll -> {resp.status_code}: {_short(resp.text)}", resp.status_code)
            body = self._json(resp, "operation poll") if resp.content else {}
            status = (body.get("status") or "").lower()
            if status in ("succeeded", "completed"):
                result = self._send("GET", f"{location}/result", scope)
                if result.status_code >= 400:
                    raise PowerBiApiError(f"operation result -> {result.status_code}: {_short(result.text)}", result.status_code)
                return self._json(result, "operation result") if result.content else body
            if status in ("failed", "cancelled"):
                raise PowerBiApiError(f"Fabric operation {status}: {_short(str(body.get('error') or body))}")
        raise PowerBiApiError("Fabric operation did not finish within the timeout")

    def fabric_get(self, path: str, **kwargs: Any) -> Any:
        return self._request("GET", FABRIC_API, path, FABRIC_SCOPE, **kwargs)

    def fabric_post(self, path: str, **kwargs: Any) -> Any:
        return self._request("POST", FABRIC_API, path, FABRIC_SCOPE, **kwargs)

    def pbi_get(self, path: str, **kwargs: Any) -> Any:
        return self._request("GET", POWERBI_API, path, POWERBI_SCOPE, **kwargs)

    def pbi_post(self, path: str, **kwargs: Any) -> Any:
        return self._request("POST", POWERBI_API, path, POWERBI_SCOPE, **kwargs)

    def _value(self, path: str) -> list[dict]:
        return (self.pbi_get(path) or {}).get("value") or []

    # -- Fabric: workspaces, items, definitions --------------------------------

    def _paged_fabric(self, path: str) -> list[dict]:
        out: list[dict] = []
        next_path: str | None = path
        while next_path:
            body = self.fabric_get(next_path) or {}
            out.extend(body.get("value") or [])
            token = body.get("continuationToken")
            if not token:
                break
            sep = "&" if "?" in path else "?"
            next_path = f"{path}{sep}continuationToken={urllib.parse.quote(token, safe='')}"
        return out

    def list_workspaces(self) -> list[dict]:
        return self._paged_fabric("/workspaces")

    def list_items(self, workspace_id: str) -> list[dict]:
        return self._paged_fabric(f"/workspaces/{workspace_id}/items")

    def item_definition(self, workspace_id: str, item_id: str, fmt: str | None = None) -> dict | None:
        path = f"/workspaces/{workspace_id}/items/{item_id}/getDefinition"
        if fmt:
            path += f"?format={fmt}"
        return self.fabric_post(path)

    # -- Power BI, per workspace --------------------------------------------------

    def groups(self) -> list[dict]:
        return self._value("/groups")

    def workspace_users(self, workspace_id: str) -> list[dict]:
        return self._value(f"/groups/{workspace_id}/users")

    def reports(self, workspace_id: str) -> list[dict]:
        return self._value(f"/groups/{workspace_id}/reports")

    def datasets(self, workspace_id: str) -> list[dict]:
        return self._value(f"/groups/{workspace_id}/datasets")

    def dataset_refreshes(self, workspace_id: str, dataset_id: str, top: int = 10) -> list[dict]:
        return self._value(f"/groups/{workspace_id}/datasets/{dataset_id}/refreshes?$top={top}")

    def dataset_datasources(self, workspace_id: str, dataset_id: str) -> list[dict]:
        return self._value(f"/groups/{workspace_id}/datasets/{dataset_id}/datasources")

    def dataflows(self, workspace_id: str) -> list[dict]:
        return self._value(f"/groups/{workspace_id}/dataflows")

    def dataflow_definition(self, workspace_id: str, dataflow_id: str) -> dict | None:
        return self.pbi_get(f"/groups/{workspace_id}/dataflows/{dataflow_id}")

    def dataflow_transactions(self, workspace_id: str, dataflow_id: str) -> list[dict]:
        return self._value(f"/groups/{workspace_id}/dataflows/{dataflow_id}/transactions")

    def dataflow_datasources(self, workspace_id: str, dataflow_id: str) -> list[dict]:
        return self._value(f"/groups/{workspace_id}/dataflows/{dataflow_id}/datasources")

    def dataflow_upstream(self, workspace_id: str, dataflow_id: str) -> list[dict]:
        return self._value(f"/groups/{workspace_id}/dataflows/{dataflow_id}/upstreamDataflows")

    def dashboards(self, workspace_id: str) -> list[dict]:
        return self._value(f"/groups/{workspace_id}/dashboards")

    def dashboard_tiles(self, workspace_id: str, dashboard_id: str) -> list[dict]:
        return self._value(f"/groups/{workspace_id}/dashboards/{dashboard_id}/tiles")

    def apps(self) -> list[dict]:
        return self._value("/apps")

    def gateways(self) -> list[dict]:
        return self._value("/gateways")

    def gateway_datasources(self, gateway_id: str) -> list[dict]:
        return self._value(f"/gateways/{gateway_id}/datasources")

    # -- Power BI, tenant-wide (admin) --------------------------------------------

    def admin_workspace_ids(self) -> list[str]:
        """Every workspace id in the tenant, personal workspaces included."""
        body = self.pbi_get("/admin/workspaces/modified?excludePersonalWorkspaces=false") or []
        return [w["id"] for w in body if w.get("id")]

    def admin_apps(self) -> list[dict]:
        return self._value("/admin/apps?$top=5000")

    def scan_workspaces(self, workspace_ids: list[str]) -> dict:
        """The scanner API for one batch (<= 100 ids): ``getInfo`` queues the
        scan, ``scanStatus`` is polled, ``scanResult`` returns the inventory
        with lineage, datasource details, schema and expressions as far as the
        tenant allows (a disabled setting shows up in each workspace's
        ``dataRetrievalState``)."""
        start = self.pbi_post(
            "/admin/workspaces/getInfo?lineage=True&datasourceDetails=True&datasetSchema=True"
            "&datasetExpressions=True&getArtifactUsers=True",
            json={"workspaces": workspace_ids},
        )
        scan_id = (start or {}).get("id")
        if not scan_id:
            raise PowerBiApiError(f"getInfo returned no scan id: {_short(str(start))}")
        deadline = time.monotonic() + POLL_TIMEOUT_S
        while True:
            status = (self.pbi_get(f"/admin/workspaces/scanStatus/{scan_id}") or {}).get("status")
            if status == "Succeeded":
                break
            if status in ("Failed", "Cancelled"):
                raise PowerBiApiError(f"scanner API scan {scan_id} ended {status}")
            if time.monotonic() > deadline:
                raise PowerBiApiError(f"scanner API scan {scan_id} did not finish within {POLL_TIMEOUT_S} s")
            self._sleep(POLL_SECONDS)
        return self.pbi_get(f"/admin/workspaces/scanResult/{scan_id}") or {}

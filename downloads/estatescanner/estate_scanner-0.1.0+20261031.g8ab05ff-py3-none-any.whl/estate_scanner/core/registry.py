"""Two open registries:

- Platforms: what BI platforms this tool knows about, and how to talk to
  each one. New adapters register here; nothing else needs editing.
- Object types: which SQLite table/name-column backs each generic object
  type tag used in `edges`. graph.py reads this instead of a hardcoded
  dict, so a new adapter introducing a new object type doesn't require
  touching graph.py.
"""

from __future__ import annotations

from dataclasses import dataclass

from .platform import PlatformAuthenticator, PlatformClient


@dataclass(frozen=True)
class PlatformDescriptor:
    key: str
    display_name: str
    status: str  # "available" | "coming_soon"
    authenticator_cls: type[PlatformAuthenticator]
    client_cls: type[PlatformClient]
    auth_mode: str  # e.g. "interactive_browser" | "api_token" | "oauth"
    instance_hint: str = "Instance name"  # placeholder for the Connect screen's instance box


@dataclass(frozen=True)
class ObjectTypeDescriptor:
    object_type: str
    table: str
    name_column: str


_platforms: dict[str, PlatformDescriptor] = {}
_object_types: dict[str, ObjectTypeDescriptor] = {}


def register_platform(descriptor: PlatformDescriptor) -> None:
    _platforms[descriptor.key] = descriptor


def get_platform(key: str) -> PlatformDescriptor:
    try:
        return _platforms[key]
    except KeyError:
        raise KeyError(f"Unknown platform {key!r}; registered: {sorted(_platforms)}") from None


def all_platforms() -> list[PlatformDescriptor]:
    return list(_platforms.values())


def register_object_type(descriptor: ObjectTypeDescriptor) -> None:
    _object_types[descriptor.object_type] = descriptor


def get_object_type(object_type: str) -> ObjectTypeDescriptor:
    try:
        return _object_types[object_type]
    except KeyError:
        raise KeyError(f"Unknown object type {object_type!r}; registered: {sorted(_object_types)}") from None


def all_object_types() -> list[ObjectTypeDescriptor]:
    return list(_object_types.values())


# The 12 object types every adapter maps into -- table/column names match
# storage/schema.sql. Registered here (not per-adapter) since the schema
# itself is shared across all platforms, not owned by any one of them.
for _descriptor in [
    ObjectTypeDescriptor("dataset", "datasets", "name"),
    ObjectTypeDescriptor("dataflow", "dataflows", "name"),
    ObjectTypeDescriptor("card", "cards", "name"),
    ObjectTypeDescriptor("dashboard", "dashboards", "name"),
    ObjectTypeDescriptor("calculated_field", "calculated_fields", "name"),
    ObjectTypeDescriptor("user", "users", "name"),
    ObjectTypeDescriptor("group", "groups_", "name"),
    ObjectTypeDescriptor("account", "accounts", "name"),
    ObjectTypeDescriptor("alert", "alerts", "name"),
    ObjectTypeDescriptor("app", "apps", "name"),
    ObjectTypeDescriptor("workspace", "workspaces", "name"),
    ObjectTypeDescriptor("gateway", "gateways", "name"),
]:
    register_object_type(_descriptor)

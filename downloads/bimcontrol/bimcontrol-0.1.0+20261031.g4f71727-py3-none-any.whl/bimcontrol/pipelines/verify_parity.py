"""Proving the migrated report returns the same numbers.

Everything before this stage checks that the migration *ran*: the SQL
parses, the model imports, the report publishes. None of that is evidence
it is **right**. Three real bugs got through a clean publish in this
tool's short history -- a dropped union branch losing a tenth of the
rows, visual types Power BI does not have, and twenty-four visuals on an
eight-card dashboard -- and every one would have been caught here.

The comparison is card against visual, not dataset against table. A Domo
card's figures already have its aggregation, grouping and filters
applied, so matching them is the question a customer actually asks:
"does the new report say what the old one said".

Rows are matched by category, not by position. Power BI and Domo sort
differently, and comparing the fifth row of one against the fifth row of
the other produces confident nonsense.
"""

from __future__ import annotations

import itertools
import math
import re
import time
from dataclasses import replace
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from typing import Any

from bimcontrol.core import parity_causes
from bimcontrol.core.engine import ReviewItem, RunContext, StageResult
from bimcontrol.pipelines.build_powerbi import REPORT_FILE
from bimcontrol.sources.domo.session import DomoAuthError, DomoSessionExpired
from bimcontrol.targets.powerbi import query

PARITY_FILE = "parity.json"

# A value is equal if it is within this relative distance. Floating point
# aggregation orders differ between engines, so exact equality on a
# division would fail on arithmetic rather than on meaning.
EXACT_TOLERANCE = 1e-9
# Beyond `ok` but below this, something is off in a way worth looking at
# rather than failing the migration over -- a rounding or type difference.
WARN_TOLERANCE = 0.001
# A figure within this of a zero on the other side is the float32 residue of a difference of two equal amounts: Domo keeps money
# in a float32 column, so 319.14 - 319.13999 is left as 9.99999e-06 where the model has 0 (Accts Receivable-SW 'Variance', 428
# 'errors' in one run). Relative to a zero that is -100 %, which is arithmetic, not meaning; it is a warn, not an error. Only
# against a zero (a side within EXACT_TOLERANCE of 0: the model's own double residue of 1e-13 counts as one): 0.00005 against
# 0.0001 is a rate that differs by half, and stays an error.
ABSOLUTE_NOISE = 1e-4
RENEWAL_RETRY_SECONDS = 60       # after a failed Domo renewal the cards fail at once for this long, then one card tries again


# Visuals that show no card's data: nothing to compare, and not counted in coverage.
NON_DATA_VISUALS = ("slicer", "textbox")


def data_visuals(report: dict[str, Any]) -> list[dict[str, Any]]:
    """The report's visuals that stand for a Domo card with data (drillthrough pages have no card of their own)."""
    return [v for page in report["pages"] for v in page["visuals"]
            if v.get("visual_type") not in NON_DATA_VISUALS and v.get("origin")
            and not str(v["origin"]).startswith("drill:")]


def _client(ctx: RunContext):
    override = ctx.options.get("powerbi_query")
    if override is not None:
        return override
    return query.PowerBIQueryClient(allow_prompt=ctx.options.get("allow_prompt") is not False)


def _card_reader(ctx: RunContext):
    override = ctx.options.get("card_reader")
    if override is not None:
        return override
    return _RenewingReader(_new_card_reader(ctx), lambda: _new_card_reader(ctx))


def _new_card_reader(ctx: RunContext):
    from bimcontrol.sources.domo import login  # noqa: PLC0415
    from bimcontrol.sources.domo.cards import DomoCardReader  # noqa: PLC0415

    return DomoCardReader(login.get_session(
        ctx.project.get("source_instance"), allow_prompt=ctx.options.get("allow_prompt")))


class _RenewingReader:
    """The Domo card reader, with a new session when Domo rejects the one it holds (bimcontrol#278).

    The stage can start an hour after the dashboard did, and another lane signing in (or the cookie expiring) makes
    Domo answer 401 to every card from then on: 35 and 47 cards of two dashboards were skipped as `domo_render_failed`.
    One new session (stored, or the cookie file the renewal command rewrites, checked against Domo) and one retry."""

    def __init__(self, reader, renew):
        self._reader, self._renew = reader, renew
        self._lost: str | None = None                   # why a renewal failed: later cards fail with it at once ...
        self._lost_at = 0.0                             # ... until a minute has passed (another lane may have signed in again)

    def render(self, *args, **kwargs):
        if self._lost is not None:
            if time.monotonic() - self._lost_at < RENEWAL_RETRY_SECONDS:
                raise DomoSessionExpired(self._lost)
            self._lost = None
        try:
            return self._reader.render(*args, **kwargs)
        except DomoSessionExpired:
            try:
                self._reader = self._renew()
            except Exception as exc:  # noqa: BLE001 -- any failure of the renewal fails this card; only a refusal locks the others out
                message = f"Domo rejected the session and a new one could not be had: {exc}"
                if isinstance(exc, DomoAuthError):      # no session to be had (cookie gone, no prompt allowed): not once more per card.
                    self._lost, self._lost_at = message, time.monotonic()   # A network blip is not that: the next card asks again
                raise DomoSessionExpired(message) from exc
            return self._reader.render(*args, **kwargs)

    def __getattr__(self, name):
        return getattr(self._reader, name)


def _domo_filters(closure: dict[str, Any], card_id: str) -> list[dict[str, Any]]:
    """The dashboard's saved filters that reach this card, in the shape Domo's page load sends them."""
    from bimcontrol.sources.domo.cards import page_filter_overrides  # noqa: PLC0415

    page_filters = closure["dashboard"].get("filters") or []
    card = next((c for c in closure.get("cards") or [] if str(c.get("id")) == str(card_id)), None)
    if not page_filters or not card:
        return []
    datasets = {d["id"]: {c["name"] for c in d.get("columns") or []} for d in closure.get("datasets") or []}
    overrides: list[dict[str, Any]] = []
    for item in page_filters:
        column = (item.get("raw") or item).get("column")
        dataset_id = next((i for i in card.get("dataset_ids") or [] if column in datasets.get(i, ())), None)
        if dataset_id:
            overrides += page_filter_overrides([item], dataset_id, datasets[dataset_id])
    return overrides


class _FinerThanTheVisual(Exception):
    """Domo lists one key several times: the card groups by a column it does not show (Profitability-Trend-SW's
    'Patient Class' table is grouped by Bad Debt Ins Code, Patient Type and Patient Class and shows the first), so its rows
    are finer than anything the visual's columns can be keyed by."""

    def __init__(self, keys: int, rows: int):
        super().__init__(f"Domo lists {rows} rows for {keys} distinct keys: the card groups by columns it does not show")


def _series_pairs(card) -> list[tuple[tuple[str, ...], Any]]:
    """((category, series), value) from a rendered card.

    Keyed on both columns when the card has a series. Collapsing to the
    category alone compares one of Domo's values against the aggregate of
    several in Power BI -- which reported three cards as broken when only
    the comparison was.
    """
    item = card.column_index("ITEM")
    value = card.column_index("VALUE")
    series = card.column_index("SERIES")
    if item is None or value is None:
        return []
    pairs = []
    for row in card.rows:
        if len(row) <= max(i for i in (item, value, series) if i is not None):
            continue
        key = (_key(row[item]),) if series is None else (_key(row[item]), _key(row[series]))
        pairs.append((key, row[value]))
    return pairs


def _cut_at_cap(card) -> bool:
    """Whether Domo stopped rendering this card: it says so, or it drew as many rows as it ever does."""
    return bool(card.limited) or len(card.rows) >= DOMO_RENDER_ROW_CAP


def _without_subtotal_rows(card, label):
    """(card, how many rows were dropped): Domo's table without the "Percent of Total X" rows it draws under each group.

    A table card saved with percent-of-total subtotal rows (Revenue Trend PoP-SW 'Payor Mix Monthly Charges Posted PoP')
    lists `Percent of Total Blue Cross` after `Blue Cross`. They are Domo's, not rows of the data, and the migrated table
    has none. Only a row whose first cell is the label alone (the total's own percentage row) or the label followed by
    the first cell of another row is dropped."""
    if not label or not card.rows:
        return card, 0
    firsts = {str(row[0]) for row in card.rows if row}
    prefix = f"{label} "
    kept = [row for row in card.rows
            if not (row and (str(row[0]) == label
                             or (str(row[0]).startswith(prefix) and str(row[0])[len(prefix):] in firsts)))]
    if len(kept) == len(card.rows):
        return card, 0
    # A render cut at the row cap stays a cut one when rows are set aside (the cap is read from the row count).
    return replace(card, rows=kept, limited=_cut_at_cap(card)), len(card.rows) - len(kept)


def _own_series_only(card):
    """(card, names of the series left out): Domo's render with only the series named after the card's own value.

    A line/bar card can come back with a SERIES column that is no data column but the name of each plotted value
    ('ALOS', 'Hospitalist Group': Physician Compare Scorecards' LOS cards). The card definition the API returns
    lists one value; the second plotted series is not in it (bimcontrol#347), so a migrated visual cannot have
    it. Only when the series names include the card's own value column is the rest set aside; any other series
    column is a real grouping and stays.
    """
    value = card.column_index("VALUE")
    series = card.column_index("SERIES")
    if value is None or series is None or value >= len(card.columns):
        return card, []
    names = {str(row[series]) for row in card.rows if len(row) > series}
    own = str(card.columns[value])
    if own not in names or len(names) < 2:
        return card, []
    kept = [row for row in card.rows if len(row) > series and str(row[series]) == own]
    keep = [i for i in range(len(card.columns)) if i != series]
    return replace(card, rows=[[row[i] for i in keep if i < len(row)] for row in kept], limited=_cut_at_cap(card),
                   columns=[card.columns[i] for i in keep],
                   mappings=[card.mappings[i] for i in keep if i < len(card.mappings)]), sorted(names - {own})


_MIDNIGHT = re.compile(r"(\d{4}-\d{2}-\d{2})T00:00:00(?:\.0+)?")
_LONG_FRACTION = re.compile(r"-?\d+\.\d{12,}")
_US_DATE = re.compile(r"(\d{1,2})/(\d{1,2})/(\d{4})")


def _number_key(value: float) -> str:
    """A fractional key at 15 significant digits and 12 decimals, whichever is coarser.

    A key computed by subtracting two measures (Executive Summary Productivity Benchmark-SW, '3 Period Trend by Departments':
    -0.0287499999999994 in Domo, -0.0287500000000001 in Power BI) differs in the last digits only, and then no row pairs: the
    same 0.15875 was reported once as only Domo's and once as only the model's."""
    return f"{round(value, 12) + 0.0:.15g}"


def _key(value: Any) -> str:
    """A category key both sides agree on.

    Domo returns an hour as the number 0 where Power BI returns "0", and
    trailing whitespace differs often enough to matter. Comparing as
    trimmed strings, with whole floats normalised, avoids reporting a
    difference that is only a type.
    """
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    if isinstance(value, float):
        return _number_key(value)
    text = str(value).strip()
    # A fraction in a row key (a Percent Reimb column of a detail table): Domo prints 0.5171267605633802, Power BI
    # 0.51712676056338 (15 significant digits, so both are compared at 15). Same number, so the same key (Clinic AR Balance-SW: 33,927 values apart).
    if _LONG_FRACTION.fullmatch(text):
        return _number_key(float(text))
    # A date Power BI returns as a datetime at midnight is the date Domo returns ('2018-01-01T00:00:00').
    midnight = _MIDNIGHT.fullmatch(text)
    if midnight:
        return midnight.group(1)
    # A date Domo's card prints as text ('03/07/2026' for the DATE the model returns as 2026-03-07T00:00:00): the same
    # date (Revenue Trend-SW, 'Manual Stats by Pay Period Export': 1,263 rows on identical dates, all keys apart).
    us_date = _US_DATE.fullmatch(text)
    return f"{us_date.group(3)}-{int(us_date.group(1)):02d}-{int(us_date.group(2)):02d}" if us_date else text


def _is_zero(value: Any) -> bool:
    try:
        return value is not None and float(value) == 0
    except (TypeError, ValueError):
        return False


def _is_blank(value: Any) -> bool:
    return value is None or (isinstance(value, str) and not value.strip())


def _delta(source: Any, target: Any) -> float | None:
    """Relative difference, or None if either side is not a number.

    A blank against a zero is no difference: a Power BI measure over no rows is
    blank where Domo shows 0 (Query Response - SW, 'Query Response' count). Nor is a
    blank against a blank: Domo renders an empty cell as '' (AR Aging 2 -SW, '% Payment').
    """
    if _is_blank(source) and (_is_blank(target) or _is_zero(target)) or _is_blank(target) and _is_zero(source):
        return 0.0
    try:
        source_number = float(source)
        target_number = float(target)
    except (TypeError, ValueError):
        # Text against text: the same text is no difference (a column of 'N' flags was 2,000 'errors' in Daily Revenue-SW).
        if isinstance(source, str) and isinstance(target, str) and source.strip() == target.strip():
            return 0.0
        return None
    if math.isclose(source_number, target_number, rel_tol=EXACT_TOLERANCE, abs_tol=EXACT_TOLERANCE):
        return 0.0
    # A figure read from a table drawn as html is only as exact as its printed digits.
    shown = getattr(source, "tolerance", 0.0)
    if shown and abs(source_number - target_number) <= shown + EXACT_TOLERANCE * abs(target_number):
        return 0.0
    if abs(target_number - source_number) <= ABSOLUTE_NOISE and min(abs(source_number), abs(target_number)) <= EXACT_TOLERANCE:
        return math.copysign(WARN_TOLERANCE, target_number - source_number)     # a warn, signed; its true size against a zero is 100 %
    if source_number == 0:
        return math.inf if target_number else 0.0
    return (target_number - source_number) / abs(source_number)


def _state(delta: float | None) -> str:
    if delta is None:
        return "error"
    if abs(delta) <= EXACT_TOLERANCE:
        return "ok"
    if abs(delta) <= WARN_TOLERANCE:
        return "warn"
    return "error"


def verify_parity(ctx: RunContext) -> StageResult:
    published = _published(ctx)
    if published is None:
        ctx.progress("nothing published to compare against, so parity was not checked")
        ctx.write_json(PARITY_FILE, {"checked": False, "rows": []},
                       kind="parity", label="Parity")
        return StageResult(summary={"checked": False})

    if published.get("refreshed") is False:
        ctx.progress("the published model holds no data (refresh did not complete), so parity was not checked")
        ctx.write_json(PARITY_FILE, {"checked": False, "rows": []},
                       kind="parity", label="Parity")
        return StageResult(summary={"checked": False, "reason": "model_not_refreshed"})

    closure = ctx.read_json("resolve_closure", "closure.json")
    report = ctx.read_json("build_report", REPORT_FILE)
    page_id = closure["dashboard"]["id"]

    comparable = [v for v in (v for page in report["pages"] for v in page["visuals"])
                  if _comparable(v) or _table_comparable(v)]
    if not comparable:
        ctx.progress("no visual on this report is a simple chart or a table")
        ctx.write_json(PARITY_FILE, {"checked": False, "rows": []},
                       kind="parity", label="Parity")
        return StageResult(summary={"checked": False, "visuals": 0})

    reader = _card_reader(ctx)
    client = _client(ctx)
    table = _table_name(ctx)
    summaries = _summaries(ctx)
    types = _column_types(ctx)

    rows: list[dict[str, Any]] = []
    review_items: list[ReviewItem] = []
    warnings: list[str] = []
    checked = matched = 0
    # What was not compared, and why: the rollup reports coverage from this (bimcontrol#164).
    skipped: list[dict[str, Any]] = []
    unfiltered: list[str] = []

    style_of = {str(c.get("id")): c.get("style") for c in closure.get("cards") or []}

    def skip(visual: dict[str, Any], reason: str, detail: str | None = None, model_error: str | None = None) -> None:
        skipped.append({"card_id": visual["origin"], "title": visual["title"],
                        "visual_type": visual.get("visual_type"), "reason": reason, **({"detail": detail} if detail else {}),
                        **({"model_error": model_error} if model_error else {})})

    for visual in comparable:
        ctx.check_cancelled()
        card_id = visual["origin"]
        title = visual["title"]
        ctx.progress(f"comparing {title!r}")

        overrides = _domo_filters(closure, card_id)
        plain = None
        try:
            # Domo applies the dashboard's saved filters only when the caller sends them (the browser does).
            if overrides:
                try:
                    card = reader.render(card_id, page_id=page_id, filters=overrides)
                except DomoSessionExpired:
                    raise                                   # not the filters' doing: the card is reported as not rendered
                except Exception as exc:  # noqa: BLE001 -- fall back to the card as the report would not show it
                    warnings.append(f"{title}: Domo refused the dashboard filters ({exc}); compared without them")
                    overrides, card = [], reader.render(card_id, page_id=page_id)
                else:
                    plain = reader.render(card_id, page_id=page_id)
            else:
                card = reader.render(card_id, page_id=page_id)
        except Exception as exc:  # noqa: BLE001 -- one card failing is a finding, not a stop
            from bimcontrol.sources.domo.cards import DomoCardError  # noqa: PLC0415

            warnings.append(f"{title}: could not read the Domo card ({exc})")
            # Domo's own wording only when Domo answered ("Rendering card N -> 400: Invalid column(s) referenced: hcpcsmod");
            # a timeout or a dropped connection is ours to name, not Domo's
            if isinstance(exc, DomoSessionExpired):
                says, voice = str(exc)[:300], ""            # our wording ("Domo rejected the session ... sign in again"; a renewal failure may be ours)
            else:
                says = str(exc).split(" -> ", 1)[-1][:300] if isinstance(exc, DomoCardError) and " -> " in str(exc) else ""
                voice = "Domo says "
            says_in_title = f" ({voice}{says})" if says else ""
            review_items.append(ReviewItem(
                kind="parity_unavailable", severity="warn",
                title=f"{title}: Domo would not render this card, so it was not compared{says_in_title}",
                source_type="card", source_id=card_id,
            ))
            skip(visual, "domo_render_failed", says or None)
            continue

        subtotal_label = (style_of.get(str(card_id)) or {}).get("subtotal_label")
        if subtotal_label:
            card, dropped = _without_subtotal_rows(card, subtotal_label)
            plain = _without_subtotal_rows(plain, subtotal_label)[0] if plain is not None else None
            if dropped:
                review_items.append(ReviewItem(
                    kind="parity_partial", severity="info",
                    title=f"{title}: Domo draws {dropped} '{subtotal_label}' subtotal row(s) under the groups; they are Domo's "
                          "table decoration, not data, and the migrated table has none. They were not compared",
                    source_type="card", source_id=card_id,
                ))
        try:
            loose: list[str] = []
            extra_series: list[str] = []
            plans = _plans(visual, card, table, report.get("filters") or [], plain, summaries, types,
                           _hidden_group_by(visual), loose, extra_series)
        except _FinerThanTheVisual as exc:
            warnings.append(f"{title}: {exc}")
            review_items.append(ReviewItem(
                kind="parity_unavailable", severity="warn",
                title=f"{title}: {exc}, so its rows cannot be lined up with the visual's and it was not compared",
                source_type="card", source_id=card_id,
            ))
            skip(visual, "rows_finer_than_the_visual")
            continue
        except query.FilterNotExpressed as exc:
            warnings.append(f"{title}: {exc}")
            review_items.append(ReviewItem(
                kind="parity_unavailable", severity="warn",
                title=f"{title}: {exc}, so the card was not compared",
                source_type="card", source_id=card_id,
            ))
            skip(visual, "filter_on_measure_not_expressed", str(exc))
            continue
        if plans is None:
            warnings.append(f"{title}: the Domo columns do not line up with the visual's")
            review_items.append(ReviewItem(
                kind="parity_unavailable", severity="warn",
                title=f"{title}: Domo's columns do not match the visual's, so it was not compared",
                source_type="card", source_id=card_id,
            ))
            skip(visual, "columns_do_not_line_up")
            continue
        if extra_series:
            warnings.append(f"{title}: Domo also draws the series {', '.join(extra_series)}, which the card definition does not hold; not compared")
            review_items.append(ReviewItem(
                kind="parity_partial", severity="warn",
                title=f"{title}: Domo draws the series {', '.join(repr(n) for n in extra_series)} beside the card's own value, and "
                      "the card definition Domo returns does not hold it, so the migrated visual has no such series. Its figures were not compared",
                source_type="card", source_id=card_id,
            ))
        if loose:
            warnings.append(f"{title}: {', '.join(loose)} left out of the comparison: Domo draws it beside grouped columns without grouping by it")
            review_items.append(ReviewItem(
                kind="parity_partial", severity="warn",
                title=f"{title}: the column(s) {', '.join(repr(n) for n in loose)} were not compared. Domo draws them beside grouped "
                      "columns without grouping by them, so each cell is one arbitrary row's value of the group, which nothing can reproduce",
                source_type="card", source_id=card_id,
            ))

        # Domo applies the dashboard's saved filters only when asked (`overrides`), so the card is compared
        # with the report's filters on both sides. Where that fails, the card is also compared with the
        # filters off on both sides, and whichever lines up better is kept; the second is labelled
        # `filter_unverified` in the coverage, because it proves the data but not the migrated filter.
        best = None
        attempt_errors: list[str] = []
        for filtered, dax, source_by_key, grain_name, read_target, summary, domo_card in plans:
            attempt = _compare(ctx, client, published, domo_card, title, dax, source_by_key, grain_name,
                               read_target, summary, top_n=_top_n_limit(visual), row_limit=visual.get("row_limit"))
            if attempt["error"] is not None:
                attempt_errors.append(f"{'with' if filtered else 'without'} the dashboard filters: {attempt['error']}")
            # By the share of figures that differ: a variant that returns far fewer rows must not win on count.
            if best is None or (attempt["error"] is None and (
                    best["error"] is not None or attempt["failure_ratio"] < best["failure_ratio"])):
                best = {**attempt, "filtered": filtered, "dax": dax, "domo_card": domo_card}
            if best["error"] is None and best["failures"] == 0:
                break
        if attempt_errors and best["error"] is None:
            warnings.append(f"{title}: the model would not answer the query " + "; ".join(attempt_errors))
        if best["error"] is not None:
            warnings.append(f"{title}: the model would not answer ({best['error']})")
            too_large = _too_large(best["error"])
            timed_out = not too_large and _timed_out(best["error"])
            review_items.append(ReviewItem(
                kind="parity_unavailable", severity="warn" if too_large or timed_out else "error",
                title=(f"{title}: too many rows to read back from the model (DirectQuery returns at most 1,000,000) or "
                       "more than Domo draws (it stops at 2,000); its rows were not compared, the table's row count was"
                       if too_large
                       else f"{title}: the published model did not answer the parity query in time (we wait 180 s, twice; Power BI "
                            "stops a query after about 225 s; on a table of millions of rows that is the usual cause); "
                            "its rows were not compared"
                       if timed_out
                       else f"{title}: the published model could not answer the parity query"),
                source_type="card", source_id=card_id, detail={"dax": best["dax"], "error": str(best["error"])[:400]},
            ))
            skip(visual, "model_result_too_large" if too_large else "model_query_timeout" if timed_out else "model_query_failed",
                 model_error=None if too_large or timed_out else str(best["error"])[:400])
            continue

        if not best["rows"]:
            warnings.append(f"{title}: neither side returned a figure to compare")
            skip(visual, "no_figures")
            continue

        checked += 1
        if not best["filtered"]:
            unfiltered.append(card_id)
            review_items.append(ReviewItem(
                kind="parity_filter_unverified", severity="warning",
                title=f"{title}: the figures only line up with Domo's when neither side applies the dashboard "
                      "filter(s), so the migrated filter is not verified for this card",
                source_type="card", source_id=card_id,
            ))
        review_items.extend(best["review_items"])
        top_rows: list[dict[str, Any]] = []
        top_filter = _top_n_filter(visual)
        if top_filter is not None:
            try:
                top_rows = _top_n_rows(client, published, visual, top_filter, best["domo_card"], report.get("filters") or [],
                                       table, best["filtered"])
            except Exception as exc:  # noqa: BLE001 -- the values were compared; the ranking was not
                warnings.append(f"{title}: could not check which categories the Top N keeps ({exc})")
                review_items.append(ReviewItem(
                    kind="parity_partial", severity="warn",
                    title=f"{title}: the values were compared, but the categories the Top {top_filter['top_n']['limit']} "
                          "keeps were not checked against Domo's",
                    source_type="card", source_id=card_id,
                ))
        for row in best["rows"] + top_rows:
            matched += row["state"] == "ok"
            rows.append({"card_id": card_id, "metric": title, **row})

        failures = [r for r in rows if r["card_id"] == card_id and r["state"] == "error"]
        if failures:
            worst = max(failures, key=lambda r: abs(r["delta"]) if r["delta"] is not None else math.inf)
            review_items.append(ReviewItem(
                kind="parity_mismatch", severity="error",
                title=(f"{title}: {len(failures)} of "
                       f"{len(best['keys'])} values differ from Domo "
                       f"(worst: {worst['grain']}, Domo {worst['source']} vs Power BI {worst['target']})"),
                source_type="card", source_id=card_id,
                detail={"failures": failures[:20]},
            ))

    for visual in data_visuals(report):
        if not (_comparable(visual) or _table_comparable(visual)):
            skip(visual, "unsupported_visual")
    table_rows = _table_row_counts(ctx, client, published, closure, review_items, reader)
    ok = sum(1 for r in rows if r["state"] == "ok")
    warn = sum(1 for r in rows if r["state"] == "warn")
    error = sum(1 for r in rows if r["state"] == "error")
    ctx.write_json(PARITY_FILE, {
        "checked": True, "cards": checked, "rows": rows,
        "totals": {"ok": ok, "warn": warn, "error": error},
        "compared_cards": sorted({r["card_id"] for r in rows}), "unfiltered_cards": unfiltered,
        "skipped": skipped, "table_rows": table_rows,
        "stale_inputs": _stale_inputs(closure, reader),
        "moved_inputs": _moved_inputs(ctx, closure, reader),
    }, kind="parity", label="Parity")
    ctx.progress(f"{ok} matched, {warn} close, {error} differ across {checked} card(s)")

    return StageResult(
        summary={"checked": True, "cards": checked, "values": len(rows),
                 "ok": ok, "warn": warn, "error": error},
        warnings=warnings, review_items=review_items,
    )


def _plans(visual, card, table, report_filters, plain=None, summaries=None, types=None, hidden=None, notes=None,
           series_left_out=None):
    """(with the report's filters?, dax, Domo values, grain, reader, summary, Domo card) for each way to ask the
    model about this card; the unfiltered one only when it differs. None if the columns do not line up.
    `card` is Domo's render with the dashboard's filters, `plain` its render without them: each is
    compared with the model queried the same way."""
    variants = [(True, report_filters, card)]
    if plain is not None or any(f.get("table") for f in report_filters):
        variants.append((False, [], plain or card))
    plans = []
    for filtered, filters, card in variants:
        if _table_comparable(visual):
            plan = _table_plan(visual, card, table, filters, summaries, types, hidden, notes)
            if plan is None:
                return None
            dax, source_by_key, grain_name, read_target, summary = plan
        elif _multi_value_comparable(visual):
            plan = _multi_value_plan(visual, card, table, filters, summaries)
            if plan is None:
                return None
            dax, source_by_key, grain_name, read_target, summary = plan
        else:
            category = visual["buckets"]["Category"][0]
            value = visual["buckets"]["Y"][0]
            series = (visual["buckets"].get("Series") or [None])[0]
            # Each field says which table it lives in (older reports did not).
            category_table = category.get("table") or table
            value_table = value.get("table") or table
            summary = None
            dax = query.category_value_dax(
                category_table, category["name"],
                query.measure_expression(value_table, value["name"], value["kind"], value.get("aggregation"),
                                         (summaries or {}).get((value_table, value["name"]))),
                series=series["name"] if series else None,
                # Report-level filters (dashboard filters with saved values) reach
                # the visuals built from the filtered table, as in the service.
                filters=(visual.get("filters") or []) + [f for f in filters if f.get("table") == category_table],
            )
            if series is None:
                card, left_out = _own_series_only(card)
                if left_out and series_left_out is not None:
                    series_left_out.extend(n for n in left_out if n not in series_left_out)
            pairs = _series_pairs(card)
            source_by_key = dict(pairs)
            if len(source_by_key) < len(pairs):
                raise _FinerThanTheVisual(len(source_by_key), len(pairs))
            grain_name = category["name"]

            def read_target(target_rows, category=category, series=series):
                found = {}
                for row in target_rows:
                    key = (_key(query.row_value(row, category["name"], category_table)),)
                    if series:
                        # The series that is the category column (the query names it once) reads the category's value.
                        same = series["name"].lower() == category["name"].lower()
                        key = key + (key[0] if same else _key(query.row_value(row, series["name"], series.get("table") or table)),)
                    found[key] = query.row_value(row, "value")
                return found

        if plans and plans[0][1] == dax:
            continue                       # the report's filters do not touch this card
        plans.append((filtered, dax, source_by_key, grain_name, read_target, summary, card))
    return plans


def _multi_value_plan(visual, card, default_table, filters, summaries):
    """The query and Domo figures for one category with several values, or None when a value field has no
    column of that name in Domo's render."""
    category = visual["buckets"]["Category"][0]
    values = _multi_value_projections(visual)
    names = [c.lower() for c in card.columns]
    item = next((i for i, m in enumerate(card.mappings) if m == "ITEM"), 0) if card.mappings else 0
    taken = {item}
    columns: list[int] = []
    for p in values:
        spellings = {_domo_name(p).lower(), (p.get("display_name") or "").lower()} - {""}
        hit = next((i for i, n in enumerate(names) if n in spellings and i not in taken), None)
        if hit is None:
            return None
        taken.add(hit)
        columns.append(hit)
    counts: dict[str, int] = {}
    labels = []
    for p in values:
        name = _domo_name(p)
        counts[name] = counts.get(name, 0) + 1
        labels.append(name if counts[name] == 1 else f"{name} #{counts[name]}")
    category_table = category.get("table") or default_table
    dax = query.table_dax(
        [(category_table, category["name"])],
        [query.measure_expression(p.get("table") or default_table, p["name"], p["kind"], p.get("aggregation"),
                                  (summaries or {}).get((p.get("table") or default_table, p["name"])))
         for p in values],
        category_table,
        filters=(visual.get("filters") or []) + [f for f in filters if f.get("table") == category_table],
    )
    source_by_key = {}
    listed = 0
    for row in card.rows:
        if len(row) <= max(columns + [item]):
            continue
        listed += 1
        for n, column in enumerate(columns):
            source_by_key[(_key(row[item]), labels[n])] = row[column]
    if listed > len(source_by_key) // max(len(columns), 1):
        raise _FinerThanTheVisual(len(source_by_key) // max(len(columns), 1), listed)

    def read_target(target_rows):
        found = {}
        for row in target_rows:
            key = _key(query.row_value(row, category["name"], category_table))
            for n in range(len(values)):
                found[(key, labels[n])] = query.row_value(row, f"v{n}")
        return found

    return dax, source_by_key, category["name"], read_target, None


# What executeQueries answers when the result is too big to pull row by row (by bytes, by rows for the column
# count, or the 1M rows a DirectQuery source may return): compare the row count and the totals instead.
_TOO_MANY_ROWS = ("DaxByteCountNotSupported", "DaxRowCountNotSupported", "exceeded the maximum allowed size")
_TIMED_OUT = ("Read timed out", "timed out before it was completed")     # the client gave up (180 s, twice) / Power BI's own 225-second limit
_DOMO_CAPPED = "Domo rendered only the first"        # raised by _compare when Domo's render is cut at its row cap


def _too_large(error: object) -> bool:
    """A card the model holds too many rows of to read back, or Domo drew only the first rows of."""
    text = str(error)
    return _DOMO_CAPPED in text or any(limit in text for limit in _TOO_MANY_ROWS)


def _timed_out(error: object) -> bool:
    """The model did not answer in time: a table of millions of rows grouped by many columns in DirectQuery (the
    Daily Charge table, 20M rows: the same query narrowed to the 2,000 keys Domo drew ran into Power BI's 225 s limit too)."""
    return any(marker in str(error) for marker in _TIMED_OUT)


def _top_n_limit(visual: dict[str, Any]) -> int | None:
    """The row limit of a visual's Top N filter (a card limited to its first N rows by a sort), if it has one."""
    return next((f["top_n"]["limit"] for f in visual.get("filters") or [] if f.get("kind") == "top_n" and f.get("top_n")), None)


def _top_n_filter(visual: dict[str, Any]) -> dict[str, Any] | None:
    return next((f for f in visual.get("filters") or [] if f.get("kind") == "top_n" and f.get("top_n")), None)


def _top_n_rows(client, published, visual, top_filter, card, report_filters, default_table, filtered):
    """Parity rows for the categories a Top N keeps.

    The values of a limited card are compared on Domo's rows only (the model's query has no Top N), so a wrong
    direction, ranking field or filter would still pass. This asks the model for its own top N categories
    (`TOPN` ranked by the visual's field, ties included) and compares the sets with the categories Domo
    rendered: a category Domo shows and the model does not keep is a difference, and so is one the model keeps
    and Domo does not, unless the model has more than N because of ties at the cut. [] when Domo's column of
    the category cannot be found."""
    spec = top_filter["top_n"]
    limit, by = spec["limit"], spec["by"]
    column = top_filter["column"]
    category_table = top_filter.get("table") or default_table
    names = {c.lower(): i for i, c in reversed(list(enumerate(card.columns)))}
    spellings = {column.lower()}
    for fields in (visual.get("buckets") or {}).values():
        for p in fields:
            if p.get("name") == column:
                spellings |= {_domo_name(p).lower(), (p.get("display_name") or "").lower()} - {""}
    index = min((names[n] for n in spellings if n in names), default=None)    # the first such column, whatever the set order
    if index is None and (visual.get("buckets") or {}).get("Category") and "ITEM" in (card.mappings or []):
        index = card.mappings.index("ITEM")         # a chart's categories come back as the ITEM column
    if index is None:
        return []
    source = {_cell(row[index]) for row in card.rows if len(row) > index}
    rank = query.measure_expression(by.get("table") or default_table, by["name"], by["kind"], by.get("aggregation"))
    filters = (visual.get("filters") or []) + (
        [f for f in report_filters if f.get("table") == category_table] if filtered else [])
    ranked = query.summarize_filtered([query.column_ref(category_table, column)], filters, category_table,
                                      [f'"topn_rank", {rank}'])
    dax = f"EVALUATE\nTOPN({int(limit)}, {ranked}, [topn_rank], {0 if spec.get('descending', True) else 1})"
    found = client.execute_dax(published["workspace_id"], published["dataset_id"], dax)
    target = {_cell(query.row_value(row, column, category_table)) for row in found}
    kept_by_ties = len(target) > int(limit)
    label = f"Top {limit} categories of {column}"
    rows = []
    for category in sorted(source - target):
        rows.append({"grain": f"{label}: {category!r} is in Domo's list, not in Power BI's",
                     "source": 1, "target": 0, "delta": None, "state": "error"})
    if not kept_by_ties:
        for category in sorted(target - source):
            rows.append({"grain": f"{label}: {category!r} is in Power BI's list, not in Domo's",
                         "source": 0, "target": 1, "delta": None, "state": "error"})
    if not rows:
        rows.append({"grain": label, "source": len(source), "target": len(source), "delta": 0.0, "state": "ok"})
    return rows


def _compare(ctx, client, published, card, title, dax, source_by_key, grain_name, read_target, summary, top_n=None,
             row_limit=None):
    """Run one query and line its answer up with Domo's. {"error", "rows", "keys", "failures", "review_items"}.
    `top_n`: the limit of the visual's Top N filter; `row_limit`: the card's own limit, applied or not."""
    review_items: list[ReviewItem] = []
    try:
        try:
            target_rows = client.execute_dax(published["workspace_id"], published["dataset_id"], dax)
        except Exception as exc:  # noqa: BLE001
            if summary is None or not any(limit in str(exc) for limit in _TOO_MANY_ROWS):
                raise
            # Too many rows to pull: compare the row count and the column
            # totals instead, and say so in the label. Unless Domo itself
            # only rendered the first rows (it stops at 2,000), in which
            # case there is no complete figure to compare against.
            if card.limited or len(card.rows) >= DOMO_RENDER_ROW_CAP:
                # Domo drew only some rows: ask the model for the rows of the values Domo drew in a key column,
                # and compare those (the rest of the model's rows have no Domo figure).
                narrowed = summary[3]() if len(summary) > 3 else None
                if narrowed is None:
                    raise RuntimeError(
                        f"{_DOMO_CAPPED} {len(card.rows)} rows of a table the model holds far more of")
                ctx.progress(f"{title!r}: Domo drew {len(card.rows)} rows of a table too large to read back; "
                             "comparing the model's rows for the keys Domo drew")
                try:
                    target_rows = client.execute_dax(published["workspace_id"], published["dataset_id"], narrowed)
                except Exception as second:  # noqa: BLE001
                    if not any(limit in str(second) for limit in _TOO_MANY_ROWS):
                        raise
                    raise RuntimeError(
                        f"{_DOMO_CAPPED} {len(card.rows)} rows of a table the model holds far more of "
                        "(and of the keys Domo drew)") from second
            else:
                ctx.progress(f"{title!r} is too large to compare row by row; comparing row count and totals")
                dax, source_by_key, read_target = summary[:3]
                grain_name = "summary"
                target_rows = client.execute_dax(published["workspace_id"], published["dataset_id"], dax)
    except Exception as exc:  # noqa: BLE001
        return {"error": exc, "rows": [], "keys": set(), "failures": math.inf, "failure_ratio": 1.0, "review_items": []}

    target_by_key = read_target(target_rows)
    if grain_name != "summary":
        target_by_key = _pair_cut_digits(source_by_key, target_by_key)
        target_by_key, rounded = _pair_display_rounded(source_by_key, target_by_key)
        if rounded:
            review_items.append(ReviewItem(
                kind="parity_partial", severity="info",
                title=f"{title}: {rounded} row(s) round to the figure Domo's card draws (Domo's card prints "
                      "1.57 where the dataset holds 1.5684): they were compared as the same row, so a real difference under half a "
                      "unit of the last digit drawn would not show",
                source_type="card", source_id=card.card_id,
            ))
        target_by_key, pre_1900 = _pair_dates_before_1900(source_by_key, target_by_key)
        if pre_1900:
            review_items.append(ReviewItem(
                kind="parity_partial", severity="info",
                title=f"{title}: {pre_1900} row(s) have a date before 1900 in Domo (such as 0015-07-19); Power BI cannot hold one and "
                      "shows the key as blank. They were compared as the same row as the one with the blank key",
                source_type="card", source_id=card.card_id,
            ))
        target_by_key, folded = _pair_case_folded(source_by_key, target_by_key)
        if folded:
            review_items.append(ReviewItem(
                kind="parity_partial", severity="info",
                title=f"{title}: {folded} value(s) differ from Domo's only in letter case ('BEATRICE' in Domo, 'Beatrice' in Power BI): "
                      "Power BI keeps one spelling of text that differs only in case; they were compared as the same row",
                source_type="card", source_id=card.card_id,
            ))
    if grain_name != "summary" and (card.limited or len(card.rows) >= DOMO_RENDER_ROW_CAP or top_n or row_limit):
        # Domo stops rendering at 2,000 rows, so everything past them has no
        # figure to compare against. Compare what Domo rendered and say so;
        # counting the rest as "missing from Domo" would be false. The same holds for a card limited to its
        # first N rows: the query here has no Top N (the published visual's filter does that), so the rows past
        # the limit are not Domo's. A limit that could not be applied (two columns are limited together) leaves the
        # model's rows past it uncounted, which is said below.
        unchecked = len(set(target_by_key) - set(source_by_key)) if not top_n else 0
        target_by_key = {k: v for k, v in target_by_key.items() if k in source_by_key}
        if unchecked:
            review_items.append(ReviewItem(
                kind="parity_partial", severity="warn",
                title=(f"{title}: Domo rendered only the first {len(card.rows)} rows, so only those were "
                       f"compared ({unchecked} more values in Power BI have no Domo figure)"),
                source_type="card", source_id=card.card_id,
            ))

    rows = []
    for key in sorted(set(source_by_key) | set(target_by_key)):
        source = source_by_key.get(key)
        target = target_by_key.get(key)
        if key not in source_by_key:
            state, delta = "error", None
        elif key not in target_by_key:
            # Power BI drops a row whose measure is blank; Domo lists it with 0 or an empty cell.
            delta = 0.0 if _is_zero(source) or _is_blank(source) else None
            state = _state(delta)
        else:
            delta = _delta(source, target)
            state = _state(delta)
        label = " · ".join(part for part in key if part)
        rows.append({
            "grain": f"{grain_name} = {label}" if label else grain_name,
            "source": source, "target": target, "delta": delta, "state": state,
            "source_row": key in source_by_key,       # Domo drew this key (its cell may still be blank)
        })
    return {"error": None, "rows": rows, "keys": set(source_by_key) | set(target_by_key),
            "failures": sum(1 for r in rows if r["state"] == "error"), "review_items": review_items,
            "failure_ratio": sum(1 for r in rows if r["state"] == "error") / max(len(rows), 1)}


_NUMBER_TEXT = re.compile(r"-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][-+]?\d+)?")


def _four_places(cell: str) -> str:
    """A number as text at four decimal places, rounded half up; any other cell as it is.

    Whole numbers and exponent forms count: `_key` prints a float Domo cut to 19.00000 as '19', and a model value below
    1e-4 as '1.23e-05'. A text with a leading zero ('00123') is an identifier, not a figure."""
    if isinstance(cell, str) and _NUMBER_TEXT.fullmatch(cell):
        try:
            return str(Decimal(cell).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP))
        except InvalidOperation:        # a text of more than ~24 integer digits: not a figure Domo cut
            return cell
    return cell


def _loose_key(key: tuple) -> tuple:
    """A row key as the comparison's renaming steps see it: numbers at four places, text without letter case."""
    return tuple(cell.casefold() if isinstance(cell, str) else cell for cell in (_four_places(c) for c in key))


def _pair_cut_digits(source_by_key: dict, target_by_key: dict) -> dict:
    """The model's keys, with each one that has no exact twin in Domo's renamed to the Domo key it equals at four places.

    Domo stores a DECIMAL to five places and draws 19.11506 where the model holds 19.1150684931507; a number in a row key
    that differs only there made the whole row 'Domo-only' (Blue Cross-SW: 9,432 values) and, in a table compared on Domo's
    keys, the model's twin was never listed. Truncating at five and rounding at four give the same result as rounding the
    original at four, so equal at four places is the right test. Only keys without an exact twin are looked at, and only
    when exactly one of each side fits: a row that also differs in a text cell, or by more than the cut digits, stays apart."""
    loose_to_domo: dict[tuple, list] = {}
    for key in source_by_key:
        if key not in target_by_key:
            loose_to_domo.setdefault(tuple(_four_places(cell) for cell in key), []).append(key)
    if not loose_to_domo:
        return target_by_key
    loose_to_model: dict[tuple, list] = {}
    for key in target_by_key:
        if key not in source_by_key:
            loose_to_model.setdefault(tuple(_four_places(cell) for cell in key), []).append(key)
    renamed = {}
    for loose, domo_keys in loose_to_domo.items():
        model_keys = loose_to_model.get(loose) or []
        if len(domo_keys) == 1 and len(model_keys) == 1:
            renamed[model_keys[0]] = domo_keys[0]
    if not renamed:
        return target_by_key
    return {renamed.get(key, key): value for key, value in target_by_key.items()}


_SHORT_DECIMAL = re.compile(r"-?\d+(?:\.\d{1,2})?")
_PLACES = {0: Decimal("1"), 1: Decimal("0.1"), 2: Decimal("0.01")}
_VARIANT_LIMIT = 4096        # renderings tried for one model row (4 per non-whole number of its key)


def _two_places(cell: str) -> str:
    """A number as text at two decimal places, rounded half up; any other cell as it is (see `_four_places`)."""
    if isinstance(cell, str) and _NUMBER_TEXT.fullmatch(cell):
        try:
            return str(Decimal(cell).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))
        except InvalidOperation:
            return cell
    return cell


def _drawn_as(domo: str, model: str) -> bool:
    """Whether Domo's cell is the model's, as a card draws it: equal, or a number of at most two decimals that the model's
    number rounds to at the decimals Domo printed (Domo draws 153,032 where the dataset holds 153031.7)."""
    if domo == model:
        return True
    if not (isinstance(domo, str) and isinstance(model, str) and _SHORT_DECIMAL.fullmatch(domo) and _NUMBER_TEXT.fullmatch(model)):
        return False
    places = len(domo.split(".")[1]) if "." in domo else 0
    try:
        return Decimal(model).quantize(_PLACES[places], rounding=ROUND_HALF_UP) == Decimal(domo)
    except InvalidOperation:
        return False


def _drawn_variants(model: str) -> list[str]:
    """How a card could print the model's number: as it is, or rounded half up to 0, 1 or 2 decimals (written as `_key` writes a float)."""
    if not (isinstance(model, str) and _NUMBER_TEXT.fullmatch(model)):
        return [model]
    try:
        number = Decimal(model)
        found = [model]
        for places in _PLACES.values():
            text = format(number.quantize(places, rounding=ROUND_HALF_UP).normalize(), "f")
            if text not in found:
                found.append(text)
        return found
    except InvalidOperation:
        return [model]


def _pair_display_rounded(source_by_key: dict, target_by_key: dict) -> tuple[dict, int]:
    """(the model's keys, with each one that has no exact twin renamed to the Domo key it equals once its numbers are
    rounded to the decimals Domo drew, how many were renamed).

    A table card draws a column at the decimals of its format: the dataset holds DRG Weight 1.5684 (Domo's SQL says so)
    and the card prints 1.57; Dept Analytics Budget-SW 'Stat Account Detail' prints the variance 153,032 where the dataset
    holds 153031.7. A number in a detail table's row key then never finds its twin and the row is 'Domo-only'
    (Discharge YOY-SW 'Discharge Detail': 196 of 256 rows; Dept Analytics Budget-SW: 245 values). Only keys without an
    exact twin are looked at. Each such model key is written the ways a card could print it (every number as it is or
    rounded to 0, 1 or 2 decimals) and looked up among Domo's: linear in the rows, however many share their text. It is paired
    only when exactly one Domo key fits and no other model key fits it; a Domo row that also equals the model's figure at two
    places (a second row of the same figure) makes it ambiguous; a row that also differs in a text cell, or by more than the
    rounding, stays apart."""
    domo_open = [key for key in source_by_key if key not in target_by_key]
    if not domo_open:
        return target_by_key, 0
    domo_set = set(domo_open)
    at_two_places: dict[tuple, int] = {}
    for key in domo_open:
        at_two_places[tuple(_two_places(c) for c in key)] = at_two_places.get(tuple(_two_places(c) for c in key), 0) + 1
    fits: dict[tuple, tuple] = {}           # model key -> the one Domo key it can be
    claimed: dict[tuple, int] = {}          # Domo key -> how many model keys fit it
    for key in target_by_key:
        if key in source_by_key:
            continue
        variants = [_drawn_variants(cell) for cell in key]
        count = 1
        for options in variants:
            count *= len(options)
        if count > _VARIANT_LIMIT:
            continue
        found = [d for d in (tuple(combo) for combo in itertools.product(*variants)) if d in domo_set]
        if len(found) != 1 or not all(_drawn_as(a, b) for a, b in zip(found[0], key)):
            continue
        if at_two_places.get(tuple(_two_places(c) for c in key), 0) > 1:
            continue                        # a second Domo row of the same figure at two places: ambiguous
        fits[key] = found[0]
        claimed[found[0]] = claimed.get(found[0], 0) + 1
    renamed = {key: domo for key, domo in fits.items() if claimed[domo] == 1}
    if not renamed:
        return target_by_key, 0
    return {renamed.get(key, key): value for key, value in target_by_key.items()}, len(renamed)


def _pair_case_folded(source_by_key: dict, target_by_key: dict) -> tuple[dict, int]:
    """(the model's keys, with each one that has no exact twin renamed to the Domo key that differs from it only in
    letter case, how many were renamed).

    Power BI stores text case-insensitively (a column holding 'Beatrice' on one row and 'BEATRICE' on another keeps one
    spelling for both), so a name Domo draws in capitals comes back in the other row's spelling (DNFB Clinic - SW: 32
    of 2,000 rows of 'NextGen Unlinked Encounters - Details'). Only keys without an exact twin, and only one-to-one."""
    def fold(key):
        return tuple(cell.casefold() if isinstance(cell, str) else cell for cell in key)

    domo: dict[tuple, list] = {}
    for key in source_by_key:
        if key not in target_by_key:
            domo.setdefault(fold(key), []).append(key)
    if not domo:
        return target_by_key, 0
    model: dict[tuple, list] = {}
    for key in target_by_key:
        if key not in source_by_key:
            model.setdefault(fold(key), []).append(key)
    renamed = {}
    for folded, domo_keys in domo.items():
        model_keys = model.get(folded) or []
        if len(domo_keys) == 1 and len(model_keys) == 1:
            renamed[model_keys[0]] = domo_keys[0]
    if not renamed:
        return target_by_key, 0
    return {renamed.get(key, key): value for key, value in target_by_key.items()}, len(renamed)


_OLD_DATE = re.compile(r"(\d{4})-\d\d-\d\d(?:[T ].*)?")


def _pair_dates_before_1900(source_by_key: dict, target_by_key: dict) -> tuple[dict, int]:
    """(the model's keys, with each one that has no exact twin and a blank cell renamed to the Domo key whose date in that
    cell is before 1900, how many were renamed).

    Power BI cannot hold a date before 1900: the DAX result carries a blank where the data has 0015-07-19 (one row of the
    Stats data, 778 rows of customer Daily Charge; Avg Stats-SW 'Average Stat Category Per Month': 8 categories, the same
    figures under a blank column key). Only a key without an exact twin, only that cell, only one-to-one; the values are
    still compared afterwards."""
    def blank(cell):
        return cell is None or cell == ""

    def old_date(cell):
        found = _OLD_DATE.fullmatch(cell) if isinstance(cell, str) else None
        return bool(found) and int(found.group(1)) < 1900

    wanted: dict[tuple, list] = {}
    for key in source_by_key:
        if key in target_by_key:
            continue
        positions = [i for i, cell in enumerate(key) if old_date(cell)]
        if len(positions) == 1:
            wanted.setdefault(tuple("" if i == positions[0] else ("" if blank(c) else c) for i, c in enumerate(key)), []).append(key)
    if not wanted:
        return target_by_key, 0
    model: dict[tuple, list] = {}
    for key in target_by_key:
        if key not in source_by_key:
            model.setdefault(tuple("" if blank(c) else c for c in key), []).append(key)
    renamed = {}
    for blanked, domo_keys in wanted.items():
        model_keys = model.get(blanked) or []
        if len(domo_keys) == 1 and len(model_keys) == 1:
            renamed[model_keys[0]] = domo_keys[0]
    if not renamed:
        return target_by_key, 0
    return {renamed.get(key, key): value for key, value in target_by_key.items()}, len(renamed)


def _comparable(visual: dict[str, Any]) -> bool:
    """Whether this visual is one category against one value.

    Tables, matrices and slicers are left alone deliberately: comparing
    them needs a different query shape, and a half-right comparison that
    reports differences which are not real is worse than none.
    """
    buckets = visual.get("buckets") or {}
    return bool(visual.get("origin")) and len(buckets.get("Category") or []) == 1 \
        and len(buckets.get("Y") or []) == 1 and len(buckets.get("Series") or []) <= 1 \
        and not buckets.get("Y2") or _multi_value_comparable(visual)


def _multi_value_projections(visual: dict[str, Any]) -> list[dict]:
    buckets = visual.get("buckets") or {}
    return list(buckets.get("Y") or []) + list(buckets.get("Y2") or [])


def _multi_value_comparable(visual: dict[str, Any]) -> bool:
    """A chart of one category and several values (a line and column combo, a multi-line chart): Domo returns
    a column per value, compared by name with each of the visual's value fields."""
    buckets = visual.get("buckets") or {}
    return bool(visual.get("origin")) and len(buckets.get("Category") or []) == 1 \
        and not buckets.get("Series") and len(_multi_value_projections(visual)) >= 2


def _table_comparable(visual: dict[str, Any]) -> bool:
    """A table visual built from a Domo card: only columns and measures, no
    category axis. Drillthrough pages are skipped; they have no card of
    their own to render."""
    return visual.get("visual_type") in ("tableEx", "pivotTable") and bool(visual.get("origin")) \
        and not str(visual["origin"]).startswith("drill:") \
        and bool(_table_projections(visual))


def _table_projections(visual: dict[str, Any]) -> list[dict]:
    """The fields of a table or pivot, in the order Domo lists them: rows, then columns, then values.
    Domo returns a pivot as flat tidy rows (row dimensions, column dimension, value), so a pivot is
    compared like a table whose dimensions are all of its row and column fields."""
    buckets = visual.get("buckets") or {}
    return [p for role in ("Rows", "Columns", "Values") for p in buckets.get(role) or []]


def _cell(value: Any) -> str:
    """A table cell both sides agree on: a Domo date and a DAX datetime for
    the same day differ only by a midnight suffix."""
    text = _key(value)
    if text.endswith("T00:00:00"):
        return text[:-9]
    # Domo's render cuts very long text (seen on a 1.5k-character list of
    # departments); the first part is enough to tell rows apart.
    return text[:CELL_PREFIX]


_NUMBER_KINDS = ("aggregation", "measure")


def _domo_name(projection: dict) -> str:
    """The Domo column a projection came from. A beast mode used on several tables is a measure per
    table, "<name> (<table>)" on all but the first (build_powerbi.measure_name_on)."""
    name, table = projection["name"], projection.get("table")
    suffix = f" ({table})" if table else ""
    return name[:-len(suffix)] if suffix and name.endswith(suffix) else name
CELL_PREFIX = 200
DOMO_RENDER_ROW_CAP = 2000


def _hidden_group_by(visual: dict[str, Any]) -> list[str]:
    """The columns Domo's card groups by that the visual does not draw and the model kept for this check (build_report's
    `kept_columns`), in the card's order."""
    return [k["column"] for k in visual.get("kept_columns") or []]


def _lined_up(group: list[list[Any]]) -> list[list[Any]]:
    """The rows of one visible key in the order both sides agree on. A row whose values are all zero or blank is left out: Power BI
    drops such a row (a blank measure) where Domo lists it, and one missing row would shift every ordinal after it."""
    def empty(values: list[Any]) -> bool:
        return all(_order_key([v]) == ((0, 0.0, ""),) for v in values)
    return sorted((v for v in group if not empty(v)), key=_order_key)


PAIR_LIMIT = 400        # rows per key up to which rows are paired by closeness (n*m pairs); beyond, by order
PAIR_BUDGET = 1_000_000     # pairs looked at for one card in all: beyond, the remaining keys are paired by order


def _closeness(a: list[Any], b: list[Any]) -> float:
    """How far two rows of one key are apart: the relative differences of their numbers, 1 for each text that differs."""
    cost = 0.0
    for x, y in zip(a, b):
        try:
            fx, fy = (0.0 if v is None or v == "" else float(v) for v in (x, y))
            if not (math.isfinite(fx) and math.isfinite(fy)):
                raise ValueError(x)         # a text 'NaN' or 'inf' is text here, not a figure
        except (TypeError, ValueError):
            cost += 0.0 if str(x).strip() == str(y).strip() else 1.0
            continue
        cost += abs(fx - fy) / max(abs(fx), abs(fy), 1.0)
    return cost


def _pair_ordinals(domo: list[list[Any]], model: list[list[Any]], budget: list[int] | None = None) -> list[int]:
    """For each of the model's rows of a key (lined up), the ordinal of the Domo row it is paired with. The rows of a key have
    no identity, so pairing both sides by their order breaks when one row differs by a little: the first value decides the
    order, one changed row moves every row after it, and a row-for-row match turns into thousands of false differences
    (Profitability Trend-SW, 'Patient Class': 3,552 values; the totals of the card agreed). Each model row goes to the
    Domo row it is closest to (the closest pair of all first); a model row without a partner gets an ordinal past Domo's.
    `budget` (one element) is what is left of the pairs one card may look at."""
    size = len(domo) * len(model)
    if size > PAIR_LIMIT * PAIR_LIMIT or not domo or not model or (budget is not None and size > budget[0]):
        return list(range(len(model)))
    if budget is not None:
        budget[0] -= size
    pairs = sorted((_closeness(d, m), i, j) for i, d in enumerate(domo) for j, m in enumerate(model))
    ordinal: dict[int, int] = {}
    taken: set[int] = set()
    for _, i, j in pairs:
        if j not in ordinal and i not in taken:
            ordinal[j] = i
            taken.add(i)
    spare = len(domo)
    for j in range(len(model)):
        if j not in ordinal:
            ordinal[j] = spare
            spare += 1
    return [ordinal[j] for j in range(len(model))]


def _order_key(values: list[Any]) -> tuple:
    """A row's values as one sortable key, the same for Domo's and the model's rows of a key: numbers by value (to four
    places, the sides differ in the last digits), blanks together, text by its text."""
    out = []
    for value in values:
        if value is None or value == "":
            out.append((0, 0.0, ""))          # a blank is a zero here: Power BI drops a row whose measures are blank, Domo lists the 0
            continue
        try:
            out.append((0, round(float(value), 4), ""))
        except (TypeError, ValueError):
            out.append((2, 0.0, str(value)))
    return tuple(out)


def _measures_only_plan(visual, card, default_table, report_filters, summaries, vals, order):
    """A table of measures and no column (Productivity Benchmark's 'FTE Opportunity'): Domo draws one row, the model answers one."""
    if not vals or len(card.rows) != 1 or len(card.rows[0]) < len(order):
        return None
    counts: dict[str, int] = {}
    labels = []
    for _, p in vals:
        name = _domo_name(p)
        counts[name] = counts.get(name, 0) + 1
        labels.append(name if counts[name] == 1 else f"{name} #{counts[name]}")
    row = card.rows[0]
    source_by_key = {(labels[n],): row[order[i]] for n, (i, _) in enumerate(vals)}
    first_table = vals[0][1].get("table") or default_table
    dax = query.table_dax(
        [], [query.measure_expression(p.get("table") or default_table, p["name"], p["kind"], p.get("aggregation"),
                                      (summaries or {}).get((p.get("table") or default_table, p["name"]))) for _, p in vals],
        first_table, filters=(visual.get("filters") or []) + [f for f in report_filters if f.get("table") == first_table])

    def read_target(target_rows):
        return {(labels[n],): query.row_value(target_rows[0], f"v{n}") for n in range(len(vals))} if target_rows else {}

    return dax, source_by_key, "row", read_target, None


def _ungrouped_columns(visual, projections, order, card) -> set[int]:
    """Indexes of the projections that are a plain column in the Values of a pivot, which Domo draws beside its ROW columns.

    Domo groups a pivot by its row columns; a plain column mapped as a VALUE is not part of the group, so each cell
    shows one arbitrary row's value of the group (Hospital & Clinic Provider Profitability: a row-level formula,
    'Hospital and Clinics Expected Reimb New', beside measures: 22,450 values 'model-only' when the model grouped by
    it). Nothing in the model can reproduce a pick Domo leaves undefined, so these columns are not compared.
    Only a pivot, only its Values bucket, only when Domo marks some column ROW: a flat table lists its rows, and
    every plain column of it (mapped VALUE too) is part of the row."""
    if visual.get("visual_type") != "pivotTable":
        return set()
    mappings = [(m or "").upper() for m in card.mappings or []]
    if "ROW" not in mappings:
        return set()
    in_values = {id(p) for p in (visual.get("buckets") or {}).get("Values") or []}
    return {j for j, p in enumerate(projections)
            if id(p) in in_values and p["kind"] == "column" and j < len(order) and order[j] < len(mappings)
            and mappings[order[j]] == "VALUE"}


def _table_plan(visual, card, default_table, report_filters, summaries=None, types=None, hidden=None, notes=None):
    """Everything needed to compare one table card, or None if Domo's
    columns cannot be lined up with the visual's.

    Plain columns identify a row; aggregated columns and measures are the
    values compared. A table of plain columns compares which rows exist
    (Power BI shows distinct combinations, so Domo's rows are de-duplicated
    the same way).
    """
    projections = _table_projections(visual)
    names = [c.lower() for c in card.columns]
    wanted = [_domo_name(p).lower() for p in projections]
    # By name: a table drawn as html heads a column with its alias ("Act Net Op Income") where the data
    # API names it ("Act Net Op Inc"), so either spelling identifies the projection.
    used: set[int] = set()
    matched: dict[int, dict] = {}
    for p in projections:
        spellings = {_domo_name(p).lower(), (p.get("display_name") or "").lower()} - {""}
        hit = next((i for i, n in enumerate(names) if n in spellings and i not in used), None)
        if hit is not None:
            used.add(hit)
            matched[hit] = p
    if len(set(names)) == len(names) and len(matched) == len(names):
        # A column Domo did not render (a hidden one) is left out of
        # the comparison on both sides, or Power BI's rows would be finer.
        projections = [matched[i] for i in range(len(names))]
        order = list(range(len(names)))
    elif len(matched) == len(projections):
        # Domo drew more columns than the visual holds (a column twice: Charge Detail 'CPT Code'; a share-of-total
        # column beside a value: Payor Mix): each field reads its first column of that name, the extras are left out.
        order = sorted(matched)
        projections = [matched[i] for i in order]
    elif len(names) == len(wanted):
        order = list(range(len(wanted)))                  # by position
    else:
        return None
    loose = _ungrouped_columns(visual, projections, order, card)
    if loose:
        if notes is not None:
            notes.extend(_domo_name(projections[j]) for j in sorted(loose) if _domo_name(projections[j]) not in notes)
        projections = [p for j, p in enumerate(projections) if j not in loose]
        order = [o for j, o in enumerate(order) if j not in loose]
    dims = [(i, p) for i, p in enumerate(projections) if p["kind"] not in _NUMBER_KINDS]
    vals = [(i, p) for i, p in enumerate(projections) if p["kind"] in _NUMBER_KINDS]
    if not dims:
        return _measures_only_plan(visual, card, default_table, report_filters, summaries, vals, order)

    # Two value columns of one name (SUM(x) and AVG(x)) must not share a key: the second is "x #2".
    counts: dict[str, int] = {}
    labels: list[str] = []
    for _, p in vals:
        name = _domo_name(p)
        counts[name] = counts.get(name, 0) + 1
        labels.append(name if counts[name] == 1 else f"{name} #{counts[name]}")

    def table_of(p):
        return p.get("table") or default_table

    first_table = table_of(dims[0][1])

    source_by_key: dict[tuple[str, ...], Any] = {}
    drawn: set[tuple[Any, ...]] = set()      # the dimension cells as Domo drew them (keys are trimmed, the model's text is not)
    drawn_rows: dict[tuple[str, ...], list[list[Any]]] = {}
    listed = 0
    for row in card.rows:
        if len(row) < len(names):
            continue
        if all(cell is None or cell == "" for cell in row):
            continue                  # Domo's blank spacer row under a pivot table
        drawn.add(tuple(row[order[i]] for i, _ in dims))
        key = tuple(_cell(row[order[i]]) for i, _ in dims)
        drawn_rows.setdefault(key, []).append([row[order[i]] for i, _ in vals])
        if not vals:
            source_by_key[key] = 1
        else:
            listed += 1
        for n, (i, p) in enumerate(vals):
            source_by_key[key + (labels[n],)] = row[order[i]]
    # The card groups by columns it does not show (a hidden `orgno` beside `orgname`): Domo lists several rows for one visible key.
    # Where the model holds those columns it is asked at that grain, and the rows of a key are lined up in the order of their values.
    finer = bool(vals) and listed > len(source_by_key) // len(vals)
    cut = card.limited or len(card.rows) >= DOMO_RENDER_ROW_CAP or bool(visual.get("row_limit") or _top_n_limit(visual))     # the last key may be half drawn
    in_model = {c.lower(): c for t, c in (types or {}) if t == first_table}      # Domo's `orgno` is the model's `OrgNo`
    extra = [in_model[h.lower()] for h in hidden or [] if h.lower() in in_model] if finer and not cut else []
    if finer and len(extra) < len(hidden or []):        # a missing column would leave the model's rows coarser than Domo's
        extra = []
    if finer and not extra:
        raise _FinerThanTheVisual(len(source_by_key) // len(vals), listed)
    if finer:
        source_by_key = {}
        for key, group in drawn_rows.items():
            for ordinal, values in enumerate(_lined_up(group)):
                for n, value in enumerate(values):
                    source_by_key[key + (f"#{ordinal + 1}", labels[n])] = value

    def build(extra_filters: list[dict[str, Any]] | None = None) -> str:
        return query.table_dax(
            [(table_of(p), p["name"]) for _, p in dims] + [(first_table, h) for h in extra],
            [query.measure_expression(table_of(p), p["name"], p["kind"], p.get("aggregation"),
                                      (summaries or {}).get((table_of(p), p["name"]))) for _, p in vals],
            first_table,
            filters=(visual.get("filters") or []) + (extra_filters or []) + [
                f for f in report_filters if f.get("table") == first_table],
        )

    dax = build()

    def narrowed() -> str | None:
        narrowing = _narrowing_filter(dims, drawn, table_of, types or {})
        return build([narrowing]) if narrowing else None

    def read_target(target_rows):
        found = {}
        grouped: dict[tuple[str, ...], list[list[Any]]] = {}
        for row in target_rows:
            key = tuple(_cell(query.row_value(row, p["name"], table_of(p))) for _, p in dims)
            if not vals:
                found[key] = 1
            if finer:
                grouped.setdefault(key, []).append([query.row_value(row, f"v{n}") for n in range(len(vals))])
                continue
            for n, (_, p) in enumerate(vals):
                found[key + (labels[n],)] = query.row_value(row, f"v{n}")
        budget = [PAIR_BUDGET]
        by_loose: dict[tuple, list] = {}        # keys the comparison renames later (letter case, digits Domo cuts) still find their Domo rows
        for domo_key in drawn_rows:
            by_loose.setdefault(_loose_key(domo_key), []).append(domo_key)
        for key, group in grouped.items():
            model_rows = _lined_up(group)
            twins = by_loose.get(_loose_key(key)) or []
            domo_key = key if key in drawn_rows else twins[0] if len(twins) == 1 else None
            for ordinal, values in zip(_pair_ordinals(_lined_up(drawn_rows.get(domo_key, [])), model_rows, budget), model_rows):
                for n, value in enumerate(values):
                    found[key + (f"#{ordinal + 1}", labels[n])] = value
        return found

    return dax, source_by_key, "row", read_target, _table_summary(
        dims, vals, source_by_key, table_of, first_table, visual, report_filters, narrowed)


def _table_summary(dims, vals, source_by_key, table_of, first_table, visual, report_filters, narrowed=None):
    """A fallback for tables too big to pull: the number of rows and the
    total of each summed column, as (dax, source values, reader, narrowed). `narrowed()` is the table's own
    query restricted to the values Domo drew in its most telling column, or None (see `_narrowing_filter`)."""
    filters = (visual.get("filters") or []) + [f for f in report_filters if f.get("table") == first_table]
    grouped = query.summarize_filtered([query.column_ref(table_of(p), p["name"]) for _, p in dims], filters,
                                       first_table, [])
    on_groups = query.measure_filters(filters)[1] is not None    # a filter on a measure keeps whole groups
    sums = [p for _, p in vals if (p.get("aggregation") or "SUM").upper() == "SUM" and p["kind"] == "aggregation"]
    pieces = [f'"rows", COUNTROWS({grouped})']
    narrowing = ", ".join(query.filter_dax(filters, first_table))
    for n, p in enumerate(sums):
        total = f"SUM({query.column_ref(table_of(p), p['name'])})"
        if on_groups:
            pieces.append(f'"s{n}", SUMX({grouped}, CALCULATE({total}{", " + narrowing if narrowing else ""}))')
        else:
            pieces.append(f'"s{n}", CALCULATE({total}{", " + narrowing if narrowing else ""})')
    dax = "EVALUATE\nROW(" + ", ".join(pieces) + ")"

    source = {("rows",): len({k[:len(dims)] for k in source_by_key})}
    for n, p in enumerate(sums):
        total = 0.0
        for key, value in source_by_key.items():
            if key[-1] == p["name"] and len(key) in (len(dims) + 1, len(dims) + 2) and isinstance(value, (int, float)):
                total += value
        source[("total of " + p["name"],)] = total

    def read(target_rows):
        found = {("rows",): query.row_value(target_rows[0], "rows")} if target_rows else {}
        for n, p in enumerate(sums):
            if target_rows:
                found[("total of " + p["name"],)] = query.row_value(target_rows[0], f"s{n}")
        return found

    return dax, source, read, narrowed


def _whole_number(cell: Any) -> bool:
    if isinstance(cell, str):
        return re.fullmatch(r"-?\d+", cell) is not None
    return isinstance(cell, (int, float)) and not isinstance(cell, bool) and float(cell).is_integer()


def _narrowing_filter(dims, drawn, table_of, types):
    """A filter limiting the table to the rows of the combinations Domo drew (`drawn`: one tuple of dimension cells
    per row, as Domo drew them), over the fewest columns that tell the drawn rows apart: each next column is the one
    that separates the most rows given those already taken, until every drawn row has its own combination (at most
    four columns).

    Domo draws at most 2,000 rows of a table; the model's full answer can be a million rows (DirectQuery's limit),
    so nothing was compared. A query for the rows of the combinations Domo drew is small, and the rows are then
    compared on Domo's keys only. Only text and whole-number columns qualify (their literals are exact: a Domo
    cell is neither cut nor blank), and they are the cells themselves, whitespace included; None when no column
    does."""
    if not drawn:
        return None
    first_table = table_of(dims[0][1])
    eligible = []
    for index, (_, projection) in enumerate(dims):
        if table_of(projection) != first_table:
            continue                # TREATAS needs the columns of one table
        data_type = types.get((table_of(projection), projection["name"]))
        cells = [cell[index] for cell in drawn]
        if data_type == "string" and all(isinstance(c, str) and c and len(c) < CELL_PREFIX for c in cells):
            eligible.append((index, projection, data_type, str))
        elif data_type == "int64" and all(_whole_number(c) for c in cells):
            eligible.append((index, projection, data_type, lambda c: str(int(c))))
    if not eligible:
        return None
    def combinations_of(columns):
        return {tuple(literal(cell[index]) for index, _, _, literal in columns) for cell in drawn}

    chosen, combinations = [], set()
    while eligible and len(chosen) < 4 and len(combinations) < len(drawn):
        entry = max(eligible, key=lambda e: len(combinations_of(chosen + [e])))      # separates the most rows
        chosen.append(entry)
        eligible.remove(entry)
        combinations = combinations_of(chosen)
    # The engine matches a text without its trailing blanks too (model.with_trimmed_text: `IN {"11-30 "}` kept none of
    # the 191 rows of '11-30'): each text cell is asked for in both spellings.
    spellings = [(lambda v: sorted({v, v.rstrip() or v})) if data_type == "string" else (lambda v: [v])
                 for _, _, data_type, _ in chosen]
    rows = {variant for combination in combinations
            for variant in itertools.product(*(spell(v) for spell, v in zip(spellings, combination)))}
    return {"table": first_table, "kind": "tuples", "columns": [projection["name"] for _, projection, _, _ in chosen],
            "data_types": ["numeric" if data_type == "int64" else "string" for _, _, data_type, _ in chosen],
            "rows": sorted(rows)}


def _table_row_counts(ctx, client, published, closure, review_items, reader=None) -> list[dict[str, Any]]:
    """Rows Domo holds now for each model table's dataset (the scan's count when Domo will not answer), against
    the rows the model holds now. A difference is drift (Domo's data moved on, or the landed copy is of another day), so
    it is listed beside the mismatches it can explain rather than read as a model fault (#164)."""
    from bimcontrol.pipelines.build_powerbi import MODEL_FILE  # noqa: PLC0415

    try:
        model = ctx.read_json("build_model", MODEL_FILE)
    except (OSError, ValueError, KeyError):
        return []
    scanned = {d["id"]: d.get("row_count") for d in closure.get("datasets") or []}
    found: list[dict[str, Any]] = []
    for table in model.get("tables") or []:
        domo_rows = scanned.get(table.get("origin"))
        live = getattr(reader, "dataset_row_count", None)
        if callable(live) and table.get("origin"):
            counted = live(table["origin"])         # None: Domo would not say; 0 is an answer
            domo_rows = domo_rows if counted is None else counted
        if domo_rows is None:
            continue
        try:
            rows = client.execute_dax(published["workspace_id"], published["dataset_id"],
                                      query.scalar_dax(f"COUNTROWS({query.quote_name(table['name'])})"))
            if not rows:                  # no answer at all is not an empty table: COUNTROWS of one returns a row holding BLANK
                continue
            counted = query.row_value(rows[0], "value")
            model_rows = int(counted) if counted is not None else 0       # COUNTROWS of an empty table is BLANK
        except Exception:  # noqa: BLE001 -- a count that cannot be read is simply not listed
            continue
        entry = {"table": table["name"], "domo_rows": int(domo_rows), "model_rows": model_rows,
                 "differs": model_rows is not None and model_rows != int(domo_rows)}
        found.append(entry)
        if entry["differs"]:
            large = not parity_causes.within_drift(domo_rows, model_rows)
            review_items.append(ReviewItem(
                kind="parity_table_row_count_differs", severity="warn" if large else "info",
                title=f"{table['name']}: Domo's dataset holds {int(domo_rows):,} rows, the model "
                      f"holds {model_rows:,}; " + (
                          "that is too far apart to be the data moving on: the conversion may have lost or added rows "
                          "(an append/snapshot dataflow keeps history its SQL cannot recompute)" if large
                          else "figures that differ may be drift between the two"),
                source_type="dataset", source_id=table.get("origin"),
            ))
    return found


def _moved_inputs(ctx, closure, reader=None) -> list[dict[str, Any]]:
    """Warehouse tables the flows read that hold another row count than Domo's dataset does now (the scan's count when
    Domo will not answer): a connector dataset is an import, the converted flows read the live table, so a table that gained
    rows after Domo's last import moves every figure built on it (#453). Read from `convert_dataflows/conversion.json`."""
    try:
        recorded = ctx.read_json("convert_dataflows", "conversion.json").get("input_rows") or []
    except (OSError, ValueError, KeyError):
        return []
    live = getattr(reader, "dataset_row_count", None)
    imported = {d["id"]: d.get("updated_at") for d in closure.get("datasets") or []}
    found = []
    for entry in recorded:
        domo_rows = entry.get("scan_rows")
        counted = live(entry["dataset_id"]) if callable(live) else None       # None: Domo would not say; 0 is an answer
        domo_rows, counted_by = (domo_rows, "scan") if counted is None else (counted, "domo")
        if domo_rows is not None and int(domo_rows) != int(entry["warehouse_rows"]):
            found.append({"dataset_id": entry["dataset_id"], "dataset": entry["dataset"], "domo_rows": int(domo_rows),
                          "warehouse_rows": int(entry["warehouse_rows"]), "imported_at": imported.get(entry["dataset_id"]),
                          "domo_rows_from": counted_by})
    return found


def _stale_inputs(closure, reader=None) -> list[dict[str, Any]]:
    """Datasets Domo built before one of their inputs was last updated: Domo has not re-run the flow since, so its
    figures are those of the older input while the converted flow reads the input as it is now (#164). Largest gap first."""
    updated = getattr(reader, "dataset_updated", None)
    if not callable(updated):
        return []
    datasets = {d["id"]: d for d in closure.get("datasets") or []}
    inputs = {f["id"]: f.get("input_dataset_ids") or [] for f in closure.get("dataflows") or []}
    built: dict[str, float | None] = {}

    def when(dataset_id: str) -> float | None:
        if dataset_id not in built:
            built[dataset_id] = updated(dataset_id)
        return built[dataset_id]

    found = []
    for dataset in datasets.values():
        output = when(dataset["id"]) if dataset.get("produced_by") else None
        for source_id in inputs.get(dataset.get("produced_by"), []):
            source = when(source_id)
            if output is not None and source is not None and source - output > 3600:
                found.append({"dataset": dataset["name"], "dataset_id": dataset["id"], "input": (datasets.get(source_id) or {}).get("name", source_id),
                              "days": round((source - output) / 86400, 1)})
    return sorted(found, key=lambda e: -e["days"])


def _summaries(ctx: RunContext) -> dict[tuple[str, str], str]:
    """(table, column) -> the model's summarizeBy, for the columns a value bucket uses bare."""
    from bimcontrol.pipelines.build_powerbi import MODEL_FILE  # noqa: PLC0415

    try:
        model = ctx.read_json("build_model", MODEL_FILE)
    except (OSError, ValueError, KeyError):
        return {}
    return {(t["name"], c["name"]): c.get("summarize_by") or "none"
            for t in model.get("tables") or [] for c in t.get("columns") or []}


def _column_types(ctx: RunContext) -> dict[tuple[str, str], str]:
    """(table, column) -> the model's data type (string, int64, double, dateTime, ...)."""
    from bimcontrol.pipelines.build_powerbi import MODEL_FILE  # noqa: PLC0415

    try:
        model = ctx.read_json("build_model", MODEL_FILE)
    except (OSError, ValueError, KeyError):
        return {}
    return {(t["name"], c["name"]): c.get("data_type") or ""
            for t in model.get("tables") or [] for c in t.get("columns") or []}


def _published(ctx: RunContext) -> dict[str, Any] | None:
    try:
        published = ctx.read_json("publish_powerbi", "published.json")
    except FileNotFoundError:
        return None
    if not published.get("semantic_model_id"):
        return None
    return {"workspace_id": published["workspace_id"],
            "dataset_id": published["semantic_model_id"],
            "refreshed": published.get("refreshed")}


def _table_name(ctx: RunContext) -> str:
    from bimcontrol.pipelines.build_powerbi import MODEL_FILE  # noqa: PLC0415

    model = ctx.read_json("build_model", MODEL_FILE)
    return model["tables"][0]["name"]

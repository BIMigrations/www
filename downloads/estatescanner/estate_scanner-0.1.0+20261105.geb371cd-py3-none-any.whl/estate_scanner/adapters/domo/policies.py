"""Domo PDP filter groups (`/api/query/v1/data-control/{dataset}/filter-groups`) in the shared shape."""

from __future__ import annotations

_OPERATORS = {
    "EQUALS": "=", "NOT_EQUALS": "!=", "GREATER_THAN": ">", "GREATER_THAN_EQUAL": ">=",
    "LESS_THAN": "<", "LESS_THAN_EQUAL": "<=", "IN": "in", "LIKE": "like", "CONTAINS": "contains",
}


def describe_policies(policies: list[dict]) -> list[dict]:
    return [
        {
            "name": p.get("name"),
            "applies_to": _applies_to(p),
            "filters": [_filter(q) for q in p.get("parameters") or []],
            "access": None,
        }
        for p in policies
    ]


def _applies_to(policy: dict) -> list[dict]:
    resources = policy.get("resources") or {}
    out: list[dict] = []
    seen: set[tuple[str, str]] = set()
    for kind, ids in (
        ("user", [*(policy.get("userIds") or []), *(resources.get("USER") or [])]),
        ("group", [*(policy.get("groupIds") or []), *(resources.get("GROUP") or [])]),
        ("virtual_user", [*(policy.get("virtualUserIds") or []), *(resources.get("VIRTUAL_USER") or [])]),
    ):
        for i in ids:
            if (kind, str(i)) not in seen:
                seen.add((kind, str(i)))
                out.append({"kind": kind, "id": str(i)})
    return out


def _filter(parameter: dict) -> str:
    """One filter of a policy in words that say no more than the platform did. Several values read as a list
    only for the operators whose meaning with a list is known (equals, not equals, in); any other operator
    keeps its own name and the list in brackets."""
    column, operator = parameter.get("name"), parameter.get("operator")
    values = parameter.get("values") or ([parameter["value"]] if parameter.get("value") is not None else [])
    shown = ", ".join(str(v) for v in values)
    symbol = _OPERATORS.get(operator, str(operator).lower() if operator else "?")
    if len(values) > 1:
        if operator in ("EQUALS", "IN"):
            text = f"{column} in ({shown})"
        elif operator == "NOT_EQUALS":
            text = f"{column} not in ({shown})"      # "col != a, b" would read as "not a, and b"
        else:
            text = f"{column} {operator or '?'} [{shown}]"
    else:
        text = f"{column} {symbol} {shown}"
    return f"not ({text})" if parameter.get("not") else text

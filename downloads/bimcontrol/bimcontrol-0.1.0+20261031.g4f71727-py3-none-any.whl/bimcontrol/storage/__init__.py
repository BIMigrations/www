"""BIMControl's own control database (projects, units, runs, events).

Not to be confused with `bimcontrol.estate`, which reads EstateScanner's
database and never writes it.
"""

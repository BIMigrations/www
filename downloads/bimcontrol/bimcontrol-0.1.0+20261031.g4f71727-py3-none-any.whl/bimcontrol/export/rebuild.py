"""Rebuild a run's dependency closure from an exported specification alone.

`bimcontrol export` writes what a scan holds as plain `bimspec` files. This module is the way back for one
dashboard: it reads only those files (no estate database, no source platform) and produces the same dict
`pipelines.domo_to_powerbi.closure_payload` writes from the scan, which is everything `build_model` and
`build_report` read. `diff_closures` then says field by field where the two differ, so "the open format is
complete enough to build the target from" is a measured list and not a claim.

The export was written to be read by people and other tools, so it is neutral where the scan is Domo's:
a spec field carries `role`/`mapping`/`column_type`, the scan's subscription column carries Domo's own
`name`/`columnType`/`mapping`. Each function below that undoes one of the exporter's conversions says which one.
"""

from __future__ import annotations

import datetime
import glob
import json
import re
from pathlib import Path
from typing import Any

MAX_DEPTH = 25


class SpecNotFound(Exception):
    """The spec directory holds no document for the object asked for."""


class _Spec:
    """Read access to one spec directory, by object id."""

    def __init__(self, root: str | Path):
        self.root = Path(root)
        if not (self.root / "manifest.json").exists():
            raise SpecNotFound(f"{self.root} is not a specification export (no manifest.json)")
        self._cache: dict[str, Any] = {}

    def _load(self, relative: str) -> Any:
        if relative not in self._cache:
            self._cache[relative] = json.loads((self.root / relative).read_text())
        return self._cache[relative]

    def find(self, folder: str, object_id: str) -> dict[str, Any] | None:
        """`<folder>/<id>-<slug>.json`. An id is never a prefix of another's `<id>-`, so the dash settles it."""
        found = sorted(glob.glob(str(self.root / folder / f"{glob.escape(str(object_id))}-*.json")))
        return self._load(str(Path(found[0]).relative_to(self.root))) if found else None

    def metrics(self) -> list[dict[str, Any]]:
        """Every metric the export holds, with the dataset document it sits in (None: unattached)."""
        if "metrics" not in self._cache:
            out = []
            for path in sorted((self.root / "metrics").glob("*.json")):
                doc = self._load(str(path.relative_to(self.root)))
                for metric in doc.get("metrics") or []:
                    out.append({**metric, "_dataset": (doc.get("dataset") or {}).get("id")})
            self._cache["metrics"] = out
        return self._cache["metrics"]


# ---- dashboard -------------------------------------------------------------------------------------------


def _layout(pages: list[dict[str, Any]]) -> dict[str, Any]:
    """The Domo layout `_layout_model` reads (`standard.template` joined to `content` on `contentKey`), from pages.

    `build_pages` turned the template into pages: the first page is the dashboard's own, every later page a
    tab. The tab nesting is not kept by the spec (a tab inside a tab is a page after its parent), and
    `_layout_model` flattens it the same way, so every tab goes under one TABS item in page order.
    """
    content: list[dict[str, Any]] = []
    keys = iter(range(10_000))

    def items_of(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
        out = []
        for item in items:
            key = next(keys)
            grid = item.get("grid") or {}
            entry = {"contentKey": key, "x": grid.get("x", 0), "y": grid.get("y", 0),
                     "width": grid.get("w", 0), "height": grid.get("h", 0), "children": []}
            if item.get("kind") == "visual":
                entry["type"] = "CARD"
                content.append({"contentKey": key, "cardId": int(item["visual"]) if str(item["visual"]).isdigit() else item["visual"],
                                "cardUrn": str(item["visual"])})
            else:
                entry["type"] = {"text": "HEADER", "control": "VARIABLE", "button": "BUTTON"}.get(item.get("kind"), "SEPARATOR")
                content.append({"contentKey": key, **({"text": item["text"]} if item.get("text") else {})})
            out.append(entry)
        return out

    if not pages:
        return {}
    template = items_of(pages[0].get("items") or [])
    tabs = []
    for page in pages[1:]:
        key = next(keys)
        content.append({"contentKey": key, "text": page.get("title")})
        tabs.append({"type": "TAB_CONTENT", "contentKey": key, "children": items_of(page.get("items") or [])})
    if tabs:
        template.append({"type": "TABS", "contentKey": next(keys), "children": tabs})
    return {"standard": {"template": template}, "content": content}


def _dashboard_filters(filters: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """The scan's `filters_json` entries from the spec's (`export` kept column, operand, values, data type)."""
    return [{"field": f.get("column"), "filterType": f.get("type"), "label": f.get("label"),
             "raw": {"column": f.get("column"), "operand": f.get("operand"), "values": list(f.get("values") or []),
                     "dataType": f.get("data_type"), "filterType": f.get("type")}}
            for f in filters]


# ---- cards -----------------------------------------------------------------------------------------------


def _calculation_names(visual: dict[str, Any], metrics_by_id: dict[str, dict[str, Any]]) -> dict[str, str]:
    """formula id -> name, for the card's own calculations and the saved metrics it refers to."""
    names = {c["id"]: c.get("name") for c in visual.get("calculations") or []}
    for field in visual.get("fields") or []:
        for key in (field.get("metric_ref"), field.get("metric")):
            if key and key not in names and key in metrics_by_id:
                names[key] = metrics_by_id[key].get("name")
    return names


def _subscription_columns(visual: dict[str, Any], names: dict[str, str], is_beast_mode) -> list[dict[str, Any]]:
    """Domo's `dataSubscriptions` (the shape `map_card` reads) from a visual's fields, one entry per component.

    A column the card names that is no column of its dataset but the name of a saved Beast Mode on it is that calculation
    (the card detail names it as a plain column; the scan's search index flags it `formula`): `is_beast_mode` says so.

    What the scan's list has that the export keeps elsewhere: a FILTER column for each saved filter (the model builds a
    calculation a card filters on, and `map_card` warns about a filter it holds no values for), an ORDER_BY and a GROUP_BY
    column for each sort and grouping, the `calender` flag of a calendar field, and the DATE_GRAIN columns beside it
    (`time_grains`)."""
    components: dict[str, dict[str, Any]] = {}

    def component(name: str, dataset: Any = None) -> dict[str, Any]:
        entry = components.setdefault(name, {"name": name, "dataSourceId": dataset, "columns": []})
        entry["dataSourceId"] = entry["dataSourceId"] or dataset
        return entry

    for field in visual.get("fields") or []:
        entry = component(field.get("component") or "main", field.get("dataset"))
        formula = field.get("metric_ref") or field.get("metric")
        name = field.get("column") or (names.get(formula) if formula else None)
        entry["columns"].append({
            "name": name, "columnType": field.get("column_type") or "SELECT", "mapping": field.get("mapping"),
            "alias": field.get("alias"), "aggregation": field.get("aggregation"),
            "formula": True if (formula and not field.get("column")) or is_beast_mode(field.get("dataset"), name) else None,
        })
    for flt in visual.get("filters") or []:
        column = flt.get("column") or ""
        component(flt.get("component") or "main")["columns"].append({
            "name": _named(column, names), "columnType": "FILTER", "formula": True if column in names else None})
    # The sort and the grouping Domo lists beside the columns. The model builds a calculation that a card only sorts or
    # groups by (a hidden helper such as 'Blended Month No'), so they are needed even though no visual draws them.
    for kind, entries in (("ORDER_BY", visual.get("sort") or []), ("GROUP_BY", visual.get("group_by") or [])):
        for item in entries:
            formula = item.get("metric_ref") or item.get("metric")
            name = item.get("column") or (names.get(formula) if formula else None)
            if name:
                component(item.get("component") or "main")["columns"].append({
                    "name": name, "columnType": kind, "aggregation": item.get("aggregation"),
                    "formula": True if formula and not item.get("column") else None})
    for grain in visual.get("time_grains") or []:
        entry = components.get(grain.get("component") or "main") or next(iter(components.values()), None)
        if entry is None:
            continue
        columns = entry["columns"]
        calendar = next((c for c in columns if c["columnType"] == "SELECT" and c["name"] == grain.get("calendar_field")), None)
        if calendar is not None:
            calendar["calender"] = True
        columns.append({"name": grain.get("date_column"), "columnType": "DATE_GRAIN",
                        "extras": [grain["grain"]] if grain.get("grain") else None})
    return list(components.values())


def _named(column: str | None, names: dict[str, str]) -> str:
    return names.get(column or "") or column or ""


def _sort(visual: dict[str, Any], names: dict[str, str], like_scan: bool) -> dict[str, Any] | None:
    """`card_sort` from the visual. A sort or grouping on a calculation names it by `formulaId` with no `column`; the
    scan's `card_sort` reads only `column`, so it gets '' there (Revenue Post/Service Date: 'Patient Detail' is sorted
    by its fiscal year calculation, and the scan's sort is by ''). Unless `like_scan`, the name is found."""
    def key(entry: dict[str, Any]) -> str:
        return _named(entry.get("column") or (entry.get("metric_ref") if not like_scan else None), names)

    ordered = [s for s in visual.get("sort") or [] if (s.get("component") or "main") == "main"]
    if not ordered:
        return None
    return {"order_by": [{"column": key(s), "aggregation": s.get("aggregation"),
                          "order": (s.get("order") or "ASCENDING").upper()} for s in ordered],
            "group_by": [key(g) for g in visual.get("group_by") or [] if (g.get("component") or "main") == "main"],
            "items": [_named(f.get("column") or f.get("metric_ref"), names) for f in visual.get("fields") or []
                      if (f.get("component") or "main") == "main" and f.get("mapping") == "ITEM"]}


def _date_range(spec: dict[str, Any], names: dict[str, str]) -> dict[str, Any]:
    window = {"dateTimeRangeType": spec.get("type"), "interval": spec.get("interval"), "offset": spec.get("offset"),
              "count": spec.get("count"), "beginDate": spec.get("begin"), "endDate": spec.get("end")}
    return {"column": {"column": _named(spec.get("column"), names)}, "dateTimeRange": window, "periods": spec.get("periods")}


def _own_calculations(visual: dict[str, Any], like_scan: bool) -> list[dict[str, Any]]:
    """The card's own calculations. The scan path (`card_formula_columns`) finds the ones a column or a filter uses; the
    export keeps every one the query mentions, a sort or a grouping included."""
    calculations = visual.get("calculations") or []
    if not like_scan:
        return calculations
    used = {f.get("metric_ref") for f in visual.get("fields") or []} | {f.get("column") for f in visual.get("filters") or []}
    return [c for c in calculations if c["id"] in used]


def _card(visual: dict[str, Any], metrics_by_id: dict[str, dict[str, Any]], card_metric_ids: list[str],
          like_scan: bool, is_beast_mode) -> dict[str, Any]:
    names = _calculation_names(visual, metrics_by_id)
    source = visual.get("source") or {}
    return {
        "id": str(visual["id"]), "name": visual.get("title"),
        "card_type": source.get("card_type"), "chart_type": source.get("chart_type"),
        **({"text": visual.get("text") or ""} if (source.get("card_type") or "").lower() == "text" else {}),
        "dataset_ids": list(visual.get("datasets") or []),
        "data_subscriptions": _subscription_columns(visual, names, is_beast_mode),
        "filters": [{"column": _named(f.get("column"), names), "operand": f.get("operand"),
                     "values": list(f.get("values") or []), "dataType": f.get("data_type")}
                    for f in visual.get("filters") or []],
        "date_ranges": [_date_range(r, names) for r in visual.get("date_ranges") or []],
        "top_n": visual.get("row_limit"),
        "style": visual.get("style") or {"legend": None, "data_labels": True},
        "sort": _sort(visual, names, like_scan),
        "drill_views": list(visual.get("drill") or []),
        "calculated_field_ids": [c["id"] for c in _own_calculations(visual, like_scan)] + card_metric_ids,
    }


# ---- datasets, dataflows, metrics ------------------------------------------------------------------------


def _pdp(policies: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Domo's `pdp_json` filter groups from the spec's `access.policies` (the reverse of `build_dataset`)."""
    return [{"filterGroupId": p.get("id"), "name": p.get("name"), "type": p.get("type"),
             "userIds": list(p.get("user_ids") or []), "groupIds": list(p.get("group_ids") or []),
             "parameters": [{"name": q.get("column"), "type": q.get("type"), "operator": q.get("operator"),
                             "values": list(q.get("values") or []), "not": q.get("negated")}
                            for q in p.get("parameters") or []]}
            for p in policies]


def _epoch_ms(iso: str | None) -> int | None:
    if not iso:
        return None
    return int(datetime.datetime.fromisoformat(iso).timestamp() * 1000)


def _dataflow(doc: dict[str, Any], known_datasets: set[str]) -> dict[str, Any]:
    steps = doc.get("steps") or []
    named = [str((s.get("config") or {}).get("dataSourceId")) for s in steps
             if s.get("type") == "LoadFromVault" and (s.get("config") or {}).get("dataSourceId")]
    appending = [s for s in steps if s.get("type") == "PublishToVault" and (s.get("config") or {}).get("versionChainType") == "APPEND"]
    guids = [str(((s.get("config") or {}).get("dataSource") or {}).get("guid")) for s in appending
             if ((s.get("config") or {}).get("dataSource") or {}).get("guid")]
    inputs = [i["dataset"] for i in doc.get("inputs") or []]
    return {
        "id": str(doc["id"]), "name": doc.get("name"), "engine": doc.get("engine"),
        "num_inputs": len(inputs), "num_outputs": len(doc.get("outputs") or []),
        "input_dataset_ids": inputs,
        "missing_input_ids": sorted({d for d in named if d not in known_datasets}),
        "disabled_in_domo": (doc.get("last_execution") or {}).get("state") == "DISABLED",
        "appends_history": bool(appending),
        "appending_dataset_ids": guids if appending and len(guids) == len(appending) else None,
        "scan_modified": _epoch_ms(doc.get("modified_at")),
    }


def closure_from_spec(spec_dir: str | Path, dashboard_id: str, card_order: list[str] | None = None,
                      like_scan: bool = False) -> dict[str, Any]:
    """The closure payload of one dashboard, from the files `bimcontrol export` wrote and nothing else.

    Cards come in the order the scan listed them (`order` on each visual), else the layout's. The build depends on it
    (which card's sort a shared column takes, where the slicers go, which of two same-named measures a card gets), so
    `card_order` lets a caller put the cards in another order to measure that.
    `like_scan=True` reads a card the way the scan path does, to measure what is left once the spec's extra knowledge is
    set aside: a sort or grouping cannot name a calculation there (see `_sort`) and a card's calculations are only those
    its columns and filters use. The default uses everything the spec holds.
    """
    spec = _Spec(spec_dir)
    dashboard = spec.find("dashboards", dashboard_id)
    if dashboard is None:
        raise SpecNotFound(f"no dashboard {dashboard_id} in {spec.root}")

    all_metrics = spec.metrics()
    metrics_by_id = {str(m["id"]): m for m in all_metrics}
    visuals = dashboard.get("visuals") or []
    card_ids = [str(v["id"]) for v in visuals]
    # Cards in the order the scan listed them (`order`, kept by the export since this was written); an export without it
    # gives them in the order the layout places them, a card the layout does not place last, by id.
    placed = [i["visual"] for p in dashboard.get("pages") or [] for i in p.get("items") or [] if i.get("kind") == "visual"]
    listed = [str(v["id"]) for v in sorted((v for v in visuals if v.get("order") is not None), key=lambda v: v["order"])]
    order = {c: n for n, c in enumerate(dict.fromkeys([*(card_order or []), *listed, *placed, *card_ids]))}
    visuals = sorted(visuals, key=lambda v: order.get(str(v["id"]), len(order)))

    # Walk upstream exactly as `resolve_dashboard` does: dataset -> producing dataflow -> its input datasets.
    dataset_ids: list[str] = []
    for visual in visuals:
        for dataset_id in visual.get("datasets") or []:
            if dataset_id not in dataset_ids:
                dataset_ids.append(dataset_id)
    datasets: dict[str, dict[str, Any]] = {}
    flows: dict[str, dict[str, Any]] = {}
    producer: dict[str, str] = {}
    roots: list[str] = []
    frontier, depth, seen = list(dataset_ids), 0, set()
    while frontier and depth <= MAX_DEPTH:
        following: list[str] = []
        for dataset_id in frontier:
            if dataset_id in seen:
                continue
            seen.add(dataset_id)
            if dataset_id not in dataset_ids:
                dataset_ids.append(dataset_id)
            doc = spec.find("models", dataset_id)
            if doc is None:
                continue
            datasets[dataset_id] = doc
            flow_id = (doc.get("lineage") or {}).get("produced_by")
            if not flow_id:
                roots.append(dataset_id)
                continue
            producer[dataset_id] = str(flow_id)
            if str(flow_id) in flows:
                continue
            flow = spec.find("transformations", str(flow_id))
            if flow is None:
                continue
            flows[str(flow_id)] = flow
            following += [i["dataset"] for i in flow.get("inputs") or []]
        frontier, depth = following, depth + 1

    dataset_docs = [datasets[d] for d in dataset_ids if d in datasets]

    # Metrics: the saved beast modes of the closure's datasets, those a card uses, and whatever they call.
    card_set = set(card_ids)
    wanted = [m for m in all_metrics if m.get("_dataset") in datasets
              or card_set & set((m.get("used_by") or {}).get("cards") or [])]
    have = {str(m["id"]) for m in wanted}
    pending = list(wanted)
    while pending:
        more = [metrics_by_id[r] for m in pending for r in (m.get("depends_on") or {}).get("metrics") or []
                if r in metrics_by_id and r not in have]
        for m in more:
            have.add(str(m["id"]))
        wanted += more
        pending = more
    local: dict[str, dict[str, Any]] = {}
    for visual in visuals:
        for calc in _own_calculations(visual, like_scan):
            local.setdefault(calc["id"], {"id": calc["id"], "name": calc.get("name"),
                                          "formula": calc.get("expression"), "data_type": calc.get("data_type")})
    metric_ids_of_card = {c: [str(m["id"]) for m in all_metrics if c in ((m.get("used_by") or {}).get("cards") or [])]
                          for c in card_ids}

    columns_of = {d: {str(c.get("name")).lower() for c in doc.get("columns") or []} for d, doc in datasets.items()}
    saved_names: dict[str, set[str]] = {}
    for m in all_metrics:
        saved_names.setdefault(str(m.get("_dataset")), set()).add(m.get("name"))

    def is_beast_mode(dataset: str | None, name: str | None) -> bool:
        return bool(dataset and name and dataset in columns_of and name.lower() not in columns_of[dataset]
                    and name in saved_names.get(str(dataset), ()))

    cards = [_card(v, metrics_by_id, metric_ids_of_card.get(str(v["id"]), []), like_scan, is_beast_mode) for v in visuals]
    payload = {
        "dashboard": {"id": str(dashboard["id"]), "name": dashboard.get("name"),
                      "filters": _dashboard_filters(dashboard.get("filters") or []),
                      "layout": _layout(dashboard.get("pages") or [])},
        "cards": cards,
        "datasets": [{
            "id": str(d["id"]), "name": d.get("name"), "provider_type": d.get("provider"), "row_count": d.get("rows"),
            "updated_at": d.get("updated_at"),
            "columns": [{"name": c.get("name"), "type": c.get("type"), "visible": c.get("visible")} for c in d.get("columns") or []],
            "pdp": _pdp((d.get("access") or {}).get("policies") or []),
            "produced_by": producer.get(str(d["id"])), "is_root": str(d["id"]) in roots,
        } for d in dataset_docs],
        "dataflows": [_dataflow(f, set(datasets)) for f in flows.values()],
        "calculated_fields": [{"id": str(m["id"]), "name": m.get("name"), "formula": m.get("expression"),
                               "data_type": m.get("data_type")} for m in wanted] + list(local.values()),
        "missing": [{"object_type": "dataset", "id": d} for d in dataset_ids if d not in datasets],
    }
    chart_types: dict[str, int] = {}
    for card in cards:
        chart_types[card["chart_type"] or "unknown"] = chart_types.get(card["chart_type"] or "unknown", 0) + 1
    payload["summary"] = {
        "dashboard_id": payload["dashboard"]["id"], "dashboard_name": payload["dashboard"]["name"],
        "cards": len(cards), "datasets": len(dataset_docs), "dataflows": len(flows),
        "calculated_fields": len(wanted), "root_datasets": len(roots),
        "chart_types": dict(sorted(chart_types.items(), key=lambda kv: -kv[1])),
        "missing": len(payload["missing"]), "warnings": [],
    }
    return payload


# ---- the measured difference -----------------------------------------------------------------------------


def diff_closures(scan: Any, spec: Any, path: str = "") -> list[dict[str, Any]]:
    """Every leaf where `spec` differs from `scan`, as `{path, scan, spec}`; lists of dicts with an `id` are matched by id.

    A key the scan has with an empty value (None, "", [], {}, False) and the spec lacks is not a difference: the
    builder reads both as absent.
    """
    def empty(value: Any) -> bool:
        return value in (None, "", [], {}, False)

    out: list[dict[str, Any]] = []
    if isinstance(scan, dict) and isinstance(spec, dict):
        for key in sorted(set(scan) | set(spec)):
            a, b = scan.get(key), spec.get(key)
            if empty(a) and empty(b):
                continue
            out += diff_closures(a, b, f"{path}.{key}" if path else key)
    elif isinstance(scan, list) and isinstance(spec, list):
        if all(isinstance(i, dict) and "id" in i for i in [*scan, *spec]) and (scan or spec):
            a = {str(i["id"]): i for i in scan}
            b = {str(i["id"]): i for i in spec}
            for key in sorted(set(a) | set(b)):
                if key not in a or key not in b:
                    out.append({"path": f"{path}[{key}]", "scan": a.get(key, "<absent>"), "spec": b.get(key, "<absent>")})
                else:
                    out += diff_closures(a[key], b[key], f"{path}[{key}]")
            if [str(i["id"]) for i in scan if str(i["id"]) in b] != [str(i["id"]) for i in spec if str(i["id"]) in a]:
                out.append({"path": f"{path}.<order>", "scan": [str(i["id"]) for i in scan], "spec": [str(i["id"]) for i in spec]})
        else:
            for n in range(max(len(scan), len(spec))):
                out += diff_closures(scan[n] if n < len(scan) else "<absent>", spec[n] if n < len(spec) else "<absent>", f"{path}[{n}]")
    elif scan != spec and not (empty(scan) and empty(spec)):
        out.append({"path": path, "scan": scan, "spec": spec})
    return out


# ---- the build, offline ----------------------------------------------------------------------------------


class _OfflineContext:
    """The part of `RunContext` that `build_model`, `build_report` and `write_pbip` use, over a directory.

    No control database, no estate, no warehouse: the stages read earlier stages' artefacts from files, so
    the closure is written where `resolve_closure` would have put it and the rest is fixed. Each dataset a
    card reads is a table "landed" at `offline.<dataset id>`, so a table has a source and the model is the
    same for any closure that names the same datasets.
    """

    def __init__(self, run_dir: Path, closure: dict[str, Any], warehouse: bool):
        self.run_dir = run_dir
        self.project = {"settings": {"warehouse": {"host": "offline", "database": "offline"} if warehouse else {}}}
        self.unit = {"source_object_id": closure["dashboard"]["id"]}
        self.options: dict[str, Any] = {}
        self.stage = "run"
        self.cancel_event = None
        run_dir.mkdir(parents=True, exist_ok=True)
        datasets = sorted({d for c in closure["cards"] for d in c.get("dataset_ids") or []})
        self.write_artefact("resolve_closure", "closure.json", closure)
        self.write_artefact("plan_data", "data_plan.json", {"datasets": []})
        self.write_artefact("land_source_data", "landings.json", {"landings": []})
        self.write_artefact("convert_dataflows", "conversion.json",
                            {"dataflows": [], "resolutions": {d: f"offline.t_{d}" for d in datasets}})

    @property
    def source_object_id(self) -> str:
        return self.unit["source_object_id"]

    def write_artefact(self, stage: str, filename: str, payload: Any) -> None:
        folder = self.run_dir / stage
        folder.mkdir(parents=True, exist_ok=True)
        (folder / filename).write_text(json.dumps(payload, indent=2, default=str))

    def stage_dir(self, stage: str | None = None) -> Path:
        folder = self.run_dir / (stage or self.stage)
        folder.mkdir(parents=True, exist_ok=True)
        return folder

    def read_json(self, stage: str, filename: str) -> Any:
        return json.loads((self.run_dir / stage / filename).read_text())

    def write_json(self, filename: str, payload: Any, **_: Any) -> Path:
        self.write_artefact(self.stage, filename, payload)
        return self.run_dir / self.stage / filename

    def progress(self, message: str) -> None:
        pass


def build_project_offline(closure: dict[str, Any], run_dir: str | Path) -> dict[str, Any]:
    """Run the three build stages on a closure and return what each said; the PBIP is under `run_dir/write_pbip`."""
    from bimcontrol.pipelines import build_powerbi  # noqa: PLC0415 -- the pipeline imports the exporter's neighbours

    context = _OfflineContext(Path(run_dir), closure, warehouse=True)
    results = {}
    for name, stage in (("build_model", build_powerbi.build_model), ("build_report", build_powerbi.build_report)):
        context.stage = name
        results[name] = stage(context)
    # The writer's warehouse steps (describe a table, split a big one) need a live warehouse: leave them out.
    context.project = {"settings": {"warehouse": {}}}
    context.stage = "write_pbip"
    results["write_pbip"] = build_powerbi.write_pbip(context)
    return results


_UUID = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}|(?<![0-9a-f])[0-9a-f]{20}(?![0-9a-f])")
_VISUAL_FILE = re.compile(r"/visuals/<id>/visual\.json$")


def _tmdl_normalised(text: str) -> str:
    """A table's TMDL with its measures and calculated columns in a fixed order.

    They come out in the order the closure lists the beast modes, which the export keeps by dataset and id, not in the
    scan's. The set is what the model is; its order shows nowhere in Power BI. Plain columns keep their order (it is
    the dataset's)."""
    blocks: list[list[str]] = []
    for line in text.split("\n"):
        top = line.startswith("\t") and not line.startswith("\t\t")
        previous_is_doc = bool(blocks) and len(blocks[-1]) == 1 and blocks[-1][0].lstrip("\t").startswith("///")
        if not blocks or (top and not previous_is_doc) or not line.startswith("\t"):
            blocks.append([line])
        else:
            blocks[-1].append(line)
    calculated = sorted(i for i, b in enumerate(blocks) if any(" = " in line for line in b[:2] if line.startswith("\t") and not line.startswith("\t\t")))
    ordered = sorted((blocks[i] for i in calculated), key=lambda b: "\n".join(b))
    for slot, block in zip(calculated, ordered):
        blocks[slot] = block
    return "\n".join("\n".join(b) for b in blocks)


def _title_of(visual: dict[str, Any]) -> str:
    try:
        return visual["visual"]["visualContainerObjects"]["title"][0]["properties"]["text"]["expr"]["Literal"]["Value"]
    except (KeyError, IndexError, TypeError):
        return ""


def _project_files(root: Path) -> tuple[dict[str, list[Any]], dict[str, list[str]]]:
    """The files of a PBIP folder by path, and each page's visuals in tab order.

    The ids the writer makes up (`lineageTag`, `logicalId`, a visual's folder and `name`, a filter's `name`) are replaced by
    `<id>`: two builds of the same definition differ in nothing else. A visual is found by what it shows (title, type and
    place) rather than by its folder; its `z` and `tabOrder` are taken out and returned as the page's order of titles.
    """
    files: dict[str, list[Any]] = {}
    order: dict[str, list[tuple[int, str]]] = {}
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        relative = _UUID.sub("<id>", str(path.relative_to(root)))
        text = _UUID.sub("<id>", path.read_text(errors="replace"))
        try:
            content: Any = json.loads(text)
        except ValueError:
            content = text
        if relative.endswith(".tmdl") and "/tables/" in relative and isinstance(content, str):
            content = _tmdl_normalised(content)
        if _VISUAL_FILE.search(relative) and isinstance(content, dict):
            position = content.get("position") or {}
            title = _title_of(content)
            page = relative.rsplit("/visuals/", 1)[0]
            order.setdefault(page, []).append((position.pop("tabOrder", 0), f"{title}|{content.get('visual', {}).get('visualType')}"))
            position.pop("z", None)
            relative += f"[{title}|{content.get('visual', {}).get('visualType')}|{position.get('x')},{position.get('y')}]"
        files.setdefault(relative, []).append(content)
    return files, {page: [name for _, name in sorted(entries)] for page, entries in order.items()}


def compare_projects(scan_dir: str | Path, spec_dir: str | Path) -> list[dict[str, Any]]:
    """Where two PBIP folders differ once made-up ids are ignored: `{path, scan, spec}` per file, through
    `diff_closures` for JSON. A page whose visuals are the same but stacked in a different order is one entry,
    `<page>#visual order`."""
    (a, order_a), (b, order_b) = _project_files(Path(scan_dir)), _project_files(Path(spec_dir))
    out: list[dict[str, Any]] = []
    for path in sorted(set(a) | set(b)):
        left, right = a.get(path), b.get(path)
        if left == right:
            continue
        if left is None or right is None:
            out.append({"path": path, "scan": left if left is not None else "<absent>",
                        "spec": right if right is not None else "<absent>"})
            continue
        for n in range(max(len(left), len(right))):
            one = left[n] if n < len(left) else "<absent>"
            two = right[n] if n < len(right) else "<absent>"
            if one == two:
                continue
            if isinstance(one, (dict, list)) and isinstance(two, (dict, list)):
                out += [{**d, "path": f"{path}#{n}:{d['path']}"} for d in diff_closures(one, two)]
            else:
                out.append({"path": f"{path}#{n}", "scan": one, "spec": two})
    for page in sorted(set(order_a) | set(order_b)):
        if order_a.get(page) != order_b.get(page):
            out.append({"path": f"{page}#visual order", "scan": order_a.get(page), "spec": order_b.get(page)})
    return out


def compare_results(scan: dict[str, Any], spec: dict[str, Any]) -> list[dict[str, Any]]:
    """What the stages said (warnings and review items) where the two builds disagree. The PBIP is not all a build
    produces: the report of what could not be carried is part of the migration, and it must not depend on the source."""
    out: list[dict[str, Any]] = []
    for stage in sorted(set(scan) | set(spec)):
        a, b = scan.get(stage), spec.get(stage)
        warnings_a, warnings_b = sorted(getattr(a, "warnings", []) or []), sorted(getattr(b, "warnings", []) or [])
        if warnings_a != warnings_b:
            out.append({"path": f"{stage}.warnings", "scan": [w for w in warnings_a if w not in warnings_b],
                        "spec": [w for w in warnings_b if w not in warnings_a]})
        items_a = sorted((i.kind, i.title) for i in getattr(a, "review_items", []) or [])
        items_b = sorted((i.kind, i.title) for i in getattr(b, "review_items", []) or [])
        if items_a != items_b:
            out.append({"path": f"{stage}.review_items", "scan": [i for i in items_a if i not in items_b],
                        "spec": [i for i in items_b if i not in items_a]})
    return out

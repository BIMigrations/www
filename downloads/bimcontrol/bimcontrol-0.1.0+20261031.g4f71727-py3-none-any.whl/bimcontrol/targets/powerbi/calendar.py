"""Domo's calendar fields as calculated columns.

A card that groups by time does not group by a dataset column: it selects a
calendar field (`CalendarMonth`, `CalendarWeek`, `CalendarQuarter`, `Year`,
`Date`) flagged `calender: true`, and names the real date column in a
`DATE_GRAIN` column next to it (its `extras` hold the grain). Domo renders the
period as a label -- `2021-Aug`, `2016-Q2`, `Week-40 2026`, `2026-09-14`, `2021`.

Power BI has no such field, so each (date column, calendar field) pair becomes
a calculated column that produces the same label, plus, where the labels do
not sort in time order, a hidden date column the label sorts by. The labels
are written exactly as Domo shows them so a parity check compares like with like.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

# calendar field -> (label DAX, sort DAX or None, label data type). {c} is the date column reference.
# The sort key is a whole number, not a date: DATE() is not allowed in a calculated column of a DirectQuery
# table, and every visual that used the sort column failed there (Clinic Collections - SW).
_FIELDS: dict[str, tuple[str, str | None, str]] = {
    "CalendarMonth": ('FORMAT({c}, "yyyy-MMM")', "YEAR({c}) * 100 + MONTH({c})", "STRING"),
    "CalendarQuarter": ('YEAR({c}) & "-Q" & QUARTER({c})',
                        "YEAR({c}) * 100 + IF(MONTH({c}) <= 3, 1, IF(MONTH({c}) <= 6, 4, IF(MONTH({c}) <= 9, 7, 10)))",
                        "STRING"),
    # ISO week (Monday start). Domo does not document its numbering; parity will say if it differs.
    "CalendarWeek": ('"Week-" & WEEKNUM({c}, 21) & " " & YEAR({c})', "YEAR({c}) * 100 + WEEKNUM({c}, 21)", "STRING"),
    "Year": ("YEAR({c})", None, "INTEGER"),
    "Date": ('FORMAT({c}, "yyyy-mm-dd")', None, "STRING"),
}


@dataclass
class CalendarColumn:
    date_column: str
    field: str

    @property
    def name(self) -> str:
        return f"{self.date_column} ({self.field})"

    @property
    def sort_name(self) -> str:
        return f"{self.date_column} ({self.field} start)"


def is_calendar(column: dict[str, Any]) -> bool:
    return bool(column.get("calender")) and column.get("name") in _FIELDS


def calendar_columns(card: dict[str, Any]) -> list[CalendarColumn]:
    """The calendar fields a card selects, each with the date column it is cut from.

    A calendar field with no `DATE_GRAIN` beside it has no date to cut, so it is
    left out (the card reports that as a warning).
    """
    found: list[CalendarColumn] = []
    for subscription in card.get("data_subscriptions") or []:
        columns = subscription.get("columns") or []
        grain = next((c for c in columns if (c.get("columnType") or "").upper() == "DATE_GRAIN" and c.get("name")), None)
        if grain is None:
            continue
        for column in columns:
            if (column.get("columnType") or "").upper() == "SELECT" and is_calendar(column):
                item = CalendarColumn(grain["name"], column["name"])
                if all(item.name != other.name for other in found):
                    found.append(item)
    return found


def label_dax(item: CalendarColumn, date_reference: str) -> str:
    return _FIELDS[item.field][0].format(c=date_reference)


def sort_dax(item: CalendarColumn, date_reference: str) -> str | None:
    template = _FIELDS[item.field][1]
    return template.format(c=date_reference) if template else None


def label_type(item: CalendarColumn) -> str:
    return _FIELDS[item.field][2]

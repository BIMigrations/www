"""Tableau workbook and data-source file reader: bytes to a plain summary (M3, task 3.4).

``read_summary(data)`` takes the bytes of a ``.twb``, ``.tds``, ``.twbx`` or ``.tdsx`` and returns a
:class:`FileSummary` of dataclasses: data sources, connections, columns, calculations (formula
character for character), parameters, worksheets, dashboards, stories, actions, data source filters,
user-function references and the extract flag, plus an ``issues`` list for everything that did not
add up. ``summary.to_dict()`` is JSON-serialisable. Opening and bounding the bytes is ``files.py``;
what may be stored from a connection is ``scrub.py``.

**Provenance, read this first.** Nothing here has read a file saved by Tableau. The element and
attribute names come from Tableau's published workbook XSD (2026.1 and 2026.2, as vendored in the
sibling BIMControl repo's ``formats/twb/schemas``), from the M3 plan, and from memory of how real
files look. The XSD covers ``.twb`` only, checks syntax only and *skips* the parts that matter most
here (connection attributes, calculation content), so those parts are written from memory and are
tagged **[U]** (unconfirmed) below. The tests use crafted files (``tests/test_tableau_workbook.py``),
contain no customer data, and prove the reader does what it says to the XML it is given, not that
Tableau writes that XML. Task 3.4(b) re-runs the same checks on workbooks published to the sandbox.

**What is returned as written.** Only two strings: a calculation's ``formula`` and a Custom SQL relation's ``text``
(the logic being inventoried). Every other string goes through ``_s``: scanned for credentials, then cut to a length cap.
Issues quote names briefly and are capped per kind. See docs/tableau-scan-decisions.md.

**What is not returned.** No raw XML is kept: the summary is the structures below and the names of
child elements that were present and not read (``unread_elements``), so a file with parts nobody
modelled says so instead of silently dropping them. Whether to keep the scrubbed XML for M4/M8 is
still the open decision in docs/tableau-scan-decisions.md. No secret-like connection attribute is
returned (``scrub.py``), and no function here logs more than counts.

**Shape of a file** (all [U] except where the XSD says):

- ``<workbook>`` holds ``<datasources>``, ``<worksheets>``, ``<dashboards>`` (a story is a dashboard
  with ``type='storyboard'``, XSD), ``<windows>``, and ``<actions>``. A ``.tds`` is a bare
  ``<datasource>``.
- A data source holds ``<connection>`` (a ``federated`` one wraps ``<named-connections>``), ``<column>``s
  (a calculated field has a ``<calculation formula=...>`` child; a *parameter* is a column with
  ``param-domain-type``, in a data source named ``Parameters``), ``<filter>``s (data source filters,
  XSD ``DataSourceFilters-G``), ``<extract enabled=...>`` (XSD ``Extract-G``).
- A worksheet is ``<table>`` with ``<view>`` (``<datasources>``, ``<datasource-dependencies>``,
  ``<filter>``), ``<panes>`` (``<pane>``: ``<mark class>``, ``<encodings>``), ``<rows>``, ``<cols>``.
- A dashboard is ``<zones>`` of nested ``<zone>``. A zone that shows a worksheet names it in ``name``
  and has no ``type-v2``; legend and filter cards also carry the sheet's name with a ``type-v2``
  [U: this naming is from memory of real files, not from the XSD].
"""

from __future__ import annotations

import logging
import re
from dataclasses import asdict, dataclass, field
from typing import Any

from .files import (
    DEFAULT_LIMITS,
    Limits,
    Node,
    NotATableauFileError,
    parse_xml,
    unpack,
)
from .scrub import MAX_INLINE_CHARS, redact_inline, split_attributes

log = logging.getLogger(__name__)

PARAMETERS_DATASOURCE = "Parameters"  # [U] the pseudo data source parameters live in

# Functions whose result depends on who is signed in: the row-level-security signal. [U: the list is
# from Tableau's function reference as remembered; a function added later is missed, not misread.]
USER_FUNCTIONS = frozenset(
    {"USERNAME", "FULLNAME", "USERDOMAIN", "ISMEMBEROF", "ISUSERNAME", "ISFULLNAME", "USERATTRIBUTE", "USERATTRIBUTEINCLUDES"}
)

# type-v2 values of dashboard zones that name the worksheet they belong to [U]. A zone with no
# type-v2 and a name is the worksheet itself.
SHEET_BOUND_ZONE_TYPES = frozenset({"filter", "color", "size", "shape", "highlighter", "map", "pageNavigation"})


# -- the summary --------------------------------------------------------------------------------------


@dataclass
class Issue:
    """Something in the file that did not add up. Never silence: the dashboard that names a missing
    sheet is an issue row, not an absence."""

    code: str
    message: str
    where: str = ""
    severity: str = "warning"


@dataclass
class UserFunctionRef:
    function: str  # upper case
    argument: str | None = None  # the first argument when it is a string literal (ISMEMBEROF("Sales")), else None


@dataclass
class ConnectionInfo:
    """One connection. ``attributes`` holds only allowlisted keys (scrub.py); ``omitted_attributes`` the
    *names* of the rest, so a reader can tell something was dropped. ``role``: ``direct``, ``named``
    (inside a federated wrapper), ``wrapper`` (the federated element itself) or ``extract``."""

    role: str
    class_: str | None = None
    name: str | None = None
    caption: str | None = None
    attributes: dict[str, str] = field(default_factory=dict)
    omitted_attributes: list[str] = field(default_factory=list)
    relations: list[RelationInfo] = field(default_factory=list)


@dataclass
class RelationInfo:
    """A table, join or Custom SQL under a connection. ``text`` is the SQL of a Custom SQL relation,
    returned as written (it is the logic being inventoried, see scrub.py)."""

    type: str | None = None
    name: str | None = None
    table: str | None = None
    connection: str | None = None
    join: str | None = None
    text: str | None = None


@dataclass
class GroupFilterInfo:
    function: str | None = None
    level: str | None = None
    member: str | None = None
    user: str | None = None
    expression: str | None = None
    depth: int = 0


@dataclass
class FilterInfo:
    class_: str | None = None
    column: str | None = None
    included_values: str | None = None
    context: bool | None = None
    min: str | None = None
    max: str | None = None
    members: list[GroupFilterInfo] = field(default_factory=list)
    # The filter's column is a calculation that calls a user function (row-level security).
    user_functions: list[UserFunctionRef] = field(default_factory=list)


@dataclass
class ColumnInfo:
    name: str | None
    caption: str | None = None
    datatype: str | None = None
    role: str | None = None
    type: str | None = None
    aggregation: str | None = None
    semantic_role: str | None = None
    hidden: bool = False
    is_calculation: bool = False
    is_parameter: bool = False


@dataclass
class CalculationInfo:
    """A calculated field. ``formula`` is exactly the attribute value the parser returns: newlines,
    tabs and unicode intact (a literal line break typed into an attribute is a space by XML's own
    rules, which is why Tableau writes ``&#13;&#10;``). ``origin`` is ``datasource`` or
    ``worksheet-dependency`` (a copy found only on a sheet; an issue is recorded)."""

    datasource: str | None
    column: str | None
    caption: str | None
    formula: str | None
    class_: str | None = None
    datatype: str | None = None
    role: str | None = None
    type: str | None = None
    origin: str = "datasource"
    user_functions: list[UserFunctionRef] = field(default_factory=list)
    grouping: dict[str, Any] | None = None  # a bin's or a group's own definition (``_grouping``); None for a formula calculation


@dataclass
class ParameterInfo:
    datasource: str | None
    name: str | None
    caption: str | None = None
    datatype: str | None = None
    role: str | None = None
    domain_type: str | None = None  # list, range, any
    value: str | None = None  # the current value, as the attribute is written
    formula: str | None = None  # the calculation child, which holds the default [U]
    allowed_values: list[dict[str, str | None]] = field(default_factory=list)  # [{value, alias}]
    range: dict[str, str | None] | None = None  # {min, max, granularity}


@dataclass
class ExtractInfo:
    enabled: bool
    units: str | None = None
    count: str | None = None
    type: str | None = None
    user_specific: str | None = None
    connection: ConnectionInfo | None = None
    filters: list[FilterInfo] = field(default_factory=list)


@dataclass
class PublishedRef:
    """``<repository-location>``: the data source is (or was derived from) one published on a server [U]."""

    id: str | None = None
    path: str | None = None
    revision: str | None = None
    site: str | None = None
    derived_from: str | None = None


@dataclass
class TableColumnInfo:
    name: str | None
    datatype: str | None = None


@dataclass
class TableInfo:
    """One table (or Custom SQL query) of a data source with its physical columns. ``columns`` come from the relation's ``<columns>``, or, when the
    relation lists none (a database table, an extract), from the data source's ``metadata-records`` of that table. ``object_id`` is the id the
    object graph's relationships name it by."""

    name: str | None
    type: str | None = None
    table: str | None = None
    connection: str | None = None
    connection_class: str | None = None
    file: str | None = None
    object_id: str | None = None
    text_format: dict[str, str] = field(default_factory=dict)
    columns: list[TableColumnInfo] = field(default_factory=list)


@dataclass
class RelationshipInfo:
    """A relationship of the object graph. ``first`` and ``second`` are object ids; ``on`` is ``"A = B"`` (``" AND "`` between pairs) and ``pairs`` the
    same as data."""

    first: str | None = None
    second: str | None = None
    first_table: str | None = None
    second_table: str | None = None
    on: str = ""
    pairs: list[dict[str, str | None]] = field(default_factory=list)


@dataclass
class StructureInfo:
    """What a data source says about its own tables: ``field_map`` is {field name: [table, column]} (``<cols><map>``, else the metadata records),
    ``joins`` the number of join relations, ``truncated`` the kinds of thing that were cut at a cap, with how many there were."""

    tables: list[TableInfo] = field(default_factory=list)
    field_map: dict[str, list[str]] = field(default_factory=dict)
    joins: int = 0
    relationships: list[RelationshipInfo] = field(default_factory=list)
    truncated: dict[str, int] = field(default_factory=dict)


@dataclass
class DataSourceInfo:
    name: str | None
    caption: str | None = None
    version: str | None = None
    has_connection: bool | None = None
    is_extract: bool = False
    extract: ExtractInfo | None = None
    published: PublishedRef | None = None
    connections: list[ConnectionInfo] = field(default_factory=list)
    columns: list[ColumnInfo] = field(default_factory=list)
    calculations: list[CalculationInfo] = field(default_factory=list)
    filters: list[FilterInfo] = field(default_factory=list)  # data source filters
    structure: StructureInfo = field(default_factory=StructureInfo)
    unread_elements: list[str] = field(default_factory=list)


@dataclass
class EncodingInfo:
    channel: str
    column: str | None = None


@dataclass
class PaneInfo:
    id: str | None = None
    mark: str | None = None
    encodings: list[EncodingInfo] = field(default_factory=list)


@dataclass
class SheetInfo:
    name: str | None
    hidden: bool = False
    datasources: list[str] = field(default_factory=list)
    fields_used: dict[str, list[str]] = field(default_factory=dict)  # data source -> column names, from datasource-dependencies
    marks: list[str] = field(default_factory=list)  # distinct, in pane order
    panes: list[PaneInfo] = field(default_factory=list)
    rows: str | None = None
    cols: str | None = None
    filters: list[FilterInfo] = field(default_factory=list)
    slices: list[str] = field(default_factory=list)
    on_dashboards: list[str] = field(default_factory=list)
    unread_elements: list[str] = field(default_factory=list)


@dataclass
class ZoneInfo:
    id: str | None
    parent_id: str | None
    depth: int
    type_v2: str | None = None
    name: str | None = None
    param: str | None = None
    x: str | None = None
    y: str | None = None
    w: str | None = None
    h: str | None = None
    hidden: bool = False
    text: str | None = None  # a text box's runs, joined
    layout: str | None = None  # "main", or the device layout name


@dataclass
class ActionInfo:
    scope: str  # "workbook" or the data source name
    name: str | None
    caption: str | None = None
    enabled: bool | None = None
    activation: str | None = None
    source_type: str | None = None
    source_datasource: str | None = None
    source_worksheet: str | None = None
    source_dashboard: str | None = None
    excluded_sheets: list[str] = field(default_factory=list)
    command: str | None = None
    params: dict[str, str | None] = field(default_factory=dict)
    link: str | None = None  # a URL action's expression, with embedded credentials redacted
    unread_elements: list[str] = field(default_factory=list)


@dataclass
class DashboardInfo:
    name: str | None
    hidden: bool = False
    size: dict[str, str] = field(default_factory=dict)
    zones: list[ZoneInfo] = field(default_factory=list)
    sheets: list[str] = field(default_factory=list)  # worksheets the zones name, in layout order, distinct
    missing_sheets: list[str] = field(default_factory=list)  # named by a zone, absent from the workbook
    device_layouts: list[str] = field(default_factory=list)
    actions: list[str] = field(default_factory=list)  # names of actions whose source is this dashboard
    unread_elements: list[str] = field(default_factory=list)


@dataclass
class StoryPointInfo:
    id: str | None
    caption: str | None = None
    captured_sheet: str | None = None
    current_sheet: str | None = None


@dataclass
class StoryInfo:
    name: str | None
    hidden: bool = False
    points: list[StoryPointInfo] = field(default_factory=list)
    zones: list[ZoneInfo] = field(default_factory=list)
    unread_elements: list[str] = field(default_factory=list)


@dataclass
class UserFunctionUse:
    """Every user-function call in the file, flat, for the row-level-security view."""

    datasource: str | None
    calculation: str | None  # the column name
    caption: str | None
    function: str
    argument: str | None


@dataclass
class FileSummary:
    file_format: str  # twb, tds, twbx, tdsx (twbx/tdsx: by the archive's member)
    kind: str  # workbook or datasource
    version: str | None = None
    original_version: str | None = None
    source_build: str | None = None
    source_platform: str | None = None
    datasources: list[DataSourceInfo] = field(default_factory=list)
    parameters: list[ParameterInfo] = field(default_factory=list)
    sheets: list[SheetInfo] = field(default_factory=list)
    dashboards: list[DashboardInfo] = field(default_factory=list)
    stories: list[StoryInfo] = field(default_factory=list)
    actions: list[ActionInfo] = field(default_factory=list)
    user_function_uses: list[UserFunctionUse] = field(default_factory=list)
    issues: list[Issue] = field(default_factory=list)
    unread_elements: list[str] = field(default_factory=list)

    @property
    def calculations(self) -> list[CalculationInfo]:
        return [c for d in self.datasources for c in d.calculations]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# -- user functions -----------------------------------------------------------------------------------

# Strings, comments and [field references] are skipped so that a field called [USERNAME()] or the text
# "ISMEMBEROF(" in a string is not a call. Every alternative consumes to the end of the input when it is
# unterminated (including a string ending in a lone backslash, and the possessive star never gives back), so a failed
# match can never be retried from the next character: the scan is linear in the formula's length whatever it holds.
_TOKEN = re.compile(
    r"""
    (?P<str>"(?:[^"\\]|\\.|\\\Z)*+(?:"|\Z)|'(?:[^'\\]|\\.|\\\Z)*+(?:'|\Z))
  | (?P<comment>//[^\n]*|/\*(?:[^*]|\*(?!/))*(?:\*/|\Z))
  | (?P<field>\[[^\]]*(?:\]|\Z))
  | (?P<ident>[A-Za-z_][A-Za-z0-9_]*)
    """,
    re.X | re.S,
)
_CALL = re.compile(r"""\s*\(\s*(?:"((?:[^"\\]|\\.)*)"|'((?:[^'\\]|\\.)*)')?""", re.S)


def user_functions_in(formula: str | None) -> list[UserFunctionRef]:
    """The user-function calls in a Tableau calculation, in order. Pure text; no call is evaluated."""
    if not formula:
        return []
    found: list[UserFunctionRef] = []
    for match in _TOKEN.finditer(formula):
        if match.lastgroup != "ident":
            continue
        name = match.group("ident").upper()
        if name not in USER_FUNCTIONS:
            continue
        call = _CALL.match(formula, match.end())
        if not call:
            continue  # the name without a call: a bare word, not a function
        arg = call.group(1) if call.group(1) is not None else call.group(2)
        found.append(UserFunctionRef(function=name, argument=_s(arg)))
    return found


# -- text fields: capped and scanned, except formulas and Custom SQL -----------------------------------------------

# Every string this module returns passes through ``_s`` (length cap, then credentials redacted) except the
# two that are the logic being inventoried and are returned as written: a calculation's ``formula`` and a
# Custom SQL relation's ``text``. A name is not exempt: a workbook author can put anything in a name.
MAX_FIELD_CHARS = 2_048  # a name, caption, member value, shelf, URL: far above a real one
MAX_TEXT_CHARS = 8_192  # a dashboard text box
MAX_NAME_IN_ISSUE = 120  # how much of a name an issue repeats: an issue per zone must not copy a megabyte each time
ISSUES_PER_CODE = 50  # listed per kind of issue; the rest are counted in one summary entry
_CLIPPED = re.compile(r"…\[(\d+) chars\]$")


def _s(value: str | None, cap: int = MAX_FIELD_CHARS) -> str | None:
    """``value`` with credentials redacted, then cut to ``cap`` characters (the cut says how long it was)."""
    if value is None:
        return None
    # Redaction looks at no more than its own limit, so the work on a hostile value is bounded; the cut
    # comes after it so a secret that straddles the cut is redacted, not half shown.
    text = redact_inline(value[:MAX_INLINE_CHARS])
    if len(text) > cap or len(value) > MAX_INLINE_CHARS:
        text = text[:cap] + f"…[{len(value)} chars]"
    return text


def _a(node: Node, name: str, cap: int = MAX_FIELD_CHARS) -> str | None:
    return _s(node.get(name), cap)


def _q(name: str | None) -> str:
    """A name for an issue message: short, quoted, and the length of the original when it was cut."""
    if name is None:
        return "(no name)"
    clipped = _CLIPPED.search(name)
    length = int(clipped.group(1)) if clipped else len(name)
    if len(name) <= MAX_NAME_IN_ISSUE:
        return repr(name)
    return f"{name[:MAX_NAME_IN_ISSUE]!r}… ({length} chars)"


class _Issues:
    """Collects issues, keeping the first ``ISSUES_PER_CODE`` of each kind and counting the rest: a hostile file
    cannot make the issue list the size of the file times its own length."""

    def __init__(self, sink: list[Issue]):
        self._sink = sink
        self._counts: dict[str, int] = {}
        self._severity: dict[str, str] = {}

    def add(self, code: str, message: str, where: str = "", severity: str = "warning") -> None:
        n = self._counts[code] = self._counts.get(code, 0) + 1
        if n <= ISSUES_PER_CODE:
            self._sink.append(Issue(code, message, where, severity))
        else:
            self._severity[code] = severity

    def finish(self) -> None:
        for code, n in self._counts.items():
            if n > ISSUES_PER_CODE:
                self._sink.append(
                    Issue(code, f"{n - ISSUES_PER_CODE} more of this kind not listed ({n} in all)", "", self._severity[code])
                )


# -- helpers ------------------------------------------------------------------------------------------


def _flag(value: str | None) -> bool | None:
    if value is None:
        return None
    return value.strip().lower() == "true"


def _unread(node: Node, read: frozenset[str]) -> list[str]:
    return sorted({c.tag for c in node.children} - read)


_REF = re.compile(r"\[([^\]]*)\]")


def _column_key(ref: str | None) -> str | None:
    """``[Calculation_1]`` from ``[ds].[none:Calculation_1:nk]``, ``[Calculation_1]`` or ``Calculation_1``:
    the last bracketed part, with a ``derivation:name:type`` instance form reduced to its name [U]."""
    if not ref:
        return None
    parts = _REF.findall(ref)
    last = parts[-1] if parts else ref
    if ":" in last:
        pieces = last.split(":")
        if len(pieces) >= 3:
            last = pieces[1]
    return f"[{last}]"


MAX_GROUP_BINS = 500  # the groups of one group field kept; a field with more says so (``bin_count``)
MAX_GROUP_MEMBERS = 2_000  # the members kept across all of a group's bins (``member_count`` is the whole count)
MAX_MEMBER_CHARS = 256
# The attributes of a ``<calculation>`` kept for a bin or group. A fixed list: attribute names are an open set in a file anyone can write, and a value
# like ``hunter2`` has no ``key=`` around it for the redaction to find. The rest are named in ``unread_attributes`` (safe-looking names only).
_BIN_ATTRIBUTES = frozenset({"size", "peg", "decimals", "size-parameter", "new-bin", "scale"})
_SAFE_ATTRIBUTE_NAME = re.compile(r"[A-Za-z][A-Za-z0-9_.-]{0,39}")
_UNREAD_ATTRIBUTES_LISTED = 10


def _grouping(calc: Node) -> dict[str, Any] | None:
    """The definition of a ``<calculation>`` that is not a formula: ``class='bin'`` (size, peg, decimals; the source field is its
    ``formula``) and ``class='categorical-bin'`` (a group or a cluster: the ``column`` it groups, the ``default`` for members in no
    group, and each ``<bin value=...>`` with its ``<value>`` members, in file order). None for any other class. Bounded: at most
    ``MAX_GROUP_BINS`` bins and ``MAX_GROUP_MEMBERS`` members are kept, the counts are of everything read."""
    kind = calc.get("class")
    if kind not in ("bin", "categorical-bin"):
        return None
    skipped = [k for k in calc.attrib if k not in _BIN_ATTRIBUTES and k not in ("class", "formula", "column", "default")]
    # (``size-parameter`` names a field, like ``column``: cut, not redacted)
    out: dict[str, Any] = {"class": kind, "attributes": {k: calc.attrib[k][:MAX_FIELD_CHARS] if k == "size-parameter" else _a(calc, k) for k in calc.attrib if k in _BIN_ATTRIBUTES}}
    if skipped:
        out["unread_attributes"] = [k for k in skipped if _SAFE_ATTRIBUTE_NAME.fullmatch(k)][:_UNREAD_ATTRIBUTES_LISTED]
        out["unread_attribute_count"] = len(skipped)
    if kind == "categorical-bin":
        bins: list[dict[str, Any]] = []
        bin_count = member_count = 0
        for b in (c for c in calc.children if c.tag == "bin"):
            bin_count += 1
            values = [v for v in b.children if v.tag == "value"]
            kept = [_s(v.text, MAX_MEMBER_CHARS) for v in values[: max(0, MAX_GROUP_MEMBERS - member_count)]]
            member_count += len(values)
            if len(bins) < MAX_GROUP_BINS:
                bins.append({"value": _a(b, "value"), "default_name": _flag(b.get("default-name")), "members": kept})
        column = calc.get("column")  # a field's name, as a formula's references are: not redacted (``_s`` would read ``[Session Key: A]`` as a secret), only cut
        out.update(column=column[:MAX_FIELD_CHARS] if column is not None else None, default=_a(calc, "default"), bins=bins, bin_count=bin_count, member_count=member_count,
                   truncated=bin_count > len(bins) or member_count > sum(len(b["members"]) for b in bins))
    return out


def _group_filters(node: Node) -> list[GroupFilterInfo]:
    found: list[GroupFilterInfo] = []
    stack = [(c, 0) for c in reversed(node.children)]
    while stack:
        child, depth = stack.pop()
        if child.tag == "groupfilter":
            found.append(
                GroupFilterInfo(
                    function=_a(child, "function"),
                    level=_a(child, "level"),
                    member=_a(child, "member"),
                    user=_a(child, "user"),
                    expression=_a(child, "expression"),
                    depth=depth,
                )
            )
        stack.extend((c, depth + 1) for c in reversed(child.children))
    return found


def _calc_for(column: str | None, calcs_by_ds: dict[str | None, dict[str, CalculationInfo]], default_ds: str | None) -> CalculationInfo | None:
    """The calculation a filter's column refers to. ``[ds].[none:Calc:nk]`` names its data source first; a bare
    ``[Calc]`` is looked up in ``default_ds`` (the data source the filter sits on)."""
    key = _column_key(column)
    parts = _REF.findall(column or "")
    ds = parts[0] if len(parts) >= 2 else default_ds
    return calcs_by_ds.get(ds, {}).get(key) if key else None


def _filter(node: Node, calcs_by_ds: dict[str | None, dict[str, CalculationInfo]], default_ds: str | None) -> FilterInfo:
    column = _a(node, "column")
    calc = _calc_for(column, calcs_by_ds, default_ds)
    mn, mx = node.find("min"), node.find("max")
    return FilterInfo(
        class_=_a(node, "class"),
        column=column,
        included_values=_a(node, "included-values"),
        context=_flag(node.get("context")),
        min=_s(mn.text) if mn is not None else None,
        max=_s(mx.text) if mx is not None else None,
        members=_group_filters(node),
        user_functions=list(calc.user_functions) if calc else [],
    )


def _relations(node: Node) -> list[RelationInfo]:
    out: list[RelationInfo] = []
    for rel in node.iter("relation"):
        text = rel.text
        out.append(
            RelationInfo(
                type=_a(rel, "type"),
                name=_a(rel, "name"),
                table=_a(rel, "table"),
                connection=_a(rel, "connection"),
                join=_a(rel, "join"),
                text=text if text.strip() else None,  # Custom SQL, as written
            )
        )
    return out


def _connection(node: Node, role: str) -> ConnectionInfo:
    kept, omitted = split_attributes(node.attrib)
    return ConnectionInfo(
        role=role,
        class_=kept.get("class"),
        name=_s(kept.get("name")) or None,
        caption=_s(kept.get("caption")) or None,
        attributes={k: v for k, v in kept.items() if k not in ("class", "name", "caption")},
        omitted_attributes=omitted,
    )


def _connections(ds: Node) -> list[ConnectionInfo]:
    """Data source connections: each direct one, or each named one inside a ``federated`` wrapper. Relations
    (tables, joins, Custom SQL) go on the wrapper or direct connection that holds them."""
    out: list[ConnectionInfo] = []
    for top in ds.findall("connection"):
        named = [nc for group in top.findall("named-connections") for nc in group.findall("named-connection")]
        wrapper = _connection(top, "wrapper" if named else "direct")
        wrapper.relations = _relations(top)
        out.append(wrapper)
        for nc in named:
            inner = nc.find("connection")
            info = _connection(inner, "named") if inner is not None else ConnectionInfo(role="named")
            info.name = _a(nc, "name") or info.name
            info.caption = _a(nc, "caption") or info.caption
            out.append(info)
    return out


# -- data source structure ----------------------------------------------------------------------------

MAX_STRUCTURE_TABLES = 500  # tables of one data source
MAX_STRUCTURE_COLUMNS = 20_000  # table columns of one data source, and again the entries of its field map
MAX_RELATIONSHIPS = 500
MAX_RELATIONSHIP_PAIRS = 50  # column pairs of one relationship
_TEXT_FORMAT = ("separator", "character-set", "header")  # a text file's reading rules, kept on its table


def _bracketed(text: str | None, limit: int = 3) -> list[str]:
    """The names of ``[a].[b]``, a doubled ``]`` undone: ``["a", "b"]``; ``[]`` for text that is not that, or that holds more than ``limit`` names
    (a name is one part, ``[table].[column]`` two). One pass over the text, no retries from later characters: an unclosed ``[`` ends the scan."""
    out: list[str] = []
    i, n = 0, len(text or "")
    while i < n and text is not None:
        if text[i] != "[":
            i += 1
            continue
        if len(out) >= limit:
            return []
        i += 1
        part: list[str] = []
        while i < n:
            if text[i] == "]":
                if i + 1 < n and text[i + 1] == "]":
                    part.append("]")
                    i += 2
                    continue
                break
            part.append(text[i])
            i += 1
        else:
            return out  # never closed
        out.append("".join(part))
        i += 1
    return out


MAX_NAME_SCAN = 65_536  # a bracketed name longer than this is not read (it is cut at 2,048 characters when stored anyway)
_COLUMN_REF = re.compile(r"\[(?:[^\]]|\]\])*\](?:\.\[(?:[^\]]|\]\])*\])*")


def _names(text: str | None) -> list[str]:
    """``_bracketed`` of the raw text, each name then cleaned like every other name (``_s``): a table's name in a record or a map is the table's own cleaned
    name, whatever the cleaning did to it (a cut name is cut the same way, a redacted one the same way)."""
    if text is not None and len(text) > MAX_NAME_SCAN:
        return []
    return [_s(part) or "" for part in _bracketed(text)]


def _raw_child(node: Node, tag: str) -> str | None:
    child = node.find(tag)
    return child.text if child is not None and child.text else None


def _child_text(node: Node, tag: str) -> str | None:
    text = _raw_child(node, tag)
    return _s(text) if text else None


def _is_column(op: str | None) -> bool:
    """Is the text exactly one or more bracketed names joined by dots (``[x]``, ``[T].[x]``)? A literal, ``[a] + [b]`` or ``[x] DESC`` is not."""
    return op is not None and len(op) <= MAX_NAME_SCAN and _COLUMN_REF.fullmatch(op) is not None


def _equalities(root: Node) -> list[tuple[Node, Node]] | None:
    """The column pairs of a relationship's condition when it is exactly an equality of two columns or several of them joined by AND (nested ANDs
    included); None for anything else (``OR``, ``NOT``, ``<``, a function, an equality with a non-column side): such a condition is not listed as pairs."""
    pairs: list[tuple[Node, Node]] = []
    stack = [root]
    while stack:
        ex = stack.pop()
        op = ex.get("op")
        kids = [k for k in ex.children if k.tag == "expression"]
        if len(kids) != len(ex.children):
            return None
        if op == "AND" and kids:
            stack.extend(reversed(kids))
        elif op == "=" and len(kids) == 2 and not any(k.children for k in kids) and all(_is_column(k.get("op")) for k in kids):
            pairs.append((kids[0], kids[1]))
        else:
            return None
    return pairs


def _read_structure(node: Node, connections: list[ConnectionInfo], issues: _Issues | None, owner: str | None) -> StructureInfo:
    """The tables of a data source with their columns, the field -> (table, column) map, the join count and the object graph's relationships.

    A table is a ``<relation type='table'>`` (or Custom SQL, ``type='text'``) under the data source's connection or inside its object graph, once per
    (name, connection). Its columns are the relation's ``<columns>``; a relation with none (a database table, an extract) takes them from the
    ``metadata-record``s of class ``column`` that name it as their parent (by the record's object id when the table has one, else by name when that
    name is the table's alone). The field map is ``<cols><map key='[f]' value='[table].[column]'/>``, else the same records. Nothing is guessed: an entry
    that is not that shape is left out and counted. Each list is cut at a cap and the cut is in ``truncated``. The work is one walk over the data source's
    elements: the object graph is read through ``objects/object/properties`` and ``relationships/relationship``, never by a search below each element."""
    out = StructureInfo()
    named = {c.name: c for c in connections if c.role == "named" and c.name}
    direct = [c for c in connections if c.role == "direct"]
    relations: list[Node] = []
    maps: list[Node] = []
    records: list[Node] = []
    for top in node.findall("connection"):
        found = top.iter("relation")
        relations += found
        out.joins += sum(1 for r in found if r.get("type") == "join")
        maps += [m for cols in top.findall("cols") for m in cols.findall("map")]
        records += [r for group in top.findall("metadata-records") for r in group.findall("metadata-record") if r.get("class") == "column"]
    graph = node.find("object-graph")
    object_of: list[tuple[Node, str | None]] = [(r, None) for r in relations]
    tables_of_object: dict[str, list[tuple[str | None, str | None]]] = {}  # object id -> the (name, connection) of the tables it holds
    if graph is not None:
        for group in graph.findall("objects"):
            for obj in group.findall("object"):
                object_id = _a(obj, "id")
                for props in obj.findall("properties"):
                    for top in props.findall("relation"):
                        for rel in [top, *top.iter("relation")]:
                            object_of.append((rel, object_id))
                            if object_id and rel.get("type") in ("table", "text"):
                                tables_of_object.setdefault(object_id, []).append((_a(rel, "name"), _a(rel, "connection")))

    index: dict[tuple[str | None, str | None], TableInfo] = {}
    skipped: set[tuple[str | None, str | None]] = set()
    columns_kept = 0

    def keep_column() -> bool:
        nonlocal columns_kept
        if columns_kept >= MAX_STRUCTURE_COLUMNS:
            out.truncated["table columns"] = out.truncated.get("table columns", 0) + 1
            return False
        columns_kept += 1
        return True

    for rel, object_id in object_of:
        if rel.get("type") not in ("table", "text"):
            continue
        key = (_a(rel, "name"), _a(rel, "connection"))
        table = index.get(key)
        if table is None:
            if len(index) >= MAX_STRUCTURE_TABLES:
                skipped.add(key)
                continue
            link = named.get(key[1] or "") or (direct[0] if key[1] is None and len(direct) == 1 else None)
            table = index[key] = TableInfo(
                name=key[0], type=_a(rel, "type"), table=_a(rel, "table"), connection=key[1],
                connection_class=link.class_ if link else None,
                file=("/".join(p for p in (link.attributes.get("directory"), link.attributes.get("filename")) if p) or None) if link else None,
            )
            out.tables.append(table)
        listed = rel.find("columns")
        if listed is not None and not table.columns:  # the first copy that lists columns gives them (the object graph repeats each table)
            table.text_format = {k: v for k in _TEXT_FORMAT if (v := _a(listed, k)) is not None}
            table.columns = [TableColumnInfo(name=_a(col, "name"), datatype=_a(col, "datatype")) for col in listed.findall("column") if keep_column()]
        if object_id and table.object_id is None and len(tables_of_object.get(object_id, [])) == 1:
            table.object_id = object_id
    if skipped:
        out.truncated["tables"] = len(skipped)

    # records: columns for the tables that listed none, and the field map where `<cols>` did not give one
    by_object: dict[str, list[Node]] = {}
    by_parent: dict[str, list[Node]] = {}
    parent_of: dict[int, list[str]] = {}  # record -> its parent's names, cleaned once
    nameless_parent = 0
    for rec in records:
        parent_of[id(rec)] = _names(_raw_child(rec, "parent-name"))
        nameless_parent += not parent_of[id(rec)]
        oid = (_names(_raw_child(rec, "object-id")) or [None])[0]
        parent = parent_of[id(rec)][-1] if parent_of[id(rec)] else None
        if oid is not None:
            by_object.setdefault(oid, []).append(rec)
        if parent is not None:
            by_parent.setdefault(parent, []).append(rec)
    name_count: dict[str | None, int] = {}
    for table in out.tables:
        name_count[table.name] = name_count.get(table.name, 0) + 1
    for table in out.tables:
        if table.columns:
            continue
        mine = by_object.get(table.object_id or "") or (by_parent.get(table.name or "") if name_count[table.name] == 1 else None) or []
        table.columns = [TableColumnInfo(name=_child_text(rec, "remote-name"), datatype=_child_text(rec, "local-type"))
                         for rec in mine if _raw_child(rec, "remote-name") and keep_column()]
    odd = 0
    for m in maps:
        field_, target = _names(m.get("key")), _names(m.get("value"))
        if len(field_) != 1 or len(target) != 2:
            odd += 1
        elif field_[0] not in out.field_map:
            if len(out.field_map) >= MAX_STRUCTURE_COLUMNS:
                out.truncated["field map"] = out.truncated.get("field map", 0) + 1
                continue
            out.field_map[field_[0]] = target
    for rec in records:
        field_, parent = _names(_raw_child(rec, "local-name")), parent_of[id(rec)]
        remote = _child_text(rec, "remote-name")
        if len(field_) == 1 and parent and remote is not None and field_[0] not in out.field_map:
            if len(out.field_map) >= MAX_STRUCTURE_COLUMNS:
                out.truncated["field map"] = out.truncated.get("field map", 0) + 1
                continue
            out.field_map[field_[0]] = [parent[-1], remote]
    if nameless_parent and issues is not None:
        issues.add("structure_record", f"{nameless_parent} column records name no table (a parent of none, or of more than three parts) and were left out", f"data source {_q(owner)}")
    if odd and issues is not None:
        issues.add("field_map_entry", f"{odd} entries of a data source's field map are not [field] -> [table].[column] and were left out", f"data source {_q(owner)}")

    if graph is not None:
        table_of = {oid: held[0][0] for oid, held in tables_of_object.items() if len(held) == 1 and held[0] in index}
        unread = 0
        for group in graph.findall("relationships"):
            for rel in group.findall("relationship"):
                if len(out.relationships) >= MAX_RELATIONSHIPS:
                    out.truncated["relationships"] = out.truncated.get("relationships", 0) + 1
                    continue
                ends = {e.tag: _a(e, "object-id") for e in rel.children if e.tag in ("first-end-point", "second-end-point")}
                roots = [e for e in rel.children if e.tag == "expression"]
                equalities = _equalities(roots[0]) if len(roots) == 1 else None  # None: not an equality of two columns, or several of them joined by AND
                pairs: list[dict[str, str | None]] = []
                for left, right in equalities or []:
                    if len(pairs) >= MAX_RELATIONSHIP_PAIRS:
                        out.truncated["relationship pairs"] = out.truncated.get("relationship pairs", 0) + 1
                        continue
                    names = [(_names(side.get("op")) or [_a(side, "op")])[-1] for side in (left, right)]
                    pairs.append({"first_column": names[0], "second_column": names[1], "op": "="})
                if roots and equalities is None:
                    unread += 1
                first, second = ends.get("first-end-point"), ends.get("second-end-point")
                out.relationships.append(RelationshipInfo(
                    first=first, second=second, first_table=table_of.get(first or ""), second_table=table_of.get(second or ""),
                    on=" AND ".join(f"{p['first_column']} = {p['second_column']}" for p in pairs), pairs=pairs))
        if unread and issues is not None:
            issues.add("relationship_condition", f"{unread} relationships have a condition that is not an equality of two columns or several joined by AND; their columns are not listed",
                       f"data source {_q(owner)}")
    if out.truncated and issues is not None:
        what = ", ".join(f"{n} {kind}" for kind, n in out.truncated.items())
        issues.add("structure_truncated", f"a data source's structure was cut at its caps ({what} not kept)", f"data source {_q(owner)}")
    return out


# -- data sources -------------------------------------------------------------------------------------

_DS_READ = frozenset(
    {"connection", "column", "filter", "extract", "repository-location", "column-instance", "actions", "object-graph"}
)


def _read_datasource(node: Node, actions: list[ActionInfo], issues: _Issues | None = None) -> tuple[DataSourceInfo, list[ParameterInfo]]:
    name = _a(node, "name")
    info = DataSourceInfo(
        name=name,
        caption=_a(node, "caption"),
        version=_a(node, "version"),
        has_connection=_flag(node.get("hasconnection")),
        unread_elements=_unread(node, _DS_READ),
    )
    info.connections = _connections(node)
    info.structure = _read_structure(node, info.connections, issues, name)
    repo = node.find("repository-location")
    if repo is not None:
        info.published = PublishedRef(
            id=_a(repo, "id"), path=_a(repo, "path"), revision=_a(repo, "revision"), site=_a(repo, "site"),
            derived_from=_a(repo, "derived-from") or None,
        )
    parameters: list[ParameterInfo] = []
    calcs: dict[str | None, dict[str, CalculationInfo]] = {name: {}}
    for col in node.findall("column"):
        calc = col.find("calculation")
        is_param = col.get("param-domain-type") is not None
        info.columns.append(
            ColumnInfo(
                name=_a(col, "name"),
                caption=_a(col, "caption"),
                datatype=_a(col, "datatype"),
                role=_a(col, "role"),
                type=_a(col, "type"),
                aggregation=_a(col, "aggregation"),
                semantic_role=_a(col, "semantic-role"),
                hidden=bool(_flag(col.get("hidden"))),
                is_calculation=calc is not None and not is_param,
                is_parameter=is_param,
            )
        )
        if is_param:
            members = [
                {"value": _a(m, "value"), "alias": _a(m, "alias")}
                for group in col.findall("members") for m in group.findall("member")
            ]
            rng = col.find("range")
            parameters.append(
                ParameterInfo(
                    datasource=name,
                    name=_a(col, "name"),
                    caption=_a(col, "caption"),
                    datatype=_a(col, "datatype"),
                    role=_a(col, "role"),
                    domain_type=_a(col, "param-domain-type"),
                    value=_a(col, "value"),
                    formula=_a(calc, "formula") if calc is not None else None,
                    allowed_values=members,
                    range={"min": _a(rng, "min"), "max": _a(rng, "max"), "granularity": _a(rng, "granularity")}
                    if rng is not None else None,
                )
            )
        elif calc is not None:
            formula = calc.get("formula")  # as written: this and Custom SQL are the only text not passed through _s
            item = CalculationInfo(
                datasource=name,
                column=_a(col, "name"),
                caption=_a(col, "caption"),
                formula=formula,
                class_=_a(calc, "class"),
                datatype=_a(col, "datatype"),
                role=_a(col, "role"),
                type=_a(col, "type"),
                user_functions=user_functions_in(formula),
                grouping=_grouping(calc),
            )
            info.calculations.append(item)
            if item.column:
                calcs[name][item.column] = item
    for flt in node.findall("filter"):
        info.filters.append(_filter(flt, calcs, name))
    ext = node.find("extract")
    if ext is not None:
        info.extract = ExtractInfo(
            enabled=bool(_flag(ext.get("enabled"))),
            units=_a(ext, "units"),
            count=_a(ext, "count"),
            type=_a(ext, "type"),
            user_specific=_a(ext, "user-specific"),
            filters=[_filter(f, calcs, name) for f in ext.findall("filter")],
        )
        econn = ext.find("connection")
        if econn is not None:
            info.extract.connection = _connection(econn, "extract")
            info.extract.connection.relations = _relations(econn)
        info.is_extract = info.extract.enabled
    for group in node.findall("actions"):
        for i, action in enumerate(group.findall("action")):
            read = _read_action(action, name or "")
            actions.append(read)
            if issues is not None and not read.name:
                issues.add("unnamed_action", "an action has no name", f"action #{i + 1} of data source {_q(name)}")
    return info, parameters


# -- worksheets ---------------------------------------------------------------------------------------

_SHEET_READ = frozenset({"table", "simple-id"})
_TABLE_READ = frozenset({"view", "panes", "rows", "cols"})
_VIEW_READ = frozenset({"datasources", "datasource-dependencies", "filter", "slices"})


def _read_sheet(node: Node, calcs_by_ds: dict[str | None, dict[str, CalculationInfo]], hidden_names: set[str | None], dep_calcs: list[tuple[str, Node]]) -> SheetInfo:
    sheet = SheetInfo(name=_a(node, "name"), hidden=_a(node, "name") in hidden_names)
    unread = set(_unread(node, _SHEET_READ))
    table = node.find("table")
    if table is not None:
        unread |= {f"table/{t}" for t in _unread(table, _TABLE_READ)}
        view = table.find("view")
        if view is not None:
            unread |= {f"view/{t}" for t in _unread(view, _VIEW_READ)}
            seen_ds: set[str] = set()
            for group in view.findall("datasources"):
                for ds in group.findall("datasource"):
                    ref = _a(ds, "name")
                    if ref and ref not in seen_ds:
                        seen_ds.add(ref)
                        sheet.datasources.append(ref)
            seen_fields: dict[str, set[str]] = {}
            for dep in view.findall("datasource-dependencies"):
                ds_name = _a(dep, "datasource") or ""
                used = sheet.fields_used.setdefault(ds_name, [])
                seen = seen_fields.setdefault(ds_name, set())
                for col in dep.findall("column"):
                    nm = _a(col, "name")
                    if nm and nm not in seen:
                        seen.add(nm)
                        used.append(nm)
                    if col.find("calculation") is not None and col.get("param-domain-type") is None:
                        dep_calcs.append((ds_name, col))
                for inst in dep.findall("column-instance"):
                    nm = _a(inst, "column") or _a(inst, "name")
                    if nm and nm not in seen:
                        seen.add(nm)
                        used.append(nm)
            sheet.filters = [_filter(f, calcs_by_ds, None) for f in view.findall("filter")]
            for sl in view.findall("slices"):
                sheet.slices.extend(_s(c.text.strip()) for c in sl.findall("column") if c.text.strip())
        seen_marks: set[str] = set()
        for panes in table.findall("panes"):
            for pane in panes.findall("pane"):
                mark = pane.find("mark")
                p = PaneInfo(id=_a(pane, "id"), mark=_a(mark, "class") if mark is not None else None)
                for enc_group in pane.findall("encodings"):
                    p.encodings.extend(EncodingInfo(channel=_s(e.tag) or "", column=_a(e, "column")) for e in enc_group.children)
                sheet.panes.append(p)
                if p.mark and p.mark not in seen_marks:
                    seen_marks.add(p.mark)
                    sheet.marks.append(p.mark)
        rows, cols = table.find("rows"), table.find("cols")
        sheet.rows = _s(rows.text.strip()) if rows is not None and rows.text.strip() else None
        sheet.cols = _s(cols.text.strip()) if cols is not None and cols.text.strip() else None
    sheet.unread_elements = sorted(unread)
    return sheet


# -- dashboards, stories, actions ---------------------------------------------------------------------

_DASH_READ = frozenset({"zones", "size", "devicelayouts", "simple-id"})

# type-v2 values the reader interprets (a worksheet, a card tied to one, a container, a text box, an image, a
# web page, a blank, a title, a story navigator). XSD ZoneType-ST adds visual, currpage, dashboard-object, paramctrl,
# flipboard-nav, add-in and invalid, which are kept as zones but not understood: they are named in unread_elements.
_ZONE_TYPES_READ = frozenset(
    {"layout-basic", "layout-flow", "text", "bitmap", "web", "empty", "title", "flipboard"} | SHEET_BOUND_ZONE_TYPES
)


def _text_of(zone: Node) -> str | None:
    """The zone's OWN runs (its direct ``formatted-text`` children), never its descendants': a container does not
    contain the text of the text box inside it."""
    runs = [r.text for ft in zone.findall("formatted-text") for r in ft.findall("run")]
    joined = "".join(runs)
    return _s(joined, MAX_TEXT_CHARS) if joined else None


def _read_zones(zones_node: Node, layout: str) -> list[ZoneInfo]:
    out: list[ZoneInfo] = []
    stack: list[tuple[Node, str | None, int]] = [(z, None, 0) for z in reversed(zones_node.findall("zone"))]
    while stack:
        zone, parent, depth = stack.pop()
        zid = _a(zone, "id")
        out.append(
            ZoneInfo(
                id=zid, parent_id=parent, depth=depth, type_v2=_a(zone, "type-v2"), name=_a(zone, "name"),
                param=_a(zone, "param"), x=_a(zone, "x"), y=_a(zone, "y"), w=_a(zone, "w"), h=_a(zone, "h"),
                hidden=bool(_flag(zone.get("hidden"))), text=_text_of(zone), layout=layout,
            )
        )
        stack.extend((z, zid, depth + 1) for z in reversed(zone.findall("zone")))
    return out


def _read_action(node: Node, scope: str) -> ActionInfo:
    info = ActionInfo(scope=scope, name=_a(node, "name"), caption=_a(node, "caption"), enabled=_flag(node.get("enabled")))
    act, src, cmd, link = node.find("activation"), node.find("source"), node.find("command"), node.find("link")
    info.activation = _a(act, "type") if act is not None else None
    if src is not None:
        info.source_type = _a(src, "type")
        info.source_datasource = _a(src, "datasource")
        info.source_worksheet = _a(src, "worksheet")
        info.source_dashboard = _a(src, "dashboard")
        info.excluded_sheets = [n for e in src.findall("exclude-sheet") if (n := _a(e, "name"))]
    if cmd is not None:
        info.command = _a(cmd, "command")
        info.params = {_s(p.get("name")) or "": _a(p, "value") for p in cmd.findall("param")}
    info.link = _s((link.get("expression") if link is not None else None) or node.get("expression"))
    info.unread_elements = _unread(node, frozenset({"activation", "source", "command", "link"}))
    return info


def _read_dashboard(node: Node, hidden_names: set[str | None]) -> DashboardInfo:
    d = DashboardInfo(name=_a(node, "name"), hidden=_a(node, "name") in hidden_names, unread_elements=_unread(node, _DASH_READ))
    size = node.find("size")
    if size is not None:
        d.size = {_s(k) or "": _s(v) or "" for k, v in size.attrib.items()}
    for zones in node.findall("zones"):
        d.zones.extend(_read_zones(zones, "main"))
    for layouts in node.findall("devicelayouts"):
        for layout in layouts.findall("devicelayout"):
            label = _a(layout, "name") or "device"
            d.device_layouts.append(label)
            for zones in layout.findall("zones"):
                d.zones.extend(_read_zones(zones, label))
    other = sorted({f"zone type-v2={z.type_v2}" for z in d.zones if z.type_v2 and z.type_v2 not in _ZONE_TYPES_READ})
    d.unread_elements = sorted(set(d.unread_elements) | set(other))
    return d


def _read_story(node: Node, hidden_names: set[str | None]) -> StoryInfo:
    story = StoryInfo(name=_a(node, "name"), hidden=_a(node, "name") in hidden_names, unread_elements=_unread(node, _DASH_READ))
    for zones in node.findall("zones"):
        story.zones.extend(_read_zones(zones, "main"))
    for pt in node.iter("story-point"):
        story.points.append(
            StoryPointInfo(id=_a(pt, "id"), caption=_a(pt, "caption"), captured_sheet=_a(pt, "captured-sheet"), current_sheet=_a(pt, "current-sheet"))
        )
    return story


# -- assembling ---------------------------------------------------------------------------------------


def _is_sheet_zone(z: ZoneInfo) -> bool:
    return bool(z.name) and z.type_v2 is None


def _account_for_sheets(summary: FileSummary, issues: _Issues) -> None:
    """Every sheet on every dashboard is accounted for: found, or an issue. And the reverse link."""
    known = {s.name for s in summary.sheets if s.name}
    dash_names = {d.name for d in summary.dashboards if d.name}
    by_name = {s.name: s for s in summary.sheets if s.name}
    for dash in summary.dashboards:
        seen_sheets: set[str] = set()
        seen_missing: set[str] = set()
        for zone in dash.zones:
            sheet_zone = _is_sheet_zone(zone)
            if not zone.name and zone.type_v2 is None:
                issues.add("unnamed_zone", "a zone has neither a name nor a type", f"dashboard {_q(dash.name)} zone {_q(zone.id)}")
                continue
            if not (sheet_zone or (zone.type_v2 in SHEET_BOUND_ZONE_TYPES and zone.name)):
                continue
            where = f"dashboard {_q(dash.name)} zone {_q(zone.id)}" + ("" if zone.layout == "main" else f" ({_q(zone.layout)} layout)")
            if zone.name in known:
                if sheet_zone and zone.name not in seen_sheets:
                    seen_sheets.add(zone.name)
                    dash.sheets.append(zone.name)
                    by_name[zone.name].on_dashboards.append(dash.name or "")
                continue
            if sheet_zone:
                if zone.name not in seen_missing:
                    seen_missing.add(zone.name)
                    dash.missing_sheets.append(zone.name)
                issues.add("dashboard_sheet_missing", f"a zone shows worksheet {_q(zone.name)}, which the workbook does not contain", where)
            else:
                issues.add("dashboard_zone_name_unresolved", f"a {_q(zone.type_v2)} card names {_q(zone.name)}, which is not a worksheet in the workbook", where, "info")
    sheet_or_dash = known | dash_names
    for story in summary.stories:
        for pt in story.points:
            if pt.captured_sheet and pt.captured_sheet not in sheet_or_dash:
                issues.add(
                    "story_sheet_missing",
                    f"story point {_q(pt.id)} captures {_q(pt.captured_sheet)}, which is neither a worksheet nor a dashboard",
                    f"story {_q(story.name)}",
                )
        for zone in story.zones:
            if _is_sheet_zone(zone) and zone.name not in sheet_or_dash:
                issues.add("story_sheet_missing", f"a story zone shows {_q(zone.name)}, which is not in the workbook", f"story {_q(story.name)} zone {_q(zone.id)}")
    actions_of: dict[str, list[str]] = {}
    dash_or_sheet = dash_names | known  # once: a union built per action is quadratic
    for action in summary.actions:
        for field_name, value, pool in (
            ("source worksheet", action.source_worksheet, known),
            ("source dashboard", action.source_dashboard, dash_or_sheet),
        ):
            if value and value not in pool:
                issues.add("action_target_missing", f"action {_q(action.name)} has {field_name} {_q(value)}, which is not in the workbook", f"action {_q(action.name)}")
        for ex in action.excluded_sheets:
            if ex not in dash_or_sheet:
                issues.add("action_target_missing", f"action {_q(action.name)} excludes {_q(ex)}, which is not in the workbook", f"action {_q(action.name)}")
        if action.source_dashboard and action.name:
            actions_of.setdefault(action.source_dashboard, []).append(action.name)
    for dash in summary.dashboards:
        dash.actions = actions_of.get(dash.name or "", []) if dash.name else []
    for kind, items in (("worksheet", summary.sheets), ("dashboard", summary.dashboards)):
        seen: set[str | None] = set()
        for item in items:
            if item.name in seen:
                issues.add(f"duplicate_{kind}_name", f"two {kind}s are named {_q(item.name)}", f"{kind} {_q(item.name)}")
            seen.add(item.name)


def _account_for_datasources(summary: FileSummary, dep_calcs: list[tuple[str, Node]], issues: _Issues) -> None:
    ds_names = {d.name for d in summary.datasources if d.name} | ({PARAMETERS_DATASOURCE} if summary.parameters else set())
    by_name = {d.name: d for d in summary.datasources if d.name}
    index = {d.name: {c.column: c for c in d.calculations if c.column} for d in summary.datasources if d.name}
    for sheet in summary.sheets:
        for ref in sheet.datasources:
            if ref not in ds_names:
                issues.add("datasource_reference_missing", f"worksheet uses data source {_q(ref)}, which the workbook does not define", f"worksheet {_q(sheet.name)}", "info")
    # A calculation present in a sheet's dependencies but not on the data source: still a calculation in the XML.
    for ds_name, col in dep_calcs:
        ds = by_name.get(ds_name)
        key = _a(col, "name")
        calc = col.find("calculation")
        assert calc is not None
        formula = calc.get("formula")
        existing = index.get(ds_name, {}).get(key) if key else None
        if existing is None:
            item = CalculationInfo(
                datasource=ds_name or None, column=key, caption=_a(col, "caption"), formula=formula, class_=_a(calc, "class"),
                datatype=_a(col, "datatype"), role=_a(col, "role"), type=_a(col, "type"), origin="worksheet-dependency",
                user_functions=user_functions_in(formula), grouping=_grouping(calc),
            )
            if ds is None:  # a sheet depends on a data source the workbook does not define
                ds = by_name[ds_name] = DataSourceInfo(name=ds_name or None)
                summary.datasources.append(ds)
            ds.calculations.append(item)
            if key:
                index.setdefault(ds_name, {})[key] = item
            issues.add("calculation_only_on_worksheet", f"calculation {_q(key)} appears in a worksheet's dependencies and not on its data source", f"data source {_q(ds_name)}", "info")
        elif existing.formula != formula:
            issues.add("calculation_formula_differs", f"calculation {_q(key)} has a different formula on a worksheet than on its data source; the data source's is kept", f"data source {_q(ds_name)}")
    for ds in summary.datasources:
        for calc in ds.calculations:
            for fn in calc.user_functions:
                summary.user_function_uses.append(UserFunctionUse(ds.name, calc.column, calc.caption, fn.function, fn.argument))


def read_summary(data: bytes, limits: Limits = DEFAULT_LIMITS) -> FileSummary:
    """The summary of a Tableau file's bytes. Raises a ``TableauFileError`` for input it will not read;
    anything it can read but not make sense of becomes an entry in ``issues`` (at most ``ISSUES_PER_CODE`` of each
    kind, then one entry that counts the rest)."""
    xml, member_ext = unpack(data, limits)
    root = parse_xml(xml, limits)
    if root.tag not in ("workbook", "datasource"):
        raise NotATableauFileError("the root element is neither <workbook> nor <datasource>")
    packaged = member_ext is not None
    kind = "workbook" if root.tag == "workbook" else "datasource"
    summary = FileSummary(
        file_format=("twbx" if kind == "workbook" else "tdsx") if packaged else ("twb" if kind == "workbook" else "tds"),
        kind=kind,
        version=_a(root, "version"),
        original_version=_a(root, "original-version"),
        source_build=_a(root, "source-build"),
        source_platform=_a(root, "source-platform"),
    )
    issues = _Issues(summary.issues)
    dep_calcs: list[tuple[str, Node]] = []
    if kind == "datasource":
        ds, params = _read_datasource(root, summary.actions, issues)
        summary.datasources.append(ds)
        summary.parameters.extend(params)
    else:
        _read_workbook(root, summary, dep_calcs, issues)
    _account_for_sheets(summary, issues)
    _account_for_datasources(summary, dep_calcs, issues)
    issues.finish()
    log.debug(
        "read %s: %d data sources, %d calculations, %d sheets, %d dashboards, %d stories, %d issues",
        summary.file_format, len(summary.datasources), len(summary.calculations), len(summary.sheets),
        len(summary.dashboards), len(summary.stories), len(summary.issues),
    )
    return summary


_WB_READ = frozenset({"datasources", "worksheets", "dashboards", "windows", "actions"})


def _read_workbook(root: Node, summary: FileSummary, dep_calcs: list[tuple[str, Node]], issues: _Issues) -> None:
    summary.unread_elements = _unread(root, _WB_READ)
    hidden: set[str | None] = set()
    for windows in root.findall("windows"):
        for w in windows.findall("window"):
            if _flag(w.get("hidden")) and w.get("name"):
                hidden.add(_a(w, "name"))
    for group in root.findall("datasources"):
        for i, ds in enumerate(group.findall("datasource")):
            info, params = _read_datasource(ds, summary.actions, issues)
            if not info.name:
                issues.add("unnamed_datasource", "a data source has no name", f"data source #{i + 1}")
            is_pseudo = info.name == PARAMETERS_DATASOURCE and not info.connections
            if is_pseudo:
                summary.parameters.extend(params)
                if info.calculations or info.filters:
                    summary.datasources.append(info)  # a Parameters source that also holds more: keep what it holds
                continue
            summary.datasources.append(info)
            summary.parameters.extend(params)
    calcs_by_ds = {d.name: {c.column: c for c in d.calculations if c.column} for d in summary.datasources}
    for group in root.findall("worksheets"):
        for i, ws in enumerate(group.findall("worksheet")):
            sheet = _read_sheet(ws, calcs_by_ds, hidden, dep_calcs)
            if not sheet.name:
                issues.add("unnamed_worksheet", "a worksheet has no name", f"worksheet #{i + 1}")
            summary.sheets.append(sheet)
    for group in root.findall("dashboards"):
        for i, db in enumerate(group.findall("dashboard")):
            story = db.get("type") == "storyboard"
            read = _read_story(db, hidden) if story else _read_dashboard(db, hidden)
            if not read.name:
                issues.add("unnamed_dashboard", f"a {'story' if story else 'dashboard'} has no name", f"dashboard #{i + 1}")
            (summary.stories if story else summary.dashboards).append(read)
    for group in root.findall("actions"):
        for i, action in enumerate(group.findall("action")):
            read = _read_action(action, "workbook")
            if not read.name:
                issues.add("unnamed_action", "an action has no name", f"action #{i + 1}")
            summary.actions.append(read)
    if not (summary.datasources or summary.parameters or summary.sheets or summary.dashboards or summary.stories):
        issues.add("empty_workbook", "the workbook holds no data sources, worksheets or dashboards")

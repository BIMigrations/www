"""Pulling a Domo dataset out as CSV.

The endpoint is `GET /api/query/v1/execute/export/{dataSourceId}`, which
is what Domo's own "Export data" dialog links to. **Verified live against
the source Domo instance on 2026-09-25**: it streams `text/csv`, honours
`includeHeader`, and returned exactly the row count the scan recorded for
a 9,975-row dataflow output (1.7MB in 5.7s) and for three manual uploads.

Worth recording how it was found, because the next platform will need the
same treatment: guessing REST-ish paths under `/api/data/v1/datasources/`
produced nothing but "No static resource" 404s. Opening the dataset in
Domo and reading the export dialog's own link gave the answer in one
step. Domo's private API is undocumented -- read it off the product
rather than reasoning about what it ought to be.

`disableFormulaInterpretation=true` matches what the UI sends. It stops
Domo evaluating a leading `=` in a cell as a formula, which is a CSV
injection guard, and it is what we want: the landed table should hold
what the source holds.

A second route, `POST /api/query/v1/execute/{id}` with SQL, is kept as a
fallback. It returns JSON and pages, so it is slower, but it answers for
datasets the export endpoint refuses -- and note the two disagree: an
archived datasource returned 410 from the query API while exporting
fine, so neither is a superset of the other.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

import requests

from .session import DomoSession, DomoSessionExpired

# Domo's query API caps a single response; paging keeps well under it.
QUERY_PAGE_ROWS = 25_000
# A big export is a single streamed response and can take minutes.
REQUEST_TIMEOUT = 900


class DomoExportError(Exception):
    pass


@dataclass
class ExportResult:
    dataset_id: str
    path: Path
    rows: int
    bytes: int
    strategy: str
    attempts: list[str] = field(default_factory=list)


@dataclass
class Strategy:
    name: str
    run: Callable[["DomoExporter", str, Path], int]


class DomoExporter:
    def __init__(self, session: DomoSession, timeout: int = REQUEST_TIMEOUT):
        self.session = session
        self.http = session.requests_session()
        self.timeout = timeout

    # ---- the routes -----------------------------------------------------

    def _export_endpoint(self, dataset_id: str, path: Path) -> int:
        """What the product's own export dialog calls."""
        url = f"{self.session.base_url}/api/query/v1/execute/export/{dataset_id}"
        response = self.http.get(
            url,
            params={
                "accept": "text/csv",
                "disableFormulaInterpretation": "true",
                "includeHeader": "true",
            },
            headers={"accept": "text/csv"},
            stream=True,
            timeout=self.timeout,
        )
        self._raise_for_status(response)
        return self._stream_to_file(response, path)

    def _query_api(self, dataset_id: str, path: Path) -> int:
        """Page through with the query API the cards themselves use."""
        url = f"{self.session.base_url}/api/query/v1/execute/{dataset_id}"
        offset = 0
        written = 0
        header: list[str] | None = None

        with path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.writer(handle)
            while True:
                response = self.http.post(
                    url,
                    json={"sql": f"SELECT * FROM table LIMIT {QUERY_PAGE_ROWS} OFFSET {offset}"},
                    headers={"accept": "application/json"},
                    timeout=self.timeout,
                )
                self._raise_for_status(response)
                payload = response.json()
                rows = payload.get("rows") or []
                if header is None:
                    header = [str(c) for c in (payload.get("columns") or [])]
                    writer.writerow(header)
                for row in rows:
                    writer.writerow(["" if value is None else value for value in row])
                written += len(rows)
                if len(rows) < QUERY_PAGE_ROWS:
                    break
                offset += QUERY_PAGE_ROWS
        return written

    def strategies(self) -> list[Strategy]:
        return [
            Strategy("export_endpoint", DomoExporter._export_endpoint),
            Strategy("query_api", DomoExporter._query_api),
        ]

    # ---- the one to call ------------------------------------------------

    def export_csv(self, dataset_id: str, path: Path) -> ExportResult:
        path.parent.mkdir(parents=True, exist_ok=True)
        attempts: list[str] = []

        for strategy in self.strategies():
            try:
                rows = strategy.run(self, dataset_id, path)
            except DomoSessionExpired:
                raise  # re-authenticating is the operator's problem, not the next route's
            except Exception as exc:  # noqa: BLE001 -- any failure just means try the next route
                attempts.append(f"{strategy.name}: {type(exc).__name__}: {exc}")
                continue

            if rows <= 0 and not self._looks_like_csv(path):
                attempts.append(f"{strategy.name}: returned nothing usable")
                continue
            return ExportResult(
                dataset_id=dataset_id, path=path, rows=rows,
                bytes=path.stat().st_size, strategy=strategy.name, attempts=attempts,
            )

        raise DomoExportError(
            f"Could not export dataset {dataset_id}. Every route failed:\n  "
            + "\n  ".join(attempts)
        )

    # ---- helpers --------------------------------------------------------

    def _raise_for_status(self, response: requests.Response) -> None:
        if response.status_code == 401:
            raise DomoSessionExpired("Domo rejected the session; sign in again.")
        response.raise_for_status()

    def _stream_to_file(self, response: requests.Response, path: Path) -> int:
        """Stream to disk rather than into memory: a landed dataset can be
        far larger than the machine doing the landing."""
        content_type = (response.headers.get("content-type") or "").lower()
        if "csv" not in content_type:
            # A JSON answer here is an error payload, whatever the status said.
            raise DomoExportError(f"Expected CSV, got {content_type or 'nothing'}")
        with path.open("wb") as handle:
            for chunk in response.iter_content(chunk_size=1 << 20):
                if chunk:
                    handle.write(chunk)
        return self._count_csv_rows(path)

    @staticmethod
    def _looks_like_csv(path: Path) -> bool:
        return path.exists() and path.stat().st_size > 0

    @staticmethod
    def _count_csv_rows(path: Path) -> int:
        """Count data rows, respecting quoted newlines.

        A naive line count is wrong on this data: Domo exports free-text
        columns (exam descriptions, notes) that contain newlines inside
        quotes, and the landed row count is what we check the load against.
        """
        if not path.exists():
            return 0
        with path.open("r", newline="", encoding="utf-8", errors="replace") as handle:
            return max(sum(1 for _ in csv.reader(handle)) - 1, 0)  # minus the header

"""Convert every dataflow of a customer, independent of any one dashboard.

Dashboards used to discover converter gaps one at a time. This pipeline takes
the union of the closures of every dashboard in a customer manifest, lands the
source data those flows read and converts all of their Magic ETL to warehouse
SQL in one run, so the gaps show up together and are fixed by class.

It is the front half of the dashboard pipeline (same plan, landing and
conversion stages, fed a merged closure) and stops before any model or report.
"""

from __future__ import annotations

from bimcontrol.core.engine import Pipeline, ReviewItem, RunContext, Stage, StageResult
from bimcontrol.estate.closure import resolve_dashboard
from bimcontrol.pipelines.convert_etl import convert_dataflows
from bimcontrol.pipelines.data_plan import land_source_data, plan_data
from bimcontrol.pipelines.domo_to_powerbi import CLOSURE_FILE, closure_payload
from bimcontrol.pipelines.drift import dataflow_drift


def merge_closures(payloads: list[dict]) -> dict:
    """One closure over many dashboards: datasets, dataflows and beast modes by id."""
    merged: dict = {"cards": [], "datasets": [], "dataflows": [], "calculated_fields": [], "missing": []}
    index: dict[str, dict[str, dict]] = {"datasets": {}, "dataflows": {}, "calculated_fields": {}}
    seen_missing: set[tuple[str, str]] = set()
    for payload in payloads:
        merged["cards"].extend(payload["cards"])
        for key, seen in index.items():
            for item in payload[key]:
                have = seen.get(item["id"])
                if have is None:
                    seen[item["id"]] = dict(item)
                elif key == "datasets" and not have.get("produced_by") and item.get("produced_by"):
                    have["produced_by"] = item["produced_by"]
        for item in payload["missing"]:
            if (item["object_type"], item["id"]) not in seen_missing:
                seen_missing.add((item["object_type"], item["id"]))
                merged["missing"].append(item)
    for dataset in index["datasets"].values():
        dataset["is_root"] = not dataset.get("produced_by")
    for key, seen in index.items():
        merged[key] = list(seen.values())
    merged["summary"] = {
        "dashboards": len(payloads),
        "cards": len(merged["cards"]),
        "datasets": len(merged["datasets"]),
        "dataflows": len(merged["dataflows"]),
        "calculated_fields": len(merged["calculated_fields"]),
        "root_datasets": sum(1 for d in merged["datasets"] if d["is_root"]),
        "missing": len(merged["missing"]),
        "warnings": [],
    }
    return merged


def resolve_customer_closure(ctx: RunContext) -> StageResult:
    # Imported here: core.customer imports the runner, which imports the pipelines.
    from bimcontrol.core.customer import Manifest, select_dashboards

    manifest = Manifest.from_dict(ctx.options["manifest"])
    with ctx.estate() as reader:
        chosen = select_dashboards(reader, manifest)
        payloads = []
        for index, selected in enumerate(chosen, start=1):
            ctx.check_cancelled()
            payloads.append(closure_payload(reader, resolve_dashboard(reader, selected.id)))
            if index % 10 == 0:
                ctx.progress(f"{index}/{len(chosen)} dashboards resolved")
    merged = merge_closures(payloads)
    merged["dashboard"] = {"id": ctx.source_object_id, "name": manifest.name}
    ctx.write_json(CLOSURE_FILE, merged, kind="closure", label=f"{manifest.name}: dependency closure")
    summary = merged["summary"]
    ctx.progress(
        f"{summary['dashboards']} dashboards: {summary['datasets']} datasets "
        f"({summary['root_datasets']} sources), {summary['dataflows']} dataflows"
    )
    review_items = [
        ReviewItem(
            kind="missing_object",
            title=f"{item['object_type']} {item['id']} is referenced but not in the scan",
            source_type=item["object_type"], source_id=item["id"],
            detail={"reason": "deleted, or outside the scanning user's permissions"},
        )
        for item in merged["missing"]
    ]
    review_items += dataflow_drift(ctx, merged["dataflows"])
    return StageResult(summary=summary, review_items=review_items)


PIPELINE = Pipeline(
    name="domo_estate_sql",
    stages=[
        Stage("resolve_closure", "Resolve every dashboard's dependency closure", resolve_customer_closure),
        Stage("plan_data", "Decide where each dataset's data comes from", plan_data, version="2"),
        Stage("land_source_data", "Land manual uploads and feeds in the warehouse", land_source_data),
        Stage("convert_dataflows", "Convert Magic ETL to warehouse SQL", convert_dataflows),
    ],
)

"""Which datasets does one column of a dataset come from?

A dataset Domo built long before its input moved (parity's `stale_inputs`) is frozen: its rows are those of an older
build. Every card reading a dataset downstream of it is not "mostly off for no reason" -- but only the *columns* derived
from the frozen dataset are frozen (Profitability Trend-SW 'Patient Class': `Bad Debt Ins Code` is a LEFT JOIN to a Bad
Debt dataset built 840 days before its input, `Cases` is not). This follows one column through the converted dataflow SQL
the run already holds (`convert_dataflows/`), with sqlglot's column lineage, and returns the datasets it reads.

Evidence only, never a stop: what it cannot read (sqlglot not installed, SQL it cannot parse, a leaf it cannot place, time
used up) comes back as `UNKNOWN` among the feeders, so a caller asking "is this column read only from frozen datasets"
says no, and the card stays as it was.
"""

from __future__ import annotations

import json
import re
import time
from pathlib import Path
from typing import Any

UNKNOWN = "?"           # a feeder the lineage could not name: never "frozen"
CLOCK = "@clock"        # not a dataset: the column is computed from the date or time the flow runs (CURRENT_DATE, GETDATE())
_QUOTED = re.compile(r'"([^"]+)"')
POSITION_COLUMN = "_domo_row_"   # Domo's stored order: a landed table may carry it though no column list says so
BATCH_COLUMNS = ("_batch_id_", "_batch_last_run_")
BUDGET_SECONDS = 60.0   # lineage time per run: a run that spends it has no further evidence, as one without sqlglot
MAX_DEPTH = 6           # flows feeding flows; the customer's deepest chain is 4


def _feeds_value(clock: Any) -> bool:
    """Whether a clock call changes the value of the projection it sits in, not only which branch it takes: a clock inside a
    comparison or a CASE condition (`CASE WHEN CURRENT_DATE > DATE '2020-01-01' THEN id END`) decides, it does not flow into the value."""
    from sqlglot import exp  # noqa: PLC0415 -- optional dependency (`bimcontrol[export]`)

    node = clock
    while node.parent is not None and not isinstance(node.parent, exp.Select):
        parent = node.parent
        if isinstance(parent, exp.Predicate) or (isinstance(parent, exp.If) and parent.args.get("this") is node):
            return False
        node = parent
    return True


def _load(run_dir: Path, *parts: str) -> Any:
    try:
        return json.loads(run_dir.joinpath(*parts).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def _key(table: str, db: str = "") -> str:
    """A table as `schema.table`, lower case (the warehouse folds case), whichever way the statement spells it."""
    schema, _, name = table.rpartition(".")
    return f"{(db or schema).lower()}.{name.lower()}" if (db or schema) else name.lower()


class ColumnLineage:
    """The lineage of one run: `feeders(dataset_id, column)` is the set of dataset ids that column reads, transitively."""

    def __init__(self, run_dir: str | Path, stop_at: frozenset[str] | set[str] = frozenset()):
        """`stop_at`: datasets whose own feeders do not matter (Domo's copy is frozen there): a path ends at the first one."""
        self.run_dir = Path(run_dir)
        self._stop_at = frozenset(stop_at)
        conversion = _load(self.run_dir, "convert_dataflows", "conversion.json") or {}
        closure = _load(self.run_dir, "resolve_closure", "closure.json") or {}
        landings = _load(self.run_dir, "land_source_data", "landings.json") or {}
        landed = {_key(x["table_ref"]): x.get("dataset_id") for x in landings.get("landings") or [] if x.get("table_ref")}
        self._landed = set(landed)
        self._output: dict[str, dict[str, Any]] = {}                    # dataset id -> converted output
        flow_table: dict[str, str] = {}                                 # dataset id -> schema.table the flow built
        for flow in conversion.get("dataflows") or []:
            for out in flow.get("outputs") or []:
                if out.get("data_source_id") and out.get("artefact"):
                    self._output[out["data_source_id"]] = out
                    if out.get("materialised_as"):
                        flow_table[out["data_source_id"]] = _key(out["materialised_as"])
        # A table this run's flows built can differ from Domo's dataset; a landed copy is Domo's own rows and cannot.
        self._dataset_of = {table: ds for ds, table in flow_table.items()}
        self._flow_table = flow_table
        declared = {d.get("id"): [c["name"] for c in d.get("columns") or [] if c.get("name")] for d in closure.get("datasets") or []}
        self._columns: dict[str, list[str]] = {}                        # schema.table -> its columns
        for ds, table in flow_table.items():
            self._columns[table] = [c["name"] for c in self._output[ds].get("columns") or [] if c.get("name")]
        for table, ds in landed.items():
            self._columns.setdefault(table, declared.get(ds) or [])
        for ds, table in (conversion.get("resolutions") or {}).items():
            self._columns.setdefault(_key(table), declared.get(ds) or [])
        self._cache: dict[tuple[str, str], frozenset[str]] = {}
        self._schemas: dict[tuple[bool, bool], dict[str, Any]] = {}
        self._spent = 0.0
        self._busy_since: float | None = None
        self._prepared: dict[str, tuple[Any, Any, Any] | None] = {}

    def produced(self, dataset_id: str) -> bool:
        """Whether a converted dataflow of this run writes the dataset (a landed source does not have one)."""
        return dataset_id in self._output

    def reaches(self, dataset_id: str, targets: set[str]) -> bool:
        """Whether the dataset's flow, or a flow behind it, names a table one of `targets` built. Text only, no parsing: the
        cheap test that keeps the lineage (seconds per column on a flow of 400 columns) to the datasets that can matter."""
        wanted = {self._flow_table[t] for t in targets if t in self._flow_table}
        seen: set[str] = set()
        todo = [dataset_id]
        while todo:
            current = todo.pop()
            if current in seen:
                continue
            seen.add(current)
            sql = (self._sql(current) or "").lower()
            for table, source in self._dataset_of.items():
                if table.rpartition(".")[2] in sql:
                    if table in wanted:
                        return True
                    if self.produced(source):
                        todo.append(source)
        return False

    def _schema_for(self, with_position: bool = False, keep_batch: bool = False) -> dict[str, Any]:
        """The tables' columns as the statements see them. A landed table may also carry Domo's stored-order column, which
        an artefact does not list; a statement that orders by it needs it in the schema, and one that does not breaks
        on the duplicate a `t1.*, t2.*` then makes: `_prepare` tries both. A table read in place may carry the batch
        markers too (customer Payroll's `t2.* EXCLUDE(t2."_batch_id_", ...)` reads a table that has them): the last variant keeps them."""
        variant = (with_position, keep_batch)
        if variant not in self._schemas:
            schema: dict[str, dict[str, dict[str, str]]] = {}
            for table, columns in self._columns.items():
                if not columns:
                    continue
                if table not in self._landed and not keep_batch:       # a table read in place (a connector's) has the dataset's columns, minus its batch markers
                    columns = [c for c in columns if c.lower() not in BATCH_COLUMNS]
                extra = [POSITION_COLUMN] if with_position and table in self._landed else []
                db, _, name = table.rpartition(".")
                schema.setdefault(db or "public", {})[name] = {c: "text" for c in [*columns, *extra]}
            self._schemas[variant] = schema
        return self._schemas[variant]

    def _sql(self, dataset_id: str) -> str | None:
        name = (self._output.get(dataset_id) or {}).get("artefact") or ""
        if not name.endswith(".sql"):
            return None
        folder = self.run_dir / "convert_dataflows"
        for candidate in (name[: -len(".sql")] + ".full.sql", name):     # a staged flow's whole statement first
            try:
                return (folder / candidate).read_text(encoding="utf-8")
            except OSError:
                continue
        return None

    def feeders(self, dataset_id: str, column: str, depth: int = MAX_DEPTH) -> frozenset[str]:
        """The dataset ids `column` of `dataset_id` is derived from, through every converted dataflow on the way.

        Datasets built by this run's flows only (a landed copy is Domo's own rows). `UNKNOWN` is among them when a part of
        the column could not be traced. `exhausted` says the time ran out: answers after that are not answers."""
        key = (dataset_id, column.lower())
        if key in self._cache:
            return self._cache[key]
        if self.exhausted:
            return frozenset({UNKNOWN})
        top = depth == MAX_DEPTH
        if top:
            self._busy_since = time.monotonic()
        self._cache[key] = frozenset({UNKNOWN})     # a cycle is no evidence either
        try:
            self._cache[key] = frozenset(self._follow(dataset_id, column, depth))
        except Exception:  # noqa: BLE001 -- evidence that cannot be read is no evidence, whatever the reason
            self._cache[key] = frozenset({UNKNOWN})
        if top:
            self._spent += time.monotonic() - self._busy_since
            self._busy_since = None
        if self.exhausted:
            self._cache.pop(key, None)              # what a cut-off lookup returned is not its answer
            return frozenset({UNKNOWN})
        return self._cache[key]

    @property
    def exhausted(self) -> bool:
        """Whether the run's lineage time ran out (a result computed with it is not to be kept)."""
        return self._busy_for() > BUDGET_SECONDS

    def _busy_for(self) -> float:
        return self._spent + (time.monotonic() - self._busy_since if self._busy_since is not None else 0.0)

    def _prepare(self, dataset_id: str) -> tuple[Any, Any, Any] | None:
        """The statement of the dataset's flow, parsed and qualified once (the expensive part), with the scope lineage reads."""
        if dataset_id not in self._prepared:
            from sqlglot import parse_one  # noqa: PLC0415 -- optional dependency (`bimcontrol[export]`)
            from sqlglot.optimizer import qualify  # noqa: PLC0415
            from sqlglot.optimizer.scope import build_scope  # noqa: PLC0415
            from sqlglot.schema import ensure_schema  # noqa: PLC0415

            prepared = None
            sql = self._sql(dataset_id)
            for with_position, keep_batch in ((False, False), (True, False), (True, True)):     # a landed table may carry Domo's stored order, which the statement may order by
                if sql is None:
                    break
                try:
                    schema = ensure_schema(self._schema_for(with_position, keep_batch), dialect="redshift")
                    tree = qualify.qualify(parse_one(sql, dialect="redshift"), dialect="redshift", schema=schema,
                                           validate_qualify_columns=False, identify=False)
                    scope = build_scope(tree)
                    if scope is not None:
                        prepared = (tree, scope, schema)
                        break
                except Exception:  # noqa: BLE001, S112 -- this variant does not read the statement: try the next
                    continue
            self._prepared[dataset_id] = prepared
        return self._prepared[dataset_id]

    def _follow(self, dataset_id: str, column: str, depth: int) -> set[str]:
        from sqlglot import exp, lineage  # noqa: PLC0415

        clock_nodes = (exp.CurrentDate, exp.CurrentTimestamp, exp.CurrentTime, exp.CurrentDatetime, exp.Localtimestamp)

        prepared = self._prepare(dataset_id) if depth > 0 else None
        if prepared is None:
            return {UNKNOWN}
        tree, scope, schema = prepared
        node = None
        spellings = {m for m in _QUOTED.findall(self._sql(dataset_id) or "") if m.lower() == column.lower()}
        for name in dict.fromkeys((column, *sorted(spellings), column.lower())):     # the statement's spelling; sqlglot lower-cases
            try:
                node = lineage.lineage(name, tree, schema=schema, dialect="redshift", scope=scope, copy=False)
                break
            except lineage.SqlglotError:
                continue
        if node is None:
            return {UNKNOWN}
        found: set[str] = set()
        seen: set[int] = set()
        todo = [node]
        while todo:
            node = todo.pop()
            if id(node) in seen:
                continue
            seen.add(id(node))
            todo.extend(node.downstream)
            if node.expression is not None and any(_feeds_value(c) for c in node.expression.find_all(*clock_nodes)):
                found.add(CLOCK)
            if node.downstream:
                continue
            table = getattr(node.source, "name", "") if isinstance(node.source, exp.Table) else ""
            if not table:
                # a leaf that is no table: a constant (`CAST(1 AS BIGINT) AS cases`) reads nothing; anything else (an
                # unexpanded star, a column that did not resolve) was not traced
                projected = node.expression
                if projected is None or isinstance(projected, exp.Placeholder) or isinstance(node.source, exp.Placeholder) \
                        or projected.find(exp.Column, exp.Star) is not None:     # sqlglot's Placeholder: a column that did not resolve
                    found.add(UNKNOWN)
                continue
            key = _key(table, getattr(node.source, "db", "") or "")
            if "." not in key:                      # a statement that does not say the schema: the unique table of that name
                named = {t for t in (*self._dataset_of, *self._landed, *self._columns) if t.rpartition(".")[2] == key}
                key = next(iter(named)) if len(named) == 1 else key
            if key in self._landed or (key in self._columns and key not in self._dataset_of):
                continue                            # Domo's own rows (landed) or a table read in place: equal by construction
            source = self._dataset_of.get(key)
            if source is None:
                found.add(UNKNOWN)                  # a table this run does not know
                continue
            if source == dataset_id:
                found.add(UNKNOWN)                  # the flow reads its own earlier output (an append): that history is not traced
                continue
            found.add(source)
            leaf_column = node.name.rpartition(".")[2]
            if self.produced(source) and leaf_column and source not in self._stop_at:
                found |= self.feeders(source, leaf_column, depth - 1)
        return found

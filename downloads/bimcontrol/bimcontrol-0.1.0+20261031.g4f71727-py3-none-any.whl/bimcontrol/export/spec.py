"""The open specification format: its version, vocabularies and JSON Schemas.

This is a product surface (the website promises plain files that outlive any
BI platform), so the format is written down here, versioned, and validated
on export. Change it additively within a major version; a breaking change
bumps `SPEC_VERSION`'s major and the schemas ship with the new number.

Vocabulary is platform-neutral where the meaning is the same everywhere (a
column chart, a pivot, a filter with an operand) and keeps the source
platform's own name next to it (`source.chart_type`) so nothing is lost and
a reader can tell exactly what was translated.
"""

from __future__ import annotations

from typing import Any

SPEC_NAME = "bimspec"
SPEC_VERSION = "1.3"
SPEC_ID = f"{SPEC_NAME}/{SPEC_VERSION}"

# Domo chart type -> (neutral kind, variant). Anything not listed (or whose
# prefix is not recognised by `neutral_visual`) is kind "other" with the
# source chart type kept, never guessed.
_NEUTRAL_EXACT: dict[str, tuple[str, str | None]] = {
    "badge_vert_stackedbar": ("column", "stacked"),
    "badge_vert_multibar": ("column", "clustered"),
    "badge_vert_bar": ("column", "clustered"),
    "badge_vert_100pct": ("column", "stacked100"),
    "badge_vert_stackedbar100": ("column", "stacked100"),
    "badge_vert_percentbar": ("column", "stacked100"),
    "badge_vert_nestedbar": ("column", "nested"),
    "badge_vert_rtmultibar": ("column", "clustered"),
    "badge_vert_rtbar": ("column", "clustered"),
    "badge_vert_bullet": ("bullet", None),
    "badge_horiz_stackedbar": ("bar", "stacked"),
    "badge_horiz_multibar": ("bar", "clustered"),
    "badge_horiz_bar": ("bar", "clustered"),
    "badge_horiz_100pct": ("bar", "stacked100"),
    "badge_horiz_stackedbar100": ("bar", "stacked100"),
    "badge_horiz_nestedbar": ("bar", "nested"),
    "badge_line": ("line", None),
    "badge_trendline": ("line", None),
    "badge_two_trendline": ("line", "two_series"),
    "badge_curvedline": ("line", "curved"),
    "badge_symbolline": ("line", "symbols"),
    "badge_line_bar": ("combo", "line_column"),
    "badge_line_stackedbar": ("combo", "line_stacked_column"),
    "badge_line_clusterbar": ("combo", "line_clustered_column"),
    "badge_area": ("area", None),
    "badge_stackedarea": ("area", "stacked"),
    "badge_stackedtrend": ("area", "stacked"),
    "badge_pie": ("pie", None),
    "badge_donut": ("donut", None),
    "badge_nautilus_donut": ("donut", None),
    "badge_singlevalue": ("single_value", None),
    "badge_multi_value": ("single_value", "multi"),
    "badge_pop_multi_value": ("single_value", "period_over_period"),
    "badge_gauge": ("gauge", None),
    "badge_filledgauge": ("gauge", "filled"),
    "badge_basic_table": ("table", None),
    "badge_table": ("table", None),
    "badge_flex_table": ("table", "flex"),
    "badge_pivot_table": ("pivot", None),
    "badge_heat_table": ("pivot", "heat"),
    "badge_heatmap_table": ("pivot", "heat"),
    "badge_heatmap": ("heatmap", None),
    "badge_treemap": ("treemap", None),
    "badge_word_cloud": ("word_cloud", None),
    "badge_xyscatterplot": ("scatter", None),
    "badge_xyscatterplot_basic": ("scatter", None),
    "badge_bubble": ("scatter", "bubble"),
    "badge_map": ("map", None),
    "badge_world_map": ("map", "world"),
    "badge_map_us_county": ("map", "us_county"),
    "badge_map_latlong": ("map", "lat_long"),
    "badge_calendar": ("calendar", None),
    "badge_checkbox_selector": ("selector", "checkbox"),
    "badge_dropdown_selector": ("selector", "dropdown"),
    "badge_range_selector": ("selector", "range"),
    "badge_date_selector": ("selector", "date"),
    "badge_slicer": ("selector", "slicer"),
    "badge_textbox": ("text", None),
}

NON_DATA_KINDS = {"text"}


def neutral_visual(chart_type: str | None, card_type: str | None) -> tuple[str, str | None]:
    """`(kind, variant)` for a Domo card."""
    if chart_type in _NEUTRAL_EXACT:
        return _NEUTRAL_EXACT[chart_type]
    if (card_type or "").lower() in {"text", "document"}:
        return "text", None
    return "other", None


# ---- JSON Schemas -------------------------------------------------------

_STR = {"type": "string"}
_STR_OR_NULL = {"type": ["string", "null"]}
_INT = {"type": "integer"}
_INT_OR_NULL = {"type": ["integer", "null"]}
_STR_LIST = {"type": "array", "items": _STR}

_SOURCE = {
    "type": "object",
    "required": ["platform", "type", "id"],
    "properties": {"platform": _STR, "type": _STR, "id": _STR},
}
_PRINCIPAL = {
    "type": ["object", "null"],
    "required": ["id"],
    "properties": {"id": _STR, "name": _STR_OR_NULL},
}
_FILTER = {
    "type": "object",
    "required": ["column", "operand", "values"],
    "properties": {
        "column": _STR_OR_NULL, "label": _STR_OR_NULL, "operand": _STR_OR_NULL,
        "values": {"type": "array"}, "data_type": _STR_OR_NULL, "component": _STR_OR_NULL, "type": _STR_OR_NULL,
    },
}
_FIELD = {
    "type": "object",
    "required": ["role"],
    "properties": {
        "role": _STR, "column": _STR_OR_NULL, "metric": _STR_OR_NULL, "dataset": _STR_OR_NULL,
        "aggregation": _STR_OR_NULL, "alias": _STR_OR_NULL, "format": {"type": ["object", "null"]},
        "component": _STR_OR_NULL, "metric_ref": _STR_OR_NULL, "mapping": _STR_OR_NULL, "column_type": _STR_OR_NULL,
    },
}
_VISUAL = {
    "type": "object",
    "required": ["id", "title", "type", "source", "datasets", "fields", "filters"],
    "properties": {
        "id": _STR, "title": _STR_OR_NULL, "description": _STR_OR_NULL,
        "type": _STR, "variant": _STR_OR_NULL, "order": {"type": ["integer", "null"]},
        "source": {"type": "object", "required": ["platform", "type", "id"],
                   "properties": {"platform": _STR, "type": _STR, "id": _STR,
                                  "chart_type": _STR_OR_NULL, "card_type": _STR_OR_NULL}},
        "owner": _PRINCIPAL,
        "datasets": _STR_LIST,
        "fields": {"type": "array", "items": _FIELD},
        "filters": {"type": "array", "items": _FILTER},
        "sort": {"type": "array"}, "group_by": {"type": "array"},
        "drill": {"type": "array"}, "text": _STR_OR_NULL,
        "date_ranges": {"type": "array", "items": {"type": "object", "required": ["column", "type"], "properties": {
            "column": _STR_OR_NULL, "type": _STR_OR_NULL, "interval": _STR_OR_NULL, "offset": {}, "count": {},
            "begin": {}, "end": {}, "periods": {}}}},
        "row_limit": {"type": ["object", "null"], "required": ["limit"], "properties": {
            "limit": _INT, "order_by": {"type": "array"}, "group_by": {"type": "array"}}},
        "calculations": {"type": "array", "items": {"type": "object", "required": ["id", "expression"], "properties": {
            "id": _STR, "name": _STR_OR_NULL, "language": _STR, "expression": _STR_OR_NULL,
            "data_type": _STR_OR_NULL, "persisted_on_dataset": {"type": "boolean"}}}},
        "time_grains": {"type": "array", "items": {"type": "object", "required": ["date_column", "calendar_field"], "properties": {
            "date_column": _STR, "calendar_field": _STR_OR_NULL, "grain": _STR_OR_NULL, "component": _STR_OR_NULL}}},
        "style": {"type": ["object", "null"], "properties": {"legend": _STR_OR_NULL, "data_labels": {"type": "boolean"}, "subtotal_label": _STR_OR_NULL}},
    },
}
_GRID = {"type": "object", "required": ["x", "y", "w", "h"],
         "properties": {"x": {"type": "number"}, "y": {"type": "number"},
                        "w": {"type": "number"}, "h": {"type": "number"}}}

SCHEMAS: dict[str, dict[str, Any]] = {
    "manifest": {
        "type": "object",
        "required": ["spec", "kind", "generated_at", "source", "counts", "reconciliation"],
        "properties": {
            "spec": _STR, "kind": {"enum": ["manifest"]}, "generated_at": _STR,
            "source": {"type": "object", "required": ["platform"], "properties": {"platform": _STR}},
            "scope": {"type": "object"},
            "counts": {"type": "object"},
            "reconciliation": {"type": "object", "required": ["ok", "checks"],
                               "properties": {"ok": {"type": "boolean"}, "checks": {"type": "array"}}},
            "limits": _STR_LIST,
        },
    },
    "dashboard": {
        "type": "object",
        "required": ["spec", "kind", "id", "name", "source", "pages", "filters", "visuals"],
        "properties": {
            "spec": _STR, "kind": {"enum": ["dashboard"]}, "id": _STR, "name": _STR_OR_NULL,
            "source": _SOURCE, "owner": _PRINCIPAL,
            "parent_id": _STR_OR_NULL, "children": _STR_LIST, "apps": _STR_LIST,
            "pages": {"type": "array", "items": {
                "type": "object", "required": ["title", "items"],
                "properties": {"title": _STR, "items": {"type": "array", "items": {
                    "type": "object", "required": ["kind"],
                    "properties": {"kind": {"enum": ["visual", "text", "control", "button"]},
                                   "visual": _STR_OR_NULL, "text": _STR_OR_NULL, "grid": _GRID}}}}}},
            "filters": {"type": "array", "items": _FILTER},
            "visuals": {"type": "array", "items": _VISUAL},
        },
    },
    "visual": _VISUAL | {"required": ["spec", "kind", *_VISUAL["required"]],
                         "properties": _VISUAL["properties"] | {"spec": _STR, "kind": {"enum": ["visual"]}}},
    "metrics": {
        "type": "object",
        "required": ["spec", "kind", "dataset", "metrics"],
        "properties": {
            "spec": _STR, "kind": {"enum": ["metrics"]}, "dataset": {"type": ["object", "null"]},
            "metrics": {"type": "array", "items": {
                "type": "object", "required": ["id", "name", "language", "expression", "source"],
                "properties": {
                    "id": _STR, "name": _STR_OR_NULL, "language": _STR_OR_NULL,
                    "expression": _STR_OR_NULL, "data_type": _STR_OR_NULL,
                    "scope": {"enum": ["dataset", "card", "unattached"]},
                    "status": _STR_OR_NULL, "locked": {"type": ["boolean", "null"]},
                    "depends_on": {"type": "object"}, "used_by": {"type": "object"},
                    "also_datasets": _STR_LIST, "source": _SOURCE}}},
        },
    },
    "dataset": {
        "type": "object",
        "required": ["spec", "kind", "id", "name", "source", "columns", "access", "lineage"],
        "properties": {
            "spec": _STR, "kind": {"enum": ["dataset"]}, "id": _STR, "name": _STR_OR_NULL,
            "source": _SOURCE, "provider": _STR_OR_NULL,
            "rows": _INT_OR_NULL, "deleted": {"type": ["boolean", "null"]},
            "created_at": _STR_OR_NULL, "updated_at": _STR_OR_NULL, "owner": _PRINCIPAL,
            "columns": {"type": "array", "items": {
                "type": "object", "required": ["name", "type"],
                "properties": {"name": _STR, "type": _STR_OR_NULL, "visible": {"type": ["boolean", "null"]}}}},
            "access": {"type": "object", "required": ["policies"],
                       "properties": {"policies": {"type": "array"}}},
            "lineage": {"type": "object", "required": ["produced_by", "consumed_by", "used_by_visuals"],
                        "properties": {"produced_by": _STR_OR_NULL, "consumed_by": _STR_LIST,
                                       "used_by_visuals": _STR_LIST}},
        },
    },
    "transformation": {
        "type": "object",
        "required": ["spec", "kind", "id", "name", "source", "engine", "inputs", "outputs", "steps"],
        "properties": {
            "spec": _STR, "kind": {"enum": ["transformation"]}, "id": _STR, "name": _STR_OR_NULL,
            "source": _SOURCE, "engine": _STR_OR_NULL, "owner": _PRINCIPAL,
            "deleted": {"type": ["boolean", "null"]}, "modified_at": _STR_OR_NULL,
            "last_execution": {"type": ["object", "null"]},
            "inputs": {"type": "array", "items": {"type": "object", "required": ["dataset"],
                                                  "properties": {"dataset": _STR, "name": _STR_OR_NULL}}},
            "outputs": {"type": "array", "items": {"type": "object", "required": ["dataset"],
                                                   "properties": {"dataset": _STR, "name": _STR_OR_NULL}}},
            "sql": {"type": ["object", "null"]},
            "steps": {"type": "array", "items": {
                "type": "object", "required": ["id", "type", "depends_on", "config"],
                "properties": {"id": _STR, "type": _STR, "name": _STR_OR_NULL,
                               "depends_on": _STR_LIST, "config": {"type": "object"}}}},
        },
    },
    "principals": {
        "type": "object",
        "required": ["spec", "kind", "users", "groups"],
        "properties": {"spec": _STR, "kind": {"enum": ["principals"]},
                       "users": {"type": "array"}, "groups": {"type": "array"}},
    },
    "catalog": {
        "type": "object",
        "required": ["spec", "kind", "items"],
        "properties": {"spec": _STR, "kind": {"enum": ["apps", "alerts", "accounts"]},
                       "items": {"type": "array"}},
    },
    "app": {
        "type": "object",
        "required": ["spec", "kind", "id", "name", "source", "views", "navigation", "theme"],
        "properties": {
            "spec": _STR, "kind": {"enum": ["app"]}, "id": _STR, "name": _STR_OR_NULL, "source": _SOURCE,
            "app_type": _STR_OR_NULL, "owner": _PRINCIPAL, "landing_dashboard": _STR_OR_NULL,
            "views": {"type": "array", "items": {
                "type": "object", "required": ["id", "title"],
                "properties": {"id": _STR, "title": _STR_OR_NULL, "parent_id": _STR_OR_NULL,
                               "order": _INT_OR_NULL, "visible": {"type": ["boolean", "null"]},
                               "dashboard_exported": {"type": "boolean"}}}},
            "navigation": {"type": "array", "items": {
                "type": "object", "required": ["entity"],
                "properties": {"entity": _STR_OR_NULL, "entity_id": _STR_OR_NULL, "title": _STR_OR_NULL,
                               "description": _STR_OR_NULL, "order": _INT_OR_NULL, "visible": {"type": ["boolean", "null"]},
                               "icon": {"type": ["object", "null"]}, "icon_position": _STR_OR_NULL,
                               "interaction": {"type": ["object", "string", "null"]}, "style": {"type": ["object", "string", "null"]}}}},
            "theme": {"type": ["object", "null"]},
        },
    },
    "extract": {
        "type": "object",
        "required": ["spec", "kind", "id", "name", "source", "connector", "airbyte", "datasets"],
        "properties": {
            "spec": _STR, "kind": {"enum": ["extract"]}, "id": _STR, "name": _STR_OR_NULL, "source": {"type": "object"},
            "connector": _STR, "account_id": _STR_OR_NULL,
            "airbyte": {
                "type": "object", "required": ["source_connector", "connection_specification", "catalog", "configured_catalog"],
                "properties": {
                    "source_connector": _STR, "docker_repository": _STR,
                    "connection_specification": {"type": "object", "required": ["template", "values_in_scan"],
                                                 "properties": {"template": {"type": "object"},
                                                                "values_in_scan": {"type": "boolean"},
                                                                "validated_against_connector_spec": {"type": "boolean"}}},
                    # Airbyte Protocol: AirbyteCatalog / ConfiguredAirbyteCatalog.
                    "catalog": {"type": "object", "required": ["streams"], "properties": {"streams": {"type": "array", "items": {
                        "type": "object", "required": ["name", "json_schema", "supported_sync_modes"],
                        "properties": {"name": _STR, "json_schema": {"type": "object"},
                                       "supported_sync_modes": {"type": "array", "items": {"enum": ["full_refresh", "incremental"]}}}}}}},
                    "configured_catalog": {"type": "object", "required": ["streams"], "properties": {"streams": {"type": "array", "items": {
                        "type": "object", "required": ["stream", "sync_mode", "destination_sync_mode"],
                        "properties": {"stream": {"type": "object"}, "sync_mode": {"enum": ["full_refresh", "incremental"]},
                                       "destination_sync_mode": {"enum": ["append", "overwrite", "append_dedup"]}}}}}},
                },
            },
            "datasets": {"type": "array", "items": {"type": "object", "required": ["id", "stream"],
                                                    "properties": {"id": _STR, "name": _STR_OR_NULL, "stream": _STR}}},
            "notes": _STR_OR_NULL,
        },
    },
    "extract_index": {
        "type": "object",
        "required": ["spec", "kind", "datasets", "summary"],
        "properties": {
            "spec": _STR, "kind": {"enum": ["extract_index"]}, "summary": {"type": "object"},
            "datasets": {"type": "array", "items": {
                "type": "object", "required": ["dataset", "category", "unit", "reason"],
                "properties": {"dataset": _STR, "name": _STR_OR_NULL, "provider": _STR_OR_NULL, "account": _STR_OR_NULL,
                               "category": {"enum": ["extractable", "manual_upload", "manual_entry", "derived", "platform_internal",
                                                     "pushed", "no_airbyte_source", "unclassified", "consumer_model"]},
                               "airbyte_source": _STR_OR_NULL, "unit": _STR_OR_NULL, "reason": _STR_OR_NULL}}},
        },
    },
    "lineage": {
        "type": "object",
        "required": ["spec", "kind", "nodes", "edges"],
        "properties": {
            "spec": _STR, "kind": {"enum": ["lineage"]},
            "nodes": {"type": "array", "items": {"type": "object", "required": ["id", "type"],
                                                 "properties": {"id": _STR, "type": _STR, "name": _STR_OR_NULL}}},
            "edges": {"type": "array", "items": {"type": "object", "required": ["from", "to", "type"],
                                                 "properties": {"from": _STR, "to": _STR, "type": _STR}}},
        },
    },
}

# One field-level lineage edge per line in lineage/fields.jsonl.
FIELD_EDGE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "required": ["from", "to", "type"],
    "properties": {"from": _STR, "to": _STR, "type": {"enum": ["column_in_metric", "column_in_visual",
                                                                "metric_in_metric", "metric_in_visual"]}},
}


# ---- a small validator --------------------------------------------------
# Just the JSON Schema keywords the schemas above use. Kept in-house so the
# exporter can check its own output without adding a dependency.

_TYPES = {
    "object": dict, "array": list, "string": str, "boolean": bool, "null": type(None),
}


def _is_type(value: Any, name: str) -> bool:
    if name == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if name == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    return isinstance(value, _TYPES[name])


def validate(value: Any, schema: dict[str, Any], path: str = "$") -> list[str]:
    """Return the problems found (empty when `value` conforms)."""
    problems: list[str] = []
    wanted = schema.get("type")
    if wanted is not None:
        names = wanted if isinstance(wanted, list) else [wanted]
        if not any(_is_type(value, n) for n in names):
            return [f"{path}: expected {'/'.join(names)}, got {type(value).__name__}"]
    if "enum" in schema and value not in schema["enum"]:
        problems.append(f"{path}: {value!r} is not one of {schema['enum']}")
    if isinstance(value, dict):
        for key in schema.get("required", []):
            if key not in value:
                problems.append(f"{path}: missing required '{key}'")
        for key, sub in (schema.get("properties") or {}).items():
            if key in value:
                problems += validate(value[key], sub, f"{path}.{key}")
    if isinstance(value, list) and "items" in schema:
        for i, item in enumerate(value):
            problems += validate(item, schema["items"], f"{path}[{i}]")
    return problems

"""The BimDash connection: whether this machine is paired, pairing it with a code, and forgetting the pairing.

The answer is always `bimdash.status`: names, dates and the BimDash address, never the device token (which stays in the
private file beside the database). Pairing runs in the request, one short call to BimDash."""

from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from estate_scanner import bimdash

router = APIRouter()


def _directory(request: Request) -> Path:
    return Path(request.app.state.db_path).parent


class ConnectRequest(BaseModel):
    code: str
    device_name: str | None = None


@router.get("")
def get_status(request: Request):
    return bimdash.status(_directory(request))


@router.post("/connect")
def connect(body: ConnectRequest, request: Request):
    try:
        return bimdash.connect(_directory(request), body.code, body.device_name)
    except bimdash.BimdashError as exc:
        # 400: the code or the request; the wording says which of them to fix. Nothing in it is a code or a token.
        raise HTTPException(400, str(exc)) from None


@router.delete("")
def disconnect(request: Request):
    try:
        return bimdash.disconnect(_directory(request))
    except bimdash.BimdashError as exc:
        raise HTTPException(500, str(exc)) from None

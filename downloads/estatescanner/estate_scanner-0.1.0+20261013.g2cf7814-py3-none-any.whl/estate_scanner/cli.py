from __future__ import annotations

import argparse
import sys

from . import adapters  # noqa: F401 -- import triggers every platform's registration
from . import graph
from .core import registry
from .core.orchestrator import run_full_scan
from .storage import db


def _get_client(conn, platform_key: str, instance: str, cookie_file: str | None):
    descriptor = registry.get_platform(platform_key)
    authenticator = descriptor.authenticator_cls()

    if cookie_file:
        session = authenticator.load_cookie_file(instance, cookie_file)
        db.persist_session(conn, session)
        return descriptor.client_cls(session)

    persisted = db.load_persisted_credentials(conn, platform_key, instance)
    if persisted is not None:
        session = authenticator.restore_session(instance, persisted)
        client = descriptor.client_cls(session)
        if client.verify_session():
            return client
        db.drop_persisted_session(conn, platform_key, instance)

    session = authenticator.login_interactive(instance)
    db.persist_session(conn, session)
    return descriptor.client_cls(session)


def cmd_platforms(args: argparse.Namespace) -> None:
    for descriptor in registry.all_platforms():
        print(f"{descriptor.key:<10} {descriptor.display_name:<15} {descriptor.status:<12} auth={descriptor.auth_mode}")


def cmd_login(args: argparse.Namespace) -> None:
    conn = db.connect(args.db_path or db.DEFAULT_DB_PATH)
    client = _get_client(conn, args.platform, args.instance, args.cookie_file)
    if not client.verify_session():
        print(f"Signed in to {args.platform}/{args.instance} but session verification failed.")
        sys.exit(1)
    print(f"Signed in to {args.platform}/{args.instance} and verified the session.")


def cmd_scan(args: argparse.Namespace) -> None:
    conn = db.connect(args.db_path or db.DEFAULT_DB_PATH)
    client = _get_client(conn, args.platform, args.instance, args.cookie_file)
    if args.skip_group_membership and hasattr(client, "fetch_group_memberships"):
        client.fetch_group_memberships = False

    def on_progress(event):
        total = f"of {event.total} " if event.total is not None else ""
        print(f"  {event.phase}: {event.completed} {total}· {event.elapsed_s:.1f}s elapsed", flush=True)

    scan_id = run_full_scan(conn, client, args.platform, args.instance, on_progress=on_progress)
    print(f"Scan {scan_id} complete. Database: {args.db_path or db.DEFAULT_DB_PATH}")


def cmd_graph_report(args: argparse.Namespace) -> None:
    conn = db.connect(args.db_path or db.DEFAULT_DB_PATH)
    g = graph.build_graph(conn, platform=args.platform)
    print(f"{g.number_of_nodes()} nodes, {g.number_of_edges()} edges")
    print()
    print("Most connected nodes:")
    for key, attrs, degree in graph.most_connected(g, top_n=args.top):
        print(f"  {degree:>4}  {attrs['platform']}/{attrs['type']:<17} {attrs['name'] or attrs['id']}")


def cmd_export(args: argparse.Namespace) -> None:
    from .export import export_scan

    try:
        path = export_scan(args.db_path or db.DEFAULT_DB_PATH, args.dest)
    except (FileNotFoundError, ValueError) as exc:
        print(exc)
        sys.exit(1)
    print(f"Saved {path} (no sign-in session included). Attach it to an email to BI Migrations.")


def cmd_ui(args: argparse.Namespace) -> None:
    try:
        from . import desktop
    except ImportError:
        print("The desktop UI needs the 'ui' extra: pip install 'estate-scanner[ui]'")
        sys.exit(1)
    if args.check:
        sys.exit(desktop.check(db_path=args.db_path))
    desktop.main(db_path=args.db_path, browser=args.browser)


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="estate-scanner")
    parser.add_argument("--db-path", default=None, help="SQLite database path (default: ~/.estate-scanner/estate.db)")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("platforms", help="List known BI platforms and their status").set_defaults(func=cmd_platforms)

    login = sub.add_parser("login", help="Sign in to a BI platform and persist the session")
    login.add_argument("instance", help="Platform instance/tenant name, e.g. 6intelligence")
    login.add_argument("--platform", default="domo", help="Platform key (default: domo)")
    login.add_argument("--cookie-file", default=None, help="Domo only: JSON cookie file instead of interactive login")
    login.set_defaults(func=cmd_login)

    scan_cmd = sub.add_parser("scan", help="Run a full estate scan")
    scan_cmd.add_argument("instance", help="Platform instance/tenant name, e.g. 6intelligence")
    scan_cmd.add_argument("--platform", default="domo", help="Platform key (default: domo)")
    scan_cmd.add_argument("--cookie-file", default=None, help="Domo only: JSON cookie file instead of interactive login")
    scan_cmd.add_argument("--skip-group-membership", action="store_true", help="Skip per-user group-membership lookups (one call per user; matters most on large orgs)")
    scan_cmd.set_defaults(func=cmd_scan)

    report = sub.add_parser("graph-report", help="Print the most-connected nodes in the estate graph")
    report.add_argument("--platform", default=None, help="Restrict to one platform (default: all)")
    report.add_argument("--top", type=int, default=20)
    report.set_defaults(func=cmd_graph_report)

    export = sub.add_parser("export", help="Save the scan as a zip that is safe to email (sessions removed)")
    export.add_argument("--dest", default=None, help="Folder to save into (default: Documents)")
    export.set_defaults(func=cmd_export)

    ui = sub.add_parser("ui", help="Launch the desktop UI (pywebview + FastAPI)")
    ui.add_argument("--browser", action="store_true", help="Open in the default web browser instead of a native window")
    ui.add_argument("--check", action="store_true", help="Self-test: server answers and the native window backend imports")
    ui.set_defaults(func=cmd_ui)

    args = parser.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    sys.exit(main())

"""Bring a database made before `instance` was part of the key up to the current layout (#55).

Runs by itself when a database is opened (`db.connect`), once: `PRAGMA user_version` = 1 marks a file
done. What it does, in this order:

1. Takes the write lock, then copies the file (storage/backup.py), refusing when the disk cannot hold the copy.
2. In the same transaction: normalises `scans.instance` and `platform_sessions.instance`, counts what the
   old layout had already lost, rebuilds the 14 tables with `instance` in their key, checks the row
   counts, drops the old tables. Any error rolls the whole transaction back: the file is then the
   original, and `MigrationFailed` names the copy.

A row gets the instance of the last scan that saw it (edges: the scan that wrote them). A row whose
first and last scan belong to different instances is a collision that had already happened: the old
layout kept one row per id, so the other instance's version exists only in `raw_objects`. The report
counts those rows; a rescan restores them. The migration does not repair what it cannot see.
"""

from __future__ import annotations

import json
import logging
import sqlite3
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

from estate_scanner.core.instances import normalise_instance
from estate_scanner.core.registry import all_object_types

from .backup import NotEnoughDiskSpace, backup_database

log = logging.getLogger(__name__)

LAYOUT_VERSION = 1  # PRAGMA user_version of a database whose tables carry `instance`
_SUFFIX = "__pre_instance"
_EXTRA_TABLES = ("refreshes", "edges")


class MigrationFailed(RuntimeError):
    """The migration stopped; the database file is as it was. `backup` is the copy taken first."""

    def __init__(self, message: str, backup: Path | None):
        super().__init__(message)
        self.backup = backup


@dataclass
class MigrationReport:
    backup: str
    seconds: float = 0.0
    rows: dict[str, int] = field(default_factory=dict)
    # rows whose first and last scan are different instances: the older version is gone from the typed table
    collisions: dict[str, int] = field(default_factory=dict)
    # edges whose end is an object of another instance than the edge's own scan: reported, not guessed
    edges_across_instances: dict[str, int] = field(default_factory=dict)
    instance_names_changed: list[dict] = field(default_factory=list)  # {table, platform, from, to, rows}
    sessions_merged: int = 0  # saved sign-ins that normalised to the same name; the newest kept
    # The file after the migration. The old tables are dropped, not vacuumed (a VACUUM needs free disk the size of the file and
    # minutes): their pages are free pages SQLite reuses, so the file does not shrink until `compact`.
    size_bytes: int = 0
    free_bytes: int = 0
    free_share: float = 0.0


def instance_tables() -> list[str]:
    return [d.table for d in all_object_types()] + list(_EXTRA_TABLES)


def _columns(con: sqlite3.Connection, table: str) -> list[str]:
    return [row[1] for row in con.execute(f"PRAGMA table_info({table})")]


def _tables(con: sqlite3.Connection) -> set[str]:
    return {row[0] for row in con.execute("SELECT name FROM sqlite_master WHERE type = 'table'")}


def tables_without_instance(con: sqlite3.Connection) -> list[str]:
    present = _tables(con)
    return [t for t in instance_tables() if t in present and "instance" not in _columns(con, t)]


def ensure_current(db_path: Path | str, *, schema_statements: list[str]) -> MigrationReport | None:
    """Migrate `db_path` if it is in the old layout; None when there was nothing to do (new file,
    or already current)."""
    db_path = Path(db_path)
    if not db_path.exists() or db_path.stat().st_size == 0:
        return None
    probe = sqlite3.connect(db_path, timeout=60)
    try:
        old = tables_without_instance(probe)
    finally:
        probe.close()
    if not old:
        return None

    con = sqlite3.connect(db_path, timeout=600, isolation_level=None)  # explicit BEGIN/COMMIT below
    con.create_function("norm_instance", 2, normalise_instance, deterministic=True)
    backup: Path | None = None
    try:
        con.execute("BEGIN IMMEDIATE")
        # Another process may have finished while this one waited for the write lock.
        old = tables_without_instance(con)
        if not old:
            con.execute("ROLLBACK")
            return None
        # The copy is taken with the lock held, not before it: three processes opening one old file at once
        # each took a 700 MB copy when it came first. The backup API reads while this connection holds the
        # write lock, which nothing has yet used.
        backup = backup_database(db_path, "instance")
        started = time.monotonic()
        report = MigrationReport(backup=str(backup))
        _migrate(con, old, schema_statements, report)
        con.execute(f"PRAGMA user_version = {LAYOUT_VERSION}")
        con.execute("COMMIT")
    except NotEnoughDiskSpace:
        raise
    except BaseException as exc:
        if con.in_transaction:
            con.execute("ROLLBACK")
        log.error("Migrating %s to the instance layout failed; the file is unchanged, %s", db_path,
                  f"the copy is {backup}" if backup else "no copy was taken")
        raise MigrationFailed(
            f"Could not bring {db_path} up to date ({type(exc).__name__}: {exc}). The file is unchanged"
            + (f"; a copy was taken first at {backup}." if backup else "."),
            backup,
        ) from exc
    finally:
        con.close()
    report.seconds = round(time.monotonic() - started, 1)
    _measure(db_path, report)
    _write_report(backup, report)
    log.warning(
        "Migrated %s to the instance layout in %.1f s. Copy: %s. Collisions already in the old layout: %s. "
        "The file is %.1f MB, %.1f%% of it free pages that a later compaction would give back.",
        db_path, report.seconds, backup, report.collisions or "none",
        report.size_bytes / 1e6, report.free_share * 100,
    )
    return report


def _measure(db_path: Path, report: MigrationReport) -> None:
    con = sqlite3.connect(db_path, timeout=60)
    try:
        page_size = con.execute("PRAGMA page_size").fetchone()[0]
        free_pages = con.execute("PRAGMA freelist_count").fetchone()[0]
    finally:
        con.close()
    report.size_bytes = db_path.stat().st_size
    report.free_bytes = free_pages * page_size
    report.free_share = round(report.free_bytes / report.size_bytes, 3) if report.size_bytes else 0.0


def _write_report(backup: Path, report: MigrationReport) -> None:
    path = backup.with_name(backup.name.removesuffix(".bak") + ".report.json")
    path.write_text(json.dumps(asdict(report), indent=2))


def _migrate(con: sqlite3.Connection, old: list[str], schema_statements: list[str], report: MigrationReport) -> None:
    con.execute("DROP VIEW IF EXISTS estate_objects")  # holds no data; the schema recreates it with `instance`
    _normalise_names(con, report)
    _count_losses(con, old, report)
    for table in old:
        # An index keeps its name when its table is renamed, and the new layout reuses the names.
        for (index,) in con.execute(
            "SELECT name FROM sqlite_master WHERE type = 'index' AND tbl_name = ? AND sql IS NOT NULL", (table,)
        ).fetchall():
            con.execute(f"DROP INDEX {index}")
        con.execute(f"ALTER TABLE {table} RENAME TO {table}{_SUFFIX}")
    for statement in schema_statements:
        con.execute(statement)
    for table in old:
        _copy_table(con, table, report)
    for table in old:
        con.execute(f"DROP TABLE {table}{_SUFFIX}")


def _copy_table(con: sqlite3.Connection, table: str, report: MigrationReport) -> None:
    old_cols = set(_columns(con, table + _SUFFIX))
    cols = [c for c in _columns(con, table) if c != "instance" and c in old_cols]
    scan_column = "scan_id" if table == "edges" else "last_seen_scan_id"
    names = ", ".join(["instance", *cols])
    values = ", ".join(
        [f"COALESCE((SELECT s.instance FROM scans s WHERE s.id = o.{scan_column}), '')", *[f"o.{c}" for c in cols]]
    )
    con.execute(f"INSERT INTO {table} ({names}) SELECT {values} FROM {table}{_SUFFIX} o")  # noqa: S608 -- table names come from the registry
    before = con.execute(f"SELECT COUNT(*) FROM {table}{_SUFFIX}").fetchone()[0]  # noqa: S608
    after = con.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]  # noqa: S608
    if before != after:
        raise RuntimeError(f"{table}: {before} rows before, {after} after the copy")
    report.rows[table] = after


def _normalise_names(con: sqlite3.Connection, report: MigrationReport) -> None:
    """One spelling per instance in `scans` and `platform_sessions` (a name typed with another case, or
    with `.domo.com`, was another instance to every query)."""
    present = _tables(con)
    if "scans" not in present:
        return
    for platform, instance, n in con.execute("SELECT platform, instance, COUNT(*) FROM scans GROUP BY platform, instance").fetchall():
        new = normalise_instance(platform, instance)
        if new != instance:
            con.execute("UPDATE scans SET instance = ? WHERE platform = ? AND instance = ?", (new, platform, instance))
            report.instance_names_changed.append({"table": "scans", "platform": platform, "from": instance, "to": new, "rows": n})
    sessions = con.execute("SELECT platform, instance, updated_at FROM platform_sessions").fetchall() if "platform_sessions" in present else []
    keep: dict[tuple[str, str], tuple[str, str]] = {}  # (platform, new name) -> (updated_at, old name)
    for platform, instance, updated_at in sessions:
        key = (platform, normalise_instance(platform, instance))
        if key not in keep or (updated_at or "") > keep[key][0]:
            keep[key] = (updated_at or "", instance)
    for platform, instance, _ in sessions:
        key = (platform, normalise_instance(platform, instance))
        if keep[key][1] != instance:
            con.execute("DELETE FROM platform_sessions WHERE platform = ? AND instance = ?", (platform, instance))
            report.sessions_merged += 1
    for (platform, new), (_, instance) in keep.items():
        if new != instance:
            con.execute("UPDATE platform_sessions SET instance = ? WHERE platform = ? AND instance = ?", (new, platform, instance))
            report.instance_names_changed.append({"table": "platform_sessions", "platform": platform, "from": instance, "to": new, "rows": 1})


def _count_losses(con: sqlite3.Connection, old: list[str], report: MigrationReport) -> None:
    """Read the old tables (before they are renamed) for what the old layout had already lost or mixed."""
    if "scans" not in _tables(con):
        return
    for table in old:
        if table == "edges":
            continue
        n = con.execute(
            f"SELECT COUNT(*) FROM {table} t JOIN scans f ON f.id = t.first_seen_scan_id "  # noqa: S608
            "JOIN scans l ON l.id = t.last_seen_scan_id WHERE f.platform = l.platform AND f.instance != l.instance"
        ).fetchone()[0]
        if n:
            report.collisions[table] = n
    if "edges" not in old:
        return
    for descriptor in all_object_types():
        if descriptor.table not in old:
            continue
        for side in ("src", "dst"):
            n = con.execute(
                f"SELECT COUNT(*) FROM edges e JOIN scans es ON es.id = e.scan_id "  # noqa: S608
                f"JOIN {descriptor.table} t ON t.platform = e.platform AND t.id = e.{side}_id "
                "JOIN scans ts ON ts.id = t.last_seen_scan_id "
                f"WHERE e.{side}_type = ? AND es.instance != ts.instance",
                (descriptor.object_type,),
            ).fetchone()[0]
            if n:
                report.edges_across_instances[f"{side}:{descriptor.object_type}"] = n

"""Thin client for Domo's private per-instance API.

Every endpoint here was confirmed live against 6intelligence.domo.com, either
by the sibling ``domo-etl-converter`` tool (dataflow tile DAG, dataset/stream
detail) or by watching the real Domo web app's own network traffic (search,
page/card containment, data apps, group membership).

The single biggest find is ``/api/search/v1/query``: Domo's own unified
search index, which covers essentially every object type in the estate
(datasets, dataflows, cards, pages, users, groups, accounts, data apps, Beast
Mode calculated fields, alerts) through one endpoint, keyed by the
``entities`` filter, and already carries lineage fields inline (a dataflow's
``inputDatasets``/``outputDatasets``, a card's ``dataSourceIds``, a Beast
Mode's ``links``). It pages via ``count``/``offset`` (2000 confirmed to work
in one call) but hard-caps at ``offset + count <= 10000`` regardless of
filters -- ``search_all()``/``search_datasources_all()`` bisect on
``create_date`` to work around that for any entity whose total exceeds it
(confirmed live: CARD at 24,809 rows, BEAST_MODE at 30,928). It's also
rate-limited (a per-window budget was observed around 300 requests,
surfaced via the ``x-ratelimit-remaining``/``x-ratelimit-reset`` response
headers).
"""

from __future__ import annotations

import time
from collections.abc import Iterator

import requests

from estate_scanner.core.pagination import bisect_paginate

from .auth import DomoSession

DEFAULT_SEARCH_PAGE_SIZE = 2000


class DomoSessionExpiredError(RuntimeError):
    pass


class DomoSearchLimitExceededError(RuntimeError):
    """Domo's /api/search/v1/query (and the datasources/search endpoint)
    refuses offset+count > 10,000 for a single query, regardless of
    filters. Should not normally surface -- search_all()/
    search_datasources_all() bisect proactively to stay under it -- but
    distinguishing it here means a bug in that bisection logic fails with a
    clear message instead of a generic HTTPError."""


def _date_range_filter(field: str, frm: int | None, to: int | None) -> list[dict]:
    if frm is None and to is None:
        return []
    return [{"field": field, "filterType": "range", "from": frm, "to": to}]


class DomoHttp:
    def __init__(self, session: DomoSession):
        self._instance_session = session
        self._http = requests.Session()
        for cookie in session.cookies:
            self._http.cookies.set(cookie["name"], cookie["value"], domain=cookie["domain"], path=cookie.get("path", "/"))
        self._http.headers.update({"x-csrf-token": session.csrf_token, "Accept": "application/json"})

    def _request(self, method: str, path: str, **kwargs) -> dict | list:
        resp = self._http.request(method, self._instance_session.base_url + path, **kwargs)
        if resp.status_code == 401:
            raise DomoSessionExpiredError(f"Domo session expired on {method} {path}")
        if resp.status_code == 429:
            reset_at = resp.headers.get("x-ratelimit-reset")
            wait_s = max(1.0, float(reset_at) - time.time()) if reset_at else 5.0
            time.sleep(min(wait_s, 60.0))
            resp = self._http.request(method, self._instance_session.base_url + path, **kwargs)
        if resp.status_code == 400:
            try:
                message = resp.json().get("message", "")
            except ValueError:
                message = ""
            if "10,000 results" in message or "10000 results" in message:
                raise DomoSearchLimitExceededError(message)
        resp.raise_for_status()
        return resp.json()

    def _get(self, path: str, **kwargs) -> dict | list:
        return self._request("GET", path, **kwargs)

    def _post(self, path: str, **kwargs) -> dict | list:
        return self._request("POST", path, **kwargs)

    # -- Unified search index (confirmed) ------------------------------------
    # entities: e.g. "DATASET", "DATAFLOW", "CARD", "PAGE", "USER", "GROUP",
    # "ACCOUNT", "DATA_APP", "BEAST_MODE", "ALERT". ("APP" also works but
    # returns Domo's public app-store catalog, not this customer's own
    # objects — its databaseId/customer fields are "GlobalSearchCustomer",
    # not the real instance's customer id. Use DATA_APP for the customer's
    # own installed/authored apps instead.)

    def search(self, entities: list[str], count: int, offset: int = 0, query: str = "*", filters: list[dict] | None = None) -> dict:
        return self._post(
            "/api/search/v1/query",
            json={
                "entities": entities,
                "filters": filters or [],
                "combineResults": True,
                "query": query,
                "count": count,
                "offset": offset,
                "sort": {"isRelevance": False, "fieldSorts": [{"field": "create_date", "sortOrder": "DESC"}]},
            },
        )

    def search_all(self, entity: str, page_size: int = DEFAULT_SEARCH_PAGE_SIZE, date_field: str = "create_date", safe_threshold: int = 8000) -> Iterator[dict]:
        """Yields every searchObject for one entity type, bisecting on
        `date_field` to stay under the 10,000-result cap for any entity
        whose total exceeds it."""
        def count_fn(frm: int | None, to: int | None) -> int:
            body = self.search([entity], count=0, offset=0, filters=_date_range_filter(date_field, frm, to))
            return body.get("totalResultCount", 0)

        def fetch_page_fn(frm: int | None, to: int | None, offset: int, limit: int) -> list[dict]:
            body = self.search([entity], count=limit, offset=offset, filters=_date_range_filter(date_field, frm, to))
            return body.get("searchObjects") or []

        yield from bisect_paginate(
            count_fn=count_fn, fetch_page_fn=fetch_page_fn,
            lo_bound=None, hi_bound=None,
            safe_threshold=safe_threshold, page_size=page_size,
        )

    # -- Dataset search (confirmed) ------------------------------------------
    # Richer than the DATASET entity in /api/search/v1/query: carries Domo's
    # own precomputed downstream-impact counts (impactCardCount,
    # impactDataFlowCount, impactDataSourceCount, impactAlertCount) plus the
    # full column schema. Also indexes dataflow *outputs* (dataProviderType
    # "DataFlow") alongside real connector-backed datasets.

    def search_datasources(self, count: int, offset: int = 0, filters: list[dict] | None = None) -> dict:
        return self._post(
            "/api/data/ui/v3/datasources/search",
            json={
                "entities": ["DATASET"],
                "filters": filters or [],
                "combineResults": True,
                "query": "*",
                "count": count,
                "offset": offset,
                "sort": {"isRelevance": False, "fieldSorts": [{"field": "create_date", "sortOrder": "DESC"}]},
            },
        )

    def search_datasources_all(self, page_size: int = 500, date_field: str = "create_date", safe_threshold: int = 8000) -> Iterator[dict]:
        """Same bisection strategy as search_all(), applied here too for
        consistency even though today's real dataset count (2,764) is under
        the cap. Note: this endpoint's filter support hasn't been
        independently confirmed the way /api/search/v1/query's was; the
        fast path never exercises it while a customer's dataset count stays
        under safe_threshold, and bisect_paginate's "stuck" fallback caps
        rather than hangs if this endpoint turns out to ignore the filter.
        """
        def count_fn(frm: int | None, to: int | None) -> int:
            body = self.search_datasources(count=0, offset=0, filters=_date_range_filter(date_field, frm, to))
            return body.get("_metaData", {}).get("totalCount", 0)

        def fetch_page_fn(frm: int | None, to: int | None, offset: int, limit: int) -> list[dict]:
            body = self.search_datasources(count=limit, offset=offset, filters=_date_range_filter(date_field, frm, to))
            return body.get("dataSources") or []

        yield from bisect_paginate(
            count_fn=count_fn, fetch_page_fn=fetch_page_fn,
            lo_bound=None, hi_bound=None,
            safe_threshold=safe_threshold, page_size=page_size,
        )

    # -- Dataflows (confirmed) ------------------------------------------------

    def list_dataflows(self) -> list[dict]:
        """Every dataflow in the instance, unpaginated (confirmed: 1,294 rows in one response).

        Prefer search_all("DATAFLOW") for inventory purposes — it carries
        input/output dataset lineage already. This is for the full tile DAG
        (get_dataflow) which the search index doesn't have.
        """
        return self._get("/api/dataprocessing/v1/dataflows")

    def get_dataflow(self, dataflow_id: str) -> dict:
        """Full tile DAG for one dataflow. Expensive to call for every dataflow
        (one request each) — treat as opt-in deep enrichment, not default scan."""
        return self._get(f"/api/dataprocessing/v1/dataflows/{dataflow_id}")

    # -- Dataset / stream detail (confirmed) ---------------------------------
    # search_datasources_all() already includes rowCount/columnCount/schema/
    # impact counts. These per-id calls are only needed for the streamId's
    # connector configuration (e.g. the raw SQL query text for a SQL-based
    # connector), which isn't indexed anywhere in search.

    def get_dataset_details(self, data_source_id: str) -> dict:
        return self._get(
            f"/api/data/v3/datasources/{data_source_id}",
            params={"includeAllDetails": "true", "includePrivate": "true"},
        )

    def get_stream_details(self, stream_id: str) -> dict:
        return self._get(f"/api/data/v1/streams/{stream_id}")

    # -- Pages / cards (confirmed) --------------------------------------------

    def get_page_cards(self, page_id: str) -> dict:
        """Cards actually placed on a page, by real id — for page->card containment edges."""
        return self._get(
            f"/api/content/v3/stacks/{page_id}/cards",
            params={
                "includeV4PageLayouts": "true",
                "parts": "metadata,datasources,owners,drillPathURNs,certification,dateInfo,subscriptions,slicers,metadataOverrides",
            },
        )

    def get_subpages_summary(self, page_ids: list[str]) -> list[dict]:
        """Page hierarchy (children) for a batch of page ids."""
        return self._get(
            "/api/content/v1/pages/subpagessummary",
            params=[("includeChildren", "true")] + [("pageIds", pid) for pid in page_ids],
        )

    def get_dataset_pdp_policies(self, dataset_id: str) -> list[dict]:
        """Personalized Data Permissions (row-level security) policies on a
        dataset; [] when it has none. Read-only."""
        return self._get(f"/api/query/v1/data-control/{dataset_id}/filter-groups")

    def get_page_filters(self, page_id: str) -> dict:
        """Page-level filter/analyzer config -- backs Dashboard.filters."""
        return self._get(f"/api/content/v3/pages/{page_id}/analyzer")

    def get_page_named_filters(self, page_id: str) -> dict:
        return self._get(f"/api/content/v3/pages/{page_id}/analyzer/named")

    def get_cards_detail(self, urns: list[str], parts: str | None = None) -> list[dict]:
        """Full card definitions (chart config, drill paths, per-component
        overrides) for a batch of card ids -- backs Card.definition. Batch
        via urns in one GET; the caller chunks (confirmed live with 17
        urns in one call; keep well under URL-length limits for larger
        batches -- see DomoClient's BATCH size)."""
        return self._get(
            "/api/content/v1/cards",
            params={
                "urns": ",".join(urns),
                "parts": parts or "drillPath,masonData,metadata,metadataOverrides,problems,properties,subscriptions",
                "includeFiltered": "true",
            },
        )

    # -- Data apps (confirmed) ------------------------------------------------

    def list_dataapps(self) -> list[dict]:
        """The customer's own Data Apps (App Studio), each with a landingViewId
        pointing at the page it opens on."""
        return self._get("/api/content/v1/dataapps", params={"type": "app"})

    def get_app_detail(self, app_id: str) -> dict:
        """Full app definition: every view (each is itself a dashboard id),
        the nav menu structure, and the branding theme -- backs
        App.views/navigations/theme. The plain list endpoint above only
        returns a landingViewId; this is what actually shows what an app
        is made of."""
        return self._get(f"/api/content/v1/dataapps/{app_id}", params={"authoring": "true", "includeHiddenViews": "true"})

    # -- Users / groups (confirmed) -------------------------------------------

    def get_user_groups(self, user_id: str) -> dict:
        """A user's group memberships -- backs the member_of edge. Reachable
        but never wired into any scan before this."""
        return self._get(f"/api/content/v2/users/{user_id}/groups", params={"includeMemberCount": "false"})

    # -- Calculated fields / Beast Mode formulas (confirmed) -------------------

    def get_functions_batch(self, ids: list[str]) -> dict:
        """The actual formula expression + everything needed to translate it
        (referenced functions, column positions, aggregation behavior) for
        a batch of Beast Mode ids -- backs CalculatedField.formula/
        definition. Domo's unified search index never exposes the formula
        text itself, only referenced column/function names -- this
        dedicated batch endpoint (confirmed live) is the only source for
        the real expression. Returns a dict keyed by id (as a string)."""
        return self._post("/api/query/v1/functions/list/id", json={"timeout": {}, "ids": ids})

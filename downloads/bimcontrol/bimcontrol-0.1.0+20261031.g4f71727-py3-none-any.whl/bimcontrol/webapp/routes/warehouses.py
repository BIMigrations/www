"""Warehouse connections: what can be used, what is configured, and
whether it actually works.

Secrets never pass through here. A password posted to this endpoint is
dropped rather than stored, and the response says so: the control
database gets copied around with a project, and a warehouse password is
not something to copy around with it. Credentials come from the
environment at the point of use -- see warehouses/redshift.py.
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Body, Depends, HTTPException

from bimcontrol import warehouses
from bimcontrol.storage import db

from .runs import get_conn

router = APIRouter()

# Accepted on a warehouse's settings. Anything else is ignored, so a
# stray "password" in a payload cannot end up persisted by accident.
ALLOWED_SETTINGS = {
    "key", "host", "port", "database", "user", "landing_schema",
    "s3_bucket", "s3_prefix", "aws_region", "iam_role", "keep_staged_files",
    "account", "warehouse", "role", "project", "dataset", "location",
}
SECRET_KEYS = {"password", "secret", "aws_secret_access_key", "private_key", "token"}


@router.get("/warehouses")
def list_warehouses() -> dict[str, Any]:
    """Every warehouse BIMControl knows, and whether it is built yet."""
    return {"items": warehouses.list_warehouses()}


def _project_or_404(conn, project_id: str) -> dict[str, Any]:
    project = db.get_project(conn, project_id)
    if project is None:
        raise HTTPException(status_code=404, detail=f"No project with id {project_id!r}")
    return project


@router.get("/projects/{project_id}/warehouse")
def get_warehouse(project_id: str, conn=Depends(get_conn)) -> dict[str, Any]:
    project = _project_or_404(conn, project_id)
    settings = (project.get("settings") or {}).get("warehouse") or {}
    return {
        "configured": bool(settings.get("host") or settings.get("account") or settings.get("project")),
        "settings": settings,
        "staging": "s3" if settings.get("s3_bucket") else "none (inserts only)",
    }


@router.post("/projects/{project_id}/warehouse")
def set_warehouse(
    project_id: str, conn=Depends(get_conn), body: dict[str, Any] = Body(...)
) -> dict[str, Any]:
    project = _project_or_404(conn, project_id)
    key = body.get("key", "redshift")
    if key not in warehouses.ADAPTERS:
        raise HTTPException(
            status_code=400,
            detail=f"Unknown warehouse {key!r}. Known: {', '.join(sorted(warehouses.ADAPTERS))}",
        )

    rejected = sorted(k for k in body if k.lower() in SECRET_KEYS)
    settings = {k: v for k, v in body.items() if k in ALLOWED_SETTINGS}
    settings["key"] = key
    settings.setdefault("landing_schema", "bimcontrol_landing")

    project_settings = dict(project.get("settings") or {})
    project_settings["warehouse"] = settings
    db.update_project(conn, project_id, settings=project_settings)

    return {
        "settings": settings,
        "rejected_secrets": rejected,
        "note": (
            "Secrets are not stored. Set REDSHIFT_PASSWORD (and AWS credentials "
            "or REDSHIFT_COPY_IAM_ROLE for staged loads) in the environment."
            if rejected else None
        ),
    }


@router.post("/projects/{project_id}/warehouse/check")
def check_warehouse(project_id: str, conn=Depends(get_conn)) -> dict[str, Any]:
    """Prove the connection before a migration depends on it.

    Reports rather than raises for an unconfigured or unbuilt warehouse:
    the Connections screen wants to show a red light, not a stack trace.
    """
    project = _project_or_404(conn, project_id)
    settings = (project.get("settings") or {}).get("warehouse") or {}
    if not settings:
        return {"ok": False, "error": "No warehouse configured for this project."}
    try:
        return warehouses.get_adapter(settings.get("key", "redshift"), settings).check()
    except Exception as exc:  # noqa: BLE001 -- every failure here is a red light
        return {"ok": False, "warehouse": settings.get("key"), "error": str(exc)}

from __future__ import annotations

import dataclasses

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from estate_scanner.core import registry
from estate_scanner.core.instances import normalise_instance
from estate_scanner.core.orchestrator import run_full_scan
from estate_scanner.storage import db, delete

from ..deps import get_conn
from ..graph_cache import invalidate as invalidate_graph_cache
from ..jobs import JobAlreadyRunning, jobs

router = APIRouter()


class ScanRequest(BaseModel):
    platform: str = "domo"
    instance: str
    skip_group_membership: bool = False


@router.post("")
def start_scan(body: ScanRequest, request: Request):
    try:
        descriptor = registry.get_platform(body.platform)
    except KeyError:
        raise HTTPException(404, f"Unknown platform: {body.platform}") from None
    db_path = request.app.state.db_path
    instance = normalise_instance(body.platform, body.instance)

    def do_scan(job):
        conn = db.connect(db_path)
        try:
            authenticator = descriptor.authenticator_cls()
            persisted = db.load_persisted_credentials(conn, body.platform, instance)
            if persisted is None:
                raise RuntimeError(f"No saved session for {body.platform}/{instance} -- connect first")
            session = authenticator.restore_session(instance, persisted)
            client = descriptor.client_cls(session)
            if not client.verify_session():
                raise RuntimeError("Session expired -- reconnect")
            if body.skip_group_membership and hasattr(client, "fetch_group_memberships"):
                client.fetch_group_memberships = False

            def on_progress(event):
                job.progress = {
                    "phase": event.phase, "completed": event.completed,
                    "total": event.total, "elapsed_s": event.elapsed_s, "message": event.message,
                }

            def on_scan_started(scan_id):
                job.result = {"scan_id": scan_id}  # also read when the scan fails: its issues explain how far it got

            scan_id = run_full_scan(conn, client, body.platform, instance, on_progress=on_progress, on_scan_started=on_scan_started)
            return {"scan_id": scan_id}
        finally:
            conn.close()
            invalidate_graph_cache()

    try:
        job = jobs.start("scan", do_scan, exclusive=True)  # a second tab or a reload cannot start a second scan beside the first
    except JobAlreadyRunning:
        raise HTTPException(409, _SCAN_RUNNING) from None
    return {"job_id": job.id}


@router.get("/jobs/{job_id}/progress")
def scan_job_progress(job_id: str):
    job = jobs.get(job_id)
    if job is None:
        raise HTTPException(404, "Unknown job")
    return {"status": job.status, "progress": job.progress, "result": job.result, "error": job.error}


@router.get("")
def list_scans(conn=Depends(get_conn)):
    rows = conn.execute(
        "SELECT id, platform, instance, started_at, finished_at, status,"
        " (SELECT COUNT(*) FROM scan_issues WHERE scan_id = scans.id) AS issue_count"
        " FROM scans ORDER BY id DESC"
    ).fetchall()
    return [dict(r) for r in rows]


_SCAN_RUNNING = "A scan is running. Wait for it to finish, then try again."


class ConfirmRequest(BaseModel):
    confirm: str


class StartFreshRequest(BaseModel):
    platform: str
    instance: str
    confirm: str


def _preview_json(preview) -> dict:
    out = dataclasses.asdict(preview)
    out["backup_path"] = str(preview.backup_path) if preview.backup_path else None
    out["lines"] = preview.lines()
    if jobs.scan_running() and not out["refusal"]:
        out["refusal"] = _SCAN_RUNNING
    return out


def _refused(exc: delete.DeleteRefused) -> HTTPException:
    return HTTPException(404 if isinstance(exc, delete.UnknownTarget) else 409, str(exc))


def _backup_json(backup: delete.Backup) -> dict:
    return {"backup_path": str(backup.path), "backup_bytes": backup.size_bytes}


# The fixed-path routes come before `/{scan_id}` so "start-fresh-preview" is never read as a scan number.
@router.get("/start-fresh-preview")
def start_fresh_preview(platform: str, instance: str, conn=Depends(get_conn)):
    try:
        return _preview_json(delete.preview_start_fresh(conn, platform, instance))
    except delete.DeleteRefused as exc:
        raise _refused(exc) from None


@router.post("/start-fresh")
def start_fresh(body: StartFreshRequest, conn=Depends(get_conn)):
    if jobs.scan_running():
        raise HTTPException(409, _SCAN_RUNNING)
    try:
        result = delete.start_fresh(conn, body.platform, body.instance, body.confirm)
    except delete.DeleteRefused as exc:
        raise _refused(exc) from None
    finally:
        invalidate_graph_cache()
    return {"platform": result.preview.platform, "instance": result.preview.instance, **_backup_json(result.backup)}


@router.get("/{scan_id}/delete-preview")
def delete_preview(scan_id: int, conn=Depends(get_conn)):
    try:
        return _preview_json(delete.preview_delete_scan(conn, scan_id))
    except delete.DeleteRefused as exc:
        raise _refused(exc) from None


@router.post("/{scan_id}/delete")
def delete_scan(scan_id: int, body: ConfirmRequest, conn=Depends(get_conn)):
    if jobs.scan_running():
        raise HTTPException(409, _SCAN_RUNNING)
    try:
        result = delete.delete_scan(conn, scan_id, body.confirm)
    except delete.DeleteRefused as exc:
        raise _refused(exc) from None
    finally:
        invalidate_graph_cache()
    return {"deleted_scan_id": scan_id, **_backup_json(result.backup)}


@router.get("/{scan_id}")
def get_scan(scan_id: int, conn=Depends(get_conn)):
    row = conn.execute(
        "SELECT id, platform, instance, started_at, finished_at, status, notes FROM scans WHERE id = ?", (scan_id,)
    ).fetchone()
    if row is None:
        raise HTTPException(404, "Unknown scan")
    issues = conn.execute(
        "SELECT phase, scope, message, http_status FROM scan_issues WHERE scan_id = ? ORDER BY id", (scan_id,)
    ).fetchall()
    return {**dict(row), "issues": [dict(i) for i in issues]}

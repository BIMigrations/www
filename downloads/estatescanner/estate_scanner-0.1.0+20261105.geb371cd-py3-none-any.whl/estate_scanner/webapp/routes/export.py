from __future__ import annotations

import subprocess
import sys
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from estate_scanner.export import export_scan, list_estates, read_manifest

router = APIRouter()


class RevealRequest(BaseModel):
    path: str


class ExportRequest(BaseModel):
    platform: str | None = None
    instance: str | None = None


@router.get("/estates")
def estates(request: Request):
    """The estates the zip can be of, newest first; the first is what an export without a choice takes."""
    return list_estates(request.app.state.db_path)


@router.post("")
def create_export(request: Request, body: ExportRequest | None = None):
    body = body or ExportRequest()
    try:
        zip_path = export_scan(request.app.state.db_path, platform=body.platform, instance=body.instance)
    except (FileNotFoundError, ValueError) as exc:
        raise HTTPException(400, str(exc)) from None
    manifest = read_manifest(zip_path)
    return {"path": str(zip_path), "filename": zip_path.name, "size_bytes": zip_path.stat().st_size,
            "scope": manifest["scope"], "other_estates_left_out": manifest["other_estates_left_out"]}


@router.post("/reveal")
def reveal(body: RevealRequest, request: Request):
    """Show the exported file in Finder/Explorer. Only zips made by the exporter."""
    path = Path(body.path)
    if not (path.is_file() and path.suffix == ".zip" and path.name.startswith("EstateScan-")):
        raise HTTPException(400, "Not an exported scan")
    if sys.platform == "darwin":
        subprocess.Popen(["open", "-R", str(path)])
    elif sys.platform == "win32":
        subprocess.Popen(["explorer", "/select,", str(path)])
    else:
        subprocess.Popen(["xdg-open", str(path.parent)])
    return {"ok": True}

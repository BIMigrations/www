"""The migration report: what was migrated, and what a human must still check.

This is the stage whose output leaves the building. Everything else in the
pipeline talks to the next stage; this one talks to the person paying for
the migration, and to the consultant who has to finish the last ten per
cent by hand.

Two artefacts, deliberately:

- **`migration_report.json`** is the contract. Every number in the report
  comes from it, so the control plane, a spreadsheet or a later tool can
  read the same facts without scraping HTML.
- **`migration_report.html`** is the deliverable: one file, no JavaScript,
  no network fetches, no linked stylesheet. It is going to be emailed,
  dropped in SharePoint and opened on a locked-down laptop behind a
  customer's VPN, and a report that reaches for a CDN renders as unstyled
  text in exactly those places. The design system's tokens are therefore
  inlined rather than referenced -- the one place in this repo where that
  is the right answer.

The report must describe a run that **did not finish**, because those are
the runs worth reading. Every input is optional: a run that failed in
`convert_dataflows` still gets a report saying what the closure was, how
far it got and why it stopped. `_maybe` is how that is done, and it is
why this module never raises on a missing artefact.
"""

from __future__ import annotations

import datetime as _dt
import hashlib
import html
import json
from collections import Counter
from typing import Any

from bimcontrol import __version__
from bimcontrol.core.engine import RunContext, StageResult
from bimcontrol.pipelines.build_powerbi import MODEL_FILE, REPORT_FILE
from bimcontrol.pipelines.convert_etl import CONVERSION_FILE
from bimcontrol.core import element_status, parity_causes
from bimcontrol.pipelines.data_plan import LANDINGS_FILE, PLAN_FILE
from bimcontrol.pipelines.verify_parity import PARITY_FILE
from bimcontrol.storage import db

REPORT_JSON = "migration_report.json"
REPORT_HTML = "migration_report.html"

# How many parity rows to put in the HTML. Differences are always shown in
# full; matches are a long tail that makes the file big without telling
# anybody anything, so they are summarised and sampled.
MATCHED_SAMPLE = 25
# Elements listed in full per (kind, reason) in the HTML before "and N more".
LISTED_PER_REASON = 12

# The verdict is the first thing read and the only thing some people read,
# so it is a named table rather than a chain of conditionals: a reviewer can
# check the wording without reading the logic, and a test can enumerate it.
VERDICTS: dict[str, tuple[str, str]] = {
    "failed": (
        "Failed",
        "The run stopped on an error. Nothing after the failing stage was produced.",
    ),
    "incomplete": (
        "Incomplete",
        "The run stopped before the end of the pipeline, so the migration is part-built.",
    ),
    "figures_differ": (
        "Figures differ",
        "The report was published and compared against Domo, and some figures differ. Each difference is listed "
        "below with the best-understood reason; a difference with a stated reason is a finished result, not a failure.",
    ),
    "verified": (
        "Compared with Domo",
        "Every figure that could be compared matches the Domo card it came from.",
    ),
    "unverified": (
        "Published, not verified",
        "The report was published, but its figures were not compared against Domo. "
        "Nothing here is evidence the numbers are right.",
    ),
    "generated": (
        "Project generated",
        "A Power BI project was written to disk and not published to a workspace.",
    ),
}

# Plain English for the strategy `plan_data` chose, for an audience that
# does not know the vocabulary.
STRATEGY_LABELS = {
    "dataflow_output": "Rebuilt in the warehouse by converted SQL",
    "land_from_source": "Copied out of Domo into the warehouse",
    "warehouse_table": "Already in the warehouse; pointed at in place",
    "needs_decision": "No source decided — needs a human",
}


# ---- gathering ----------------------------------------------------------


def _maybe(ctx: RunContext, stage: str, filename: str, default: Any) -> Any:
    """An artefact if the stage that writes it ran, else `default`.

    The report is most useful on a run that stopped early, so a missing
    artefact is an expected state here, not an error.
    """
    try:
        return ctx.read_json(stage, filename)
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def _duration(started: str | None, finished: str | None) -> float | None:
    if not started or not finished:
        return None
    try:
        return (_dt.datetime.fromisoformat(finished) - _dt.datetime.fromisoformat(started)).total_seconds()
    except ValueError:
        return None


# Visuals that carry no figures are not part of "how many data visuals were compared".
_NO_FIGURES = ("carries_no_figures", "structure_only", "text_carried")


def _comparison_line(elements: list[dict[str, Any]] | None) -> tuple[dict[str, int] | None, str]:
    """How much of the dashboard the verdict rests on: '7 of 7 data visuals' (#422). The word 'verified' promised more
    than a report can; the number says what was looked at. Counts the visuals with figures (a text box is not one)."""
    if elements is None:
        return None, ""
    data = [e for e in elements if e["kind"] == "visual" and e["reason"]["code"] not in _NO_FIGURES]
    compared = sum(1 for e in data if e["status"] in ("matches", "differs"))
    return ({"compared_visuals": compared, "data_visuals": len(data)},
            f"{compared:,} of {len(data):,} data visuals compared.")


def _verdict(run: dict[str, Any], published: dict[str, Any], parity: dict[str, Any]) -> str:
    if run.get("status") == "failed":
        return "failed"
    if parity.get("checked"):
        totals = parity.get("totals") or {}
        if totals.get("error"):
            return "figures_differ"
        # Nothing compared is nothing verified (Special Projects-SW, 2026-10-17: one card, no comparable figure).
        if totals.get("ok"):
            return "verified"
    if run.get("status") in ("incomplete", "cancelled"):
        return "incomplete"
    if published.get("workspace_id"):
        return "unverified"
    return "generated"


def collect(ctx: RunContext) -> dict[str, Any]:
    """Everything the report says, as one JSON-shaped dict.

    Pure assembly over artefacts and the control database: no platform
    calls, so a report can be regenerated for an old run long after its
    credentials expired.
    """
    run = db.get_run(ctx.conn, ctx.run_id) or {}
    stages = db.list_stages(ctx.conn, ctx.run_id)
    reviews = db.list_review_items(ctx.conn, run_id=ctx.run_id, status=None, limit=2000)
    artefacts = db.list_artefacts(ctx.conn, ctx.run_id)

    closure = _maybe(ctx, "resolve_closure", "closure.json", {})
    plan = _maybe(ctx, "plan_data", PLAN_FILE, {})
    landings = _maybe(ctx, "land_source_data", LANDINGS_FILE, {})
    conversion = _maybe(ctx, "convert_dataflows", CONVERSION_FILE, {})
    model = _maybe(ctx, "build_model", MODEL_FILE, {})
    report = _maybe(ctx, "build_report", REPORT_FILE, {})
    published = _maybe(ctx, "publish_powerbi", "published.json", {})
    parity = _maybe(ctx, "verify_parity", PARITY_FILE, {})

    landed_rows = {entry["dataset_id"]: entry for entry in landings.get("landings") or []}
    settings = ctx.project.get("settings") or {}

    datasets = []
    for entry in plan.get("datasets") or []:
        landing = landed_rows.get(entry.get("dataset_id")) or {}
        strategy, reason = entry.get("strategy"), entry.get("reason")
        if strategy == "dataflow_output" and landing:
            # The plan expected the converted SQL to supply it; the landing stage copied Domo's last output instead (a
            # flow with a deleted input, or one reading an archived dataset): say what happened, not what was planned.
            strategy = "land_from_source"
            reason = "a snapshot of Domo's last output; the dataflow that produces it could not be rebuilt in the warehouse"
        datasets.append({
            "dataset_id": entry.get("dataset_id"),
            "name": entry.get("name"),
            "provider_type": entry.get("provider_type"),
            "strategy": strategy,
            "strategy_label": STRATEGY_LABELS.get(strategy, strategy),
            "reason": reason,
            "scan_row_count": entry.get("row_count"),
            "table_ref": landing.get("table_ref") or entry.get("warehouse_table"),
            "rows_landed": landing.get("rows"),
            "already_present": landing.get("already_present"),
        })

    visuals = []
    cards_by_id = {str(card["id"]): card for card in closure.get("cards") or []}
    for page in report.get("pages") or []:
        for visual in page.get("visuals") or []:
            card = cards_by_id.get(str(visual.get("origin"))) or {}
            visuals.append({
                "card_id": visual.get("origin"),
                "card_name": card.get("name") or visual.get("title"),
                "domo_chart_type": card.get("chart_type"),
                "title": visual.get("title"),
                "visual_type": visual.get("visual_type"),
                "fields": {role: [p.get("name") for p in fields]
                           for role, fields in (visual.get("buckets") or {}).items()},
            })

    measures = [
        {"table": table["name"], "name": measure["name"], "expression": measure["expression"],
         "needs_review": bool(measure.get("needs_review")), "origin": measure.get("origin"),
         "description": measure.get("description")}
        for table in model.get("tables") or []
        for measure in table.get("measures") or []
    ]

    parity_rows = parity.get("rows") or []
    by_card: dict[str, dict[str, Any]] = {}
    for row in parity_rows:
        card = by_card.setdefault(row.get("metric") or row.get("card_id") or "", {
            "metric": row.get("metric"), "card_id": row.get("card_id"),
            "ok": 0, "warn": 0, "error": 0,
        })
        card[row.get("state", "error")] = card.get(row.get("state", "error"), 0) + 1

    counts = {
        "cards": (closure.get("summary") or {}).get("cards", len(closure.get("cards") or [])),
        # Cards that became a visual; slicers and text boxes have no card.
        "visuals": len({v["card_id"] for v in visuals if str(v["card_id"]) in cards_by_id}),
        "datasets": len(closure.get("datasets") or []),
        "dataflows": len(closure.get("dataflows") or []),
        "tables": len(model.get("tables") or []),
        "measures": len(measures),
        "measures_needing_review": sum(1 for m in measures if m["needs_review"]),
        "rows_landed": sum(int(d["rows_landed"] or 0) for d in datasets if d["rows_landed"]),
        "open_reviews": sum(1 for r in reviews if r["status"] == "open"),
        "review_errors": sum(1 for r in reviews if r["status"] == "open" and r["severity"] == "error"),
        # Visuals Power BI is known to draw as an error (build_report's lint): never "proven".
        "visual_errors": sum(1 for r in reviews if r["status"] == "open" and r["kind"] == "visual_will_not_draw"),
    }

    verdict = _verdict(run, published, parity)
    try:
        assessed = element_status.assess(closure=closure, report=report, model=model, parity=parity, reviews=reviews,
                                         causes=parity_causes.explain_differences(ctx.run_dir))
        status_error = None
    except Exception as exc:  # noqa: BLE001 -- an artefact of an older shape must not stop the report; it says so instead
        assessed, status_error = {"elements": None, "tally": None}, f"{type(exc).__name__}: {exc}"
    compared, compared_line = _comparison_line(assessed["elements"])
    return {
        "schema": "bimcontrol.migration_report/1",
        "generated_at": db.now(),
        "tool": {"name": "BIMControl", "version": __version__},
        "verdict": {
            "key": verdict,
            "title": VERDICTS[verdict][0],
            "statement": VERDICTS[verdict][1] + (" " + compared_line if compared_line and parity.get("checked") else ""),
            **(compared or {}),
        },
        "migration": {
            "source_platform": ctx.project.get("source_platform"),
            "source_instance": ctx.project.get("source_instance"),
            "target_platform": ctx.project.get("target_platform"),
            "unit_type": ctx.unit.get("unit_type"),
            "source_object_id": ctx.unit.get("source_object_id"),
            "name": (closure.get("dashboard") or {}).get("name") or ctx.unit.get("name"),
            "workspace": (settings.get("powerbi") or {}).get("workspace"),
            "warehouse": plan.get("warehouse") or (settings.get("warehouse") or {}).get("key"),
        },
        "run": {
            "id": ctx.run_id,
            "status": run.get("status"),
            "pipeline": run.get("pipeline"),
            "worker_id": run.get("worker_id"),
            "started_at": run.get("started_at"),
            "finished_at": run.get("finished_at"),
            "duration_seconds": _duration(run.get("started_at"), run.get("finished_at")),
            "stopped_reason": run.get("stopped_reason"),
            "error": run.get("error"),
            "error_stage": run.get("error_stage"),
        },
        "counts": counts,
        "stages": [
            {"name": s["name"], "title": s["title"], "status": s["status"],
             "attempt": s["attempt"], "warning_count": s["warning_count"],
             "result": s.get("result"), "error": s.get("error"),
             "duration_seconds": _duration(s.get("started_at"), s.get("finished_at"))}
            for s in stages
        ],
        "closure": {
            "summary": closure.get("summary") or {},
            "dataflows": closure.get("dataflows") or [],
            "missing": closure.get("missing") or [],
        },
        "data": {
            "warehouse": plan.get("warehouse"),
            "landing_schema": plan.get("landing_schema"),
            "datasets": datasets,
        },
        "transformations": {
            "validated_against_warehouse": conversion.get("validated"),
            "dataflows": [
                {"dataflow_id": entry.get("dataflow_id"), "name": entry.get("name"),
                 "outputs": entry.get("outputs") or [],
                 "unsupported_tile_types": entry.get("unsupported_tile_types") or [],
                 "unresolved_sources": entry.get("unresolved_sources") or [],
                 "tiles_with_warnings": entry.get("tiles_with_warnings")}
                for entry in conversion.get("dataflows") or []
            ],
        },
        "model": {
            "name": model.get("name"),
            "tables": [
                {"name": t["name"], "origin": t.get("origin"),
                 "columns": len(t.get("columns") or []),
                 "measures": len(t.get("measures") or []),
                 "source_kind": (t.get("source") or {}).get("kind")}
                for t in model.get("tables") or []
            ],
            "measures": measures,
        },
        "visuals": visuals,
        # Every element with a status word and a reason (bimcontrol.core.element_status); parity is evidence for it.
        "elements": assessed["elements"],
        "element_tally": assessed["tally"],
        "element_status_error": status_error,
        "published": {
            "workspace_id": published.get("workspace_id"),
            "report_url": published.get("report_url"),
            "items": published.get("items") or [],
        },
        "parity": {
            "checked": bool(parity.get("checked")),
            "cards": parity.get("cards"),
            "totals": parity.get("totals") or {},
            "by_card": sorted(by_card.values(), key=lambda c: (-c["error"], -c["warn"], c["metric"] or "")),
            "rows": parity_rows,
        },
        "review_items": [
            {"id": r["id"], "stage": r["stage"], "kind": r["kind"], "severity": r["severity"],
             "title": r["title"], "status": r["status"], "source_type": r["source_type"],
             "source_id": r["source_id"], "resolution_note": r.get("resolution_note")}
            for r in reviews
        ],
        # The report's own two files are added here rather than read back
        # from the database: they are written after this runs, and a list
        # headed "what the run produced" that omits the thing being read
        # is the kind of small dishonesty that makes a reader distrust the
        # rest.
        "artefacts": [
            {"stage": a["stage"], "kind": a["kind"], "label": a["label"],
             "path": a["path"], "bytes": a["bytes"]}
            for a in artefacts
        ] + [
            {"stage": "report", "kind": "report", "label": "Migration report",
             "path": f"report/{REPORT_HTML}", "bytes": None},
            {"stage": "report", "kind": "report", "label": "Migration report (data)",
             "path": f"report/{REPORT_JSON}", "bytes": None},
        ],
    }


# ---- the stage ----------------------------------------------------------


def report_fingerprint(ctx: RunContext) -> str:
    """Invalidate the report whenever any earlier stage re-ran.

    The report is a view over every other stage, so the thing that makes it
    stale is upstream work, not its own inputs. Without this a resume that
    re-ran `verify_parity` would keep yesterday's report alongside today's
    figures.
    """
    stages = db.list_stages(ctx.conn, ctx.run_id)
    material = [f"{s['name']}:{s['status']}:{s['fingerprint'] or ''}:{s['attempt']}"
                for s in stages if s["name"] != "report"]
    return hashlib.sha256("|".join(material).encode()).hexdigest()[:16]


def write_report(ctx: RunContext) -> StageResult:
    payload = collect(ctx)
    ctx.write_json(REPORT_JSON, payload, kind="report", label="Migration report (data)")
    ctx.write_text(REPORT_HTML, render_html(payload), kind="report",
                   label="Migration report", media_type="text/html")

    totals = payload["parity"]["totals"]
    ctx.progress(
        f"{payload['verdict']['title'].lower()}: "
        f"{payload['counts']['visuals']} of {payload['counts']['cards']} card(s) migrated, "
        f"{payload['counts']['open_reviews']} item(s) to review"
    )
    return StageResult(summary={
        "verdict": payload["verdict"]["key"],
        "cards": payload["counts"]["cards"],
        "visuals": payload["counts"]["visuals"],
        "open_reviews": payload["counts"]["open_reviews"],
        "parity_errors": totals.get("error"),
        "elements": (payload.get("element_tally") or {}).get("by_status"),
    })


def stamp_final_run(ctx: RunContext, run: dict[str, Any]) -> None:
    """Put the run's final state into the report the run wrote.

    The report is written by the last stage, while the run is still `running` with no end time; the file outlives the
    run, so it is brought up to date once the run has ended (#423). A run that never reached the report has none.
    """
    path = ctx.run_dir / "report" / REPORT_JSON
    if not path.exists():
        return
    payload = json.loads(path.read_text())
    payload["run"].update(
        status=run.get("status"), finished_at=run.get("finished_at"),
        duration_seconds=_duration(run.get("started_at"), run.get("finished_at")),
        stopped_reason=run.get("stopped_reason"), error=run.get("error"), error_stage=run.get("error_stage"),
    )
    ctx.stage = "report"
    ctx.write_json(REPORT_JSON, payload, kind="report", label="Migration report (data)")
    ctx.write_text(REPORT_HTML, render_html(payload), kind="report", label="Migration report", media_type="text/html")
    ctx.stage = None


# ---- rendering ----------------------------------------------------------


def _e(value: Any) -> str:
    return html.escape("" if value is None else str(value))


def _figure(value: Any) -> str:
    """A figure as plain text (no markup: for a sentence that is escaped afterwards)."""
    if isinstance(value, float):
        return f"{value:,.4g}" if abs(value) < 1e6 else f"{value:,.0f}"
    if isinstance(value, int):
        return f"{value:,}"
    return str(value)


def _num(value: Any, dash: str = "—") -> str:
    """A number in mono type, which is how every figure in the system is set."""
    if value is None or value == "":
        return f'<span class="num dim">{dash}</span>'
    return f'<span class="num">{_e(_figure(value))}</span>'


def _percent(value: float | None) -> str:
    if value is None:
        return _num(None)
    return f'<span class="num">{value * 100:+.3f}%</span>'


def _duration_text(seconds: float | None) -> str:
    if seconds is None:
        return _num(None)
    if seconds < 60:
        return f'<span class="num">{seconds:.1f}s</span>'
    return f'<span class="num">{int(seconds // 60)}m {int(seconds % 60):02d}s</span>'


def _code(value: Any) -> str:
    """A code span, or a dash. An empty `<code>` renders as a small grey
    box with nothing in it, which reads as a defect in the report rather
    than as an absent value."""
    if value in (None, ""):
        return '<span class="num dim">—</span>'
    return f"<code>{_e(value)}</code>"


def _chip(text: Any, kind: str = "neutral") -> str:
    return f'<span class="chip chip-{kind}">{_e(text)}</span>'


# Stage and parity statuses map to one of four visual states. Red is
# reserved for a real failure: an unbuilt stage is grey, not red.
STATUS_KIND = {
    "succeeded": "ok", "ok": "ok",
    "warn": "warn", "running": "info", "pending": "idle",
    "skipped": "idle", "not_implemented": "idle", "cancelled": "idle",
    "failed": "error", "error": "error",
}

STYLES = """
:root {
  --ink-900:#0A0D12; --ink-500:#3A424F; --ink-400:#5F6874; --ink-300:#8A929D;
  --ink-100:#DCDFE4; --paper-100:#FAF9F5; --paper-200:#F4F2EC; --paper-300:#EFECE3;
  --paper-000:#FFFFFF; --teal-600:#0B7F6B; --teal-100:#CDF6EC; --teal-050:#E6F7F3;
  --amber-600:#A8530F; --amber-100:#FBE7D5; --red-500:#C0362C; --red-100:#FADCD9;
  --blue-500:#2E6BA8; --blue-100:#D9E7F5;
  --source:var(--amber-600); --target:var(--teal-600);
  --font-ui:Archivo,"Helvetica Neue",Helvetica,Arial,sans-serif;
  --font-mono:"JetBrains Mono","SF Mono",ui-monospace,Menlo,monospace;
}
*,*::before,*::after{box-sizing:border-box}
body{margin:0;background:var(--paper-200);color:var(--ink-900);
  font:400 13px/1.55 var(--font-ui);-webkit-font-smoothing:antialiased}
.sheet{max-width:1080px;margin:0 auto;padding:32px 24px 72px}
h1{font-size:24px;font-weight:700;margin:0 0 4px;letter-spacing:-0.01em}
h2{font-size:15px;font-weight:600;margin:0 0 12px}
h3{font-size:13px;font-weight:600;margin:20px 0 8px;color:var(--ink-500)}
p{margin:0 0 10px;max-width:72ch}
a{color:var(--teal-600);text-decoration:none}
.eyebrow{font-size:11px;font-weight:600;letter-spacing:0.08em;text-transform:uppercase;
  color:var(--ink-400);margin:0 0 6px}
.num{font-family:var(--font-mono);font-variant-numeric:tabular-nums;font-size:0.95em}
.dim{color:var(--ink-300)}
header.masthead{border-bottom:1px solid var(--ink-100);padding-bottom:20px;margin-bottom:24px}
.lineage{display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-top:14px}
.lineage .side{flex:1 1 220px;min-width:200px;padding:10px 12px;border-radius:6px;
  border:1px solid var(--ink-100);background:var(--paper-000)}
.lineage .from{border-left:3px solid var(--source)}
.lineage .to{border-left:3px solid var(--target)}
.lineage .arrow{color:var(--ink-300);font-size:18px}
.lineage .label{font-size:11px;text-transform:uppercase;letter-spacing:0.08em;color:var(--ink-400)}
.lineage .value{font-weight:600}
.verdict{border-radius:8px;padding:16px 18px;margin:0 0 24px;border:1px solid var(--ink-100);
  background:var(--paper-000);border-left:4px solid var(--ink-300)}
.verdict.ok{border-left-color:var(--teal-600);background:var(--teal-050)}
.verdict.error{border-left-color:var(--red-500);background:#FCEEEC}
.verdict.warn{border-left-color:var(--amber-600);background:#FCF2E9}
.verdict .title{font-size:17px;font-weight:700;margin-bottom:4px}
.verdict p{margin:0}
.metrics{display:flex;flex-wrap:wrap;gap:10px;margin:0 0 28px}
.metric{flex:1 1 150px;min-width:140px;background:var(--paper-000);border:1px solid var(--ink-100);
  border-radius:6px;padding:12px 14px}
.metric .k{font-size:11px;text-transform:uppercase;letter-spacing:0.07em;color:var(--ink-400)}
.metric .v{font-family:var(--font-mono);font-size:22px;font-weight:500;line-height:1.3}
.metric .v.error{color:var(--red-500)} .metric .v.ok{color:var(--teal-600)}
section{background:var(--paper-000);border:1px solid var(--ink-100);border-radius:8px;
  padding:20px;margin:0 0 20px}
table{width:100%;border-collapse:collapse;font-size:12px}
th{text-align:left;font-weight:600;font-size:11px;letter-spacing:0.04em;text-transform:uppercase;
  color:var(--ink-400);border-bottom:1px solid var(--ink-100);padding:6px 8px;vertical-align:bottom}
td{padding:6px 8px;border-bottom:1px solid var(--paper-300);vertical-align:top}
tr:last-child td{border-bottom:none}
td.r,th.r{text-align:right}
.source-col{color:var(--amber-600)}
.chip{display:inline-block;font-size:10.5px;font-weight:600;letter-spacing:0.03em;
  padding:1px 7px;border-radius:9px;border:1px solid transparent;white-space:nowrap}
.chip-ok{background:var(--teal-100);color:#06554A}
.chip-warn{background:var(--amber-100);color:#7E3D0A}
.chip-error{background:var(--red-100);color:#A82B22}
.chip-info{background:var(--blue-100);color:#23568A}
.chip-idle{background:var(--ink-100);color:var(--ink-500)}
.chip-neutral{background:var(--paper-300);color:var(--ink-500)}
.chip-source{background:var(--amber-100);color:#7E3D0A}
.chip-target{background:var(--teal-100);color:#06554A}
code{font-family:var(--font-mono);font-size:11.5px;background:var(--paper-300);
  padding:1px 4px;border-radius:3px;word-break:break-word}
details{margin-top:12px}
summary{cursor:pointer;font-size:12px;color:var(--ink-500);font-weight:600;padding:4px 0}
.empty{color:var(--ink-400);font-style:italic}
footer{margin-top:32px;padding-top:16px;border-top:1px solid var(--ink-100);
  font-size:11px;color:var(--ink-400)}
@media print{
  body{background:var(--paper-000)}
  .sheet{max-width:none;padding:0}
  section{break-inside:avoid;border-color:var(--ink-100)}
  details{display:block} details>summary{display:none} details[open]>*,details>*{display:revert}
}
"""


def render_html(payload: dict[str, Any]) -> str:
    """One self-contained HTML file from the report payload.

    Reads only `payload`, so the JSON artefact is the whole truth and the
    HTML cannot drift away from it. No JavaScript: this file is opened from
    email clients and locked-down desktops where script is the first thing
    stripped.
    """
    migration = payload["migration"]
    name = migration.get("name") or migration.get("source_object_id") or "Migration"
    parts = [
        "<!doctype html>",
        '<html lang="en-GB"><head><meta charset="utf-8">',
        '<meta name="viewport" content="width=device-width, initial-scale=1">',
        f"<title>{_e(name)} — migration report</title>",
        f"<style>{STYLES}</style></head><body><div class='sheet'>",
        _masthead(payload),
        _verdict_block(payload),
        _metrics(payload),
        _elements_section(payload),
        _parity_section(payload),
        _review_section(payload),
        _visuals_section(payload),
        _measures_section(payload),
        _data_section(payload),
        _transformations_section(payload),
        _stages_section(payload),
        _artefacts_section(payload),
        _footer(payload),
        "</div></body></html>",
    ]
    return "\n".join(part for part in parts if part)


def _masthead(payload: dict[str, Any]) -> str:
    migration, run = payload["migration"], payload["run"]
    name = migration.get("name") or migration.get("source_object_id")
    source = " · ".join(filter(None, [
        (migration.get("source_platform") or "").title() or None,
        migration.get("source_instance"),
    ]))
    target = " · ".join(filter(None, [
        "Power BI" if migration.get("target_platform") == "powerbi" else migration.get("target_platform"),
        migration.get("workspace"),
    ]))
    return f"""
<header class="masthead">
  <p class="eyebrow">BIMControl migration report</p>
  <h1>{_e(name)}</h1>
  <p class="dim">{_e(migration.get('unit_type') or 'dashboard').capitalize()}
     {_num(migration.get('source_object_id'))} ·
     run {_num(run.get('id'))} ·
     {_e(_date_text(payload['generated_at']))}</p>
  <div class="lineage">
    <div class="side from"><div class="label">Migrated from</div>
      <div class="value source-col">{_e(source or 'unknown source')}</div></div>
    <div class="arrow">&rarr;</div>
    <div class="side to"><div class="label">Migrated to</div>
      <div class="value">{_e(target or 'a Power BI project on disk')}</div></div>
  </div>
</header>"""


def _date_text(timestamp: str | None) -> str:
    if not timestamp:
        return ""
    try:
        return _dt.datetime.fromisoformat(timestamp).strftime("%d %B %Y, %H:%M UTC")
    except ValueError:
        return timestamp


def _verdict_block(payload: dict[str, Any]) -> str:
    verdict, run = payload["verdict"], payload["run"]
    kind = {"verified": "ok", "figures_differ": "warn", "failed": "error",
            "incomplete": "warn", "unverified": "warn"}.get(verdict["key"], "")
    extra = ""
    if run.get("error"):
        extra = (f"<p style='margin-top:8px'>Stopped in "
                 f"<code>{_e(run.get('error_stage'))}</code>: {_e(run['error'])}</p>")
    elif run.get("stopped_reason"):
        extra = f"<p style='margin-top:8px'>{_e(run['stopped_reason']).capitalize()}.</p>"
    return f"""
<div class="verdict {kind}">
  <div class="title">{_e(verdict['title'])}</div>
  <p>{_e(verdict['statement'])}</p>{extra}
</div>"""


def _metrics(payload: dict[str, Any]) -> str:
    counts, totals = payload["counts"], payload["parity"]["totals"]
    cells = [
        ("Cards migrated", f"{counts['visuals']}/{counts['cards']}", ""),
        ("Measures", counts["measures"], ""),
        ("Rows landed", counts["rows_landed"], ""),
    ]
    if payload["parity"]["checked"]:
        cells.append(("Figures matching",
                      f"{totals.get('ok', 0)}/{sum(totals.get(k, 0) for k in ('ok', 'warn', 'error'))}",
                      "ok" if not totals.get("error") else "error"))
    by_status = (payload.get("element_tally") or {}).get("by_status") or {}
    if by_status:
        cells += [(element_status.STATUS_WORDS[s], by_status.get(s, 0), "") for s in element_status.STATUSES]
    cells.append(("To review", counts["open_reviews"], "error" if counts["review_errors"] else ""))
    return ('<div class="metrics">' + "".join(
        f'<div class="metric"><div class="k">{_e(k)}</div>'
        f'<div class="v {kind}">{_e(v) if not isinstance(v, int) else f"{v:,}"}</div></div>'
        for k, v, kind in cells) + "</div>")


_ELEMENT_CHIP = {"matches": "ok", "differs": "warn", "not_compared": "idle", "not_migrated": "error"}


def _gap_figure(value: Any) -> str:
    """One side of the largest gap: a row only the other side has reads 'has no value', not 'None'."""
    return "has no value (blank)" if value is None else _figure(value)


_HELD_WORDS = {"both": "the data holds both the value and the text without its blank, which the engine cannot tell apart",
               "unknown": "what the data holds was not read"}


def _reason_evidence(ev: dict[str, Any]) -> str:
    """The part of a reason's evidence its words point at ('see the evidence'): the filter values, or both row counts."""
    parts = [f"{f['column']} = \"{f['value']}\" ({_HELD_WORDS.get(f.get('data_holds'), f.get('data_holds') or 'unknown')})"
             for f in ev.get("blank_filter_values") or []]
    parts += [f"{m.get('dataset') or 'an input'}: Domo {m['domo_rows']:,} rows"
              f" ({'asked now' if m.get('domo_rows_from') == 'domo' else 'from the scan'}), warehouse {m['warehouse_rows']:,}"
              + (f" ({m['percent_apart']} % apart)" if m.get("percent_apart") is not None else "")
              for m in ev.get("moved_inputs") or []]
    return f"; {'; '.join(parts)}" if parts else ""


def _evidence_text(element: dict[str, Any]) -> str:
    ev = element.get("evidence") or {}
    if "largest_gap" in ev:
        gap = ev["largest_gap"]
        text = (f"{ev['values_differing']:,} of {ev['values_compared']:,} values differ; largest: Domo {_gap_figure(gap['source'])}, "
                f"Power BI {_gap_figure(gap['target'])} ({gap['grain']})")
        return text + _reason_evidence(ev)
    if "source_rows" in ev:
        return f"Domo {ev['source_rows']:,} rows, warehouse {ev['warehouse_rows']:,}"
    if "values_compared" in ev:
        return f"{ev['values_compared']:,} values compared"
    if ev.get("domo_says"):
        return f"Domo says: {ev['domo_says']}"
    if ev.get("model_says"):
        return f"Power BI says: {ev['model_says']}"
    return ev.get("review") or ""


def _elements_section(payload: dict[str, Any]) -> str:
    elements = payload.get("elements")
    if elements is None:
        if payload.get("element_status_error"):
            return ("<section><h2>Element by element</h2><p class='empty'>The per-element status could not be worked out for "
                    f"this run ({_e(payload['element_status_error'])}); the figures below are unaffected.</p></section>")
        return ""
    tally = payload["element_tally"]
    words = ", ".join(f"{tally['by_status'][s]:,} {element_status.STATUS_WORDS[s].lower()}" for s in element_status.STATUSES)
    listed, hidden = [], Counter()
    for e in elements:
        if e["status"] == "matches":
            continue
        key = (e["kind"], e["reason"]["code"])
        if sum(1 for x in listed if (x["kind"], x["reason"]["code"]) == key) >= LISTED_PER_REASON:
            hidden[key] += 1  # a 90-role model would otherwise list 90 identical lines; the JSON has them all
        else:
            listed.append(e)
    out = [f"""
<section><h2>Element by element</h2>
<p>{_num(tally['total'])} elements: {words}. Every element has a status word and a reason; colour is never the only
signal. Differing figures with a stated reason are a finished result. <em>Unexplained</em> means we do not know why yet.</p>"""]
    reasons = "".join(
        f"<tr><td>{_chip(element_status.STATUS_WORDS[r['status']], _ELEMENT_CHIP[r['status']])}</td>"
        f"<td>{_e(element_status.REASONS[r['code']][1])}</td><td class='r'>{_num(r['count'])}</td></tr>"
        for r in tally["reasons"])
    out.append(f"<table><thead><tr><th>Status</th><th>Reason</th><th class='r'>Elements</th></tr></thead><tbody>{reasons}</tbody></table>")
    if listed:
        rows = "".join(
            f"<tr><td>{_chip(element_status.STATUS_WORDS[e['status']], _ELEMENT_CHIP[e['status']])}</td>"
            f"<td class='dim'>{_e(e['kind'].replace('_', ' '))}</td><td>{_e(e.get('name'))}</td>"
            f"<td>{_e(e['reason']['text'])}<br><span class='dim'>{_e(_evidence_text(e))}</span></td></tr>"
            for e in listed)
        more = "".join(f"<p class='dim'>… and {n:,} more {_e(k[0].replace('_', ' '))} element(s) with the same reason "
                       f"({_e(k[1])}); all of them are in <code>{REPORT_JSON}</code>.</p>" for k, n in sorted(hidden.items()))
        out.append(f"""<details open><summary>{len(listed) + sum(hidden.values())} element(s) that are not a match</summary>
<table><thead><tr><th>Status</th><th>Kind</th><th>Element</th><th>Reason</th></tr></thead><tbody>{rows}</tbody></table>{more}</details>""")
    out.append("</section>")
    return "".join(out)


def _parity_section(payload: dict[str, Any]) -> str:
    parity = payload["parity"]
    if not parity["checked"]:
        return """
<section><h2>Parity against Domo</h2>
<p class="empty">The figures were not compared against Domo on this run, so nothing
here is evidence the migrated report is correct.</p></section>"""

    totals = parity["totals"]
    differing = [r for r in parity["rows"] if r["state"] != "ok"]
    matched = [r for r in parity["rows"] if r["state"] == "ok"]

    by_card = "".join(
        f"<tr><td>{_e(card['metric'])}</td>"
        f"<td class='r'>{_num(card['ok'])}</td>"
        f"<td class='r'>{_num(card['warn'])}</td>"
        f"<td class='r'>{_num(card['error'])}</td>"
        f"<td>{_chip('matches', 'ok') if not card['error'] else _chip('differs', 'error')}</td></tr>"
        for card in parity["by_card"])

    out = [f"""
<section><h2>Parity against Domo</h2>
<p>Each migrated visual was asked for its figures and compared against the same
Domo card, matched by category rather than by position.
{_num(totals.get('ok', 0))} of
{_num(sum(totals.get(k, 0) for k in ('ok', 'warn', 'error')))} values match across
{_num(parity.get('cards'))} card(s).</p>
<table><thead><tr><th>Card</th><th class="r">Match</th><th class="r">Close</th>
<th class="r">Differ</th><th>Verdict</th></tr></thead><tbody>{by_card}</tbody></table>"""]

    if differing:
        out.append(f"""
<h3>Differences, in full</h3>
<table><thead><tr><th>Card</th><th>Grain</th><th class="r source-col">Domo</th>
<th class="r">Power BI</th><th class="r">Difference</th><th>State</th></tr></thead><tbody>"""
            + "".join(
                f"<tr><td>{_e(r['metric'])}</td><td>{_e(r['grain'])}</td>"
                f"<td class='r source-col'>{_num(r['source'])}</td>"
                f"<td class='r'>{_num(r['target'])}</td>"
                f"<td class='r'>{_percent(r['delta'])}</td>"
                f"<td>{_chip(r['state'], STATUS_KIND.get(r['state'], 'neutral'))}</td></tr>"
                for r in differing)
            + "</tbody></table>")

    if matched:
        out.append(f"""
<details><summary>{len(matched)} matching value(s)</summary>
<table><thead><tr><th>Card</th><th>Grain</th><th class="r source-col">Domo</th>
<th class="r">Power BI</th></tr></thead><tbody>"""
            + "".join(
                f"<tr><td>{_e(r['metric'])}</td><td>{_e(r['grain'])}</td>"
                f"<td class='r source-col'>{_num(r['source'])}</td>"
                f"<td class='r'>{_num(r['target'])}</td></tr>"
                for r in matched[:MATCHED_SAMPLE])
            + "</tbody></table>"
            + (f"<p class='dim'>Showing the first {MATCHED_SAMPLE}; the rest are in "
               f"<code>{REPORT_JSON}</code>.</p>" if len(matched) > MATCHED_SAMPLE else "")
            + "</details>")

    out.append("</section>")
    return "".join(out)


def _review_section(payload: dict[str, Any]) -> str:
    items = [i for i in payload["review_items"] if i["status"] == "open"]
    if not items:
        return """
<section><h2>What needs a human</h2>
<p class="empty">Nothing was flagged for review on this run.</p></section>"""
    # Errors first: a reader working down the list should hit the things
    # that block delivery before the things that merely want checking.
    items.sort(key=lambda i: (i["severity"] != "error", i["stage"] or "", i["id"]))
    rows = "".join(
        f"<tr><td>{_chip(i['severity'], STATUS_KIND.get(i['severity'], 'neutral'))}</td>"
        f"<td>{_e(i['title'])}</td>"
        f"<td>{_code(i['kind'])}</td>"
        f"<td class='dim'>{_e(i['stage'])}</td>"
        f"<td class='dim'>{_e(i['source_type'])} {_num(i['source_id'], dash='')}</td></tr>"
        for i in items)
    return f"""
<section><h2>What needs a human</h2>
<p>{_num(len(items))} open item(s). An item here is work the factory could not
finish by itself, not necessarily a defect.</p>
<table><thead><tr><th>Severity</th><th>Item</th><th>Kind</th><th>Stage</th>
<th>Source object</th></tr></thead><tbody>{rows}</tbody></table></section>"""


def _visuals_section(payload: dict[str, Any]) -> str:
    visuals = payload["visuals"]
    if not visuals:
        return ""
    rows = "".join(
        f"<tr><td class='source-col'>{_e(v['card_name'])}</td>"
        f"<td>{_code(v['domo_chart_type'])}</td>"
        f"<td>{_e(v['title'])}</td>"
        f"<td>{_code(v['visual_type'])}</td>"
        f"<td class='dim'>{_e(_fields_text(v['fields']))}</td></tr>"
        for v in visuals)
    unmapped = payload["counts"]["cards"] - payload["counts"]["visuals"]
    note = (f"<p>{_num(unmapped)} card(s) became no visual; each one is in the review "
            f"list above.</p>" if unmapped > 0 else "")
    return f"""
<section><h2>Cards and the visuals they became</h2>{note}
<table><thead><tr><th class="source-col">Domo card</th><th class="source-col">Domo chart</th>
<th>Power BI visual</th><th>Visual type</th><th>Fields</th></tr></thead>
<tbody>{rows}</tbody></table></section>"""


def _fields_text(fields: dict[str, list[Any]]) -> str:
    return "; ".join(f"{role}: {', '.join(str(n) for n in names)}"
                     for role, names in fields.items() if names)


def _measures_section(payload: dict[str, Any]) -> str:
    measures = payload["model"]["measures"]
    if not measures:
        return ""
    needs_review = [m for m in measures if m["needs_review"]]
    tables = "".join(
        f"<tr><td>{_e(t['name'])}</td><td class='dim source-col'>{_num(t['origin'])}</td>"
        f"<td class='r'>{_num(t['columns'])}</td><td class='r'>{_num(t['measures'])}</td>"
        f"<td>{_code(t['source_kind'])}</td></tr>"
        for t in payload["model"]["tables"])

    out = [f"""
<section><h2>The semantic model</h2>
<table><thead><tr><th>Table</th><th class="source-col">From Domo dataset</th>
<th class="r">Columns</th><th class="r">Measures</th><th>Loaded by</th></tr></thead>
<tbody>{tables}</tbody></table>"""]

    if needs_review:
        out.append(f"""
<h3>Measures that need checking</h3>
<p>{_num(len(needs_review))} of {_num(len(measures))} beast modes could not be
translated with confidence. Each is present in the model as a blank measure
carrying its original formula, so the report opens and the gap is visible rather
than silently wrong.</p>
<table><thead><tr><th>Measure</th><th>Original Domo formula</th></tr></thead><tbody>"""
            + "".join(
                f"<tr><td>{_e(m['name'])}</td>"
                f"<td><code>{_e((m['description'] or m['expression'])[:400])}</code></td></tr>"
                for m in needs_review)
            + "</tbody></table>")

    translated = [m for m in measures if not m["needs_review"]]
    if translated:
        out.append(f"""
<details><summary>{len(translated)} translated measure(s)</summary>
<table><thead><tr><th>Measure</th><th>DAX</th></tr></thead><tbody>"""
            + "".join(f"<tr><td>{_e(m['name'])}</td><td><code>{_e(m['expression'])}</code></td></tr>"
                      for m in translated)
            + "</tbody></table></details>")

    out.append("</section>")
    return "".join(out)


def _data_section(payload: dict[str, Any]) -> str:
    datasets = payload["data"]["datasets"]
    if not datasets:
        return ""
    rows = "".join(
        f"<tr><td class='source-col'>{_e(d['name'])}</td>"
        f"<td>{_code(d['provider_type'])}</td>"
        f"<td>{_e(d['strategy_label'])}</td>"
        f"<td>{_code(d['table_ref'])}</td>"
        f"<td class='r source-col'>{_num(d['scan_row_count'])}</td>"
        f"<td class='r'>{_num(d['rows_landed'])}</td></tr>"
        for d in datasets)
    warehouse = payload["data"].get("warehouse") or "no warehouse"
    return f"""
<section><h2>Where the data comes from</h2>
<p>Every dataset the cards read has to exist in the customer's own warehouse
(<code>{_e(warehouse)}</code>). Spreadsheets uploaded by hand into Domo exist
nowhere else, so BIMControl copies them across; everything else is either
rebuilt by converted SQL or pointed at where it already sits.</p>
<table><thead><tr><th class="source-col">Domo dataset</th><th>Kind</th>
<th>How it is supplied</th><th>Warehouse table</th>
<th class="r source-col">Rows in scan</th><th class="r">Rows landed</th></tr></thead>
<tbody>{rows}</tbody></table></section>"""


def _transformations_section(payload: dict[str, Any]) -> str:
    transformations = payload["transformations"]
    flows = transformations["dataflows"]
    if not flows:
        return ""
    validated = transformations.get("validated_against_warehouse")
    validation = {
        True: "Every script was planned by the warehouse before being used, so it is known to run.",
        False: "The scripts were not planned by the warehouse, so whether they run is unproven.",
        None: "No warehouse was configured, so the scripts were not checked against one.",
    }[validated if validated in (True, False) else None]
    rows = "".join(
        f"<tr><td class='source-col'>{_e(flow['name'])}</td>"
        f"<td class='dim source-col'>{_num(flow['dataflow_id'])}</td>"
        f"<td>{_num(len(flow['outputs']))}</td>"
        f"<td>{', '.join(_e(o.get('destination_name')) for o in flow['outputs'])}</td>"
        f"<td class='r'>{_num(sum(int(o.get('sql_chars') or 0) for o in flow['outputs']))}</td></tr>"
        for flow in flows)
    return f"""
<section><h2>Transformations rebuilt as SQL</h2>
<p>{validation}</p>
<table><thead><tr><th class="source-col">Magic ETL dataflow</th><th class="source-col">Id</th>
<th>Scripts</th><th>Writes</th><th class="r">SQL characters</th></tr></thead>
<tbody>{rows}</tbody></table></section>"""


def _stages_section(payload: dict[str, Any]) -> str:
    rows = "".join(
        f"<tr><td>{_e(s['title'])}</td>"
        f"<td>{_chip(s['status'].replace('_', ' '), STATUS_KIND.get(s['status'], 'neutral'))}</td>"
        f"<td class='r'>{_duration_text(s['duration_seconds'])}</td>"
        f"<td class='dim'>{_e(_result_text(s))}</td></tr>"
        for s in payload["stages"])
    run = payload["run"]
    return f"""
<section><h2>How the run went</h2>
<p>Pipeline <code>{_e(run.get('pipeline'))}</code> on worker
<code>{_e(run.get('worker_id'))}</code>, {_duration_text(run.get('duration_seconds'))} in total.</p>
<table><thead><tr><th>Stage</th><th>Status</th><th class="r">Took</th>
<th>Result</th></tr></thead><tbody>{rows}</tbody></table></section>"""


def _result_text(stage: dict[str, Any]) -> str:
    if stage.get("error"):
        return stage["error"]
    result = stage.get("result") or {}
    return ", ".join(f"{k.replace('_', ' ')} {v}" for k, v in result.items())


def _artefacts_section(payload: dict[str, Any]) -> str:
    artefacts = payload["artefacts"]
    if not artefacts:
        return ""
    rows = "".join(
        f"<tr><td>{_e(a['label'] or a['path'])}</td><td><code>{_e(a['path'])}</code></td>"
        f"<td class='r'>{_num(a['bytes'])}</td></tr>"
        for a in artefacts)
    return f"""
<section><h2>What the run produced</h2>
<details><summary>{len(artefacts)} artefact(s) on the machine that ran this migration</summary>
<table><thead><tr><th>Artefact</th><th>Path in the run directory</th>
<th class="r">Bytes</th></tr></thead><tbody>{rows}</tbody></table></details></section>"""


def _footer(payload: dict[str, Any]) -> str:
    tool = payload["tool"]
    return f"""
<footer>{_e(tool['name'])} {_e(tool['version'])} · generated
{_e(_date_text(payload['generated_at']))} · the figures in this report come from
<code>{REPORT_JSON}</code> in the same run directory.</footer>"""

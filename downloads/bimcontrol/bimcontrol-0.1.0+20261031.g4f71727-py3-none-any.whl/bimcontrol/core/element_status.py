"""Per-element status of a migration: matches / differs / not compared / not migrated, each with a reason.

Parity used to decide a dashboard's outcome ("proven" or not). It is evidence now: this module reads what the run
found (the figures compared, what could not be compared and why, what was not migrated and why) and says, for every
element, one of four things, always with a word and a reason:

- **matches**: the source and Power BI agree on the evidence we have (figures compared, row counts equal);
- **differs**: they do not agree, with the best-understood reason from `REASONS` below; `unexplained` says plainly that
  we do not know why yet;
- **not compared**: migrated, but nothing was compared, with why (a slicer carries no figures; Domo itself could not
  draw the card; the result was too large ...);
- **not migrated**: left out or only partly built, with the review item that says why.

A differing figure with a stated reason is a finished state, not a failure. The reasons are a named table so a reviewer
can read the wording without reading the logic, and a test can enumerate it. Nothing here calls a platform: it is a pure
function over a run's artefacts, so it can be re-run on an old run.
"""

from __future__ import annotations

import re
from collections import Counter
from typing import Any

from ..export.airbyte import classify as classify_source
from . import parity_causes
from .parity_causes import within_drift

MATCHES, DIFFERS, NOT_COMPARED, NOT_MIGRATED = "matches", "differs", "not_compared", "not_migrated"
STATUSES = (DIFFERS, NOT_MIGRATED, NOT_COMPARED, MATCHES)  # the order they are listed in: what needs a reader first
# Within a status, what a reader came for first; the kinds a dashboard has dozens of (drill views, roles) come last, so
# 91 roles without members do not push the one visual that differs off the first screen.
KIND_ORDER = ("visual", "measure", "table", "filter", "page", "text", "layout", "drill", "rls_role")
STATUS_WORDS = {MATCHES: "Matches", DIFFERS: "Differs", NOT_COMPARED: "Not compared", NOT_MIGRATED: "Not migrated"}

# code -> (status it belongs to, one line a customer can read). The status is part of the code's meaning.
REASONS: dict[str, tuple[str, str]] = {
    # matches
    "figures_equal": (MATCHES, "Every figure compared equals the source's (within 0.1 %)."),
    "row_counts_equal": (MATCHES, "The table has the same number of rows as the source dataset."),
    "every_visual_using_it_matches": (MATCHES, "Every compared visual that uses it matches the source."),
    # differs
    "stale_source_data": (DIFFERS, "The source's input data is older than the warehouse copy (or the other way round), so the figures describe different days."),
    "case_collapse": (DIFFERS, "The source keeps text that differs only in letter case as separate values (Balance forward, balance forward); Power BI shows them as one value, so the figures of the "
                               "spellings it folded are added to the one it kept. The totals agree."),
    "source_moved_since_import": (DIFFERS, "A table this visual reads holds more or fewer rows than Domo's dataset does (compared with Domo's count now, or the scan's when Domo would not answer; the evidence gives both counts), and each differing figure is within 2 % of Domo's. "
                                           "That is consistent with the source having moved on since Domo's import (rows posted or removed), so the figures would describe different days of it: a possible cause for this visual, not confirmed by its figures."),
    "blank_filter_value": (DIFFERS, "A filter of this visual lists a value that ends in a blank (see the evidence). Domo matches it as written; the Power BI engine drops trailing blanks, so the migrated filter also matches the text without the blank "
                                    "and can keep rows Domo's filter drops (a possible cause for this visual, found in the filter and not checked row by row)."),
    "row_count_drift": (DIFFERS, "The warehouse table and the source dataset have a different number of rows; the differing figures are within that gap."),
    "key_reads_run_date": (DIFFERS, "A column this visual is keyed on is computed from the date the flow runs (an age, 'days since'). Domo's dataset holds the values of its last run, the migrated model those of the day it ran, so the rows of the two days do not pair (a possible cause for this visual, found in the flow's SQL and not checked row by row)."),
    "domo_keeps_arbitrary_row": (DIFFERS, "A Remove Duplicates step upstream meets keys whose rows differ. The source keeps the first stored row of a key and the migrated flow keeps the first by the position the row landed with, so figures agree when the data lands in the same order; a different landing order is a possible cause here, not a confirmed one."),
    "source_reads_run_date": (DIFFERS, "The source dataflow reads the date it runs; its dataset holds the values of its last run, the migrated flow reads today's date, so date-dependent figures can differ by the days since (a possible cause for this element, not checked against it)."),
    "measure_reads_clock": (DIFFERS, "A measure this visual shows reads today's date (a forecast, 'yesterday', a trailing window). Domo drew its figure at its own moment and clock, the migrated model uses the date it is asked on, so the figures can differ (a possible cause for this element, not checked against it)."),
    "append_history_not_reproduced": (DIFFERS, "The source dataset, or one it is built from, accumulates history across runs; the rebuild starts from today's inputs."),
    "source_changed_since_scan": (DIFFERS, "The source dataflow was edited after the scan this migration was built from."),
    "domo_draws_nothing": (DIFFERS, "Domo's own render of this card returned no rows; the migrated visual draws the values the data holds. Check the card in Domo."),
    "unexplained": (DIFFERS, "The figures differ and we do not know why yet."),
    "model_table_empty": (DIFFERS, "The model's table holds no rows although the source dataset has some: the warehouse load or the Power BI refresh "
                                   "did not fill it (see the run's events), so there is nothing to compare."),
    "column_supplied_empty": (DIFFERS, "The visual reads a column the source's schema lists but the warehouse table does not hold (for the batch id and last-run time Domo adds when it loads a dataset, "
                                       "the warehouse has no equivalent), so the model supplies it empty; rows keyed on it cannot pair with the source's."),
    "platform_data_not_landed": (DIFFERS, "The table is built from the platform's own data about itself (usage and audit logs). No warehouse holds it and no connector extracts it, "
                                          "so it was not landed: the model's table is empty and there is nothing to compare. It describes the platform's use, not the business."),
    # not compared
    "carries_no_figures": (NOT_COMPARED, "A slicer, text box or page carries no figures; there is nothing to compare."),
    "text_carried": (NOT_COMPARED, "A notebook card: its text was carried into a text box in the same place; it has no figures to compare."),
    "structure_only": (NOT_COMPARED, "Migrated; only its figures can be compared, and it has none of its own."),
    "parity_not_run": (NOT_COMPARED, "The report was not published or refreshed, so no figures were compared."),
    "domo_render_failed": (NOT_COMPARED, "Domo itself could not draw this card, so there is nothing to compare against."),
    "rows_finer_than_the_visual": (NOT_COMPARED, "The source returns rows finer than the visual draws; they cannot be lined up."),
    "filter_on_measure_not_expressed": (NOT_COMPARED, "The card is filtered on a measure in a way the comparison query cannot repeat, so its figures were not compared."),
    "columns_do_not_line_up": (NOT_COMPARED, "The visual's columns could not be matched one to one with the source's."),
    "model_result_too_large": (NOT_COMPARED, "The Power BI result was too large to read back."),
    "model_query_timeout": (NOT_COMPARED, "Power BI did not answer the comparison query in time (usually a table of millions of rows in DirectQuery): its rows were not read back."),
    "model_query_failed": (NOT_COMPARED, "Power BI could not answer the comparison query."),
    "no_figures": (NOT_COMPARED, "The card returned no figures."),
    "unsupported_visual": (NOT_COMPARED, "This visual type has no comparison yet."),
    "not_compared": (NOT_COMPARED, "Not compared (the run recorded no reason)."),
    "no_visual_uses_it": (NOT_COMPARED, "No compared visual uses it."),
    "used_by_differing_visuals": (NOT_COMPARED, "It is used by visuals whose figures differ; the difference is not pinned to this measure."),
    "no_row_evidence": (NOT_COMPARED, "Row counts were not compared for this table."),
    "roles_not_compared": (NOT_COMPARED, "Migrated; the source's access policies are not compared with the role's effect."),
    # not migrated
    "unmapped_card": (NOT_MIGRATED, "No Power BI visual could be built for this card."),
    "card_without_dataset": (NOT_MIGRATED, "The card reads no dataset, so there is no data to draw."),
    "layout_components_unmapped": (NOT_MIGRATED, "This layout component (text, shape, button ...) has no Power BI equivalent here."),
    "dashboard_filters_unmapped": (NOT_MIGRATED, "A dashboard filter could not be carried over."),
    "drill_view_not_migrated": (NOT_MIGRATED, "The drill view could not be built."),
    "drill_view_columns_missing": (NOT_MIGRATED, "The drill view names columns the model does not hold."),
    "untranslated_measure": (NOT_MIGRATED, "The calculation could not be translated to DAX; a placeholder stands in."),
    "measure_not_found": (NOT_MIGRATED, "The visual uses a calculation the scan does not hold."),
    "members_not_mapped": (NOT_MIGRATED, "The row-level-security role is built, its members are not: the source's users have no Power BI identity mapped, so nobody gets the role's rows until someone adds them."),
    "rls_unsupported": (NOT_MIGRATED, "The source's row-level policy has a shape Power BI roles cannot express."),
    "table_without_source": (NOT_MIGRATED, "The table has no source to load from: it is empty."),
    "missing_table": (NOT_MIGRATED, "The dataset the table stands for is not in the scan."),
    "visual_will_not_draw": (NOT_MIGRATED, "Power BI is known to draw this visual as an error."),
}

# Review-item kinds that mean "this element was not (fully) migrated", by the element kind they apply to.
_NOT_MIGRATED_KINDS = {
    "unmapped_card": "visual", "card_without_dataset": "visual", "visual_will_not_draw": "visual",
    "drill_view_not_migrated": "drill", "drill_view_columns_missing": "drill",
    "untranslated_measure": "measure", "measure_not_found": "visual",
    "rls_unsupported": "rls_role", "table_without_source": "table", "missing_table": "table",
}
_ARBITRARY = {"unique_keeps_arbitrary_row": "domo_keeps_arbitrary_row",
              "reads_run_date": "source_reads_run_date",
              "append_history_not_reproduced": "append_history_not_reproduced",
              "dataflow_edited_since_scan": "source_changed_since_scan"}
# When a card reads several flows that each carry a possible cause, the most certain one comes first:
# a flow that reads today's date differs from Domo's last run unless the dates agree, a Remove Duplicates tie only if the
# landing order differs (#361); neither is checked against the card (the texts say 'possible cause'). Review order must not decide (DNFB Clinic's date-bucket card read 'ties', pass 12).
_ARBITRARY_RANK = ("measure_reads_clock", "source_reads_run_date", "append_history_not_reproduced", "source_changed_since_scan", "domo_keeps_arbitrary_row")
_CAUSE_TO_REASON = {"stale_input": "stale_source_data", "row_count": "row_count_drift", "source_moved": "source_moved_since_import", "run_date": "key_reads_run_date",
                    "case_collapse": "case_collapse", "unexplained": "unexplained"}
_NON_DATA_VISUALS = ("slicer", "textbox")
_NOT_TEXT = ("numeric", "long", "double", "decimal", "date", "datetime", "timestamp")      # model.with_trimmed_text widens text only


_CLOCK = re.compile(r"\b(?:TODAY|NOW|UTCTODAY|UTCNOW)\s*\(", re.IGNORECASE)
_MEASURE_REF = re.compile(r"(?<!')\[([^\]]+)\]")        # `[Name]` is a measure; `'T'[Name]` is a column that may share its name


def _non_data_label(visual: dict[str, Any]) -> str:
    return visual.get("title") or visual.get("text") or visual.get("sync_group") or visual.get("visual_type")


def _slicer_table(visual: dict[str, Any]) -> str | None:
    for field in ((visual.get("buckets") or {}).get("Values") or []):
        if isinstance(field, dict) and field.get("table"):
            return str(field["table"])
    return None


def _unmapped_named(kind: str, detail: Any) -> tuple[str, str]:
    """What the review item of a dashboard filter / layout component that was not carried over names: `(names, why)`, or
    `("", "")` when its detail names nothing. The element says which one it is, not only how many ('1 dashboard filter(s) have
    no Power BI equivalent' next to a filter called 'DRG No & Name' that no table has a column for)."""
    detail = detail if isinstance(detail, dict) else {}
    if kind == "dashboard_filters_unmapped":
        found = [(f.get("label"), f.get("reason")) for f in detail.get("filters") or [] if isinstance(f, dict) and f.get("label")]
    elif kind == "layout_components_unmapped":
        found = [(" ".join(str(c[k]) for k in ("type", "label") if c.get(k)), f"on page {c['page']}" if c.get("page") else "")
                 for c in detail.get("components") or [] if isinstance(c, dict) and (c.get("type") or c.get("label"))]
    else:
        return "", ""
    if not found:
        return "", ""
    names = ", ".join(str(n) for n, _ in found[:3]) + (f" and {len(found) - 3} more" if len(found) > 3 else "")
    return names, "; ".join(f"{n}: {w}" if w else str(n) for n, w in found[:3])


def _clock_measures(model: dict[str, Any]) -> set[str]:
    """Names of the model's measures whose DAX reads the clock, directly or through another measure they use."""
    expressions = {m.get("name"): m.get("expression") or ""
                   for t in model.get("tables") or [] for m in t.get("measures") or [] if m.get("name")}
    clock = {n for n, e in expressions.items() if _CLOCK.search(e)}
    while True:
        more = {n for n, e in expressions.items() if n not in clock and any(r in clock for r in _MEASURE_REF.findall(e))}
        if not more:
            return clock
        clock |= more


def _clock_cards(report: dict[str, Any], clock: set[str]) -> set[str]:
    """Origins (card ids) of the report's visuals that show one of those measures."""
    found: set[str] = set()
    for page in report.get("pages") or []:
        for visual in page.get("visuals") or []:
            for fields in (visual.get("buckets") or {}).values():
                if any(isinstance(f, dict) and f.get("kind") == "measure" and f.get("name") in clock for f in fields or []):
                    found.add(str(visual.get("origin")))
    return found


def _has_history_upstream(dataset: str, producer: dict[str, str], inputs_of_flow: dict[str, list[str]],
                          codes_by_dataset: dict[str, list[str]]) -> bool:
    """Whether the dataset, or a dataset its producing flows read from (however far back), accumulates history in Domo."""
    seen: set[str] = set()
    todo = [dataset]
    while todo:
        current = todo.pop()
        if current in seen:
            continue
        seen.add(current)
        if "append_history_not_reproduced" in codes_by_dataset.get(current, []):
            return True
        todo.extend(inputs_of_flow.get(producer.get(current, ""), []))
    return False


def _reads_platform_data(dataset: str, platform: set[str], producer: dict[str, str], inputs_of_flow: dict[str, list[str]]) -> bool:
    """Whether every source the dataset is built from, however far back, is one of the platform's own datasets (Domo's activity log).

    One business source among them and the table may be empty for another reason, so that is not claimed."""
    seen: set[str] = set()
    todo = [dataset]
    roots: set[str] = set()
    while todo:
        current = todo.pop()
        if current in seen:
            continue
        seen.add(current)
        inputs = inputs_of_flow.get(producer.get(current, ""))
        if inputs:
            todo.extend(inputs)
        else:
            roots.add(current)
    return bool(roots) and roots <= platform


def _widened_blank_values(report: dict[str, Any]) -> dict[str, list[dict[str, str]]]:
    """card id -> the (column, value) pairs of its IN filters whose value ends in a blank and that the model matches differently from Domo.

    `blank_held` is the model's answer to "which spellings does the data hold" (`Table.blank_values`): "trimmed" and "neither"
    keep the value as written, as Domo applies it; "blank" widens it where the widening changes nothing (no row without the
    blank). Left are "both" (the engine cannot tell 'CC ' from 'CC', Domo can) and no answer (a run of an older build, an
    offline export, a query that failed), where the widened filter may keep rows Domo's drops."""
    found: dict[str, list[dict[str, str]]] = {}
    for page in report.get("pages") or []:
        for visual in page.get("visuals") or []:
            for flt in visual.get("filters") or []:
                if flt.get("kind") != "in" or str(flt.get("data_type") or "").lower() in _NOT_TEXT:
                    continue
                for value in flt.get("values") or []:
                    if isinstance(value, str) and value != value.rstrip() and (flt.get("blank_held") or {}).get(value, "both") == "both":
                        found.setdefault(str(visual.get("origin")), []).append({
                            "column": flt.get("column"), "value": value, "data_holds": (flt.get("blank_held") or {}).get(value, "unknown")})
    return found


def _moved_evidence(entry: dict[str, Any]) -> dict[str, Any]:
    """One moved input as the evidence shows it: both row counts, the gap, and whose count Domo's is (`domo` = asked now, `scan`)."""
    domo, warehouse = entry["domo_rows"], entry["warehouse_rows"]
    return {"dataset": entry.get("dataset"), "domo_rows": domo, "warehouse_rows": warehouse,
            "percent_apart": round(abs(warehouse - domo) * 100 / domo, 2) if domo else None, "domo_rows_from": entry.get("domo_rows_from")}


def _el(kind: str, element_id: str, name: str | None, code: str, **extra: Any) -> dict[str, Any]:
    status, text = REASONS[code]
    return {"id": f"{kind}:{element_id}", "kind": kind, "name": name, "status": status,
            "reason": {"code": code, "text": text}, **extra}


def _fmt(value: Any) -> Any:
    return round(value, 6) if isinstance(value, float) else value


def _visual_element(card: dict[str, Any], rows: list[dict[str, Any]], skip: dict[str, Any] | None,
                    parity_checked: bool, cause: str | None, flow_codes: list[str], table_empty: bool = False,
                    upstream_history: bool = False, tables_short: bool = False, platform_data: bool = False,
                    null_column: bool = False, blank_values: list[dict[str, str]] | None = None,
                    moved_inputs: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    cid = str(card["id"])
    name = card.get("name")
    # `source_moved` names no flow and no value: any cause the run can tie to a flow, a column or a table says more and wins over it.
    open_cause = cause in (None, "unexplained", "source_moved")
    if rows:
        bad = [r for r in rows if r.get("state") == "error"]
        if not bad:
            return _el("visual", cid, name, "figures_equal",
                       evidence={"values_compared": len(rows), "within_tolerance": sum(1 for r in rows if r.get("state") == "warn")})
        worst = max((r for r in bad if r.get("delta") is not None), key=lambda r: abs(r["delta"]), default=bad[0])
        code = min(flow_codes, key=_ARBITRARY_RANK.index) if flow_codes and open_cause else _CAUSE_TO_REASON.get(cause or "unexplained", "unexplained")
        # A clock moves values; it does not remove rows. When everything that differs is a row Domo has and the model lacks, the
        # history the dataset accumulated explains it better than the run date (Accts Receivable-SW 'Monthly SnapShot': 52 values,
        # every one an old snapshot date, none the model's alone).
        # The model's table has to be short of Domo's rows too (a measure that is blank drops its row from the comparison as a missing one).
        if ((code in ("source_reads_run_date", "measure_reads_clock") and "append_history_not_reproduced" in flow_codes
             or code == "unexplained" and open_cause and upstream_history)
                and tables_short
                and all(r.get("source") is not None and r.get("target") is None for r in bad)):
            code = "append_history_not_reproduced"
        # A filter value the model matches more widely than Domo does names a column and a value: it says more than a count that moved.
        if blank_values and open_cause and code in ("unexplained", "source_moved_since_import"):
            code = "blank_filter_value"
        # Domo drew no row at all (every compared value is the model's alone): a card Domo's render draws empty,
        # Utilization Review's 'Test Cases (IP Acute) for Segments'. A rule about Domo's render, so it comes first.
        # A key Domo drew with a blank cell (`source_row`) is not that; rows of earlier runs lack the field.
        if open_cause and all(
                r.get("source") is None and r.get("target") is not None and not r.get("source_row") for r in rows):
            code = "domo_draws_nothing"
        # A column the warehouse table lacks is supplied as NULL (a review item names it): what is keyed on or measured over it cannot pair.
        if null_column and open_cause:
            code = "column_supplied_empty"
        # A table that holds nothing explains every value read from it, whatever the flows or Domo's render did
        # (YOY Clinic Posting Date-SW: the 20M-row Charge Claims load timed out, 3,005 values read 'unexplained').
        if table_empty and open_cause:
            code = "platform_data_not_landed" if platform_data else "model_table_empty"
        return _el("visual", cid, name, code, evidence={
            "values_compared": len(rows), "values_differing": len(bad),
            "largest_gap": {"grain": worst.get("grain"), "source": _fmt(worst.get("source")),
                            "target": _fmt(worst.get("target")), "delta": _fmt(worst.get("delta"))},
            **({"blank_filter_values": blank_values} if code == "blank_filter_value" else {}),
            **({"moved_inputs": [_moved_evidence(e) for e in moved_inputs]} if code == "source_moved_since_import" and moved_inputs else {})})
    if skip:
        reason = skip.get("reason") if skip.get("reason") in REASONS else "not_compared"
        return _el("visual", cid, name, reason, evidence={"visual_type": skip.get("visual_type"),
                                                          **({"domo_says": skip["detail"]} if skip.get("detail") else {}),
                                                          **({"model_says": skip["model_error"]} if skip.get("model_error") else {})})
    return _el("visual", cid, name, "parity_not_run" if not parity_checked else "no_figures")


def assess(*, closure: dict[str, Any], report: dict[str, Any], model: dict[str, Any], parity: dict[str, Any],
           reviews: list[dict[str, Any]], causes: dict[str, Any] | None = None) -> dict[str, Any]:
    """`{elements: [...], tally: {...}}` for one run. Elements are listed with what needs a reader first."""
    checked = bool(parity.get("checked"))
    rows_by_card: dict[str, list[dict[str, Any]]] = {}
    for row in parity.get("rows") or []:
        rows_by_card.setdefault(str(row.get("card_id")), []).append(row)
    skipped = {str(s.get("card_id")): s for s in parity.get("skipped") or []}
    by_card_cause = ((causes or {}).get("by_card")) or {}
    open_reviews = [r for r in reviews if r.get("status") in (None, "open")]
    review_for: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for r in open_reviews:
        review_for.setdefault((r.get("kind"), str(r.get("source_id"))), []).append(r)
    kinds_present = {r.get("kind") for r in open_reviews}

    # Flows that explain a differing figure without parity's own cause: card -> dataset -> producing dataflow. The closure
    # names the producer on the dataset (`produced_by`); an append-history review is about the dataset itself.
    producer = {str(d["id"]): str(d["produced_by"]) for d in closure.get("datasets") or [] if d.get("produced_by") is not None}
    flow_codes_by_flow: dict[str, list[str]] = {}
    codes_by_dataset: dict[str, list[str]] = {}
    for r in open_reviews:
        code = _ARBITRARY.get(r.get("kind"))
        if code and r.get("source_id") is not None:
            target = codes_by_dataset if r.get("source_type") == "dataset" else flow_codes_by_flow
            target.setdefault(str(r["source_id"]), []).append(code)

    inputs_of_flow = {str(f["id"]): [str(i) for i in f.get("input_dataset_ids") or []] for f in closure.get("dataflows") or []}
    elements: list[dict[str, Any]] = []
    clock_cards = _clock_cards(report, _clock_measures(model))
    cards = {str(c["id"]): c for c in closure.get("cards") or []}
    origin_of_table = {t.get("name"): str(t.get("origin")) for t in model.get("tables") or []}
    empty_origins = {origin_of_table[t["table"]] for t in parity.get("table_rows") or []
                     if t.get("table") in origin_of_table and t.get("model_rows") == 0 and (t.get("domo_rows") or 0) > 0}
    platform = {str(d["id"]) for d in closure.get("datasets") or []
                if d.get("produced_by") is None and classify_source(d.get("provider_type"), None)["category"] == "platform_internal"}
    platform_origins = {o for o in empty_origins if _reads_platform_data(o, platform, producer, inputs_of_flow)}
    null_columns: dict[str, set[str]] = {}
    for r in open_reviews:
        if r.get("kind") == "column_supplied_as_null" and isinstance(r.get("detail"), dict):
            null_columns.setdefault(str(r.get("source_id")), set()).update(str(c).lower() for c in r["detail"].get("columns") or [])
    reads_null: set[str] = set()
    if null_columns:
        for page in report.get("pages") or []:
            for visual in page.get("visuals") or []:
                for fields in (visual.get("buckets") or {}).values():
                    if any(isinstance(f, dict) and f.get("kind") == "column" and str(f.get("name")).lower() in null_columns.get(origin_of_table.get(f.get("table"), ""), ())
                           for f in fields or []):
                        reads_null.add(str(visual.get("origin")))
    blank_values = _widened_blank_values(report)
    short_origins = {origin_of_table[t["table"]] for t in parity.get("table_rows") or []
                     if t.get("table") in origin_of_table and (t.get("domo_rows") or 0) > (t.get("model_rows") or 0)
                     and not within_drift(t.get("domo_rows") or 0, t.get("model_rows") or 0)}
    placed: set[str] = set()
    for page in report.get("pages") or []:
        for visual in page.get("visuals") or []:
            origin = str(visual.get("origin"))
            if origin in cards:
                placed.add(origin)

    for cid, card in cards.items():
        if (card.get("card_type") or "").lower() in ("text", "document") and cid not in rows_by_card:
            elements.append(_el("visual", cid, card.get("name"), "text_carried" if cid in placed else "carries_no_figures"))
            continue
        blocked = next((k for k in ("unmapped_card", "card_without_dataset", "visual_will_not_draw") if (k, cid) in review_for), None)
        if blocked and cid not in placed and not rows_by_card.get(cid):
            elements.append(_el("visual", cid, card.get("name"), blocked, evidence={"review": review_for[(blocked, cid)][0].get("title")}))
            continue
        flow_codes = (["measure_reads_clock"] if cid in clock_cards else []) + [
            c for ds in card.get("dataset_ids") or []
            for c in codes_by_dataset.get(str(ds), []) + flow_codes_by_flow.get(producer.get(str(ds), ""), [])]
        table_empty = any(str(ds) in empty_origins for ds in card.get("dataset_ids") or [])
        upstream_history = any(_has_history_upstream(str(ds), producer, inputs_of_flow, codes_by_dataset) for ds in card.get("dataset_ids") or [])
        tables_short = any(str(ds) in short_origins for ds in card.get("dataset_ids") or [])
        empty_read = [str(ds) for ds in card.get("dataset_ids") or [] if str(ds) in empty_origins]
        platform_data = bool(empty_read) and all(ds in platform_origins for ds in empty_read)      # one business table empty too: say the plain thing
        elements.append(_visual_element(card, rows_by_card.get(cid, []), skipped.get(cid), checked, by_card_cause.get(cid), flow_codes,
                                        table_empty, upstream_history, tables_short, platform_data, cid in reads_null,
                                        blank_values.get(cid),
                                        parity_causes.moved_inputs_of([str(d) for d in card.get("dataset_ids") or []], closure, parity)))

    # Pages, slicers, text boxes and drill pages of the report.
    labels = Counter(_non_data_label(v) for p in report.get("pages") or [] for v in p.get("visuals") or []
                                 if v.get("visual_type") in _NON_DATA_VISUALS and str(v.get("origin")) not in cards)
    for page in report.get("pages") or []:
        name = page.get("display_name") or page.get("name")
        elements.append(_el("drill" if page.get("drillthrough") else "page", str(page.get("name")), name, "structure_only"))
        for visual in page.get("visuals") or []:
            if visual.get("visual_type") in _NON_DATA_VISUALS and str(visual.get("origin")) not in cards:
                label = _non_data_label(visual)
                if labels[label] > 1 and (table := _slicer_table(visual)):      # three 'Attributed Provider Group' slicers, one per table
                    label = f"{label} ({table})"
                elements.append(_el("filter" if visual["visual_type"] == "slicer" else "text",
                                    f"{page.get('name')}/{visual.get('origin')}", label, "carries_no_figures"))
    for kind in ("dashboard_filters_unmapped", "layout_components_unmapped", "drill_view_not_migrated", "drill_view_columns_missing"):
        for r in open_reviews:
            if r.get("kind") == kind:
                el_kind = "drill" if kind.startswith("drill") else "filter" if kind.startswith("dashboard") else "layout"
                named, why = _unmapped_named(kind, r.get("detail"))
                elements.append(_el(el_kind, f"{kind}/{r.get('id')}", named or r.get("title"), kind,
                                    **({"evidence": {"review": why}} if named else {})))

    # Tables: row counts, from parity.
    table_rows = {t.get("table"): t for t in parity.get("table_rows") or []}
    for table in model.get("tables") or []:
        tname = table.get("name")
        origin = str(table.get("origin"))
        blocked = next((k for k in ("table_without_source", "missing_table") if (k, origin) in review_for), None)
        evidence = table_rows.get(tname)
        if blocked:
            elements.append(_el("table", tname, tname, blocked))
        elif evidence is None:
            elements.append(_el("table", tname, tname, "no_row_evidence"))
        elif evidence.get("model_rows") == 0 and (evidence.get("domo_rows") or 0) > 0:
            elements.append(_el("table", tname, tname, "platform_data_not_landed" if origin in platform_origins else "model_table_empty",
                                evidence={"source_rows": evidence.get("domo_rows"), "warehouse_rows": 0}))
        elif evidence.get("differs"):
            elements.append(_el("table", tname, tname, "row_count_drift",
                                evidence={"source_rows": evidence.get("domo_rows"), "warehouse_rows": evidence.get("model_rows")}))
        else:
            elements.append(_el("table", tname, tname, "row_counts_equal",
                                evidence={"source_rows": evidence.get("domo_rows"), "warehouse_rows": evidence.get("model_rows")}))

    # Measures: matches only when the visuals that use them were compared and all match.
    status_of_visual = {e["id"].split(":", 1)[1]: e["status"] for e in elements if e["kind"] == "visual"}
    uses: dict[str, set[str]] = {}
    for page in report.get("pages") or []:
        for visual in page.get("visuals") or []:
            for fields in (visual.get("buckets") or {}).values():
                for field in fields:
                    uses.setdefault(field.get("name"), set()).add(str(visual.get("origin")))
    for table in model.get("tables") or []:
        for measure in table.get("measures") or []:
            mname = measure.get("name")
            ident = f"{table.get('name')}.{mname}"
            if measure.get("needs_review"):
                elements.append(_el("measure", ident, mname, "untranslated_measure"))
                continue
            seen = [status_of_visual[v] for v in uses.get(mname, set()) if v in status_of_visual]
            compared = [s for s in seen if s in (MATCHES, DIFFERS)]
            if compared and all(s == MATCHES for s in compared):
                elements.append(_el("measure", ident, mname, "every_visual_using_it_matches", evidence={"visuals": len(compared)}))
            elif DIFFERS in compared:
                elements.append(_el("measure", ident, mname, "used_by_differing_visuals", evidence={"visuals": len(compared)}))
            else:
                elements.append(_el("measure", ident, mname, "no_visual_uses_it"))

    # Row-level-security roles.
    for role in model.get("roles") or []:
        rname = role.get("name")
        if not role.get("members") and "rls_roles_without_members" in kinds_present:
            elements.append(_el("rls_role", rname, rname, "members_not_mapped"))
        else:
            elements.append(_el("rls_role", rname, rname, "roles_not_compared"))
    for r in open_reviews:  # a policy that could not become a role has no role to list
        if r.get("kind") == "rls_unsupported":
            elements.append(_el("rls_role", f"unsupported/{r.get('id')}", r.get("title"), "rls_unsupported"))

    # Two cards of one name (Accts Receivable: two 'customer ATB Comparison') read as one row listed twice: the card id tells them apart.
    card_names = Counter(e["name"] for e in elements if e["kind"] == "visual" and e["name"])
    for e in elements:
        if e["kind"] == "visual" and e["name"] and card_names[e["name"]] > 1:
            e["name"] = f"{e['name']} (card {e['id'].split(':', 1)[1]})"

    # Several headers of one page share the origin "header": an id names one element (the console keys its rows by it).
    occurrences: Counter = Counter()
    for e in elements:
        occurrences[e["id"]] += 1
        if occurrences[e["id"]] > 1:
            e["id"] = f"{e['id']}#{occurrences[e['id']]}"

    order = {s: i for i, s in enumerate(STATUSES)}
    kinds = {k: i for i, k in enumerate(KIND_ORDER)}
    elements.sort(key=lambda e: (order[e["status"]], kinds.get(e["kind"], len(kinds)), e["kind"], str(e.get("name") or "")))
    return {"elements": elements, "tally": tally(elements)}


def tally(elements: list[dict[str, Any]]) -> dict[str, Any]:
    """Counts per status overall and per element kind, and per reason code (so 'unexplained' is a number)."""
    overall = Counter(e["status"] for e in elements)
    by_kind: dict[str, Counter] = {}
    reasons: Counter = Counter()
    for e in elements:
        by_kind.setdefault(e["kind"], Counter())[e["status"]] += 1
        reasons[(e["status"], e["reason"]["code"])] += 1
    return {
        "total": len(elements),
        "by_status": {s: overall.get(s, 0) for s in STATUSES},
        "by_kind": {k: {s: c.get(s, 0) for s in STATUSES} for k, c in sorted(by_kind.items())},
        "reasons": [{"status": s, "code": c, "count": n} for (s, c), n in sorted(reasons.items(), key=lambda kv: (STATUSES.index(kv[0][0]), -kv[1]))],
    }

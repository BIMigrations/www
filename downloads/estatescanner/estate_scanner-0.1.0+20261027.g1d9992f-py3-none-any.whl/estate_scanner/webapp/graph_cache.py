"""Tiny in-process cache for the built networkx graph. Rebuilding it from
SQL is a few seconds for a large estate (60k+ nodes) -- too slow to redo on
every single object-detail click. Invalidated whenever a scan completes.
"""

from __future__ import annotations

import threading

import networkx as nx

from estate_scanner import graph as graph_module

_lock = threading.Lock()
_cache: dict[str | None, nx.DiGraph] = {}


def get_graph(conn, platform: str | None = None) -> nx.DiGraph:
    with _lock:
        if platform not in _cache:
            _cache[platform] = graph_module.build_graph(conn, platform=platform)
        return _cache[platform]


def invalidate() -> None:
    with _lock:
        _cache.clear()

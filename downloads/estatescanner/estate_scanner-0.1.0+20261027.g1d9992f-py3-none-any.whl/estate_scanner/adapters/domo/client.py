"""DomoClient: maps Domo's raw API payloads into the platform-agnostic
domain model (estate_scanner.core.models). This is where every Domo JSON
field name Domo actually uses gets translated into the generic vocabulary
the rest of the system speaks -- nothing outside this file (and http.py's
raw endpoint calls) should ever see a Domo field name.
"""

from __future__ import annotations

import datetime as _dt
from collections.abc import Iterator

from estate_scanner.core.models import (
    Account,
    Alert,
    App,
    AppView,
    CalculatedField,
    Card,
    Dashboard,
    DashboardFilter,
    Dataflow,
    Dataset,
    Group,
    ObjectRef,
    User,
)
from estate_scanner.core.platform import PlatformClient

from .auth import DomoSession
from .http import DomoHttp

_ESTIMATE_ENTITY = {
    "user": "USER", "group": "GROUP", "account": "ACCOUNT", "dataflow": "DATAFLOW",
    "card": "CARD", "dashboard": "PAGE", "calculated_field": "BEAST_MODE", "alert": "ALERT",
    "app": "DATA_APP",
}

# Batch sizes for the "full definition" detail endpoints promoted into the
# default scan (see the module docstring on each fetch_* below for why).
# Cards go via a GET with urns joined into the URL -- kept well under
# typical URL-length limits (confirmed live with 17 urns in one call).
# Beast Mode formulas go via a POST with a JSON body, so there's no
# URL-length concern; still batched to bound response size per call.
_CARD_DETAIL_BATCH = 75
# What a card's calculations need to be migrated; the rest of each entry (column positions and the like)
# is large and nothing reads it: card details with all of it added ~80 KB per card.
_FORMULA_KEYS = ("id", "templateId", "name", "formula", "dataType", "status", "persistedOnDataSource", "variable")


def _slim_formulas(detail: dict) -> None:
    """Keep each card-level calculation to the fields a migration reads."""
    block = detail.get("formulas")
    inner = block.get("formulas") if isinstance(block, dict) else None
    if isinstance(inner, dict):
        detail["formulas"] = {
            formula_id: {key: entry[key] for key in _FORMULA_KEYS if key in entry}
            for formula_id, entry in inner.items() if isinstance(entry, dict)}
_DRILL_MAX_DEPTH = 3
_DRILL_PARTS = "drillPath,metadata,subscriptions"
_FUNCTION_BATCH = 300


def _s(value) -> str | None:
    return None if value is None else str(value)


def _epoch_ms_to_dt(value) -> _dt.datetime | None:
    if value is None:
        return None
    try:
        return _dt.datetime.fromtimestamp(int(value) / 1000, tz=_dt.timezone.utc)
    except (TypeError, ValueError, OSError):
        return None


class DomoClient(PlatformClient):
    platform = "domo"

    def __init__(self, session: DomoSession, fetch_group_memberships: bool = True):
        super().__init__(session)
        self._http = DomoHttp(session)
        self.fetch_group_memberships = fetch_group_memberships

    def verify_session(self) -> bool:
        from .http import DomoSessionExpiredError
        try:
            self._http.search(["USER"], count=1, offset=0)
            return True
        except DomoSessionExpiredError:
            return False

    # -- Users / groups -------------------------------------------------------

    def fetch_users(self) -> Iterator[User]:
        for obj in self._http.search_all("USER"):
            user_id = _s(obj.get("databaseId"))
            group_ids: list[str] = []
            if self.fetch_group_memberships and user_id:
                try:
                    group_ids = [_s(g.get("id")) for g in self._http.get_user_groups(user_id) if g.get("id") is not None]
                except Exception:
                    pass  # group membership is enrichment, not core identity -- don't fail the whole scan over it
            yield User(
                id=user_id, name=obj.get("displayName"), email=obj.get("emailAddress"),
                role=obj.get("roleName"), title=obj.get("businessRole"),
                group_ids=group_ids, raw_payload=obj,
            )

    def fetch_groups(self) -> Iterator[Group]:
        for obj in self._http.search_all("GROUP"):
            yield Group(id=_s(obj.get("databaseId")), name=obj.get("displayName"), raw_payload=obj)

    def fetch_accounts(self) -> Iterator[Account]:
        for obj in self._http.search_all("ACCOUNT"):
            yield Account(
                id=_s(obj.get("databaseId")), name=obj.get("displayName") or obj.get("name"),
                owner_id=_s(obj.get("ownedById")), connector_type=obj.get("dataProviderType"), raw_payload=obj,
            )

    # -- Datasets / dataflows --------------------------------------------------

    def fetch_datasets(self) -> Iterator[Dataset]:
        for obj in self._http.search_datasources_all():
            owner = obj.get("owner") or {}
            schema_tables = (obj.get("schema") or {}).get("tables") or []
            schema_columns = schema_tables[0].get("columns") if schema_tables else None
            dataset_id = _s(obj.get("id"))
            pdp_policies = None
            if dataset_id:
                try:
                    pdp_policies = self._http.get_dataset_pdp_policies(dataset_id)
                except Exception:
                    pass  # enrichment; null (not captured) is distinguishable from [] (no policies)
            yield Dataset(
                id=_s(obj.get("id")), name=obj.get("name"), owner_id=_s(owner.get("id")),
                provider_type=obj.get("dataProviderType"),
                # Only available via a per-dataset detail call
                # (get_dataset_details), not this bulk listing -- left null
                # in the default scan rather than paying 1 extra request per
                # dataset for a narrow-value field. fetch_dataset_detail()
                # below populates it on demand.
                stream_id=None,
                row_count=obj.get("rowCount"), column_count=obj.get("columnCount"),
                schema_columns=schema_columns,
                created_at=_epoch_ms_to_dt(obj.get("created")), updated_at=_epoch_ms_to_dt(obj.get("lastUpdated")),
                downstream_card_count=obj.get("impactCardCount"),
                downstream_dataflow_count=obj.get("impactDataFlowCount"),
                downstream_dataset_count=obj.get("impactDataSourceCount"),
                downstream_alert_count=obj.get("impactAlertCount"),
                pdp_policies=pdp_policies,
                raw_payload=obj,
            )

    def fetch_dataflows(self) -> Iterator[Dataflow]:
        """The full per-tile transform DAG is fetched for every dataflow
        here (one extra request each) -- promoted from opt-in enrichment
        into the default scan, since it's what a migration actually needs
        to regenerate the ETL, not just its input/output lineage."""
        for obj in self._http.search_all("DATAFLOW"):
            status = obj.get("status")
            engine = (obj.get("dataFlowType") or "").lower() or None
            df_id = _s(obj.get("databaseId"))
            definition = None
            if df_id:
                try:
                    definition = self._http.get_dataflow(df_id)
                except Exception:
                    pass  # full definition is enrichment; the summary fields above still stand
            yield Dataflow(
                id=df_id, name=obj.get("name"), owner_id=_s(obj.get("ownedById")),
                engine=engine, is_deleted=bool(obj.get("deleted")),
                input_dataset_ids=[_s(d.get("id")) for d in obj.get("inputDatasets") or [] if d.get("id")],
                output_dataset_ids=[_s(d.get("id")) for d in obj.get("outputDatasets") or [] if d.get("id")],
                last_run_state=status,
                last_run_failed=(status not in ("SUCCESS", "ENABLED")) if status else None,
                last_run_at=_epoch_ms_to_dt(obj.get("lastRunDate") or obj.get("createDate")),
                definition=definition,
                raw_payload=obj,
            )

    def fetch_dataset_detail(self, dataset_id: str) -> dict | None:
        """Opt-in deep enrichment: connector configuration (incl. streamId
        and, for SQL-based connectors, the raw query text) -- one extra
        request each, not part of the default scan."""
        detail = self._http.get_dataset_details(dataset_id)
        stream_id = _s(detail.get("streamId"))
        result = {"stream_id": stream_id, "detail": detail}
        if stream_id:
            try:
                result["stream"] = self._http.get_stream_details(stream_id)
            except Exception:
                pass
        return result

    def fetch_dataflow_detail(self, dataflow_id: str) -> dict | None:
        """Opt-in deep enrichment: the full per-tile Magic ETL DAG."""
        return self._http.get_dataflow(dataflow_id)

    # -- Cards / dashboards -----------------------------------------------------

    def fetch_cards(self) -> Iterator[Card]:
        """Full chart definitions are fetched in batches (not one call per
        card -- there can be tens of thousands) via the same endpoint the
        card editor itself uses, promoted from opt-in into the default
        scan for the same migration-fidelity reason as fetch_dataflows."""
        batch: list[dict] = []
        for obj in self._http.search_all("CARD"):
            batch.append(obj)
            if len(batch) >= _CARD_DETAIL_BATCH:
                yield from self._cards_with_detail(batch)
                batch = []
        if batch:
            yield from self._cards_with_detail(batch)

    def _cards_with_detail(self, batch: list[dict]) -> Iterator[Card]:
        urns = [_s(o.get("databaseId")) for o in batch if o.get("databaseId") is not None]
        detail_by_id: dict[str, dict] = {}
        if urns:
            try:
                for detail in self._http.get_cards_detail(urns):
                    detail_id = _s(detail.get("id") or detail.get("urn"))
                    if detail_id:
                        detail_by_id[detail_id] = detail
            except Exception:
                pass  # full definitions are enrichment; the search summary below still stands
        for detail in detail_by_id.values():
            _slim_formulas(detail)
        for card_id, detail in detail_by_id.items():
            views = self._fetch_drill_views(card_id, detail)
            if views:
                detail["drillViews"] = views  # additive: absent when the card has no drill path
        for obj in batch:
            card_id = _s(obj.get("databaseId"))
            yield Card(
                id=card_id, name=obj.get("title"), owner_id=_s(obj.get("ownedById")),
                card_type=obj.get("cardType"),
                dataset_ids=[_s(d) for d in obj.get("dataSourceIds") or [] if d is not None],
                definition=detail_by_id.get(card_id),
                raw_payload=obj,
            )

    def _fetch_drill_views(self, card_id: str, detail: dict) -> dict[str, dict]:
        """Drill ids in a card's drillPath are derived cards `dr:<viewId>:<cardId>`
        that no listing returns. Fetch them (read-only), level by level to the
        depth Domo allows, keyed by view id. Each view keeps its own drillPath,
        so the nesting is recoverable. Best effort: a failure leaves the card
        without views rather than failing the scan."""
        views: dict[str, dict] = {}
        pending = list(((detail.get("drillPath") or {}).get("paths") or {}))
        for _ in range(_DRILL_MAX_DEPTH):
            pending = [v for v in pending if v not in views]
            if not pending:
                break
            nxt: list[str] = []
            try:
                for view in self._http.get_cards_detail([f"dr:{v}:{card_id}" for v in pending], parts=_DRILL_PARTS):
                    view_id = _s(view.get("id"))
                    if view_id:
                        views[view_id] = view
                        nxt.extend((view.get("drillPath") or {}).get("paths") or {})
            except Exception:
                break
            pending = nxt
        return views

    def fetch_dashboards(self) -> Iterator[Dashboard]:
        """Scans the union of the general PAGE search results and every
        app-view id discovered by fetch_apps() (run first -- see
        core/orchestrator.py's phase order). App views are dashboards in
        their own right (Domo's own "Data App View" page sub-type) but
        don't reliably show up in the general PAGE index, so without this
        union an app's own screens would silently never get scanned."""
        pages = list(self._http.search_all("PAGE"))
        page_ids = [_s(p.get("urn") or p.get("databaseId")) for p in pages]
        seen_ids = set(page_ids)
        extra_views = getattr(self, "_extra_dashboard_views", {})
        extra_ids = [vid for vid in extra_views if vid not in seen_ids]
        all_ids = page_ids + extra_ids

        parent_by_child: dict[str, str] = {}
        if all_ids:
            try:
                summary = self._http.get_subpages_summary(all_ids)
                for entry in summary:
                    parent_id = _s(entry.get("pageId"))
                    for child in entry.get("children") or []:
                        child_id = _s(child.get("pageId"))
                        if child_id and parent_id:
                            parent_by_child[child_id] = parent_id
            except Exception:
                pass  # hierarchy is enrichment; most Domo estates are flat anyway

        for obj in pages:
            page_id = _s(obj.get("urn") or obj.get("databaseId"))
            card_ids, filters, layout = self._fetch_dashboard_content(page_id)
            yield Dashboard(
                id=page_id, name=obj.get("title"), owner_id=_s(obj.get("ownedById")),
                parent_id=parent_by_child.get(page_id), card_ids=card_ids, filters=filters,
                layout=layout, raw_payload=obj,
            )

        for page_id in extra_ids:
            view = extra_views[page_id]
            card_ids, filters, layout = self._fetch_dashboard_content(page_id)
            yield Dashboard(
                id=page_id, name=view.get("title"),
                parent_id=parent_by_child.get(page_id) or view.get("parentViewId"),
                card_ids=card_ids, filters=filters, layout=layout, raw_payload=view,
            )

    def _fetch_dashboard_content(self, page_id: str) -> tuple[list[str], list[DashboardFilter], dict | None]:
        card_ids: list[str] = []
        layout: dict | None = None
        try:
            stack = self._http.get_page_cards(page_id)
            card_ids = [_s(c.get("id") or c.get("urn")) for c in stack.get("cards") or [] if c.get("id") or c.get("urn")]
            layout = stack.get("pageLayoutV4")
        except Exception:
            pass  # e.g. a page this session can't access

        filters: list[DashboardFilter] = []
        try:
            analyzer = self._http.get_page_filters(page_id)
            filters = [
                DashboardFilter(field=f.get("column"), label=f.get("column"), filter_type=f.get("filterType"), raw_payload=f)
                for f in analyzer.get("filters") or []
            ]
        except Exception:
            pass

        return card_ids, filters, layout

    # -- Calculated fields / alerts / apps ---------------------------------------

    def fetch_calculated_fields(self) -> Iterator[CalculatedField]:
        """Domo's unified search index never exposes the actual formula
        text (only which columns/functions it references) -- the real
        expression comes from a dedicated batch endpoint, promoted into
        the default scan for the same migration-fidelity reason as
        fetch_dataflows/fetch_cards."""
        batch: list[dict] = []
        for obj in self._http.search_all("BEAST_MODE"):
            batch.append(obj)
            if len(batch) >= _FUNCTION_BATCH:
                yield from self._calculated_fields_with_detail(batch)
                batch = []
        if batch:
            yield from self._calculated_fields_with_detail(batch)

    def _calculated_fields_with_detail(self, batch: list[dict]) -> Iterator[CalculatedField]:
        ids = [_s(o.get("databaseId")) for o in batch if o.get("databaseId") is not None]
        detail_by_id: dict = {}
        if ids:
            try:
                detail_by_id = self._http.get_functions_batch(ids) or {}
            except Exception:
                pass  # the expression is enrichment; the search summary below still stands

        for obj in batch:
            bm_id = _s(obj.get("databaseId"))
            links = obj.get("links") or []
            detail = detail_by_id.get(bm_id) if bm_id else None
            yield CalculatedField(
                id=bm_id, name=obj.get("name"), owner_id=_s(obj.get("owner")),
                status=obj.get("status"), data_type=obj.get("datatype"),
                is_global=bool(obj.get("global")), is_locked=bool(obj.get("locked")),
                formula_language="domo_beast_mode",
                formula=detail.get("expression") if detail else None,
                definition=detail,
                # Fixes a real casing bug from the original scan code:
                # link["type"] must be lowercased to match the lowercase
                # object_type vocabulary everywhere else, or these edges
                # silently fail to resolve against the typed tables.
                linked_object_refs=[
                    ObjectRef(link["type"].lower(), _s(link["id"]))
                    for link in links if link.get("type") and link.get("id") is not None
                ],
                raw_payload=obj,
            )

    def fetch_alerts(self) -> Iterator[Alert]:
        for obj in self._http.search_all("ALERT"):
            resource_type = obj.get("resourceType")
            resource_id = obj.get("resourceId")
            watched = ObjectRef(resource_type.lower(), _s(resource_id)) if resource_type and resource_id else None
            yield Alert(
                id=_s(obj.get("databaseId")), name=obj.get("name"), owner_id=_s(obj.get("ownedById")),
                rule=obj.get("rule"), watched_object=watched, disabled=bool(obj.get("disabled")),
                raw_payload=obj,
            )

    def fetch_apps(self) -> Iterator[App]:
        """Runs before fetch_dashboards() (see core/orchestrator.py's phase
        order) so the app-view ids discovered here (self._extra_dashboard_views)
        are ready for fetch_dashboards() to union in -- otherwise a Data
        App's own screens (which don't reliably show up in the general
        PAGE search) would never get scanned as dashboards at all.

        /api/content/v1/dataapps only returns a narrow subset (e.g. apps
        the current user owns/can edit) -- search_all("DATA_APP") is the
        complete inventory. The per-app detail call (authoring=true,
        includeHiddenViews=true) is what actually shows what an app is
        made of: every view (each IS a dashboard id), the nav menu
        structure, and the branding theme -- promoted into the default
        scan for the same reason as the other "full definition" fetches.
        """
        landing_by_id: dict[str, str] = {}
        try:
            for obj in self._http.list_dataapps():
                app_id = _s(obj.get("dataAppId"))
                landing_id = _s(obj.get("landingViewId"))
                if app_id and landing_id:
                    landing_by_id[app_id] = landing_id
        except Exception:
            pass

        self._extra_dashboard_views: dict[str, dict] = {}

        for obj in self._http.search_all("DATA_APP"):
            app_id = _s(obj.get("databaseId"))
            owners = obj.get("owners") or []
            owner_id = _s(owners[0].get("id")) if owners else None

            views: list[AppView] = []
            navigations: list[dict] = []
            theme: dict | None = None
            if app_id:
                try:
                    detail = self._http.get_app_detail(app_id)
                    navigations = detail.get("navigations") or []
                    theme = detail.get("theme")
                    for v in detail.get("views") or []:
                        view_id = _s(v.get("viewId"))
                        if not view_id:
                            continue
                        parent_view_id = _s(v.get("parentViewId")) if v.get("parentViewId") else None
                        views.append(AppView(
                            view_id=view_id, title=v.get("title"), parent_view_id=parent_view_id,
                            view_order=v.get("viewOrder"), visible=bool(v.get("visible", True)),
                        ))
                        self._extra_dashboard_views[view_id] = {
                            "title": v.get("title"), "parentViewId": parent_view_id,
                        }
                except Exception:
                    pass  # views/navigations/theme are enrichment; the search summary below still stands

            yield App(
                id=app_id, name=obj.get("title"), owner_id=owner_id, app_type="data_app",
                landing_dashboard_id=landing_by_id.get(app_id),
                views=views, navigations=navigations, theme=theme,
                raw_payload=obj,
            )

    # -- Progress estimation ------------------------------------------------

    def estimate_total(self, object_type: str) -> int | None:
        if object_type == "dataset":
            body = self._http.search_datasources(count=0, offset=0)
            return body.get("_metaData", {}).get("totalCount")
        entity = _ESTIMATE_ENTITY.get(object_type)
        if not entity:
            return None
        body = self._http.search([entity], count=0, offset=0)
        return body.get("totalResultCount")

"""Tiny in-process cache for the built networkx graph. Rebuilding it from
SQL is a few seconds for a large estate (60k+ nodes) -- too slow to redo on
every single object-detail click. Invalidated whenever a scan completes.
"""

from __future__ import annotations

import threading

import networkx as nx

from estate_scanner import graph as graph_module
from estate_scanner.storage import db

_lock = threading.Lock()
_cache: dict[tuple, nx.DiGraph] = {}


def get_graph(conn, platform: str | None = None, instance: str | None = None) -> nx.DiGraph:
    """The graph the screens show: with several instances of a platform and none named, the newest scan's."""
    pairs = tuple(db.scope(conn, platform, instance, latest=True))
    with _lock:
        if pairs not in _cache:
            _cache[pairs] = graph_module.build_graph(conn, platform=platform, instance=instance, latest=True)
        return _cache[pairs]


def invalidate() -> None:
    with _lock:
        _cache.clear()

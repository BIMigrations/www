"""What may be stored from a Tableau connection, and what never is.

A workbook's connection elements carry whatever the driver wanted: ``password`` in older files,
OAuth blobs (``server-oauth``), ``odbc-connect-string-extras`` holding ``PWD=...``, SAS and API
tokens, ``one-time-sql`` that logs in. Attribute names are not a closed set (the XSD leaves
connection attributes unvalidated, plan [C R21]), so a list of *bad* names is a list of the ones
someone thought of. The rule here is the other way round:

1. **Allowlist.** Only the attributes in ``CONNECTION_KEEP`` are returned, and only their values.
   Every other attribute is returned as a *name* in ``omitted_attributes`` (so a reader can see that
   something was dropped, and a migration can ask for it by hand), never its value.
2. **Denylist as a second lock.** A name that looks like a secret is dropped even if someone adds it
   to the allowlist later; a test fails if the allowlist ever contains one. ``SAFE_NAMES`` lists the
   names that match a secret pattern by accident and are kept (``authentication`` is how the user
   signs in, not a credential).
3. **Value redaction.** A kept value is still scanned for ``user:password@host`` and
   ``password=...`` inside it (a ``server`` or ``dbname`` that someone pasted a connection string
   into) and the secret part is replaced with ``***``.

What this does not cover, deliberately: a formula's text and a Custom SQL relation's text are the
logic being inventoried and are returned character for character. A credential typed into a
calculation or a query is not a connection attribute and is not found by name; it stays in the
customer's own database like the rest of their estate, and it is stated in the PR and the docs.
"""

from __future__ import annotations

import re
import unicodedata
from typing import Mapping

REDACTED = "***"

# Matched against the lower-cased name with "-", "_", "." and spaces removed, as a substring. Broad on
# purpose: a false positive costs a dropped attribute, a false negative costs a leaked secret.
SECRET_NAME_PARTS = (
    "password", "passwd", "passphrase", "pwd", "pass",
    "token", "secret", "credential", "cred",
    "key",  # authkey, apikey, accesskey, privatekey, sharedkey, keychain
    "auth",  # auth, oauth, authkey, authorization, authtoken
    "sas", "sig", "signature",
    "cookie", "session", "bearer", "jwt", "saml", "cert", "private", "otp", "pin",
)

# Names that contain a pattern by accident and are not credentials. Exact match after normalising.
SAFE_NAMES = frozenset({"authentication", "authenticationtype", "sslmode", "passthrough"})

# The only connection attributes whose values are returned. Names are from memory of real files and
# the XSD's sample connections [unconfirmed: 3.4(b) checks each against sandbox workbooks]; adding a
# name here is a decision that its value is never a secret.
CONNECTION_KEEP = (
    "class", "name", "caption",
    "server", "port", "dbname", "database", "schema", "catalog", "service", "warehouse", "role",
    "project", "dataset", "directory", "filename", "http-path", "workgroup",
    "username", "authentication", "sslmode",
    "tablename", "channel",
)

# -- inline redaction -------------------------------------------------------------------------------------------
# Every pattern below is linear in the length of the text: each starts only at a token boundary, each repeat is
# bounded or consumes what it matches, and an unterminated quote or brace takes the rest of the line instead of
# failing and being retried from the next character.

# A value longer than this is not scanned and not kept: no connection field is, and the scan is for short strings.
MAX_VALUE_CHARS = 2_048
MAX_INLINE_CHARS = 16_384

_URL = re.compile(r"(?P<scheme>[A-Za-z][A-Za-z0-9+.\-]{0,31}://)(?P<rest>[^\s'\"<>]{1,2048})")
_BARE_USERINFO = re.compile(r"(?<![A-Za-z0-9_.\-:/@%])(?P<user>[A-Za-z0-9_.\-]{1,64}):(?P<pw>[^\s'\"/<>]{1,256})@(?=[A-Za-z0-9\[])")
_NOT_CREDENTIALS = frozenset({"mailto", "xmpp", "sip", "sips", "sms", "tel", "urn", "geo"})  # 'scheme:thing@host', not 'user:password@host'
_AUTH_HEADER = re.compile(
    r"(?i)(?<![A-Za-z0-9_.\-:])(?P<key>authorization|proxy-authorization)(?P<sep>\s{0,8}[=:]\s{0,8})(?:(?:bearer|basic|digest|token)\s+)?[^\s;&\"']+"
)
_BEARER = re.compile(r"(?i)(?<![A-Za-z0-9_.\-])(?P<key>bearer\s+)[A-Za-z0-9._~+/=\-]{3,}")
_KEYSEP = re.compile(
    r"""(?<![A-Za-z0-9_.\-:])(?P<key>[A-Za-z0-9_.\-]{1,64})(?P<sep>["']?\s{0,8}(?P<op>[=:])\s{0,8})"""
)
_VALUE = re.compile(
    r"""\{(?:[^}]|\}\}){0,2048}\}   # braced: may hold ';' and spaces
      | "[^"]*" | '[^']*'               # quoted
      | ["'{][^\n]*                     # unterminated: to the end of the line
      | [^;&\s"'}]+                     # bare
    """,
    re.X,
)
_WORD = re.compile(r"[A-Z]+(?![a-z])|[A-Z]?[a-z]+|[0-9]+")
_SECRET_WORDS = frozenset(
    {"password", "passwd", "pwd", "pass", "passphrase", "token", "secret", "credential", "credentials", "cred", "creds",
     "apikey", "key", "accesskey", "authkey", "auth", "authorization", "sas", "sig", "signature", "bearer", "cookie",
     "jwt", "otp", "sid", "pw", "ticket", "session", "sessionid", "oauth", "privatekey", "sharedkey", "secretkey"}
)
_SECRET_SUFFIXES = ("password", "passwd", "passphrase", "secret", "token", "apikey", "accesskey", "privatekey", "authkey",
                    "secretkey", "sharedkey", "signature", "sessionid", "credential", "credentials")
_PORT = re.compile(r"[0-9]{1,5}\Z")


def _is_secret_key(key: str) -> bool:
    """A key is a secret when a whole word of it is (``AccountKey``, ``x-api-key``, ``JSESSIONID``), never for a word that
    merely contains one (``design-db``, ``keycloak``, ``bypass``)."""
    if re.sub(r"[-_.]", "", key.lower()).endswith(_SECRET_SUFFIXES):
        return True
    return any(w.lower() in _SECRET_WORDS for w in _WORD.findall(key))


def _url(match: re.Match[str]) -> str:
    rest = match.group("rest")
    before = rest[: rest.rfind("@")] if "@" in rest else ""
    at = rest.rfind("@")
    if at < 0:
        return match.group(0)
    if "?" in before or "#" in before:  # an '@' in the query or fragment is not the end of the user information
        authority = re.split(r"[/?#]", rest, maxsplit=1)[0]
        at = authority.rfind("@")
        if at < 0:
            return match.group(0)
    return match.group("scheme") + REDACTED + rest[at:]  # keep the '@' and the host


def _keyvals(text: str) -> str:
    """Redact the value of every ``key=value`` / ``key: value`` whose key is a secret. The key and separator are matched
    first and the value only for a secret key, so scanning continues inside the value of an ordinary key (the query
    of a URL) instead of skipping it, and still visits each position once."""
    out: list[str] = []
    pos = last = 0
    while True:
        m = _KEYSEP.search(text, pos)
        if m is None:
            break
        pos = m.end()
        if not _is_secret_key(m.group("key")):
            continue
        value = _VALUE.match(text, pos)
        if value is None:
            continue
        if m.group("op") == ":" and (_PORT.match(value.group(0)) or value.group(0).startswith("//")):
            continue  # host:port, or scheme://: a ':' is a separator only for a real key: value form
        out.append(text[last:pos])
        out.append(REDACTED)
        pos = last = value.end()
    out.append(text[last:])
    return "".join(out)


def _bare(match: re.Match[str]) -> str:
    return match.group(0) if match.group("user").lower() in _NOT_CREDENTIALS else REDACTED + "@"


def _normal(name: str) -> str:
    return re.sub(r"[\s_.\-]", "", name.lower())


def is_secret_name(name: str) -> bool:
    n = _normal(name)
    if n in SAFE_NAMES:
        return False
    return any(part in n for part in SECRET_NAME_PARTS)


def redact_inline(value: str) -> str:
    """``value`` with embedded credentials replaced by ``***``: ``scheme://user:pass@host`` (up to the last ``@`` of
    the authority), ``user:pass@host``, ``Authorization:`` and ``Bearer`` values, and ``key=value`` / ``key: value``
    where the key has a secret word in it (value braced, quoted, unterminated or bare). A host and port, or a
    word that merely contains ``key`` or ``pass``, is left alone. Unchanged when it holds nothing of the sort."""
    if len(value) > MAX_INLINE_CHARS:
        return REDACTED
    value = _URL.sub(_url, value)
    value = _BARE_USERINFO.sub(_bare, value)
    value = _AUTH_HEADER.sub(lambda m: m.group("key") + m.group("sep") + REDACTED, value)
    value = _BEARER.sub(lambda m: m.group("key") + REDACTED, value)
    return _keyvals(value)


def split_attributes(attrib: Mapping[str, str]) -> tuple[dict[str, str], list[str]]:
    """``(kept, omitted names)`` for a connection's attributes. Nothing in ``omitted`` carries a value."""
    kept: dict[str, str] = {}
    omitted: list[str] = []
    for name, value in attrib.items():
        if name in CONNECTION_KEEP and not is_secret_name(name) and len(value) <= MAX_VALUE_CHARS:
            kept[name] = redact_inline(value)
        else:
            omitted.append(name)
    return kept, sorted(omitted)


# -- free text that is stored (3.8) ---------------------------------------------------------------------------------------------------------------
# Letters a hostile text may swap for look-alikes in a key ("p\u0430ssword"): the Cyrillic and Greek ones that read as a Latin letter, and the small capitals.
# The keys are lower case: the map is applied AFTER the case fold, so the capital Cyrillic A of "P\u0410SSWORD" is covered by its small one.
_SMALL_CAPS = "\u1d00\u0299\u1d04\u1d05\u1d07\ua730\u0262\u029c\u026a\u1d0a\u1d0b\u029f\u1d0d\u0274\u1d0f\u1d18\u0280\ua731\u1d1b\u1d1c\u1d20\u1d21\u028f\u1d22"
_LOOK_ALIKES = str.maketrans({
    "\u0430": "a", "\u0435": "e", "\u043e": "o", "\u0440": "p", "\u0441": "c", "\u0445": "x", "\u0443": "y", "\u0456": "i", "\u0455": "s",
    "\u0458": "j", "\u04bb": "h", "\u0501": "d", "\u03bf": "o", "\u03b1": "a", "\u03c1": "p", "\u03b5": "e", "\u03b9": "i", "\u03ba": "k",
    "\u03bd": "v", "\u03c5": "u", "\u0475": "v", "\u051b": "q", "\u051d": "w", "\u0261": "g", "\u043a": "k",
    **dict(zip(_SMALL_CAPS, "abcdefghijklmnoprstuvwyz")),
})


# The same letters for a text whose case is kept: a capital look-alike turns into the capital Latin letter ("P\u0410SSWORD" -> "PASSWORD").
_LOOK_ALIKES_CASED = str.maketrans({
    **_LOOK_ALIKES,
    **{ord(chr(k).upper()): v.upper() for k, v in _LOOK_ALIKES.items() if len(chr(k).upper()) == 1 and chr(k).upper() != chr(k)},
})


def fold_keeping_case(text: str) -> str:
    """``fold_for_search`` without the case fold: the same disguises undone, the capitals kept. ``redact_inline`` finds a word like ``cookie`` or ``ticket``
    in ``UserCookie`` only through the capital that starts it, and ``fold_for_search`` lower-cases that capital away; the search therefore looks at both."""
    folded = unicodedata.normalize("NFKC", text)
    stripped = "".join(ch for ch in unicodedata.normalize("NFD", folded) if unicodedata.category(ch) not in ("Cf", "Mn"))
    return unicodedata.normalize("NFKC", stripped).translate(_LOOK_ALIKES_CASED)


def fold_for_search(text: str) -> str:
    """The text as a reader sees it, lower case: compatibility forms folded (NFKC), every invisible format character (zero-width space, joiner, soft hyphen,
    bidi marks) and every combining mark removed ("pa\u0301ssword"), the case folded, then look-alike letters (Cyrillic and Greek ones, small capitals) turned
    into the Latin ones. A secret-looking pair that is only disguised this way shows in the result, except
    that the lower case erases the capitals a camelCase key is split at (``UserCookie``): ``fold_keeping_case`` is searched as well.

    Not covered, deliberately: an encoding that is not a spelling of the text (rot13, base85, a cipher) and a look-alike this table does not list; a
    secret held by the client is also searched in its base64, base32 and hex forms elsewhere (``http._views``), but a pair of an unknown secret is found only
    by its key and its look-alikes. It is a search view, never what is stored."""
    folded = unicodedata.normalize("NFKC", text)
    stripped = "".join(ch for ch in unicodedata.normalize("NFD", folded) if unicodedata.category(ch) not in ("Cf", "Mn"))
    return unicodedata.normalize("NFKC", stripped).casefold().translate(_LOOK_ALIKES)

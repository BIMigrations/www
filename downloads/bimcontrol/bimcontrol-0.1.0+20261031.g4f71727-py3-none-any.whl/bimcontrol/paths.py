"""Where BIMControl keeps its own state on disk.

Everything lives under `~/.bimcontrol`: the control database, one
directory of artefacts per run, and this node's worker identity. The
estate database is NOT in here -- that belongs to EstateScanner and is
only ever opened read-only (see estate/reader.py).

These are functions rather than constants because the location is read
from `BIMCONTROL_HOME` at the point of use: a test points it at a
temporary directory, and a swarm node can be given its own.
"""

from __future__ import annotations

import os
from pathlib import Path


def home() -> Path:
    return Path(os.environ.get("BIMCONTROL_HOME") or (Path.home() / ".bimcontrol")).expanduser()


def default_db_path() -> Path:
    return home() / "control.db"


def runs_dir() -> Path:
    return home() / "runs"


def run_dir(run_id: str) -> Path:
    return runs_dir() / run_id


def worker_id_path() -> Path:
    return home() / "worker_id"


def estates_dir() -> Path:
    """Where imported EstateScanner exports are extracted."""
    return home() / "estates"


def _current_estate_pointer() -> Path:
    return estates_dir() / "current"


def set_current_estate(db_path: str | Path) -> None:
    """Remember an imported scan as the one to load when nothing says otherwise."""
    estates_dir().mkdir(parents=True, exist_ok=True)
    _current_estate_pointer().write_text(str(Path(db_path).resolve()), encoding="utf-8")


def default_estate_db_path() -> Path:
    """`ESTATE_SCANNER_DB`, else the last imported scan, else EstateScanner's own default."""
    if os.environ.get("ESTATE_SCANNER_DB"):
        return Path(os.environ["ESTATE_SCANNER_DB"]).expanduser()
    try:
        imported = Path(_current_estate_pointer().read_text(encoding="utf-8").strip())
        if imported.is_file():
            return imported
    except OSError:
        pass
    return Path.home() / ".estate-scanner" / "estate.db"

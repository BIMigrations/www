from estate_scanner.core.registry import PlatformDescriptor, register_platform

from .auth import DomoAuthenticator, DomoSession
from .client import DomoClient
from .http import DomoHttp, DomoSearchLimitExceededError, DomoSessionExpiredError

register_platform(
    PlatformDescriptor(
        key="domo",
        display_name="Domo",
        status="available",
        authenticator_cls=DomoAuthenticator,
        client_cls=DomoClient,
        auth_mode="interactive_browser",
        instance_hint="Instance name, e.g. yourcompany",
    )
)

__all__ = [
    "DomoAuthenticator",
    "DomoSession",
    "DomoClient",
    "DomoHttp",
    "DomoSearchLimitExceededError",
    "DomoSessionExpiredError",
]

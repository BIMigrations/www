"""The connection to BimDash: pair this machine with a BimDash organisation using the four-character code BimDash shows.

BimDash (the web dashboard at bimigrations.com/dashboard) owns the pairing. Its ``device-pairing`` function takes
``{"action": "claim", "code", "device_id", "device_name", "platform", "app_version"}`` without a sign-in and answers with a
``device_token`` (shown once; BimDash keeps only its hash), the ``device_id`` and the ``org_id``. A code is single use, valid
for 10 minutes, and every refusal reads the same ("Invalid or expired code."), so this module never tries to tell the reasons
apart either. BimDash limits wrong guesses per network address (10 in 15 minutes) and per device id (5 in 15 minutes), and locks a
code that was matched 5 times after it was used or had expired.

What is sent: the code, a device id made here, the device name the person confirmed, the operating system's name and this
app's version. No scan data leaves with it. What is kept: the device token goes into this machine's OS keychain (Windows
Credential Manager, macOS Keychain, a Linux Secret Service) and nowhere else -- never a plain-text file, never the database,
so the exported scan (a sanitised copy of the database) cannot carry it. The rest of the connection (the device id, the org's
id and name, the name and date, BimDash's address -- none of it secret) is kept in ``bimdash-device.json`` beside the
database, readable by its owner only (mode 600 on Linux and macOS; on Windows the owner-only ACL is estatescanner#101's).
The token is never logged, never put in an error message and never handed to the browser.
"""

from __future__ import annotations

import json
import os
import platform
import re
import secrets
import sys
import threading
import time
import unicodedata
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from importlib import metadata
from pathlib import Path
from urllib.parse import urlsplit

import requests

# BimDash's production Supabase project (the address its own dashboard talks to; it is public, like any web address).
DEFAULT_BASE_URL = "https://iiznemotvcrukeajsist.supabase.co"
BASE_URL_ENV = "ESTATE_SCANNER_BIMDASH_URL"
PAIRING_PATH = "/functions/v1/device-pairing"
FILE_NAME = "bimdash-device.json"

# The same 28 characters BimDash draws codes from (no I, O, S, Z, 0, 1, 2, 5: nothing that looks like another character).
CODE_ALPHABET = "ABCDEFGHJKLMNPQRTUVWXY346789"
CODE_LENGTH = 4
DEVICE_ID_PATTERN = re.compile(r"^[A-Za-z0-9._:@-]{1,128}$")
NAME_MAX = 80
_TIMEOUT = (10, 20)  # per wait for the network, not in total: see _DEADLINE
_DEADLINE = 30.0  # seconds for the whole answer; a server that drips one byte a second is cut here
_MAX_ANSWER = 64 * 1024
_lock = threading.Lock()  # one pairing or disconnect at a time in this process (two windows, a double click)

BAD_CODE = "BimDash did not accept that code. A code works once and expires after 10 minutes: make a new one in BimDash and try again."
SAME_MACHINE_OTHER_ACCOUNT = " If this machine is already paired to another BimDash account, disconnect first (estate-scanner disconnect) and pair again."
TOO_MANY = "BimDash has stopped accepting codes from this network for a while after several wrong ones. Wait 15 minutes, then make a new code in BimDash."
# A 403 is not the generic code refusal (that is a 400): something between the
# machine and BimDash, or BimDash itself, refused the pairing outright. The way
# back is the same either way -- a fresh code -- but the sentence says so.
PAIR_AGAIN = "BimDash refused the pairing. Make a new code in BimDash and pair again; if it keeps happening, ask the organisation's administrator to check Devices in BimDash."

KEYCHAIN_SERVICE = "estate-scanner"
KEYCHAIN_ACCOUNT = "bimdash-device-token"


class BimdashError(Exception):
    """A sentence for the person using the app. Never holds a code or a token."""


@dataclass(frozen=True)
class Connection:
    device_id: str
    device_token: str
    org_id: str
    device_name: str
    paired_at: str
    base_url: str
    org_name: str | None = None  # what BimDash calls the organisation; older BimDash answers name it not

    def public(self) -> dict:
        """What the screen and the API may show: everything but the token."""
        return {
            "connected": True, "device_id": self.device_id, "org_id": self.org_id, "org_name": self.org_name,
            "device_name": self.device_name, "paired_at": self.paired_at, "bimdash": urlsplit(self.base_url).netloc,
        }


def normalise_code(text: str | None) -> str:
    """The code as BimDash stores it: upper case, with the spaces and dashes a person pastes along with it removed. Raises when it is
    not four characters of BimDash's alphabet (the wording is BimDash's own, so a typo and a wrong code read alike)."""
    flat = "".join(c for c in unicodedata.normalize("NFKC", text or "") if unicodedata.category(c) != "Cf")  # fullwidth letters, zero-width characters
    code = re.sub(r"[\s-]+", "", flat).upper()
    if len(code) != CODE_LENGTH or any(c not in CODE_ALPHABET for c in code):
        raise BimdashError(f"A BimDash code is {CODE_LENGTH} characters, letters and digits (for example 4WEA). Copy it from the Scan your estate step in BimDash.")
    return code


def clean_device_name(text: str | None) -> str:
    name = " ".join((text or "").split())[:NAME_MAX].strip()
    return name or default_device_name()


def default_device_name() -> str:
    host = (platform.node() or "").split(".")[0].strip()
    return f"Estate Scanner on {host}"[:NAME_MAX] if host else "Estate Scanner"


def base_url() -> str:
    """BimDash's address; the environment can point it at another one (a test BimDash). A code and a token only ever travel over https,
    or to this machine itself."""
    url = (os.environ.get(BASE_URL_ENV) or DEFAULT_BASE_URL).strip().rstrip("/")
    parts = urlsplit(url)
    local = parts.hostname in ("127.0.0.1", "localhost", "::1")
    if parts.scheme not in ("https", "http") or not parts.hostname or (parts.scheme == "http" and not local) or parts.username or parts.password:
        raise BimdashError(f"{BASE_URL_ENV} must be an https address (http only for this machine itself).")
    return url


def _os_name() -> str:
    return {"darwin": "macos", "win32": "windows"}.get(sys.platform, "linux")


def _app_version() -> str:
    try:
        return metadata.version("estate-scanner")[:32]
    except metadata.PackageNotFoundError:
        return "unknown"


def _post(url: str, body: dict, session: requests.Session | None) -> tuple[int, bytes]:
    """One POST, with the answer read in pieces: at most ``_MAX_ANSWER`` bytes, not compressed, within ``_DEADLINE`` seconds in all. Returns
    (status, body); a body that was too long or too slow comes back as ``_MAX_ANSWER + 1`` bytes, which ``claim`` refuses."""
    local = urlsplit(url).hostname in ("127.0.0.1", "localhost", "::1")
    own = session is None
    session = session or requests.Session()
    if local:
        session.trust_env = False  # a proxy named in the environment never sees a code or a token meant for this machine
    started = time.monotonic()
    try:
        answer = session.post(url + PAIRING_PATH, json=body, timeout=_TIMEOUT, allow_redirects=False, stream=True,
                              headers={"Accept-Encoding": "identity"})
        try:
            chunks, size = [], 0
            for chunk in answer.iter_content(chunk_size=1):  # one byte a time: a larger read would wait for that many bytes before the deadline is looked at
                size += len(chunk)
                chunks.append(chunk)
                if size > _MAX_ANSWER or time.monotonic() - started > _DEADLINE:
                    return answer.status_code, b"x" * (_MAX_ANSWER + 1)
            return answer.status_code, b"".join(chunks)
        finally:
            answer.close()
    except requests.RequestException as exc:
        # The exception text can name the address, never the body; say only what kind of failure it was.
        raise BimdashError(f"Could not reach BimDash ({type(exc).__name__}). Check this machine's internet connection and try again.") from None
    finally:
        if own:
            session.close()


def claim(code: str, device_name: str | None = None, *, device_id: str | None = None, session: requests.Session | None = None) -> Connection:
    """Spend a BimDash code. Raises BimdashError with a sentence; nothing is stored here (see ``connect``)."""
    code = normalise_code(code)
    url = base_url()
    device_id = device_id or f"estate-scanner-{uuid.uuid4().hex}"
    body = {"action": "claim", "code": code, "tool": "estate-scanner", "device_id": device_id, "device_name": clean_device_name(device_name),
            "platform": _os_name(), "app_version": _app_version()}
    status_code, raw = _post(url, body, session)
    if status_code == 429:
        raise BimdashError(TOO_MANY)
    if status_code == 403:
        raise BimdashError(PAIR_AGAIN)
    if status_code in (400, 401, 404):
        raise BimdashError(BAD_CODE)
    if status_code != 200 or len(raw) > _MAX_ANSWER:
        raise BimdashError(f"BimDash answered with an error (HTTP {status_code}) or an answer that was too long. Try again in a minute; if it keeps happening, tell BI Migrations.")
    try:
        data = json.loads(raw)
    except (ValueError, RecursionError):
        data = None
    data = data if isinstance(data, dict) else {}
    token = data.get("device_token") or data.get("token")
    paired_id = data.get("device_id")
    org_id = data.get("org_id")
    if (not isinstance(token, str) or not 16 <= len(token) <= 512 or token != token.strip() or any(c.isspace() for c in token)
            or not isinstance(paired_id, str) or not DEVICE_ID_PATTERN.match(paired_id) or not isinstance(org_id, str) or not 0 < len(org_id) <= 64):
        raise BimdashError("BimDash's answer was not what this version of Estate Scanner expects, so nothing was saved. Update Estate Scanner and try again.")
    name = data.get("device_name") if isinstance(data.get("device_name"), str) else body["device_name"]
    # The org's name is display only (the id is what pairing is bound to), so
    # an answer without one, or with an odd one, still pairs: shown as text it
    # is trimmed and cut; anything else is shown as the id instead.
    org_name = data.get("org_name")
    org_name = " ".join(org_name.split())[:120] if isinstance(org_name, str) and org_name.strip() else None
    return Connection(paired_id, token, org_id, clean_device_name(name), datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), url, org_name)


# -- the file and the keychain --------------------------------------------------------------------------


def connection_path(directory: Path | str) -> Path:
    return Path(directory) / FILE_NAME


def _keychain():
    """The OS keychain, as the ``keyring`` package sees it. Imported lazily:
    only pairing needs it, its absence must be a sentence rather than a
    traceback, and it must never fall back to a plain-text file."""
    try:
        import keyring
    except ImportError as exc:
        raise BimdashError(
            "No OS keychain is available (the 'keyring' package is not installed)."
            " The BimDash key is never kept in a plain-text file, so pairing cannot continue."
        ) from exc
    return keyring


def keychain_save(token: str) -> None:
    try:
        _keychain().set_password(KEYCHAIN_SERVICE, KEYCHAIN_ACCOUNT, token)
    except BimdashError:
        raise
    except Exception as exc:
        if type(exc).__name__ == "NoKeyringError":
            raise BimdashError(
                "No OS keychain is available on this machine. The BimDash key is never"
                " kept in a plain-text file, so pairing cannot continue."
            ) from None
        raise BimdashError(
            f"Could not keep the BimDash key in this machine's keychain ({type(exc).__name__})."
            " The key is never kept in a plain-text file."
        ) from None


def keychain_load() -> str | None:
    try:
        return _keychain().get_password(KEYCHAIN_SERVICE, KEYCHAIN_ACCOUNT) or None
    except BimdashError:
        raise
    except Exception as exc:
        raise BimdashError(f"Could not read the BimDash key from this machine's keychain ({type(exc).__name__}).") from None


def keychain_forget() -> None:
    try:
        _keychain().delete_password(KEYCHAIN_SERVICE, KEYCHAIN_ACCOUNT)
    except BimdashError:
        raise
    except Exception as exc:
        if type(exc).__name__ == "PasswordDeleteError":
            return  # the entry is already gone: disconnect stays idempotent
        raise BimdashError(f"Could not remove the BimDash key from this machine's keychain ({type(exc).__name__}).") from None


def save(directory: Path | str, connection: Connection) -> None:
    """Keep the connection: the token in the OS keychain, the rest (none of it
    secret) in the file beside the database. The file is replaced whole, mode
    600 from the first byte: the temp file has a name nobody can predict, is
    created exclusively and without following a symlink (the way the Tableau
    secret file is written), so a planted file can neither keep a looser mode
    nor redirect the write. The keychain is filled only once the file is on
    disk; a failure in either is a BimdashError, the temp file is removed, and
    ``connect`` then removes both halves so no half a connection is left."""
    path = connection_path(directory)
    tmp = None
    try:
        path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
        for _ in range(5):
            tmp = path.with_name(f"{path.name}.{secrets.token_hex(8)}.tmp")
            try:
                fd = os.open(tmp, flags, 0o600)
                break
            except FileExistsError:
                tmp = None
        else:
            raise BimdashError(f"Could not create a private file beside {path.parent}.")
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            if os.name != "nt":
                os.fchmod(fh.fileno(), 0o600)
            json.dump({"device_id": connection.device_id, "org_id": connection.org_id, "org_name": connection.org_name,
                       "device_name": connection.device_name, "paired_at": connection.paired_at, "base_url": connection.base_url}, fh)
        os.replace(tmp, path)
        tmp = None
        keychain_save(connection.device_token)
    except OSError as exc:
        if tmp is not None:
            tmp.unlink(missing_ok=True)
        raise BimdashError(f"Could not save the BimDash connection: {exc.strerror or type(exc).__name__}.") from None
    except BaseException:
        if tmp is not None:
            tmp.unlink(missing_ok=True)
        raise


def load(directory: Path | str) -> Connection | None:
    """The saved connection, None when there is none. A file others can read, a link, or one that cannot be understood is refused with a
    sentence (a connection whose details others can read is not used quietly, like ssh with a private key). The token itself comes from
    the keychain; a connection whose key is no longer there is refused too, because it cannot authenticate."""
    path = connection_path(directory)
    if not path.exists() and not path.is_symlink():
        return None
    try:
        if path.is_symlink():
            raise BimdashError(f"{path} is a link, which is not followed; disconnect and connect again.")
        if os.name != "nt" and path.stat().st_mode & 0o077:
            raise BimdashError(f"{path} can be read by other users of this machine; run: chmod 600 {path}, or disconnect and connect again.")
        data = json.loads(path.read_text(encoding="utf-8"))
        fields = [data[k] for k in ("device_id", "org_id", "device_name", "paired_at", "base_url")]
        if not all(isinstance(f, str) and f for f in fields):
            raise ValueError("a field is not text")
        org_name = data.get("org_name")
        if org_name is not None and not isinstance(org_name, str):
            raise ValueError("the organisation's name is not text")
    except (OSError, ValueError, KeyError, TypeError):
        raise BimdashError(f"The saved BimDash connection ({path.name}) cannot be read. Disconnect and connect again.") from None
    token = keychain_load()
    if token is None:
        raise BimdashError("The BimDash key is no longer in this machine's keychain. Disconnect and connect again with a new code.")
    return Connection(fields[0], token, fields[1], fields[2], fields[3], fields[4], org_name)


def forget(directory: Path | str) -> bool:
    """Remove the saved connection from this machine: the file and the keychain entry. BimDash keeps listing the device until someone
    removes it there (Devices)."""
    try:
        connection_path(directory).unlink()
        removed = True
    except FileNotFoundError:
        removed = False
    except OSError as exc:
        raise BimdashError(f"Could not remove the saved BimDash connection: {exc.strerror or type(exc).__name__}.") from None
    keychain_forget()
    return removed


def _destination() -> dict:
    """Where the next pairing would go: the host of the BimDash this app talks
    to. Not a secret (the address is public), and the one thing that tells a
    person whose code keeps failing apart: a code only works in the BimDash
    that issued it, so a screen that names its BimDash makes a wrong or
    missing ESTATE_SCANNER_BIMDASH_URL visible before any code is spent."""
    try:
        return {"bimdash": urlsplit(base_url()).netloc}
    except BimdashError:
        return {}  # a bad override is the pairing attempt's problem to explain


def status(directory: Path | str) -> dict:
    """What the screen shows. Never the token."""
    try:
        connection = load(directory)
    except BimdashError as exc:
        return {"connected": False, "problem": str(exc), "suggested_name": default_device_name(), **_destination()}
    if connection is None:
        return {"connected": False, "suggested_name": default_device_name(), **_destination()}
    return connection.public()


def connect(directory: Path | str, code: str, device_name: str | None = None, *, session: requests.Session | None = None) -> dict:
    """Spend the code, keep the connection, answer with ``status``. Pairing again replaces the old connection but keeps its device id
    (BimDash refuses a device id already paired to someone else, and counts one device, not two). If the code is spent and the connection
    then cannot be kept (the file or the keychain refuses), the old connection (whose token BimDash no longer accepts) is removed from
    both places too, and the sentence says a new code is needed."""
    with _lock:
        try:
            previous = load(directory)
        except BimdashError:
            previous = None
        try:
            connection = claim(code, device_name, device_id=previous.device_id if previous else None, session=session)
        except BimdashError as exc:
            if previous is not None and str(exc) == BAD_CODE:
                raise BimdashError(BAD_CODE + SAME_MACHINE_OTHER_ACCOUNT) from None
            raise
        try:
            save(directory, connection)
        except BimdashError as exc:
            try:
                forget(directory)
            except BimdashError:
                pass
            raise BimdashError(f"{exc} BimDash has used the code, so make a new one and try again.") from None
        return connection.public()


def disconnect(directory: Path | str) -> dict:
    with _lock:
        forget(directory)
    return status(directory)

"""Customer batches started from the screen (bimcontrol#255).

A batch is `customer.run_batch` on a thread of the app's process, as a single run is (`runner.RunManager`): the dashboards
run one after another, the rollup file is rewritten after each, and a stop is asked for, never forced. Stop lets the dashboard
in flight finish; "stop now" also cancels it at its next stage boundary (a cancelled run is resumed by the next batch).

State is in memory: after the app restarts a batch that was running shows as not running, and its unfinished dashboard is
resumed by the next start (the rollup file and the control database hold everything else). One batch per customer; two
customers at once share the converter, which works one dataflow at a time.
"""

from __future__ import annotations

import json
import re
import threading
from collections import deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from bimcontrol.core import customer, runner
from bimcontrol.estate.reader import EstateNotFoundError, EstateReader
from bimcontrol.storage import db

MANIFEST_FILE = "manifest.json"
_LOG_LINES = 40


def customer_key(name: str) -> str:
    """The directory a customer's files live in: the name with anything but letters, digits, '-' and '_' made '_'."""
    return customer.rollup_path(name).parent.name


def _slot(name: str) -> str:
    """The guard's key: the directory name without case (on a case-insensitive disk 'Acme' and 'acme' are one directory)."""
    return customer_key(name).casefold()


def _owner(name: str) -> str | None:
    """The customer name whose files are in this name's directory, if any (two names can make one directory name)."""
    saved = saved_manifest(name)
    if saved and saved.get("customer"):
        return str(saved["customer"])
    try:
        rollup = json.loads(customer.rollup_path(name).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return str(rollup.get("customer")) if isinstance(rollup, dict) and rollup.get("customer") else None


def validate_manifest(data: Any) -> customer.Manifest:
    """A Manifest from a posted body; ValueError says what is wrong (a bad name, a pattern that is not a regex)."""
    if not isinstance(data, dict):
        raise ValueError("the manifest must be an object")
    for part in ("include", "exclude"):
        found = data.get(part) or {}
        if not isinstance(found, dict) or any(
                not isinstance(v, list) or any(isinstance(i, bool) or not isinstance(i, (str, int)) for i in v)
                for v in found.values()):
            raise ValueError(f'"{part}" must hold lists of text')
    for part in ("first", "rerun_proven"):                   # ordering lists of dashboard ids (no form for them: a manifest file sets them)
        found = data.get(part) or []
        if not isinstance(found, list) or any(isinstance(i, bool) or not isinstance(i, (str, int)) for i in found):
            raise ValueError(f'"{part}" must be a list of dashboard ids')
    cleaned = {"customer": data.get("customer"),
               **{part: {key: [str(i) for i in items] for key, items in (data.get(part) or {}).items()}
                  for part in ("include", "exclude")},
               **{part: [str(i) for i in data.get(part) or []] for part in ("first", "rerun_proven")}}
    if sum(len(v) for part in ("include", "exclude") for v in cleaned[part].values()) + len(cleaned["first"]) + len(cleaned["rerun_proven"]) > 500 \
            or any(len(i) > 300 for part in ("include", "exclude") for v in cleaned[part].values() for i in v):
        raise ValueError("the manifest is too long: at most 500 lines of at most 300 characters")
    if not isinstance(data.get("customer"), str):
        raise ValueError("the customer name must be text")
    manifest = customer.Manifest.from_dict(cleaned)
    if not re.search(r"[A-Za-z0-9]", manifest.name):
        raise ValueError("the customer name needs a letter or a digit")
    if len(manifest.name) > 80:
        raise ValueError("the customer name is longer than 80 characters")
    for pattern in manifest.name_regexes:
        try:
            re.compile(pattern)
        except re.error as exc:
            raise ValueError(f"{pattern!r} is not a regular expression: {exc}") from None
    if not (manifest.name_suffixes or manifest.name_prefixes or manifest.name_contains or manifest.name_regexes
            or manifest.ids):
        raise ValueError("the manifest selects nothing: give a suffix, prefix, text, pattern or dashboard id to include")
    return manifest


def selection(estate_db_path: str | Path, manifest: customer.Manifest) -> list[customer.Selected]:
    with EstateReader(estate_db_path, platform="domo") as reader:
        return customer.select_dashboards(reader, manifest)


def saved_manifest(name: str) -> dict[str, Any] | None:
    path = customer.rollup_path(name).parent / MANIFEST_FILE
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None


def _save_manifest(manifest: customer.Manifest) -> None:
    path = customer.rollup_path(manifest.name).parent / MANIFEST_FILE
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(manifest.to_dict(), indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    tmp.replace(path)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class _Batch:
    def __init__(self, manifest: customer.Manifest, total: int | None, options: dict[str, Any]):
        self.manifest = manifest
        self.total = total
        self.options = options
        self.started_at = _now()
        self.finished_at: str | None = None
        self.stop_requested = threading.Event()
        self.cancel_run = threading.Event()
        self.current: dict[str, Any] | None = None
        self.started = 0
        self.result: str | None = None
        self.log: deque[str] = deque(maxlen=_LOG_LINES)
        self.log_lock = threading.Lock()
        self.thread: threading.Thread | None = None

    def running(self) -> bool:
        return bool(self.thread and self.thread.is_alive())

    def to_dict(self) -> dict[str, Any]:
        return {
            "running": self.running(), "customer": self.manifest.name, "key": customer_key(self.manifest.name), "started_at": self.started_at,
            "finished_at": self.finished_at, "stopping": self.running() and self.stop_requested.is_set(),
            "dashboards": self.total, "started": self.started, "current": self.current if self.running() else None,
            "result": self.result, "options": self.options, "log": self.log_lines(),
        }

    def log_lines(self) -> list[str]:
        with self.log_lock:
            return list(self.log)


class BatchManager:
    def __init__(self, db_path: str | Path | None = None, execute=runner.execute_run):
        self.db_path = db_path
        self._execute = execute            # replaced in tests: a run takes minutes
        self._batches: dict[str, _Batch] = {}
        self._lock = threading.Lock()

    def start(self, manifest: customer.Manifest, estate_db_path: str | Path, *, limit: int | None = None,
              rerun_unproven: bool = False, retry_failed: bool = True, force: bool = False) -> dict[str, Any]:
        """Start the manifest's batch. RuntimeError if the customer's batch is running; a manifest that matches nothing
        ends the batch at once with that result (the selection is read on the batch's thread)."""
        key = _slot(manifest.name)
        if not Path(estate_db_path).is_file():
            raise EstateNotFoundError(f"No estate database at {estate_db_path}")
        owner = _owner(manifest.name)
        if owner is not None and owner != manifest.name:
            raise ValueError(f"{manifest.name!r} would share its folder with the customer {owner!r}: rename one of them")
        options = {"limit": limit, "rerun_unproven": rerun_unproven, "retry_failed": retry_failed, "force": force}
        batch = _Batch(manifest, None, options)

        def execute(conn, run_id, estate):
            batch.current = {**(batch.current or {}), "run_id": run_id}
            return self._execute(conn, run_id, estate, cancel_event=batch.cancel_run)

        def on_dashboard(s: customer.Selected, n: int) -> None:
            batch.started = n
            batch.current = {"id": s.id, "name": s.name, "run_id": None}

        def say(line: str) -> None:
            if line.strip():
                with batch.log_lock:
                    batch.log.append(f"{datetime.now().strftime('%H:%M:%S')} {line.strip()}")

        def work() -> None:
            try:
                conn = db.connect(self.db_path)
                try:
                    # Reading the closures of a hundred dashboards takes seconds: not in the request that starts the batch.
                    selected = selection(estate_db_path, manifest)
                    batch.total = len(selected)
                    if not selected:
                        batch.result = "no dashboard in the scan matches this manifest"
                        say(batch.result)
                        return
                    rollup = customer.run_batch(
                        conn, estate_db_path, manifest, selected, limit=limit, force=force, retry_failed=retry_failed,
                        rerun_unproven=rerun_unproven, execute=execute, say=say, on_dashboard=on_dashboard,
                        should_stop=batch.stop_requested.is_set)
                    batch.result = ("stopped on request" if batch.cancel_run.is_set()
                                    else rollup.get("stopped") or "finished: nothing left to start")
                finally:
                    conn.close()
            except Exception as exc:  # noqa: BLE001 -- nothing above this to catch it
                batch.result = f"crashed: {type(exc).__name__}: {exc}"
                say(batch.result)
            finally:
                batch.finished_at = _now()

        # Registered and started under the lock: a second start of the same customer sees a batch that is running.
        with self._lock:
            old = self._batches.get(key)
            if old is not None and old.running():
                raise RuntimeError(f"{manifest.name}: a batch is already running")
            try:
                _save_manifest(manifest)
            except OSError as exc:
                raise RuntimeError(f"could not save the manifest: {exc}") from exc
            batch.thread = threading.Thread(target=work, name=f"batch-{key}", daemon=True)
            self._batches[key] = batch
            batch.thread.start()
        return batch.to_dict()

    def status(self, name: str) -> dict[str, Any] | None:
        with self._lock:
            batch = self._batches.get(_slot(name))
        return batch.to_dict() if batch else None

    def stop(self, name: str, now: bool = False) -> bool:
        """Ask the customer's running batch to stop after the dashboard in flight (`now`: cancel that one too)."""
        with self._lock:
            batch = self._batches.get(_slot(name))
        if batch is None or not batch.running():
            return False
        batch.stop_requested.set()
        if now:
            batch.cancel_run.set()
        return True

    def join(self, name: str, timeout: float | None = None) -> None:
        """Wait for a batch to end. For tests and a clean shutdown."""
        with self._lock:
            batch = self._batches.get(_slot(name))
        if batch and batch.thread:
            batch.thread.join(timeout)

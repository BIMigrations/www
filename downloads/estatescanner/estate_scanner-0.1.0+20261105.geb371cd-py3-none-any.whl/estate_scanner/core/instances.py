"""The name of a platform instance (a Domo subdomain, a Power BI tenant) as the database stores it.

Every typed row carries it (#55), so two spellings of one instance would be two instances. One
function decides the spelling, and it is applied wherever a name enters: scan start, saved sign-in,
and the migration of a database that predates the column.
"""

from __future__ import annotations

_DOMO_SUFFIX = ".domo.com"


def normalise_instance(platform: str, name: str | None) -> str:
    """Trim and lower-case; a Domo name also loses a trailing `.domo.com` (the sign-in adds it)."""
    value = (name or "").strip().lower()
    if platform == "domo" and value.endswith(_DOMO_SUFFIX):
        value = value[: -len(_DOMO_SUFFIX)]
    return value


class AmbiguousInstance(LookupError):
    """A caller asked for a platform's objects without naming the instance, and the database holds several."""

    def __init__(self, platform: str, instances: list[str]):
        self.platform = platform
        self.instances = instances
        super().__init__(
            f"The database holds {len(instances)} instances of {platform!r}: {', '.join(repr(i) for i in instances)}. "
            "Name the instance."
        )

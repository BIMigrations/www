"""Remember which SQL the warehouse has already accepted, across dashboards and lanes.

A customer's dashboards share dataflows: the customer's 34 flows behind the Claims and Daily Charge tables are converted
by every dashboard that reads them, and the warehouse is asked to plan the same script three times each time (the repair
pass, the validation and the column description), 1-40 s on an idle cluster and 13-21 minutes on a busy one. Converted
SQL is deterministic for an unchanged flow, converter and input mapping, so an accepted script is accepted again.

Only acceptances are kept for later, keyed on the warehouse (host, port, user, database), the exact text and a fingerprint of the
code that lands tables (the column types of an input, and so of the described columns, come from it), and only for a
while (inputs can be re-landed under the same name): a rejection is always asked again. One JSON line per fact in
`validated_sql.jsonl`, appended (small appends from several lanes do not interleave); the last line for a key wins.
`BIMCONTROL_VALIDATION_CACHE_HOURS=0` turns it off.
"""

from __future__ import annotations

import contextlib
import functools
import hashlib
import json
import os
import re
import time
from pathlib import Path
from typing import Any

from bimcontrol import paths

DEFAULT_HOURS = 12.0
DEFAULT_LOCK_MINUTES = 60.0
LOCK_POLL_SECONDS = 0.5


def _hours() -> float:
    try:
        return float(os.environ.get("BIMCONTROL_VALIDATION_CACHE_HOURS", DEFAULT_HOURS))
    except ValueError:
        return DEFAULT_HOURS


# the modules that decide what a landed table looks like; a change to one of them can change the types of an input
_LANDING_CODE = ("pipelines/data_plan.py", "warehouses/base.py", "warehouses/redshift.py", "warehouses/snowflake.py",
                 "warehouses/bigquery.py")


@functools.lru_cache(maxsize=1)
def _landing_code() -> str:
    root, digest = Path(__file__).resolve().parent.parent, hashlib.sha256()
    for name in _LANDING_CODE:
        try:
            digest.update((root / name).read_bytes())
        except OSError:
            digest.update(b"?")
    return digest.hexdigest()[:16]


def _key(settings: dict[str, Any], sql: str) -> str:
    where = "|".join(str(settings.get(k, "")) for k in ("key", "host", "port", "user", "database", "landing_schema"))
    return hashlib.sha256(f"{where}|{_landing_code()}\n{sql.strip().rstrip(';')}".encode()).hexdigest()


def _path():
    return paths.home() / "validated_sql.jsonl"


def lookup(settings: dict[str, Any], sql: str) -> dict[str, Any] | None:
    """The cached acceptance of this script ({"columns": [...] or None}), or None."""
    ttl = _hours() * 3600
    if ttl <= 0 or not settings.get("host"):
        return None
    key, found = _key(settings, sql), None
    try:
        lines = _path().read_text(encoding="utf-8").splitlines()
    except OSError:
        return None
    for line in lines:
        try:
            entry = json.loads(line)
        except ValueError:
            continue
        if entry.get("k") == key:
            found = entry
    if found is None or time.time() - float(found.get("t") or 0) > ttl:
        return None
    return found


def store(settings: dict[str, Any], sql: str, columns: list[tuple[str, str]] | None = None) -> None:
    if _hours() <= 0 or not settings.get("host"):
        return
    entry = {"k": _key(settings, sql), "t": round(time.time()),
             "columns": [list(c) for c in columns] if columns is not None else None}
    try:
        _path().parent.mkdir(parents=True, exist_ok=True)
        with _path().open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(entry) + "\n")
    except OSError:
        pass  # a cache that cannot be written is no cache


def _wait_seconds() -> float:
    try:
        return float(os.environ.get("BIMCONTROL_PLANNING_LOCK_MINUTES", DEFAULT_LOCK_MINUTES)) * 60
    except ValueError:
        return DEFAULT_LOCK_MINUTES * 60


@contextlib.contextmanager
def _planning(settings: dict[str, Any], sql: str):
    """One planning of a script at a time on this machine. Two lanes that reach the same shared output together would
    each wait 30-40 minutes for the cluster to plan it (Customer_Charge_Claims, 2026-10-20: two identical queries
    in flight for 36 minutes); the second waits for the first and then finds the answer in the cache. Yields the time
    this lane began to wait: whatever the holder concluded after that moment answers this lane too.

    No lock when the cache is off (nothing would be found afterwards) and none that is waited for longer than
    `BIMCONTROL_PLANNING_LOCK_MINUTES` (60): a holder that hangs must not stop every lane behind it."""
    began = time.time()
    try:
        import fcntl
    except ImportError:                            # not on Windows: a desktop session plans one script at a time
        yield began
        return
    if _hours() <= 0 or not settings.get("host"):
        yield began
        return
    directory = paths.home() / "locks"
    try:
        directory.mkdir(parents=True, exist_ok=True)
        handle = open(directory / f"plan-{_key(settings, sql)[:24]}.lock", "w")  # noqa: SIM115 -- closed below
    except OSError:                                # a lock that cannot be made is no lock
        yield began
        return
    with handle:
        deadline, locked = began + _wait_seconds(), False
        while not locked:
            try:
                fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
                locked = True
            except (BlockingIOError, PermissionError):     # held by another lane
                if time.time() >= deadline:
                    break
                time.sleep(LOCK_POLL_SECONDS)
            except OSError:                                # a file system without locks: no lock
                break
        try:
            yield began
        finally:
            if locked:
                fcntl.flock(handle, fcntl.LOCK_UN)


def _rejection_since(settings: dict[str, Any], sql: str, since: float) -> str | None:
    """The error another lane got for this exact script after `since`, or None."""
    key, found = "rejected:" + _key(settings, sql), None
    try:
        lines = _path().read_text(encoding="utf-8").splitlines()
    except OSError:
        return None
    for line in lines:
        try:
            entry = json.loads(line)
        except ValueError:
            continue
        if entry.get("k") == key and float(entry.get("t") or 0) >= since:
            found = entry.get("error")
    return found


# What a rejection says when it is about the connection or the state of the warehouse rather than about the script: not
# shared, the next lane plans it itself ("relation ... does not exist" can be fixed by a lane that lands the input meanwhile).
_NOT_ABOUT_THE_SCRIPT = re.compile(
    r"ssl|eof|connection|connect to|timeout|timed out|cancel|too many|network|broken pipe|reset by peer|terminat|"
    r"relation .*does not exist|schema .*does not exist|permission denied|out of memory|disk full", re.IGNORECASE)


def _store_rejection(settings: dict[str, Any], sql: str, error: str) -> None:
    entry = {"k": "rejected:" + _key(settings, sql), "t": time.time(), "error": error}
    try:
        _path().parent.mkdir(parents=True, exist_ok=True)
        with _path().open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(entry) + "\n")
    except OSError:
        pass


def validate(adapter: Any, settings: dict[str, Any], sql: str) -> tuple[bool, str | None]:
    """`adapter.validate_sql(sql)`, answered from the cache when this exact script was accepted recently.

    A rejection is not remembered for later (it is asked again), but a lane that waited for another lane's plan of
    the same script shares its answer: three lanes behind a rejected 36-minute plan would otherwise plan it three
    times, one after the other."""
    if lookup(settings, sql) is not None:
        return True, None
    with _planning(settings, sql) as began:
        if lookup(settings, sql) is not None:            # accepted by another lane while this one waited
            return True, None
        rejected = _rejection_since(settings, sql, began)
        if rejected is not None:
            return False, rejected
        ok, error = adapter.validate_sql(sql)
        if ok:
            store(settings, sql)
        elif error and not _NOT_ABOUT_THE_SCRIPT.search(error) and _hours() > 0 and settings.get("host"):
            _store_rejection(settings, sql, error)
    return ok, error


def describe(adapter: Any, settings: dict[str, Any], sql: str, statement: str) -> list[tuple[str, str]] | None:
    """`adapter.describe_sql(statement)` for the validated script `sql`, from the cache when it holds the columns."""
    hit = lookup(settings, sql)
    if hit is not None and hit.get("columns") is not None:
        return [(name, kind) for name, kind in hit["columns"]]
    with _planning(settings, sql):
        hit = lookup(settings, sql)
        if hit is not None and hit.get("columns") is not None:
            return [(name, kind) for name, kind in hit["columns"]]
        described = adapter.describe_sql(statement)
        if described is not None:
            store(settings, sql, described)
    return described

"""FastAPI app factory: API routers first, then the frontend static files
as a fallback.

Binds to 127.0.0.1 only (see desktop.py). The routes here talk to the local
estate database, the local control database, and -- once converters are
wired in -- converter services on localhost. Nothing calls out to the
internet except the source/target BI platforms themselves.
"""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from bimcontrol import paths
from bimcontrol.core.batches import BatchManager
from bimcontrol.core.runner import RunManager
from bimcontrol.storage import db

from .routes import connections, customers, estate, runs, warehouses

STATIC_DIR = Path(__file__).parent / "static"


def create_app(estate_db_path: str | Path | None = None, db_path: str | Path | None = None) -> FastAPI:
    app = FastAPI(title="BIMControl")
    app.state.estate_db_path = Path(estate_db_path or paths.default_estate_db_path()).expanduser()
    app.state.db_path = Path(db_path or paths.default_db_path()).expanduser()
    # Background migrations live for the life of the process, not a request.
    app.state.runs = RunManager(app.state.db_path)
    app.state.batches = BatchManager(app.state.db_path)

    # Create the control database before any request arrives; the estate
    # database is deliberately not touched here, since it may not exist yet
    # and is never ours to create.
    db.connect(app.state.db_path).close()

    app.include_router(estate.router, prefix="/api/estate", tags=["estate"])
    app.include_router(runs.router, prefix="/api", tags=["migrations"])
    app.include_router(warehouses.router, prefix="/api", tags=["warehouses"])
    app.include_router(connections.router, prefix="/api", tags=["connections"])
    app.include_router(customers.router, prefix="/api", tags=["customers"])

    if STATIC_DIR.exists():
        app.mount("/", StaticFiles(directory=STATIC_DIR, html=True), name="static")

    # Same reasoning as EstateScanner: this only ever serves a local webview
    # or a developer's own tab, and the zero-build loader re-fetches every
    # .jsx on each load -- a cached copy makes an edited screen look
    # unchanged.
    @app.middleware("http")
    async def no_cache(request, call_next):
        response = await call_next(request)
        response.headers["Cache-Control"] = "no-store"
        return response

    return app

"""Stub registration for Tableau -- see adapters/qlik/__init__.py for why
this is deliberately this small."""

from estate_scanner.core.platform import PlatformAuthenticator, PlatformClient
from estate_scanner.core.registry import PlatformDescriptor, register_platform


class TableauAuthenticator(PlatformAuthenticator):
    platform = "tableau"


class TableauClient(PlatformClient):
    platform = "tableau"


register_platform(
    PlatformDescriptor(
        key="tableau", display_name="Tableau", status="coming_soon",
        authenticator_cls=TableauAuthenticator, client_cls=TableauClient, auth_mode="unknown",
    )
)

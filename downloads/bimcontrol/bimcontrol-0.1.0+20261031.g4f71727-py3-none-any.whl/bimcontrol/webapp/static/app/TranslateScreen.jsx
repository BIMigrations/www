import React from 'react';

// How each calculation was rewritten, and what a human still has to check.
//
// Two kinds of translation happen in a migration and they are done by
// different things: beast modes become DAX here in BIMControl, and Magic
// ETL becomes warehouse SQL in the external converter. Both land as
// artefacts of the run, so both are read from the run directory rather
// than recomputed -- what is on screen is what was actually used.
//
// A measure that could not be translated is shown as prominently as one
// that could. It exists in the model as a blank measure carrying its
// original formula, which is a deliberate choice: a measure that is
// obviously missing beats one that is quietly wrong.

const TABS = [
  { value: 'measures', label: 'Measures' },
  { value: 'sql', label: 'Warehouse SQL' },
  { value: 'review', label: 'To review' },
];

export function TranslateScreen({ runId, onSelectRun }) {
  const [runs, setRuns] = React.useState([]);
  const [run, setRun] = React.useState(null);
  const [model, setModel] = React.useState(null);
  const [reviews, setReviews] = React.useState([]);
  const [tab, setTab] = React.useState('measures');
  const [selected, setSelected] = React.useState(null);
  const [error, setError] = React.useState(null);

  React.useEffect(function () {
    fetchRuns({ limit: 50 }).then(function (body) { setRuns(body.items); }, function (e) { setError(e.message); });
  }, []);

  function reloadReviews(id) {
    return fetchReviews({ run_id: id, status: 'open' }).then(function (body) {
      setReviews(body.items);
    }, function () {});
  }

  React.useEffect(function () {
    if (!runId) { setRun(null); setModel(null); setReviews([]); return undefined; }
    let stale = false;
    setSelected(null);
    setModel(null);
    fetchRun(runId).then(function (body) {
      if (stale) return;
      setRun(body);
      const artefact = (body.artefacts || []).find(function (a) { return a.kind === 'model'; });
      if (!artefact) return;
      fetchArtefactText(runId, artefact.id).then(function (text) {
        if (!stale) setModel(JSON.parse(text));
      }, function () {});
    }, function (e) { if (!stale) setError(e.message); });
    reloadReviews(runId);
    return function () { stale = true; };
  }, [runId]);

  const measures = [];
  ((model && model.tables) || []).forEach(function (table) {
    (table.measures || []).forEach(function (measure) {
      measures.push(Object.assign({ table: table.name }, measure));
    });
  });
  const scripts = ((run && run.artefacts) || []).filter(function (a) { return a.kind === 'sql'; });
  const needsReview = measures.filter(function (m) { return m.needs_review; }).length;

  return (
    <React.Fragment>
      <Sidebar>
        <SidebarGroup label="Runs">
          {runs.map(function (r) {
            return (
              <NavItem key={r.id} label={r.unit_name || r.unit_id} meta={statusLabel(r.status)}
                active={r.id === runId} icon={<StatusDot status={statusDot(r.status)} />}
                onClick={function () { onSelectRun(r.id); }} />
            );
          })}
        </SidebarGroup>
        {model ? (
          <React.Fragment>
            <SidebarRule />
            <SidebarGroup label="Tables">
              {(model.tables || []).map(function (table) {
                return (
                  <NavItem key={table.name} label={table.name} provenance="target"
                    meta={(table.columns || []).length + ' cols'} />
                );
              })}
            </SidebarGroup>
          </React.Fragment>
        ) : null}
      </Sidebar>

      <Main>
        {!runId ? (
          <div style={{ flex: 1, display: 'grid', placeItems: 'center', padding: 'var(--space-10)' }}>
            <EmptyState headline="No run" accent="selected."
              body="Pick a run on the left to see how its calculations were rewritten." />
          </div>
        ) : (
          <React.Fragment>
            <PageHeader
              title="Translated"
              accent="calculations."
              meta={
                <span>
                  <span className="bit-num">{runId}</span>
                  {' · '}{measures.length} measure(s), {scripts.length} warehouse script(s)
                </span>
              }>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,minmax(0,1fr))', gap: 28, margin: '22px 0 18px' }}>
                <StatTile size="sm" tone="target" value={formatCount(measures.length - needsReview)}
                  suffix="translated" label="Beast modes now DAX" />
                <StatTile size="sm" tone="source" value={formatCount(needsReview)}
                  suffix="refused" label="Left blank, formula kept" />
                <StatTile size="sm" tone="target" value={formatCount(scripts.length)}
                  suffix="scripts" label="Magic ETL now warehouse SQL" />
                <StatTile size="sm" value={formatCount(reviews.length)} label="Open review items" />
              </div>
              <Tabs value={tab} onChange={setTab} tabs={TABS.map(function (t) {
                return Object.assign({}, t, {
                  count: t.value === 'measures' ? measures.length
                    : t.value === 'sql' ? scripts.length : reviews.length,
                });
              })} />
            </PageHeader>

            <ErrorBanner error={error} />

            <div style={{ flex: 1, minHeight: 0, overflow: 'auto' }}>
              {tab === 'measures' ? <MeasureTable measures={measures} onSelect={setSelected} /> : null}
              {tab === 'sql' ? <ScriptList run={run} scripts={scripts} onSelect={setSelected} /> : null}
              {tab === 'review' ? (
                <ReviewList items={reviews} onResolve={function (item, status) {
                  resolveReview(item.id, status).then(function () { reloadReviews(runId); });
                }} />
              ) : null}
            </div>
          </React.Fragment>
        )}
      </Main>

      <Inspector>
        <TranslationPanel run={run} selected={selected} />
      </Inspector>
    </React.Fragment>
  );
}

export function MeasureTable({ measures, onSelect }) {
  if (measures.length === 0) {
    return (
      <div style={{ padding: 'var(--space-10)', display: 'grid', placeItems: 'center' }}>
        <EmptyState headline="No measures" accent="yet."
          body="They are built by the build_model stage, from the card aggregations and beast modes." />
      </div>
    );
  }
  return (
    <DataTable
      rows={measures}
      stickyHeader
      zebra
      onRowClick={function (row) { onSelect({ kind: 'measure', measure: row }); }}
      columns={[
        { key: 'name', header: 'Measure', minWidth: 200 },
        { key: 'table', header: 'Table', muted: true, width: 170 },
        {
          key: 'expression', header: 'DAX', minWidth: 300, mono: true,
          render: function (r) {
            return (
              <span style={{
                color: r.needs_review ? 'var(--text-disabled)' : 'var(--provenance-target)',
                whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
                display: 'block', maxWidth: 420,
              }}>{r.expression}</span>
            );
          },
        },
        {
          key: 'needs_review', header: 'Result', width: 160,
          render: function (r) {
            return r.needs_review
              ? <Badge tone="warn" dot>Needs a human</Badge>
              : <Badge tone="target" dot>Translated</Badge>;
          },
        },
      ]}
    />
  );
}

export function ScriptList({ run, scripts, onSelect }) {
  if (!scripts.length) {
    return (
      <div style={{ padding: 'var(--space-10)', display: 'grid', placeItems: 'center' }}>
        <EmptyState headline="No scripts" accent="produced."
          body="Magic ETL dataflows are converted by the external converter service. If this
            dashboard has one, check the converter on the Connections screen." />
      </div>
    );
  }
  return (
    <div style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 10 }}>
      {scripts.map(function (script) {
        return (
          <div key={script.id} onClick={function () { onSelect({ kind: 'script', script: script }); }}
            style={{
              cursor: 'pointer', padding: '12px 14px', borderRadius: 'var(--radius-card)',
              border: '1px solid var(--border-hairline)', background: 'var(--surface-card)',
              display: 'flex', alignItems: 'center', gap: 12,
            }}>
            <Icon name="code" size={15} color="var(--provenance-target)" />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 'var(--text-md)' }}>{script.label || script.path}</div>
              <div className="bit-num" style={{ fontSize: 'var(--text-2xs)', color: 'var(--text-tertiary)', marginTop: 2 }}>
                {script.path}
              </div>
            </div>
            <Figure muted value={formatCount(script.bytes) + ' bytes'} />
          </div>
        );
      })}
    </div>
  );
}

export function ReviewList({ items, onResolve }) {
  if (!items.length) {
    return (
      <div style={{ padding: 'var(--space-10)', display: 'grid', placeItems: 'center' }}>
        <EmptyState tone="target" headline="Nothing" accent="to review."
          body="No stage of this run flagged anything for a human." />
      </div>
    );
  }
  const ordered = items.slice().sort(function (a, b) {
    return (a.severity === 'error' ? 0 : 1) - (b.severity === 'error' ? 0 : 1);
  });
  return (
    <div style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 10 }}>
      {ordered.map(function (item) {
        return (
          <div key={item.id} style={{
            padding: '12px 14px', borderRadius: 'var(--radius-card)',
            border: '1px solid var(--border-hairline)', background: 'var(--surface-card)',
            borderLeft: '3px solid ' + (item.severity === 'error' ? 'var(--status-error)' : 'var(--status-warn)'),
          }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 'var(--text-md)' }}>{item.title}</div>
                <div style={{ display: 'flex', gap: 8, marginTop: 6, alignItems: 'center' }}>
                  <Badge tone={item.severity === 'error' ? 'error' : 'warn'} variant="soft" mono>
                    {item.kind}
                  </Badge>
                  <span className="bit-num" style={{ fontSize: 'var(--text-2xs)', color: 'var(--text-tertiary)' }}>
                    {item.stage}{item.source_id ? ' · ' + item.source_type + ' ' + item.source_id : ''}
                  </span>
                </div>
              </div>
              <div style={{ display: 'flex', gap: 6, flex: 'none' }}>
                <Button size="sm" variant="secondary"
                  onClick={function () { onResolve(item, 'ignored'); }}>Ignore</Button>
                <Button size="sm" variant="secondary"
                  onClick={function () { onResolve(item, 'resolved'); }}>Checked</Button>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// Source above target, amber above teal: the original Domo formula and
// what it became. A translation is only reviewable next to what it came
// from.
export function TranslationPanel({ run, selected }) {
  const [sql, setSql] = React.useState(null);

  React.useEffect(function () {
    if (!selected || selected.kind !== 'script' || !run) { setSql(null); return undefined; }
    let stale = false;
    setSql(null);
    fetchArtefactText(run.id, selected.script.id).then(function (text) {
      if (!stale) setSql(text.slice(0, 60000));
    }, function () {});
    return function () { stale = true; };
  }, [selected && selected.kind, selected && (selected.script ? selected.script.id : null)]);

  if (!selected) {
    return (
      <InspectorBody>
        <EmptyState compact headline="Pick a translation"
          body="The original formula and what it became appear here, one above the other." />
      </InspectorBody>
    );
  }

  if (selected.kind === 'script') {
    return (
      <InspectorBody>
        <div>
          <span className="bit-eyebrow">Warehouse SQL</span>
          <div style={{ fontSize: 'var(--text-lg)', fontWeight: 'var(--weight-semibold)', marginTop: 6 }}>
            {selected.script.label || selected.script.path}
          </div>
        </div>
        {sql === null ? <Spinner /> : <CodeBlock code={sql} language="sql" maxHeight={520} />}
      </InspectorBody>
    );
  }

  const measure = selected.measure;
  // The translator keeps the original Domo formula in the measure's
  // description when it refuses to translate it.
  const original = measure.description || null;

  return (
    <InspectorBody>
      <div>
        <span className="bit-eyebrow">Measure</span>
        <div style={{ fontSize: 'var(--text-2xl)', fontWeight: 'var(--weight-semibold)', letterSpacing: 'var(--tracking-heading)', marginTop: 6, lineHeight: 1.2 }}>
          {measure.name}
        </div>
        <div style={{ marginTop: 8 }}>
          {measure.needs_review
            ? <Badge tone="warn" dot>Needs a human</Badge>
            : <Badge tone="target" dot>Translated</Badge>}
        </div>
      </div>

      {original ? (
        <div>
          <SectionLabel>As found · Domo</SectionLabel>
          <CodeBlock code={original} maxHeight={200} />
        </div>
      ) : null}

      <div>
        <SectionLabel>Generated · DAX</SectionLabel>
        <CodeBlock code={measure.expression} language="dax" maxHeight={220} />
      </div>

      {measure.needs_review ? (
        <Banner tone="warn" title="This one was refused, not guessed">
          The translator only handles the beast-mode shapes it can be sure of. This measure is
          blank in the model and carries its original formula, so the report opens and the gap
          is visible rather than silently wrong.
        </Banner>
      ) : null}

      <KeyValueList dense dividers items={[
        { label: 'Table', value: measure.table },
        { label: 'From', value: measure.origin || 'card aggregation', mono: true },
      ]} />
    </InspectorBody>
  );
}

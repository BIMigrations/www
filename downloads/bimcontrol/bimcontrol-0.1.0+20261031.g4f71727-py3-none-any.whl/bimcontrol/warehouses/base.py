"""The warehouse adapter interface, and the parts every warehouse shares.

A migration needs the customer's own warehouse: data that only exists
inside the source BI platform (a spreadsheet someone uploaded into Domo)
has to land somewhere the target platform can read. That is this package's
job, and it is deliberately BIMControl's rather than a converter's --
every source platform and every target warehouse needs it, so it cannot
live inside one Domo-to-Redshift translator.

Adapters do four things: make a schema, make a table, load a file into it,
and say what to call it in SQL. Everything above them (which datasets need
landing, what to tell a converter afterwards) is the pipeline's business.

Secrets are read from the environment, never from the control database and
never written to an artefact -- a run's artefacts get handed around, and a
warehouse password is not something to hand around with them.
"""

from __future__ import annotations

import contextlib
import csv
import datetime as _dt
import hashlib
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterator

# Below this, a plain batched INSERT is quicker than staging a file and is
# one less moving part. Above it, staging is the only sane route: a few
# million single-row inserts into a columnar warehouse is unusable.
BULK_LOAD_ROW_THRESHOLD = 50_000

# The first column of a landed table: the row's position in Domo's export (bimcontrol#361). Domo's Remove
# Duplicates keeps the first row of a key in the dataset's stored order, and a warehouse table has none.
ROW_ORDER_COLUMN = "_domo_row_"


class WarehouseError(Exception):
    pass


class WarehouseNotConfigured(WarehouseError):
    """Credentials or settings are missing. Says which, so it is fixable."""


@dataclass
class ColumnSpec:
    name: str
    source_type: str          # the source platform's type, e.g. Domo's STRING
    max_bytes: int | None = None   # measured from the data, for sizing


@dataclass
class TableSpec:
    schema: str
    table: str
    columns: list[ColumnSpec]
    source_id: str | None = None     # the dataSourceId this came from
    source_name: str | None = None

    @property
    def ref(self) -> str:
        return f"{self.schema}.{self.table}"


@dataclass
class LoadResult:
    table_ref: str
    rows_loaded: int
    method: str                      # copy_from_s3 | insert
    bytes_staged: int | None = None
    warnings: list[str] = field(default_factory=list)


class WarehouseAdapter(ABC):
    """One warehouse. Implementations live next to this file."""

    key: str = "abstract"
    display_name: str = "Abstract warehouse"

    def __init__(self, settings: dict[str, Any] | None = None):
        self.settings = settings or {}

    # ---- lifecycle ------------------------------------------------------

    @abstractmethod
    def connect(self) -> None:
        ...

    @abstractmethod
    def close(self) -> None:
        ...

    def __enter__(self) -> "WarehouseAdapter":
        self.connect()
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    # ---- schema and tables ----------------------------------------------

    @abstractmethod
    def ensure_schema(self, schema: str) -> None:
        ...

    @abstractmethod
    def create_table(self, spec: TableSpec, replace: bool = True) -> None:
        ...

    @abstractmethod
    def load_csv(self, spec: TableSpec, csv_path: Path, row_count: int | None = None) -> LoadResult:
        ...

    @abstractmethod
    def row_count(self, schema: str, table: str) -> int:
        ...

    @abstractmethod
    def table_exists(self, schema: str, table: str) -> bool:
        ...

    def table_has_column(self, schema: str, table: str, column: str) -> bool:
        """Whether the table has the column. An adapter that cannot tell says yes, so nothing is landed again for it."""
        return True

    def validate_sql(self, sql: str) -> tuple[bool, str | None]:
        """Ask the warehouse whether it would accept this SQL.

        Planning a statement catches what a converter cannot: columns that
        do not exist, and branches of a UNION that do not line up. It does
        not prove the results are right, only that the query is runnable.
        Adapters that cannot do this return (True, None) rather than
        blocking a migration on a check they cannot perform.
        """
        return True, None

    def query_row(self, sql: str, timeout_seconds: int = 120) -> tuple[Any, ...] | None:
        """The first row of a read-only query, or None when the adapter cannot run one.

        For checks about the data a converted script would produce, which are worth having
        and never worth failing a run: a query that errors or times out raises, the caller decides.
        """
        return None

    def describe_sql(self, sql: str) -> list[tuple[str, str]] | None:
        """The columns this SQL returns, as (name, Domo-style type), or None when unknown.

        The scan's output schema of a dataflow is only as fresh as the scan; the
        statement is what a model will actually read.
        """
        return None

    def create_table_as(
        self, schema: str, name: str, sql: str, reuse_within: _dt.timedelta | None = None,
    ) -> str:
        """Materialise a query as a table (replacing one of that name) and return its reference.

        `reuse_within`: a table already built under `name` from this very query,
        over inputs that have not been rebuilt since, and no older than this, is
        returned as it is. A resumed run does not pay again, at half an hour a
        table, for what it already built.
        """
        raise WarehouseError(f"{self.key} cannot create tables from queries yet")

    def create_view(self, schema: str, name: str, sql: str) -> str:
        """Publish a query as a named relation and return its reference.

        Used to hand one converted dataflow's output to the dataflows that
        read it. A view rather than a table: nothing is copied, and the
        data stays as fresh as the tables underneath it.
        """
        raise WarehouseError(f"{self.key} cannot create views yet")

    def lowercase_copy(
        self, source_ref: str, schema: str, name: str, reuse_since: _dt.datetime | None = None,
        reuse_within: _dt.timedelta | None = None,
    ) -> str | None:
        """Copy a table or view with lower-case column names and empty text as null, as Domo reads it.

        Converted SQL (and Power BI's query) address columns by quoted name, and a
        warehouse that folds those to lower case cannot find a column stored as
        'Dept Name'. Returns the new table's reference, or None when the source
        needs no copy (or this warehouse cannot make one).

        `reuse_since` (naive UTC): a copy already built under `name` at or after
        that moment is returned as it is. A resumed run passes its start so it
        does not rebuild, at minutes a table, what it built before it stopped.
        `reuse_within`: as for create_table_as.

        Domo reads an empty string from a connector as null, so the copy does the same
        for text columns; a source with neither mixed-case names nor text needs no copy.
        """
        return None

    def empty_text_as_null(self, sql: str) -> str | None:
        """`sql` wrapped so that an empty string in a text column is null, as Domo stores it; None: nothing to wrap
        (or this warehouse cannot say)."""
        return None

    def table_created_at(self, schema: str, table: str) -> _dt.datetime | None:
        """When the table was created (naive UTC), or None when this warehouse cannot say."""
        return None

    def mark_data_as_of(self, schema: str, table: str, as_of: _dt.datetime) -> None:
        """Record on the table the moment (naive UTC) its data was read from the source. Default: not recorded."""

    def table_data_as_of(self, schema: str, table: str) -> _dt.datetime | None:
        """When the data in the table was read from its source (naive UTC): what `mark_data_as_of` recorded, else the
        creation time. A table is created after its export has run, so the creation time is later than the data."""
        return self.table_created_at(schema, table)

    def building(self, schema: str, name: str):
        """A lock held while one process builds or lands a table, so two batch lanes do not both do it. Default: none."""
        return contextlib.nullcontext()

    def table_ref(self, schema: str, table: str) -> str:
        return f"{schema}.{table}"

    # ---- checks ---------------------------------------------------------

    def check(self) -> dict[str, Any]:
        """Prove the connection works before a migration depends on it."""
        self.connect()
        try:
            return {"warehouse": self.key, "ok": True}
        finally:
            self.close()


# ---- naming -------------------------------------------------------------

_UNSAFE = re.compile(r"[^a-z0-9_]+")


def safe_table_name(source_name: str | None, source_id: str, prefix: str = "") -> str:
    """A stable, legal table name for a source object.

    Two properties matter more than prettiness. It must be **stable** --
    the same dataset must produce the same name on every run, or a resumed
    migration lands a second copy alongside the first. And it must be
    **unique** -- Domo names collide constantly ("Clinic Posting Date"
    appears a dozen times in this estate), so a short hash of the id is
    appended rather than trusting the name.
    """
    base = _UNSAFE.sub("_", (source_name or "dataset").strip().lower()).strip("_")
    base = re.sub(r"_+", "_", base) or "dataset"
    digest = hashlib.sha1(str(source_id).encode()).hexdigest()[:8]
    # Warehouses cap identifiers (Redshift and Snowflake at 127, BigQuery
    # higher); 63 keeps room for the hash and suits Postgres-family limits.
    room = 63 - len(digest) - 1 - len(prefix)
    return f"{prefix}{base[:room].strip('_')}_{digest}"


# ---- measuring the data -------------------------------------------------


def scan_csv_widths(csv_path: Path, sample_rows: int | None = None) -> tuple[dict[str, int], int]:
    """Widest value per column, in bytes, plus the row count.

    Worth the pass over the file: sizing every string column at the maximum
    is not an option on a wide table. Redshift caps a row at 4MB, so 82
    columns declared VARCHAR(65535) is rejected outright -- and even where
    it is accepted, it wrecks the query planner's memory estimates.
    """
    widths: dict[str, int] = {}
    rows = 0
    # utf-8-sig: a byte-order mark would be part of the first column's name, and the table is named from this header
    with csv_path.open("r", newline="", encoding="utf-8-sig", errors="replace") as handle:
        reader = csv.DictReader(handle)
        for field_name in reader.fieldnames or []:
            widths[field_name] = 0
        for row in reader:
            rows += 1
            for key, value in row.items():
                if key is None or value is None:
                    continue
                length = len(value.encode("utf-8"))
                if length > widths.get(key, 0):
                    widths[key] = length
            if sample_rows is not None and rows >= sample_rows:
                break
    return widths, rows


def number_csv_rows(csv_path: Path) -> int:
    """Put the row's position in the file in front of every row, under ROW_ORDER_COLUMN; returns the row count.

    In front, not behind: Redshift's COPY fills a short row's missing trailing fields (FILLRECORD), and a number
    in the last place would land in the wrong column of such a row.
    """
    numbered = csv_path.with_name(csv_path.name + ".numbered")
    rows = 0
    # surrogateescape: bytes that are not UTF-8 go back out as they came in (COPY decides what to do with them)
    try:
        with csv_path.open("r", newline="", encoding="utf-8-sig", errors="surrogateescape") as source, \
                numbered.open("w", newline="", encoding="utf-8", errors="surrogateescape") as target:
            reader, writer = csv.reader(source), csv.writer(target, lineterminator="\n")
            header = next(reader, None)
            if header is None:
                return 0
            writer.writerow([ROW_ORDER_COLUMN, *header])
            for row in reader:
                rows += 1
                writer.writerow([rows, *row])
        numbered.replace(csv_path)
    finally:
        numbered.unlink(missing_ok=True)
    return rows


def varchar_size(max_bytes: int | None, minimum: int = 64, maximum: int = 65535) -> int:
    """Round a measured width up to a power of two, within bounds.

    Rounding up leaves headroom for values longer than anything seen so
    far, without the guesswork of a flat default.
    """
    size = minimum
    target = max(max_bytes or 0, 1)
    while size < target and size < maximum:
        size *= 2
    return min(max(size, minimum), maximum)


def read_csv_rows(csv_path: Path, batch_size: int = 1000) -> Iterator[list[tuple]]:
    """CSV in batches of tuples, with empty strings as NULL.

    Streamed rather than read whole: a landed dataset can be millions of
    rows, and the point of this package is to move data the machine cannot
    necessarily hold.
    """
    with csv_path.open("r", newline="", encoding="utf-8", errors="replace") as handle:
        reader = csv.reader(handle)
        next(reader, None)  # header
        batch: list[tuple] = []
        for row in reader:
            batch.append(tuple(value if value != "" else None for value in row))
            if len(batch) >= batch_size:
                yield batch
                batch = []
        if batch:
            yield batch

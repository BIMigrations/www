"""Power BI model roles (stored by the scan as {name, model_permission, members, filters}) in the shared shape."""

from __future__ import annotations


def describe_policies(roles: list[dict]) -> list[dict]:
    return [
        {
            "name": r.get("name"),
            "applies_to": [{"kind": "member", "label": str(m)} for m in r.get("members") or []],
            "filters": [f"{f.get('table')}: {f.get('expression')}" for f in r.get("filters") or []],
            "access": r.get("model_permission"),
        }
        for r in roles
    ]

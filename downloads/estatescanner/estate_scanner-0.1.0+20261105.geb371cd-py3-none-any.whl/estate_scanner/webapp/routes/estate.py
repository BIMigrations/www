from __future__ import annotations

import json

from fastapi import APIRouter, Depends, HTTPException

from estate_scanner import graph as graph_module
from estate_scanner.core import policies as policies_module
from estate_scanner.core.registry import all_object_types, get_object_type
from estate_scanner.storage import db

from ..deps import get_conn
from ..graph_cache import get_graph

router = APIRouter()

# Allow-listed sortable columns per object type -- never accept a raw
# column name from the request straight into SQL.
_SORTABLE = {
    "dataset": ["name", "provider_type", "row_count", "column_count", "updated_at", "downstream_card_count", "policy_count"],
    "dataflow": ["name", "engine", "num_inputs", "num_outputs", "last_execution_state", "modified_at"],
    "card": ["name", "type", "dataset_id"],
    "dashboard": ["name", "parent_dashboard_id"],
    "user": ["name", "email", "role"],
    "group": ["name"],
    "account": ["name", "connector_type"],
    "calculated_field": ["name", "formula_language", "status"],
    "alert": ["name", "resource_type", "disabled"],
    "app": ["name", "type"],
    "workspace": ["name", "type", "state", "capacity_id"],
    "gateway": ["name", "type", "status", "machine", "version"],
}


def _scope(conn, platform: str | None, instance: str | None) -> tuple[str, list]:
    """SQL for the (platform, instance) pairs a request reads. A platform holding several instances and no
    `instance` in the request shows the one its newest scan was run against."""
    return db.scope_sql(db.scope(conn, platform, instance, latest=True))

# Number of row-level policies on a dataset: NULL when none was captured (pdp_json null or not a list),
# 0 when the platform answered with none, otherwise the count. See core/policies.py.
_POLICY_COUNT = ("CASE WHEN json_valid(pdp_json) THEN "
                 "CASE WHEN json_type(pdp_json) = 'array' THEN json_array_length(pdp_json) END END")
_POLICY_FILTERS = {"any": f"{_POLICY_COUNT} > 0", "none": f"{_POLICY_COUNT} = 0", "not_captured": f"{_POLICY_COUNT} IS NULL"}


@router.get("/summary")
def summary(conn=Depends(get_conn), platform: str | None = None, instance: str | None = None):
    pairs = db.scope(conn, platform, instance, latest=True)
    where, params = db.scope_sql(pairs)
    counts = {}
    for descriptor in all_object_types():
        counts[descriptor.object_type] = conn.execute(f"SELECT COUNT(*) FROM {descriptor.table} WHERE {where}", params).fetchone()[0]  # noqa: S608 -- registry table names
    edge_count = conn.execute(f"SELECT COUNT(*) FROM edges WHERE {where}", params).fetchone()[0]  # noqa: S608
    last_scan = conn.execute(
        f"SELECT id, platform, instance, started_at, finished_at, status FROM scans WHERE {where} ORDER BY id DESC LIMIT 1", params  # noqa: S608
    ).fetchone()
    # Everything the file holds, so a screen can offer the other instances (#56); `selected` is what the counts above cover.
    held = [{"platform": p, "instance": i, "selected": (p, i) in pairs} for p in db.list_platforms(conn) for i in db.list_instances(conn, p)]
    return {"counts": counts, "edge_count": edge_count, "last_scan": dict(last_scan) if last_scan else None, "instances": held}


@router.get("/instances")
def instances(conn=Depends(get_conn)):
    """Every (platform, instance) the file holds, with its newest completed scan, for the screens' instance picker."""
    pairs = [(p, i) for p in db.list_platforms(conn) for i in db.list_instances(conn, p)]
    latest = db.latest_completed_scans(conn, pairs)
    return [
        {"platform": p, "instance": i,
         "latest_scan_id": latest[(p, i)]["id"] if (p, i) in latest else None,
         "latest_scan_finished_at": latest[(p, i)]["finished_at"] if (p, i) in latest else None}
        for p, i in pairs
    ]


@router.get("/{object_type}")
def list_objects(
    object_type: str,
    conn=Depends(get_conn),
    page: int = 1,
    page_size: int = 100,
    sort: str | None = None,
    dir: str = "asc",
    q: str | None = None,
    owner: str | None = None,
    platform: str | None = None,
    instance: str | None = None,
    policy: str | None = None,
    not_seen: bool = False,
):
    try:
        descriptor = get_object_type(object_type)
    except KeyError:
        raise HTTPException(404, f"Unknown object type: {object_type}") from None

    allowed_sorts = _SORTABLE.get(object_type, ["name"])
    sort_col = sort if sort in allowed_sorts else allowed_sorts[0]
    sort_dir = "DESC" if dir.lower() == "desc" else "ASC"

    pairs = db.scope(conn, platform, instance, latest=True)
    scope_sql, params = db.scope_sql(pairs)
    not_seen_sql, not_seen_params = db.not_seen_sql(conn, pairs)
    where: list[str] = [scope_sql]
    if not_seen:
        where.append(not_seen_sql)
        params.extend(not_seen_params)
    if owner:
        where.append("owner_id = ?")
        params.append(owner)
    if q:
        where.append(f"{descriptor.name_column} LIKE ?")
        params.append(f"%{q}%")
    if policy is not None:
        if object_type != "dataset" or policy not in _POLICY_FILTERS:
            raise HTTPException(400, f"policy must be one of {sorted(_POLICY_FILTERS)} and applies to datasets only")
        where.append(_POLICY_FILTERS[policy])
    where_sql = f"WHERE {' AND '.join(where)}" if where else ""

    total = conn.execute(f"SELECT COUNT(*) FROM {descriptor.table} {where_sql}", params).fetchone()[0]  # noqa: S608 -- table/column names are allow-listed above, never request-supplied raw
    page = max(1, page)
    page_size = max(1, min(page_size, 500))
    offset = (page - 1) * page_size
    extra = f", {_POLICY_COUNT} AS policy_count" if object_type == "dataset" else ""
    rows = conn.execute(
        f"SELECT *{extra} FROM {descriptor.table} {where_sql} ORDER BY {sort_col} {sort_dir} LIMIT ? OFFSET ?",  # noqa: S608
        [*params, page_size, offset],
    ).fetchall()
    latest = db.latest_completed_scans(conn, pairs)
    # of everything the filters match, not only this page: "N were not in the latest scan" is what a user acts on
    not_seen_total = total if not_seen else conn.execute(
        f"SELECT COUNT(*) FROM {descriptor.table} {where_sql} AND {not_seen_sql}", [*params, *not_seen_params]  # noqa: S608
    ).fetchone()[0]
    return {"rows": [{**dict(r), "not_seen_in_latest_scan": _not_seen(r, latest)} for r in rows],
            "total": total, "not_seen_total": not_seen_total, "page": page, "page_size": page_size}


def _not_seen(row, latest) -> bool:
    """Whether the newest completed scan of the row's instance began after the scan that last returned it."""
    scan = latest.get((row["platform"], row["instance"]))
    return scan is not None and row["last_seen_scan_id"] is not None and row["last_seen_scan_id"] < scan["id"]


@router.get("/{object_type}/{object_id}")
def get_object(object_type: str, object_id: str, conn=Depends(get_conn), platform: str | None = None, instance: str | None = None):
    try:
        descriptor = get_object_type(object_type)
    except KeyError:
        raise HTTPException(404, f"Unknown object type: {object_type}") from None

    scope_sql, scope_params = _scope(conn, platform, instance)
    row = conn.execute(f"SELECT * FROM {descriptor.table} WHERE {scope_sql} AND id = ? ORDER BY platform LIMIT 1", [*scope_params, object_id]).fetchone()  # noqa: S608
    if row is None:
        raise HTTPException(404, "Object not found")
    platform, instance = row["platform"], row["instance"]

    g = get_graph(conn, platform, instance)
    node_key = f"{platform}:{object_type}:{object_id}"

    result = dict(row)
    result["not_seen_in_latest_scan"] = _not_seen(row, db.latest_completed_scans(conn, [(platform, instance)]))
    result["upstream"] = [_node_summary(g, k) for k in _neighbors(g, node_key, upstream=True)]
    result["downstream"] = [_node_summary(g, k) for k in _neighbors(g, node_key, upstream=False)]
    # Role edges are not lineage (the graph leaves them out); read them from the table.
    result["access"] = _role_edges(conn, platform, instance, object_type, object_id, holders=True)
    result["holds"] = _role_edges(conn, platform, instance, object_type, object_id, holders=False)
    if object_type == "dataset":
        result["policy_status"] = policies_module.policy_status(row["pdp_json"])
        result["policies"] = _named_policies(conn, platform, instance, policies_module.describe(platform, row["pdp_json"]))
    if object_type in ("dataset", "dataflow"):
        result["refreshes"] = [dict(r) for r in conn.execute(
            "SELECT id, refresh_type, status, started_at, ended_at, error FROM refreshes "
            "WHERE platform = ? AND instance = ? AND object_type = ? AND object_id = ? ORDER BY started_at DESC, id LIMIT 200",
            (platform, instance, object_type, object_id))]
    return result


def _named_policies(conn, platform: str, instance: str, policies: list[dict]) -> list[dict]:
    """Fills in the name of each user/group a policy applies to, from the same instance's scan; an id the instance does not hold stays an id
    (the same numeric id can be another person in another instance, #55)."""
    wanted: dict[str, set[str]] = {"user": set(), "group": set()}
    for p in policies:
        for a in p["applies_to"]:
            if a["kind"] in wanted:
                wanted[a["kind"]].add(a["id"])
    names: dict[tuple[str, str], str | None] = {}
    for kind, table in (("user", "users"), ("group", "groups_")):
        ids = sorted(wanted[kind])
        for i in range(0, len(ids), 500):
            chunk = ids[i:i + 500]
            for r in conn.execute(f"SELECT id, name FROM {table} WHERE platform = ? AND instance = ? AND id IN ({','.join('?' * len(chunk))})", (platform, instance, *chunk)):  # noqa: S608
                names[(kind, r["id"])] = r["name"]
    for p in policies:
        for a in p["applies_to"]:
            if (a["kind"], a.get("id")) in names:
                a["name"] = names[(a["kind"], a["id"])]
    return policies


def _role_edges(conn, platform: str, instance: str, object_type: str, object_id: str, holders: bool) -> list[dict]:
    """The has_role edges into this object (who holds a role on it: `holders`) or out of it (what
    it holds a role on), with the other end's name and the role."""
    here, there = ("dst", "src") if holders else ("src", "dst")
    rows = conn.execute(
        f"SELECT {there}_type AS type, {there}_id AS id, raw_json FROM edges "  # noqa: S608
        f"WHERE platform = ? AND instance = ? AND edge_type = 'has_role' AND {here}_type = ? AND {here}_id = ? ORDER BY {there}_type, {there}_id",
        (platform, instance, object_type, object_id),
    ).fetchall()
    names: dict[tuple[str, str], str | None] = {}
    by_type: dict[str, list[str]] = {}
    for row in rows:
        by_type.setdefault(row["type"], []).append(row["id"])
    for t, ids in by_type.items():
        try:
            d = get_object_type(t)
        except KeyError:
            continue
        for i in range(0, len(ids), 500):
            chunk = ids[i:i + 500]
            for r in conn.execute(
                f"SELECT id, {d.name_column} AS name FROM {d.table} WHERE platform = ? AND instance = ? AND id IN ({','.join('?' * len(chunk))})",  # noqa: S608
                (platform, instance, *chunk),
            ):
                names[(t, r["id"])] = r["name"]
    out = []
    for row in rows:
        try:
            role = json.loads(row["raw_json"]).get("role") if row["raw_json"] else None
        except ValueError:
            role = None
        out.append({"type": row["type"], "id": row["id"], "name": names.get((row["type"], row["id"])), "role": role})
    return out


def _neighbors(g, node_key: str, upstream: bool) -> list[str]:
    if node_key not in g.nodes:
        return []
    reach = graph_module.upstream(g, node_key) if upstream else graph_module.downstream(g, node_key)
    return sorted(reach)


def _node_summary(g, node_key: str) -> dict:
    attrs = g.nodes[node_key]
    return {"platform": attrs["platform"], "instance": attrs["instance"], "type": attrs["type"], "id": attrs["id"], "name": attrs["name"]}

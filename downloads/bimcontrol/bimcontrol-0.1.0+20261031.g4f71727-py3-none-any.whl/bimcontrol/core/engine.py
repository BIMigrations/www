"""The run engine: executes a pipeline's stages against one migration unit.

A stage is a named function taking a `RunContext` and returning a
`StageResult`. A pipeline is an ordered list of them. The engine's whole
job is the boring part around that -- recording what happened, skipping
what is already done, and stopping cleanly.

Three rules shape everything here.

**Stages talk to each other through artefacts, not memory.** A resumed run
skips its completed stages, so anything a later stage needs must have been
written to disk, not left in a variable. `ctx.write_json()` /
`ctx.read_json()` are the channel. This is also why the artefacts are
worth reading: they are the real intermediate state, not a debug dump.

**A warning is not a failure.** Real estates are full of objects that
cannot be converted cleanly. Those become review items and the run carries
on; only an exception stops it. A migration that completes with a known
gap list is worth far more than one that dies on object 400 of 3,000.

**Stopping early is a normal outcome, not an error.** `--until`, a stage
nobody has built yet, and cancellation all end a run as `incomplete` with
a reason, which is different from `failed`.
"""

from __future__ import annotations

import hashlib
import json
import socket
import threading
import traceback
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Sequence

from bimcontrol import paths
from bimcontrol.core import provenance
from bimcontrol.estate.reader import EstateReader
from bimcontrol.storage import db


class StageNotImplemented(Exception):
    """Raised by a stage that is declared in the pipeline but not yet built.

    Declaring the whole pipeline from the start means a run shows every
    station of the factory line with the built ones lit up, rather than the
    pipeline appearing to grow as the product does.
    """


class RunCancelled(Exception):
    pass


@dataclass
class ReviewItem:
    """Something a human has to decide, raised by a stage."""

    kind: str
    title: str
    severity: str = "warn"
    source_type: str | None = None
    source_id: str | None = None
    detail: dict[str, Any] | None = None


@dataclass
class StageResult:
    """What a stage reports back. Everything is optional: a stage that just
    writes an artefact and has nothing to say returns an empty one."""

    summary: dict[str, Any] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    review_items: list[ReviewItem] = field(default_factory=list)


@dataclass
class Stage:
    """One station on the line.

    `version` is part of the fingerprint: bumping it invalidates completed
    work on resume, which is what you want when the stage's own logic
    changes rather than its inputs.
    """

    name: str
    title: str
    run: Callable[["RunContext"], StageResult | None]
    version: str = "1"
    fingerprint: Callable[["RunContext"], str] | None = None


@dataclass
class Pipeline:
    """`finish`, if set, is called once the run's final status is in the control database, for an artefact that
    quotes the run (a report is written by its own stage, while the run is still `running`)."""

    name: str
    stages: Sequence[Stage]
    finish: Callable[["RunContext", dict[str, Any]], None] | None = None

    def stage_names(self) -> list[str]:
        return [s.name for s in self.stages]

    def find(self, name: str) -> Stage | None:
        return next((s for s in self.stages if s.name == name), None)


class RunContext:
    """What a stage is handed: where to read from, where to write to, and
    how to say what is happening.

    Owns one control-database connection for the whole run, used from the
    run's own thread.
    """

    def __init__(
        self,
        conn,
        project: dict[str, Any],
        unit: dict[str, Any],
        run_id: str,
        run_dir: Path,
        estate_db_path: str | Path,
        options: dict[str, Any] | None = None,
        cancel_event: threading.Event | None = None,
    ):
        self.conn = conn
        self.project = project
        self.unit = unit
        self.run_id = run_id
        self.run_dir = Path(run_dir)
        self.estate_db_path = Path(estate_db_path)
        self.options = options or {}
        self.cancel_event = cancel_event or threading.Event()
        self.stage: str | None = None
        # In-run cache only. Never the channel between stages: a resumed run
        # starts with this empty. See the module docstring.
        self.state: dict[str, Any] = {}

    # ---- source access --------------------------------------------------

    def estate(self) -> EstateReader:
        """A read-only reader for the scan. Caller closes it, or uses it as
        a context manager."""
        return EstateReader(
            self.estate_db_path, platform=self.project["source_platform"], instance=self.project.get("source_instance")
        )

    @property
    def source_object_id(self) -> str:
        return self.unit["source_object_id"]

    # ---- artefacts ------------------------------------------------------

    def stage_dir(self, stage: str | None = None) -> Path:
        directory = self.run_dir / (stage or self.stage or "run")
        directory.mkdir(parents=True, exist_ok=True)
        return directory

    def write_json(self, filename: str, payload: Any, kind: str = "json", label: str | None = None) -> Path:
        path = self.stage_dir() / filename
        path.write_text(json.dumps(payload, indent=2, default=str))
        self._record(path, kind=kind, label=label, media_type="application/json")
        return path

    def write_text(
        self, filename: str, text: str, kind: str = "text", label: str | None = None,
        media_type: str = "text/plain",
    ) -> Path:
        path = self.stage_dir() / filename
        path.write_text(text)
        self._record(path, kind=kind, label=label, media_type=media_type)
        return path

    def read_json(self, stage: str, filename: str) -> Any:
        """Read an artefact an earlier stage wrote. Raises if it is missing,
        because a stage asking for it cannot proceed without it."""
        path = self.run_dir / stage / filename
        if not path.exists():
            raise FileNotFoundError(
                f"Stage {self.stage!r} needs {filename!r} from stage {stage!r}, "
                f"but {path} does not exist -- did that stage run?"
            )
        return json.loads(path.read_text())

    def _record(self, path: Path, kind: str, label: str | None, media_type: str | None) -> None:
        data = path.read_bytes()
        db.record_artefact(
            self.conn,
            run_id=self.run_id,
            stage=self.stage or "run",
            kind=kind,
            path=str(path.relative_to(self.run_dir)),
            label=label,
            media_type=media_type,
            size_bytes=len(data),
            sha256=hashlib.sha256(data).hexdigest(),
        )

    # ---- talking back ---------------------------------------------------

    def emit(
        self, event_type: str, message: str | None = None, level: str = "info", **payload: Any
    ) -> None:
        db.append_event(
            self.conn, self.run_id, event_type, message=message, stage=self.stage,
            level=level, payload=payload or None,
        )

    def progress(self, message: str, **payload: Any) -> None:
        self.emit("stage.progress", message, **payload)

    def check_cancelled(self) -> None:
        """Call inside any loop long enough that a user would wait on it."""
        if self.cancel_event.is_set():
            raise RunCancelled()


def worker_id() -> str:
    """This node's identity, stable across restarts.

    Solo today, but a run has to say which machine owns it before a swarm
    can tell a slow node from a dead one.
    """
    path = paths.worker_id_path()
    if path.exists():
        return path.read_text().strip()
    identity = f"{socket.gethostname()}-{db.new_id('w').split('_')[1][:6]}"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(identity)
    return identity


def closure_fingerprint(summary: dict[str, Any]) -> str:
    return hashlib.sha256(json.dumps(summary, sort_keys=True, default=str).encode()).hexdigest()[:16]


def _stage_fingerprint(stage: Stage, ctx: RunContext) -> str:
    parts = [stage.name, stage.version, ctx.unit["source_object_id"]]
    if stage.fingerprint is not None:
        parts.append(stage.fingerprint(ctx))
    return hashlib.sha256("|".join(parts).encode()).hexdigest()[:16]


def start_run(
    conn,
    pipeline: Pipeline,
    project: dict[str, Any],
    unit: dict[str, Any],
    estate_db_path: str | Path,
    options: dict[str, Any] | None = None,
) -> str:
    """Create the run row, its stage rows and its directory. Split from
    `execute` so a caller can hand the id straight back to a client and let
    the work happen in the background."""
    run_id = db.new_run_id()
    run_dir = paths.run_dir(run_id)
    run_dir.mkdir(parents=True, exist_ok=True)
    conn.execute(
        "INSERT INTO runs (id, project_id, unit_id, pipeline, status, worker_id, run_dir,"
        " options_json, started_at, heartbeat_at) VALUES (?, ?, ?, ?, 'running', ?, ?, ?, ?, ?)",
        (
            run_id, project["id"], unit["id"], pipeline.name, worker_id(), str(run_dir),
            json.dumps(options or {}), db.now(), db.now(),
        ),
    )
    conn.execute(
        "UPDATE migration_units SET latest_run_id = ?, status = 'running', updated_at = ? WHERE id = ?",
        (run_id, db.now(), unit["id"]),
    )
    conn.commit()
    db.seed_stages(conn, run_id, [(s.name, s.title) for s in pipeline.stages])
    return run_id


def execute(
    conn,
    pipeline: Pipeline,
    run_id: str,
    estate_db_path: str | Path,
    until: str | None = None,
    cancel_event: threading.Event | None = None,
) -> dict[str, Any]:
    """Run the pipeline's stages in order, skipping what is already done.

    Returns the finished run row. Never raises for a stage failure -- that
    is recorded on the run and reported; it only propagates if the control
    database itself is unusable.
    """
    provenance.code_sha()                    # the commit that is running, read before anything else can change it
    scan_read = provenance.estate_scan(estate_db_path)           # the scan this call's stages read, not one that lands meanwhile
    run = db.get_run(conn, run_id)
    project = db.get_project(conn, run["project_id"])
    unit = db.get_unit(conn, run["unit_id"])
    options = run.get("options") or {}
    # `until` is deliberately NOT inherited from the run's stored options:
    # those record what the run was originally asked to do, and resuming
    # without saying otherwise means "carry on to the end", not "stop where
    # you stopped last time".

    ctx = RunContext(
        conn=conn, project=project, unit=unit, run_id=run_id, run_dir=Path(run["run_dir"]),
        estate_db_path=estate_db_path, options=options, cancel_event=cancel_event,
    )

    # Re-seed in case the pipeline gained a stage since this run started.
    # Without it, a run created before a stage existed can never execute
    # that stage -- and "add a stage" is how this tool grows.
    db.seed_stages(conn, run_id, [(s.name, s.title) for s in pipeline.stages])

    db.update_run(conn, run_id, status="running", finished_at=None, error=None, error_stage=None)
    ctx.stage = None
    ctx.emit("run.started", f"Migrating {unit.get('name') or unit['source_object_id']}",
             pipeline=pipeline.name, stages=pipeline.stage_names(), until=until)

    status = "succeeded"
    stopped_reason: str | None = None
    error: str | None = None
    error_stage: str | None = None

    for stage in pipeline.stages:
        ctx.stage = stage.name
        db.heartbeat(conn, run_id)

        fingerprint = _stage_fingerprint(stage, ctx)
        recorded = db.get_stage(conn, run_id, stage.name)
        if recorded and recorded["status"] in ("succeeded", "skipped") \
                and recorded["fingerprint"] == fingerprint:
            # Deliberately leaves the status alone. Overwriting "succeeded"
            # with "skipped" made the stage look unfinished to the *next*
            # resume, which then re-ran the whole pipeline -- including
            # stages that call out to a live platform. That a stage was
            # skipped on this pass is an event, not a new state.
            ctx.emit("stage.skipped", f"{stage.title} is already done", level="debug")
            if until and stage.name == until:
                status, stopped_reason = "incomplete", f"stopped after {stage.name} as asked"
                break
            continue

        attempt = int(recorded["attempt"] or 0) + 1 if recorded else 1
        db.update_stage(
            conn, run_id, stage.name, status="running", attempt=attempt,
            started_at=db.now(), finished_at=None, error=None, fingerprint=fingerprint,
        )
        db.clear_open_review_items(conn, run_id, stage.name)
        ctx.emit("stage.started", stage.title)
        converter_url = provenance.converter_url(project) if stage.name == provenance.CONVERTER_STAGE else None
        build_before = provenance.converter_build(converter_url)

        try:
            result = stage.run(ctx) or StageResult()
        except StageNotImplemented as exc:
            db.update_stage(conn, run_id, stage.name, status="not_implemented", finished_at=db.now(),
                            error=str(exc) or None)
            ctx.emit("stage.not_implemented", f"{stage.title} is not built yet", level="warn")
            status = "incomplete"
            stopped_reason = f"{stage.name} is not implemented yet"
            break
        except RunCancelled:
            db.update_stage(conn, run_id, stage.name, status="cancelled", finished_at=db.now())
            ctx.emit("stage.cancelled", f"{stage.title} was cancelled", level="warn")
            status, stopped_reason = "cancelled", "cancelled"
            break
        except Exception as exc:  # noqa: BLE001 -- a stage failing is data, not a crash
            detail = traceback.format_exc()
            db.update_stage(conn, run_id, stage.name, status="failed", finished_at=db.now(),
                            error=f"{type(exc).__name__}: {exc}")
            ctx.emit("stage.failed", f"{stage.title} failed: {exc}", level="error", traceback=detail)
            status, error, error_stage = "failed", f"{type(exc).__name__}: {exc}", stage.name
            break

        for item in result.review_items:
            db.add_review_item(
                conn, run_id=run_id, unit_id=unit["id"], stage=stage.name, kind=item.kind,
                title=item.title, severity=item.severity, source_type=item.source_type,
                source_id=item.source_id, detail=item.detail,
            )
        for warning in result.warnings:
            ctx.emit("stage.warning", warning, level="warn")

        db.update_stage(
            conn, run_id, stage.name, status="succeeded", finished_at=db.now(),
            warning_count=len(result.warnings), result=result.summary,
        )
        # A converter redeployed during its stage converted with the old build for part of it: no build is recorded then.
        build = build_before if build_before and build_before == provenance.converter_build(converter_url) else None
        provenance.record_stage(ctx.stage_dir(stage.name), stage.name, converter_build=build,
                                estate_scan=scan_read if stage.name == provenance.FIRST_STAGE else None)
        ctx.emit("stage.succeeded", f"{stage.title}: done", **result.summary)

        if until and stage.name == until:
            status, stopped_reason = "incomplete", f"stopped after {stage.name} as asked"
            break

    ctx.stage = None
    open_reviews = db.count_open_reviews(conn, run_id)
    db.update_run(
        conn, run_id, status=status, finished_at=db.now(), error=error,
        error_stage=error_stage, stopped_reason=stopped_reason,
    )
    unit_status = "needs_review" if status == "succeeded" and open_reviews else status
    db.update_unit(conn, unit["id"], status=unit_status)
    final = db.get_run(conn, run_id)
    if pipeline.finish:
        try:
            pipeline.finish(ctx, final)
        except Exception as exc:  # the run is over and its status is true; a stale quote must not turn it into a crash
            ctx.emit("run.finish_failed", f"Could not update the run's artefacts: {type(exc).__name__}: {exc}", level="warn")
    ctx.emit(
        "run.finished", f"Run {status}" + (f": {stopped_reason}" if stopped_reason else ""),
        level="error" if status == "failed" else "info",
        status=status, open_reviews=open_reviews,
    )
    return final

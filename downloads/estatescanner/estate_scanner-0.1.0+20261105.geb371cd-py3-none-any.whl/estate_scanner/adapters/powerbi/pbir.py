"""Reads a report's definition parts (PBIR, or the older single-file layout) into
pages, visuals and the model fields each visual uses.

The parts come from Fabric's ``getDefinition`` as ``{path, content}`` with the
content already decoded. This module only reads them; the full parts stay in
the stored definition so nothing the summary leaves out is lost.
"""

from __future__ import annotations

import json
import re
from typing import Any

_MODEL_ID = re.compile(r"semanticmodelid=([0-9a-fA-F-]{36})")


def _json(text: Any) -> Any:
    if not isinstance(text, str):
        return None
    try:
        return json.loads(text)
    except ValueError:
        return None


def _literal(node: Any) -> str | None:
    """The text of a ``{"expr": {"Literal": {"Value": "'x'"}}}`` property."""
    try:
        value = node["expr"]["Literal"]["Value"]
    except (KeyError, TypeError):
        return None
    if isinstance(value, str) and len(value) >= 2 and value[0] == "'" and value[-1] == "'":
        return value[1:-1]
    return value if isinstance(value, str) else None


def _entity(expression: Any) -> str | None:
    try:
        return expression["SourceRef"]["Entity"]
    except (KeyError, TypeError):
        return None


def field_reference(field: Any) -> dict[str, str | None] | None:
    """One projection field -> ``{kind, table, name}``; the wrapper (Column, Measure,
    Aggregation, HierarchyLevel ...) is the kind."""
    if not isinstance(field, dict):
        return None
    for kind, body in field.items():
        if not isinstance(body, dict):
            continue
        if kind == "Aggregation":
            inner = field_reference(body.get("Expression"))
            if inner:
                inner["kind"] = f"Aggregation({body.get('Function')})"
            return inner
        expression = body.get("Expression")
        table = _entity(expression)
        if table is None and isinstance(expression, dict) and "Hierarchy" in expression:
            table = _entity(expression["Hierarchy"].get("Expression"))
        name = body.get("Property") or body.get("Level")
        if name is not None or table is not None:
            return {"kind": kind, "table": table, "name": name}
    return None


def visual_fields(visual: dict) -> list[dict[str, Any]]:
    """Every field a visual projects, with the bucket (Category, Y, Values ...) it sits in."""
    out: list[dict[str, Any]] = []
    state = (((visual.get("query") or {}).get("queryState")) or {})
    for bucket, body in state.items():
        for projection in (body or {}).get("projections") or []:
            ref = field_reference(projection.get("field"))
            if ref:
                out.append({"bucket": bucket, **ref})
    return out


def visual_title(visual: dict) -> str | None:
    for container in (visual.get("visualContainerObjects") or {}, visual.get("objects") or {}):
        for entry in container.get("title") or []:
            text = _literal((entry.get("properties") or {}).get("text"))
            if text:
                return text
    return None


def model_id_from_pbir(parts: list[dict]) -> str | None:
    for part in parts:
        if part.get("path") == "definition.pbir":
            body = _json(part.get("content")) or {}
            connection = ((body.get("datasetReference") or {}).get("byConnection") or {}).get("connectionString") or ""
            m = _MODEL_ID.search(connection)
            if m:
                return m.group(1).lower()
    return None


def summarize_report(parts: list[dict]) -> dict[str, Any]:
    """``{format, model_id, pages: [{name, display_name, order, visuals: [...]}]}``.

    A visual is ``{id, name, visual_type, title, position, fields, definition}``
    where ``definition`` is the parsed visual file. ``{}`` when the parts hold
    neither layout."""
    by_path = {p.get("path"): p.get("content") for p in parts if p.get("path")}
    pages_meta = _json(by_path.get("definition/pages/pages.json")) or {}
    visual_files = [path for path in by_path if re.fullmatch(r"definition/pages/[^/]+/visuals/[^/]+/visual\.json", path)]
    page_files = [path for path in by_path if re.fullmatch(r"definition/pages/[^/]+/page\.json", path)]
    if page_files or visual_files:
        order = {name: i for i, name in enumerate(pages_meta.get("pageOrder") or [])}
        pages: dict[str, dict] = {}
        for path in page_files:
            body = _json(by_path[path]) or {}
            folder = path.split("/")[2]
            name = body.get("name") or folder
            pages[folder] = {"name": name, "display_name": body.get("displayName"), "order": order.get(name, order.get(folder)), "visuals": []}
        for path in sorted(visual_files):
            folder = path.split("/")[2]
            body = _json(by_path[path]) or {}
            page = pages.setdefault(folder, {"name": folder, "display_name": None, "order": order.get(folder), "visuals": []})
            visual = body.get("visual") or {}
            page["visuals"].append({
                "id": body.get("name") or path.split("/")[4],
                "name": body.get("name"),
                "visual_type": visual.get("visualType") or ("group" if body.get("visualGroup") else None),
                "title": visual_title(visual),
                "position": body.get("position"),
                "fields": visual_fields(visual),
                "definition": body,
            })
        ordered = sorted(pages.values(), key=lambda p: (p["order"] is None, p["order"] if p["order"] is not None else 0, p["name"]))
        return {"format": "PBIR", "model_id": model_id_from_pbir(parts), "pages": ordered}

    legacy = _json(by_path.get("report.json"))
    if isinstance(legacy, dict) and "sections" in legacy:
        pages_out = []
        for i, section in enumerate(legacy.get("sections") or []):
            visuals = []
            for n, container in enumerate(section.get("visualContainers") or []):
                config = _json(container.get("config")) or {}
                single = config.get("singleVisual") or {}
                visuals.append({
                    "id": config.get("name") or f"visual-{n}", "name": config.get("name"), "visual_type": single.get("visualType"),
                    "title": None, "position": {k: container.get(k) for k in ("x", "y", "z", "width", "height")},
                    "fields": [], "definition": config,
                })
            pages_out.append({"name": section.get("name"), "display_name": section.get("displayName"), "order": i, "visuals": visuals})
        return {"format": "PBIR-Legacy", "model_id": model_id_from_pbir(parts), "pages": pages_out}
    return {}

"""Maps a Power BI / Microsoft Fabric tenant into the platform-agnostic core models.

How a scan reads the tenant
---------------------------
1. **Inventory** (once, cached): the admin *scanner API* when the account may use
   it -- every workspace in the tenant, with reports, datasets, dashboards (and
   tiles), dataflows, users per workspace and per item, lineage and datasource
   instances, in batches of 100. When it is refused (not an admin, setting off),
   the same shape is built workspace by workspace from the workspaces the account
   can see, and an issue says so. Either way the rest of the client sees one
   normalised snapshot.
2. **Definitions**: Fabric ``getDefinition`` on every semantic model (TMDL) and
   every report (PBIR), a few at a time. The scanner API cannot give these: a
   tenant can switch off schema and expressions for it
   (``DatasetSchemaDisabledByAdmin``), and measures live only in the TMDL anyway.
3. **Detail**: refresh history per model, last transactions per dataflow, a
   dataflow's definition export.

Nothing is skipped silently. A call that fails becomes a ``ScanIssue`` (what was
being read, the HTTP status, the message), recorded with the scan.

Object types
------------
  dataset           Semantic model. ``definition`` holds the decoded TMDL parts and
                    a summary (tables, columns, measures, partitions, roles);
                    ``schema_columns`` is the flattened column list; ``pdp_policies``
                    are its row-level-security roles.
  calculated_field  Each DAX measure and calculated column of a model.
  dataflow          Power BI dataflow (Power Query); definition = the export JSON.
  dashboard         A report (``dashboardType: report``; ``layout`` = pages, visual
                    positions, and the raw PBIR parts) or a classic dashboard
                    (``dashboardType: dashboard``, a pinboard of tiles).
  card              A report visual (one per PBIR visual file, ``card_type`` = the
                    visual type, ``definition`` = the visual file and the model
                    fields it uses) or a classic dashboard tile.
  account           A datasource instance (connection to an external source). One that goes
                    through a gateway has a ``hosts`` edge from it; so does a datasource
                    configured on a gateway that no model uses.
  gateway           An on-premises data gateway the account administers (Power BI lists only
                    those). A datasource that goes through one the account cannot list is
                    reported as a scan issue naming the gateway id, not dropped.
  user, group       Workspace and item role assignments, merged by identity; each is also a
                    ``has_role`` edge from the user or group to the workspace, report, classic
                    dashboard, semantic model or dataflow, with the role on the edge. Group
                    membership (``member_of``) is not in the Power BI APIs, so it stays empty.
  app               A published Power BI app.

  workspace         A Power BI / Fabric workspace. A ``contains`` edge runs from it to each
                    semantic model, dataflow, report, classic dashboard and app it holds
                    (visuals and measures belong to their report or model); every object
                    also keeps ``workspaceId`` / ``workspaceName`` in its raw payload.
Not mapped: alert.
"""

from __future__ import annotations

import base64
import datetime as _dt
import json
import threading
import time
from collections.abc import Callable, Iterator
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

from estate_scanner.core.models import (
    Account,
    App,
    AppView,
    CalculatedField,
    Card,
    Dashboard,
    DashboardFilter,
    Dataflow,
    Dataset,
    Gateway,
    Group,
    ObjectRef,
    Refresh,
    RoleAssignment,
    ScanIssue,
    User,
    Workspace,
)
from estate_scanner.core.platform import PlatformClient, PlatformError

from . import pbir, tmdl
from .http import SCAN_BATCH, PowerBiApiError, PowerBiHttp

DEFINITION_WORKERS = 4
SCAN_ATTEMPTS = 3  # a scanner API batch: one try and two retries
SCAN_RETRY_SECONDS = 5.0
# How many refreshes to ask for per model. Power BI's own default is the last 500 it holds, and
# fewer would put older failures out of the scan's reach for no saving worth having.
_REFRESH_HISTORY_LIMIT = 500
_ROLE_RANK = {"Admin": 4, "Member": 3, "Contributor": 2, "Viewer": 1}
_RIGHT_KEYS = ("groupUserAccessRight", "reportUserAccessRight", "datasetUserAccessRight",
               "dashboardUserAccessRight", "dataflowUserAccessRight", "appUserAccessRight")


def _s(value: Any) -> str | None:
    return None if value is None else str(value)


def _gateway_id(value: Any) -> str | None:
    """A gateway id from a datasource instance. Power BI sends an all-zero GUID for a source that goes
    through no gateway (a cloud source); that is "no gateway", never a gateway to draw an edge from."""
    text = _s(value)
    return None if not text or all(c in "0-" for c in text) else text


def _connection_details(value: Any) -> dict:
    """A JSON object Power BI sends either parsed or as a string (a gateway datasource's
    ``connectionDetails``, a gateway's ``gatewayAnnotation``); ``{}`` for anything else."""
    if isinstance(value, str):
        try:
            value = json.loads(value)
        except ValueError:
            return {}
    return value if isinstance(value, dict) else {}


def _when(value: Any) -> _dt.datetime | None:
    if not value:
        return None
    try:
        return _dt.datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None


def _refresh(entry: dict, id_key: str) -> Refresh:
    """A refresh-history entry (dataset) or a transaction (dataflow). A run still going has no end
    time, and a dataset's has no request id until the service assigns one: its start time then names it."""
    return Refresh(
        id=_s(entry.get(id_key)) or _s(entry.get("startTime")) or "", status=entry.get("status"),
        refresh_type=entry.get("refreshType"), started_at=_when(entry.get("startTime")), ended_at=_when(entry.get("endTime")),
        error=entry.get("serviceExceptionJson") or None, raw_payload=entry,
    )


def _uid(value: Any) -> str | None:
    """A user id: e-mail addresses compare case-insensitively, so they are kept lower-case;
    a GUID or other identifier is kept as it is."""
    text = _s(value)
    return text.lower() if text and "@" in text else text


def _scanner_summary(tables: list[dict]) -> dict[str, Any]:
    """The scanner API's ``tables`` (when the tenant allows schema and expressions) in the
    shape ``tmdl.summarize_model`` gives, for a model whose definition could not be read."""
    out = []
    for t in tables or []:
        columns = []
        for c in t.get("columns") or []:
            col: dict[str, Any] = {"kind": "column", "name": c.get("name"),
                                   "properties": {"dataType": c.get("dataType"), "isHidden": c.get("isHidden")}}
            if c.get("expression"):
                col["expression"] = c["expression"]
            columns.append(col)
        measures = [{"kind": "measure", "name": m.get("name"), "expression": m.get("expression"),
                     "properties": {"description": m.get("description"), "isHidden": m.get("isHidden")}}
                    for m in t.get("measures") or []]
        out.append({"name": t.get("name"), "columns": columns, "measures": measures, "partitions": []})
    return {"tables": out, "roles": []} if out else {}


def decode_definition(raw: dict | None) -> list[dict] | None:
    """Fabric returns each file as a base64 part; decode the text ones so the
    stored definition is readable. A part that is not UTF-8 stays base64."""
    if not raw:
        return None
    parts = []
    for part in (raw.get("definition") or {}).get("parts") or []:
        payload, text = part.get("payload"), None
        if payload:
            try:
                text = base64.b64decode(payload).decode("utf-8")
            except (ValueError, UnicodeDecodeError):
                text = None
        parts.append({"path": part.get("path"), "content": text if text is not None else payload,
                      "encoding": "utf-8" if text is not None else "base64"})
    return parts


def _principal_kind(user: dict) -> str:
    return (user.get("principalType") or "User").lower()


# The estate object type each kind of granted item is stored as (a report and a classic dashboard are both "dashboard").
_GRANT_TARGET = {"workspace": "workspace", "report": "dashboard", "dashboard": "dashboard", "dataset": "dataset", "dataflow": "dataflow"}


def _role_assignments(grants: list[dict]) -> list[RoleAssignment]:
    """One assignment per object the principal holds a role on. A workspace role is ranked
    (Admin > Member > Contributor > Viewer); an item's access right is kept as the service gives it."""
    found: dict[tuple[str, str], list[str]] = {}
    for g in grants:
        object_type = _GRANT_TARGET.get(g["artifactType"])
        object_id = _s(g["workspaceId"] if g["artifactType"] == "workspace" else g["artifactId"])
        if not object_type or not object_id:
            continue
        rights = found.setdefault((object_type, object_id), [])
        if g["right"] and g["right"] not in rights:
            rights.append(g["right"])
    return [RoleAssignment(ObjectRef(object_type, object_id),
                           max(rights, key=lambda r: _ROLE_RANK.get(r, 0)) if rights else None, rights)
            for (object_type, object_id), rights in found.items()]


class PowerBiClient(PlatformClient):
    platform = "powerbi"

    def __init__(self, session, http: PowerBiHttp | None = None):
        super().__init__(session)
        self._http = http or PowerBiHttp(session)
        self._issues: list[ScanIssue] = []
        self._lock = threading.Lock()
        self._tenant_cache: dict | None = None
        self._gateway_cache: dict | None = None
        self._apps_cache: list[dict] | None = None
        self._model_summaries: dict[str, dict] = {}
        self._report_summaries: dict[tuple[str, str], tuple[list[dict] | None, dict]] = {}
        self._definitions: dict[tuple[str, str], dict | None] = {}
        self._details: dict[tuple[str, str], Any] = {}
        self._sleep = time.sleep
        self._detail_errors: dict[tuple[str, str], str] = {}

    # -- issues ------------------------------------------------------------------

    def _issue(self, scope: str, exc: Exception | str, phase: str | None = None, status: int | None = None) -> None:
        status = exc.status if isinstance(exc, PowerBiApiError) else status
        with self._lock:
            self._issues.append(ScanIssue(scope=scope, message=str(exc), status=status, phase=phase))

    def take_issues(self) -> list[ScanIssue]:
        with self._lock:
            issues, self._issues = self._issues, []
        return issues

    def _try(self, scope: str, call: Callable[[], Any], default: Any = None, report: bool = True) -> Any:
        try:
            return call()
        except PowerBiApiError as exc:
            if report:
                self._issue(scope, exc)
            return default

    def verify_session(self) -> bool:
        try:
            self._http.pbi_get("/groups?$top=1")
            return True
        except PlatformError:  # sign-in lost or refused; anything else is a bug and should show
            return False

    # -- inventory ---------------------------------------------------------------

    def _tenant(self) -> dict:
        """The normalised snapshot: ``{via, workspaces: [...], datasourceInstances: [...]}``."""
        if self._tenant_cache is None:
            try:
                self._tenant_cache = self._scan_tenant()
            except PowerBiApiError as exc:
                if exc.status not in (401, 403, 404):
                    raise
                self._issue(
                    "scanner API",
                    f"The tenant-wide scanner API is not available to this account ({exc}); "
                    "scanned the workspaces the account can see instead. Lineage, other people's "
                    "workspaces and per-item users are missing from this scan.",
                    phase="setup",
                )
                self._tenant_cache = self._scan_visible_workspaces()
            if not self._tenant_cache["workspaces"]:
                who = "The scanner API lists" if self._tenant_cache["via"] == "scanner" else "The signed-in account can see"
                self._issue(
                    "workspaces",
                    f"{who} no workspaces, so this scan is empty. Check that the account is the intended one "
                    "(an admin, for a whole tenant) before relying on it.",
                    phase="setup",
                )
        return self._tenant_cache

    def _scan_batch(self, ids: list[str]) -> dict:
        """One scanner API batch, asked again when the service fails it. A refusal
        (401/403/404) is not retried: asking again will not change the answer."""
        for attempt in range(1, SCAN_ATTEMPTS + 1):
            try:
                return self._http.scan_workspaces(ids)
            except PowerBiApiError as exc:
                if exc.status in (401, 403, 404) or attempt == SCAN_ATTEMPTS:
                    raise
                self._sleep(SCAN_RETRY_SECONDS * attempt)
        raise AssertionError("unreachable")

    def _scan_tenant(self) -> dict:
        ids = self._http.admin_workspace_ids()
        workspaces: list[dict] = []
        instances: dict[str, dict] = {}
        batches = [ids[i : i + SCAN_BATCH] for i in range(0, len(ids), SCAN_BATCH)]
        scanned = asked = 0
        last_error: PowerBiApiError | None = None
        for number, batch_ids in enumerate(batches, 1):
            try:
                batch = self._scan_batch(batch_ids)
            except PowerBiApiError as exc:
                if not scanned and exc.status in (401, 403, 404):
                    raise  # the account may not use the scanner API at all: _tenant() falls back
                last_error = exc
                self._issue(
                    f"scanner API batch {number} of {len(batches)}",
                    f"{len(batch_ids)} workspace(s) were not scanned ({exc}); first id {batch_ids[0]}. "
                    "Everything in them is missing from this scan.",
                    phase="setup",
                    status=exc.status,
                )
                continue
            scanned += 1
            asked += len(batch_ids)
            workspaces.extend(batch.get("workspaces") or [])
            for inst in batch.get("datasourceInstances") or []:
                instances[_s(inst.get("datasourceId"))] = inst
        if last_error is not None and not scanned:
            raise last_error  # every batch failed: there is no scan to report; the issues above stay
        missing = asked - len(workspaces)
        if missing > 0:
            self._issue("scanner API", f"{missing} of {asked} workspaces came back empty from the scanner API", phase="setup")
        restricted: dict[str, int] = {}
        for ws in workspaces:
            if ws.get("dataRetrievalState"):
                restricted[ws["dataRetrievalState"]] = restricted.get(ws["dataRetrievalState"], 0) + 1
        for state, count in restricted.items():
            self._issue(
                "scanner API",
                f"The tenant restricts what the scanner API returns for {count} of {len(workspaces)} workspaces ({state}); "
                "tables, columns and measures are read from each model's definition instead.",
                phase="setup",
            )
        return {"via": "scanner", "workspaces": workspaces, "datasourceInstances": list(instances.values())}

    def _scan_visible_workspaces(self) -> dict:
        workspaces, instances = [], {}
        for ws in self._http.groups():
            wid, name = ws["id"], ws.get("name")
            scope = f"workspace {name}"
            entry: dict[str, Any] = {"id": wid, "name": name, "type": ws.get("type"), "state": "Active",
                                     "isOnDedicatedCapacity": ws.get("isOnDedicatedCapacity"), "capacityId": ws.get("capacityId")}
            entry["users"] = self._try(f"{scope} / users", lambda: self._http.workspace_users(wid), [])
            entry["reports"] = self._try(f"{scope} / reports", lambda: self._http.reports(wid), [])
            entry["datasets"] = self._try(f"{scope} / datasets", lambda: self._http.datasets(wid), [])
            entry["dataflows"] = self._try(f"{scope} / dataflows", lambda: self._http.dataflows(wid), [])
            entry["dashboards"] = self._try(f"{scope} / dashboards", lambda: self._http.dashboards(wid), [])
            for dataset in entry["datasets"]:
                sources = self._try(f"{scope} / datasources of {dataset.get('name')}",
                                    lambda d=dataset: self._http.dataset_datasources(wid, d["id"]), [])
                dataset["datasourceUsages"] = [{"datasourceInstanceId": _s(s.get("datasourceId"))} for s in sources if s.get("datasourceId")]
                for s in sources:
                    if s.get("datasourceId"):
                        instances[_s(s["datasourceId"])] = s
            for flow in entry["dataflows"]:
                flow_id = flow.get("objectId") or flow.get("id")
                if not flow_id:
                    continue
                sources = self._try(f"{scope} / datasources of dataflow {flow.get('name')}",
                                    lambda f=flow_id: self._http.dataflow_datasources(wid, f), [])
                flow["datasourceUsages"] = [{"datasourceInstanceId": _s(s.get("datasourceId"))} for s in sources if s.get("datasourceId")]
                for s in sources:
                    if s.get("datasourceId"):
                        instances[_s(s["datasourceId"])] = s
                flow["upstreamDataflows"] = self._try(f"{scope} / upstream dataflows of {flow.get('name')}",
                                                      lambda f=flow_id: self._http.dataflow_upstream(wid, f), [])
            for report in entry["reports"]:
                report["datasetId"] = report.get("datasetId")
            workspaces.append(entry)
        return {"via": "workspaces", "workspaces": workspaces, "datasourceInstances": list(instances.values())}

    def _each(self, key: str) -> Iterator[tuple[dict, dict]]:
        for ws in self._tenant()["workspaces"]:
            for item in ws.get(key) or []:
                yield ws, item

    def estimate_total(self, object_type: str) -> int | None:
        """How many objects the phase will yield, so the scan screen can show a bar. Called right
        before the phase starts: whatever an earlier phase already read is in memory, and what a phase
        would read first anyway (report definitions for cards, the app list) is read here."""
        tenant = self._tenant()["workspaces"]
        if object_type == "workspace":
            return len(tenant)
        if object_type in ("dataset", "dataflow"):
            return sum(len(ws.get(object_type + "s") or []) for ws in tenant)
        if object_type == "dashboard":
            return sum(len(ws.get("reports") or []) + len(ws.get("dashboards") or []) for ws in tenant)
        if object_type == "gateway":
            return len(self._gateways()["gateways"])
        if object_type == "user":
            principals = self._principals()
            return sum(1 for e in principals.values() if _principal_kind(e["first"]) != "group") + len(self._owners_without_a_role(set(principals)))
        if object_type == "group":
            return sum(1 for e in self._principals().values() if _principal_kind(e["first"]) == "group")
        if object_type == "account":
            used, unused = self._account_sources()
            return len(used) + len(unused)
        if object_type == "app":
            return len(self._app_list())
        if object_type == "card":
            self._prefetch_definitions("reports")
            visuals = sum(len(p["visuals"]) for ws, r in self._each("reports") if r.get("id") for p in self._report_summary(ws, r)[1].get("pages", []))
            return visuals + sum(sum(1 for t in self._tiles(ws, d) if t.get("id")) for ws, d in self._each("dashboards"))
        if object_type == "calculated_field":
            return sum(len(self._field_items(table)) for ws, d in self._each("datasets") if d.get("id")
                       for table in self._model_summary(d, self._definition(ws, d["id"], d.get("name") or d["id"])).get("tables", []))
        return None

    @staticmethod
    def _where(ws: dict) -> dict:
        return {"workspaceId": ws.get("id"), "workspaceName": ws.get("name")}

    # -- definitions and detail (concurrent, memoised) ----------------------------

    def _definition(self, ws: dict, item_id: str, label: str) -> list[dict] | None:
        key = (ws["id"], item_id)
        with self._lock:
            if key in self._definitions:
                return self._definitions[key]
        raw = self._try(f"workspace {ws.get('name')} / definition of {label}", lambda: self._http.item_definition(ws["id"], item_id))
        parts = decode_definition(raw)
        with self._lock:
            self._definitions[key] = parts
        return parts

    def _prefetch_definitions(self, key: str) -> None:
        """Download every definition of one kind at once, a few at a time, so the
        mapping loop below reads from memory."""
        with self._lock:
            done = set(self._definitions)
        jobs = [(ws, item["id"], item.get("name") or item["id"]) for ws, item in self._each(key)
                if item.get("id") and (ws["id"], item["id"]) not in done]
        if not jobs:
            return
        pool = ThreadPoolExecutor(max_workers=DEFINITION_WORKERS)
        try:
            futures = [pool.submit(self._definition, *job) for job in jobs]
            for future in as_completed(futures):
                future.result()  # a fatal error (sign-in lost) stops here, not after every queued download
        finally:
            pool.shutdown(wait=True, cancel_futures=True)

    def _detail(self, key: tuple[str, str], scope: str, call: Callable[[], Any], report: bool = True) -> Any:
        with self._lock:
            if key in self._details:
                return self._details[key]
        try:
            value = call()
        except PowerBiApiError as exc:
            if report:
                self._issue(scope, exc)
            value = None
            with self._lock:
                self._detail_errors[key] = str(exc)
        with self._lock:
            self._details[key] = value
        return value

    # -- workspaces ------------------------------------------------------------------

    # Held by the contained objects' own payloads (and, for roles, by users and groups);
    # repeating them in the workspace row would store the whole tenant a second time.
    _WORKSPACE_CONTENT = ("reports", "datasets", "dataflows", "dashboards", "users", "datamarts", "warehouses", "Lakehouse",
                          "notebooks", "SparkJobDefinition")

    def fetch_workspaces(self) -> Iterator[Workspace]:
        for ws in self._tenant()["workspaces"]:
            wid = _s(ws.get("id"))
            if not wid:
                continue
            counts = {k: len(ws[k]) for k in self._WORKSPACE_CONTENT if isinstance(ws.get(k), list)}
            yield Workspace(
                id=wid, name=ws.get("name"), workspace_type=ws.get("type"), state=ws.get("state"),
                capacity_id=_s(ws.get("capacityId")) or None, is_on_dedicated_capacity=ws.get("isOnDedicatedCapacity"),
                raw_payload={**{k: v for k, v in ws.items() if k not in self._WORKSPACE_CONTENT}, "itemCounts": counts},
            )

    # -- users, groups -------------------------------------------------------------

    def _principals(self) -> dict[str, dict]:
        """Every user / group / app principal found in workspace and item roles,
        merged by identifier with the roles they hold where."""
        merged: dict[str, dict] = {}

        def add(principal: dict, ws: dict, artifact: tuple[str, str | None] | None) -> None:
            identifier = _uid(principal.get("identifier") or principal.get("graphId") or principal.get("emailAddress"))
            if not identifier:
                return
            right = next((principal[k] for k in _RIGHT_KEYS if principal.get(k)), None)
            entry = merged.setdefault(identifier, {"first": principal, "grants": []})
            entry["grants"].append({**self._where(ws), "artifactType": artifact[0] if artifact else "workspace",
                                    "artifactId": artifact[1] if artifact else None, "right": right})

        for ws in self._tenant()["workspaces"]:
            for u in ws.get("users") or []:
                add(u, ws, None)
            for kind, key in (("report", "reports"), ("dataset", "datasets"), ("dashboard", "dashboards"), ("dataflow", "dataflows")):
                for item in ws.get(key) or []:
                    for u in item.get("users") or []:
                        add(u, ws, (kind, item.get("id") or item.get("objectId")))
        return merged

    def fetch_users(self) -> Iterator[User]:
        principals = self._principals()
        for identifier, entry in principals.items():
            first = entry["first"]
            if _principal_kind(first) == "group":
                continue
            workspace_rights = [g["right"] for g in entry["grants"] if g["artifactType"] == "workspace" and g["right"]]
            role = max(workspace_rights, key=lambda r: _ROLE_RANK.get(r, 0)) if workspace_rights else None
            yield User(
                id=identifier, name=first.get("displayName") or identifier, email=first.get("emailAddress"), role=role,
                role_assignments=_role_assignments(entry["grants"]), raw_payload={**first, "grants": entry["grants"]},
            )
        yield from self._owners_without_a_role(set(principals))

    def _owners_without_a_role(self, known: set[str]) -> list[User]:
        """People who configured or created something but hold no role anywhere the scan saw, so
        the `owns` edge has someone to point at."""
        seen: set[str] = set()
        out = []
        for key, field in (("datasets", "configuredBy"), ("dataflows", "configuredBy"), ("reports", "createdBy")):
            for _, item in self._each(key):
                owner = _uid(item.get(field))
                if owner and owner not in known and owner not in seen:
                    seen.add(owner)
                    out.append(User(id=owner, name=owner, email=owner if "@" in owner else None,
                                    raw_payload={"source": f"{field} of a {key[:-1]}; no role found in the scan"}))
        return out

    def fetch_groups(self) -> Iterator[Group]:
        for identifier, entry in self._principals().items():
            first = entry["first"]
            if _principal_kind(first) == "group":
                yield Group(id=identifier, name=first.get("displayName") or identifier,
                            role_assignments=_role_assignments(entry["grants"]), raw_payload={**first, "grants": entry["grants"]})

    # -- accounts ---------------------------------------------------------------------

    @staticmethod
    def _account_label(source_type: str | None, details: dict) -> tuple[str | None, str | None]:
        """``(connector kind, display name)`` of a datasource from its type and connection details."""
        where = (details.get("server") or details.get("url") or details.get("path") or details.get("database")
                 or details.get("extensionDataSourcePath"))
        # A Power Query connector that is not built in reports as "Extension"; its own kind is the useful name.
        kind = details.get("extensionDataSourceKind") or source_type
        return kind, f"{kind}: {where}" if where else kind

    def _listed_datasources(self) -> dict[str, tuple]:
        """``{datasource id: (gateway id, payload)}`` for the datasources of the gateways the account can list."""
        return {_s(ds.get("id")): (gid, ds) for gid, datasources in self._gateways()["datasources"].items() for ds in datasources}

    def _account_sources(self) -> tuple[dict[str, tuple], dict[str, tuple]]:
        """``(used, unused)``, each ``{account id: (gateway id, payload)}``: the datasources a model or
        dataflow in the scan reaches, and those a listed gateway holds that nothing in the scan uses."""
        used = {_s(inst.get("datasourceId")): (_gateway_id(inst.get("gatewayId")), inst) for inst in self._tenant()["datasourceInstances"]}
        return used, {i: v for i, v in self._listed_datasources().items() if i not in used}

    def fetch_accounts(self) -> Iterator[Account]:
        listed = self._listed_datasources()
        used, unused = self._account_sources()
        for account_id, (gateway_id, inst) in used.items():
            _, on_gateway = listed.get(account_id, (None, None))
            kind, name = self._account_label(inst.get("datasourceType"), inst.get("connectionDetails") or {})
            yield Account(
                id=account_id, name=name, connector_type=kind, gateway_id=gateway_id or (listed.get(account_id) or (None,))[0],
                raw_payload={**inst, "gatewayDatasource": on_gateway} if on_gateway else inst,
            )
        # A datasource set up on a gateway that no model or dataflow in the scan uses.
        for account_id, (gateway_id, ds) in unused.items():
            kind, name = self._account_label(ds.get("datasourceType"), _connection_details(ds.get("connectionDetails")))
            yield Account(id=account_id, name=ds.get("datasourceName") or name, connector_type=kind, gateway_id=gateway_id, raw_payload=ds)

    # -- gateways ---------------------------------------------------------------------------

    def _gateways(self) -> dict:
        """``{gateways: [...], datasources: {gateway id: [...]}}``, read once. Power BI lists only the
        gateways the signed-in account administers, and refuses a gateway's datasources to anyone else."""
        if self._gateway_cache is None:
            gateways = self._try("gateways", self._http.gateways, default=[])
            datasources = {}
            for g in gateways:
                gid = _s(g.get("id"))
                if gid:
                    datasources[gid] = self._try(f"gateway {g.get('name') or gid} / datasources",
                                                 lambda gid=gid: self._http.gateway_datasources(gid), default=[])
            self._gateway_cache = {"gateways": gateways, "datasources": datasources}
        return self._gateway_cache

    def fetch_gateways(self) -> Iterator[Gateway]:
        inventory = self._gateways()
        for g in inventory["gateways"]:
            gid = _s(g.get("id"))
            if not gid:
                continue
            annotation = _connection_details(g.get("gatewayAnnotation"))
            yield Gateway(
                id=gid, name=g.get("name") or annotation.get("gatewayName"), gateway_type=g.get("type"), status=g.get("gatewayStatus"),
                machine=annotation.get("gatewayMachine"), version=annotation.get("gatewayVersion"),
                raw_payload={**{k: v for k, v in g.items() if k != "publicKey"}, "annotation": annotation},
            )
        # Datasources the scan found going through a gateway this account cannot list.
        unlisted: dict[str, int] = {}
        for inst in self._tenant()["datasourceInstances"]:
            gid = _gateway_id(inst.get("gatewayId"))
            if gid and gid not in inventory["datasources"]:
                unlisted[gid] = unlisted.get(gid, 0) + 1
        if unlisted:
            self._issue(
                "gateways",
                f"{sum(unlisted.values())} datasource(s) go through {len(unlisted)} gateway(s) this account cannot list "
                f"({', '.join(sorted(unlisted))}): Power BI shows a gateway only to its administrators, so those gateways, "
                "their machines and their other datasources are missing from this scan.",
                phase="gateway",
            )

    # -- datasets (semantic models) -------------------------------------------------------

    def _model_summary(self, d: dict, parts: list[dict] | None) -> dict[str, Any]:
        """Tables, measures and roles of a model: from its TMDL, else from what the scanner API returned."""
        key = d.get("id")
        if key in self._model_summaries:
            return self._model_summaries[key]
        summary = tmdl.summarize_model(parts) if parts else _scanner_summary(d.get("tables") or [])
        if key:
            self._model_summaries[key] = summary
        return summary

    def fetch_datasets(self) -> Iterator[Dataset]:
        self._prefetch_definitions("datasets")
        flows_by_model = self._dataflows_feeding_models()
        for ws, d in self._each("datasets"):
            did = d.get("id")
            if not did:
                continue
            parts = self._definition(ws, did, d.get("name") or did)
            summary = self._model_summary(d, parts)
            history = self._detail(
                ("refresh", did), f"workspace {ws.get('name')} / refresh history of {d.get('name')}",
                lambda: self._http.dataset_refreshes(ws["id"], did, _REFRESH_HISTORY_LIMIT), report=False,
            )
            definition = None
            if parts is not None:
                definition = {"parts": parts, "model": summary}
            elif d.get("tables"):
                definition = {"model": {"tables": d["tables"]}, "source": "scanner"}
            columns = [
                {"name": c["name"], "table": t["name"], "type": (c.get("properties") or {}).get("dataType"),
                 "calculated": "expression" in c}
                for t in summary.get("tables", []) for c in t["columns"]
            ] or None
            roles = None
            if parts is not None:
                roles = [
                    {"name": r["name"], "model_permission": r["model_permission"], "members": r["members"],
                     "filters": [{"table": p["table"], "expression": p["filter"]} for p in r["table_permissions"]]}
                    for r in summary.get("roles", [])
                ]
            yield Dataset(
                id=_s(did), name=d.get("name"), owner_id=_uid(d.get("configuredBy")), workspace_id=_s(ws.get("id")),
                created_at=_when(d.get("createdDate")), provider_type=d.get("contentProviderType") or d.get("targetStorageMode"),
                schema_columns=columns, column_count=len(columns) if columns else None,
                is_deleted=(ws.get("state") == "Deleted"), pdp_policies=roles, definition=definition,
                account_ids=[_s(u.get("datasourceInstanceId")) for u in d.get("datasourceUsages") or [] if u.get("datasourceInstanceId")],
                refreshes=None if history is None else [_refresh(h, "requestId") for h in history],
                raw_payload={**d, **self._where(ws), "refreshHistory": history[:10] if history else history,
                             "refreshHistoryError": self._detail_errors.get(("refresh", did)),
                             "upstreamDataflows": d.get("upstreamDataflows"), "upstreamDatasets": d.get("upstreamDatasets"),
                             "dataflowsFeeding": flows_by_model.get(did, [])},
            )

    def _dataflows_feeding_models(self) -> dict[str, list[str]]:
        out: dict[str, list[str]] = {}
        for _, d in self._each("datasets"):
            for up in d.get("upstreamDataflows") or []:
                if up.get("targetDataflowId"):
                    out.setdefault(d["id"], []).append(up["targetDataflowId"])
        return out

    # -- calculated fields (measures, calculated columns) ----------------------------------

    def fetch_calculated_fields(self) -> Iterator[CalculatedField]:
        for ws, d in self._each("datasets"):
            did = d.get("id")
            parts = self._definition(ws, did, d.get("name") or did) if did else None
            for table in self._model_summary(d, parts).get("tables", []):
                for kind, item in self._field_items(table):
                    props = item.get("properties") or {}
                    yield CalculatedField(
                        id=f"{did}:{table['name']}:{item['name']}", name=item["name"], formula_language="dax",
                        formula=item.get("expression"), data_type=props.get("dataType"),
                        is_global=False, is_locked=False,
                        linked_object_refs=[ObjectRef("dataset", _s(did))],
                        definition={"kind": kind, "table": table["name"], "properties": props},
                        raw_payload={**self._where(ws), "datasetId": did, "table": table["name"], "kind": kind},
                    )

    @staticmethod
    def _field_items(table: dict) -> list[tuple[str, dict]]:
        """``(kind, item)`` for each measure and calculated column of a model table."""
        return [("measure", m) for m in table["measures"]] + [("calculated_column", c) for c in table["columns"] if "expression" in c]

    # -- dataflows ---------------------------------------------------------------------------

    def fetch_dataflows(self) -> Iterator[Dataflow]:
        outputs: dict[str, list[str]] = {}
        for did, flows in self._dataflows_feeding_models().items():
            for flow_id in flows:
                outputs.setdefault(flow_id, []).append(did)
        for ws, df in self._each("dataflows"):
            df_id = df.get("objectId") or df.get("id")
            if not df_id:
                continue
            scope = f"workspace {ws.get('name')} / dataflow {df.get('name')}"
            definition = self._detail(("dataflow", df_id), f"{scope} / definition",
                                      lambda: self._http.dataflow_definition(ws["id"], df_id))
            listed = self._detail(("dataflow-tx", df_id), f"{scope} / transactions",
                                  lambda: self._http.dataflow_transactions(ws["id"], df_id), report=False)
            transactions = listed or []
            last = transactions[0] if transactions else {}
            yield Dataflow(
                id=_s(df_id), name=df.get("name"), engine="power_query", owner_id=_uid(df.get("configuredBy")),
                workspace_id=_s(ws.get("id")),
                output_dataset_ids=outputs.get(df_id, []),
                input_dataset_ids=[],
                account_ids=[_s(u.get("datasourceInstanceId")) for u in df.get("datasourceUsages") or [] if u.get("datasourceInstanceId")],
                upstream_dataflow_ids=[_s(u.get("targetDataflowId")) for u in df.get("upstreamDataflows") or [] if u.get("targetDataflowId")],
                last_run_state=last.get("status"), last_run_failed=(last.get("status") == "Failed") if last else None,
                last_run_at=_when(last.get("endTime")), definition=definition,
                refreshes=None if listed is None else [_refresh(t, "id") for t in transactions],
                raw_payload={**df, **self._where(ws), "transactions": transactions[:10],
                             "transactionsError": self._detail_errors.get(("dataflow-tx", df_id))},
            )

    # -- dashboards and cards --------------------------------------------------------------------

    def _report_summary(self, ws: dict, report: dict) -> tuple[list[dict] | None, dict]:
        key = (ws["id"], report["id"])
        if key not in self._report_summaries:
            parts = self._definition(ws, report["id"], report.get("name") or report["id"])
            self._report_summaries[key] = (parts, pbir.summarize_report(parts) if parts else {})
        return self._report_summaries[key]

    def _card_id(self, report_id: str, page: dict, visual: dict) -> str:
        return f"{report_id}:{page['name']}:{visual['id']}"

    def fetch_dashboards(self) -> Iterator[Dashboard]:
        self._prefetch_definitions("reports")
        for ws, r in self._each("reports"):
            rid = r.get("id")
            if not rid:
                continue
            parts, summary = self._report_summary(ws, r)
            model_id = _s(r.get("datasetId")) or summary.get("model_id")
            card_ids, pages = [], []
            for page in summary.get("pages", []):
                card_ids.extend(self._card_id(rid, page, v) for v in page["visuals"])
                pages.append({
                    "name": page["name"], "display_name": page["display_name"], "order": page["order"],
                    "visuals": [{"id": v["id"], "card_id": self._card_id(rid, page, v), "visual_type": v["visual_type"],
                                 "title": v["title"], "position": v["position"]} for v in page["visuals"]],
                })
            layout = {"format": summary.get("format"), "model_id": summary.get("model_id"), "pages": pages, "parts": parts} if parts is not None else None
            owner = next((u.get("emailAddress") for u in r.get("users") or [] if u.get("reportUserAccessRight") == "Owner"), None)
            yield Dashboard(
                id=_s(rid), name=r.get("name"), owner_id=_uid(owner or r.get("createdBy")), workspace_id=_s(ws.get("id")),
                created_at=_when(r.get("createdDateTime")), updated_at=_when(r.get("modifiedDateTime")),
                card_ids=card_ids, dataset_ids=[model_id] if model_id else [],
                filters=self._report_filters(parts), layout=layout,
                raw_payload={**r, **self._where(ws), "dashboardType": "report"},
            )
        for ws, dash in self._each("dashboards"):
            did = dash.get("id")
            if not did:
                continue
            tiles = self._tiles(ws, dash)
            yield Dashboard(
                id=_s(did), name=dash.get("displayName") or dash.get("name"), owner_id=None, workspace_id=_s(ws.get("id")),
                card_ids=[_s(t["id"]) for t in tiles if t.get("id")],
                raw_payload={**{k: v for k, v in dash.items() if k != "tiles"}, **self._where(ws), "dashboardType": "dashboard"},
            )

    def _report_filters(self, parts: list[dict] | None) -> list[DashboardFilter]:
        import json  # noqa: PLC0415 -- only this one place parses the filter file

        for part in parts or []:
            if part.get("path") == "definition/report.json" and isinstance(part.get("content"), str):
                try:
                    body = json.loads(part["content"])
                except ValueError:
                    return []
                out = []
                for f in (body.get("filterConfig") or {}).get("filters") or []:
                    ref = pbir.field_reference(f.get("field"))
                    out.append(DashboardFilter(field=ref and ref["name"], label=ref and ref["table"],
                                               filter_type=f.get("type"), raw_payload=f))
                return out
        return []

    def _tiles(self, ws: dict, dash: dict) -> list[dict]:
        if dash.get("tiles") is not None:
            return dash["tiles"]
        return self._detail(("tiles", dash["id"]), f"workspace {ws.get('name')} / tiles of dashboard {dash.get('displayName')}",
                            lambda: self._http.dashboard_tiles(ws["id"], dash["id"])) or []

    def fetch_cards(self) -> Iterator[Card]:
        self._prefetch_definitions("reports")  # cards come before dashboards in a scan; read them a few at a time
        for ws, r in self._each("reports"):
            rid = r.get("id")
            if not rid:
                continue
            _, summary = self._report_summary(ws, r)
            model_id = _s(r.get("datasetId")) or summary.get("model_id")
            for page in summary.get("pages", []):
                for v in page["visuals"]:
                    yield Card(
                        id=self._card_id(rid, page, v), name=v["title"] or v["visual_type"], card_type=v["visual_type"],
                        dataset_ids=[model_id] if model_id else [],
                        definition={"page": {"name": page["name"], "display_name": page["display_name"]},
                                    "fields": v["fields"], "position": v["position"], "visual": v["definition"]},
                        raw_payload={**self._where(ws), "reportId": rid, "pageName": page["name"], "visualId": v["id"]},
                    )
        for ws, dash in self._each("dashboards"):
            for tile in self._tiles(ws, dash):
                if not tile.get("id"):
                    continue
                dataset_id, report_id = _s(tile.get("datasetId")), _s(tile.get("reportId"))
                yield Card(
                    id=_s(tile["id"]), name=tile.get("title") or tile.get("subTitle"), card_type="tile",
                    dataset_ids=[dataset_id] if dataset_id else [],
                    source_dashboard_ids=[report_id] if report_id else [],
                    definition=tile,
                    raw_payload={**tile, **self._where(ws), "dashboardId": dash.get("id")},
                )

    # -- apps ----------------------------------------------------------------------------------------

    def _app_list(self) -> list[dict]:
        """The apps, read once: the tenant-wide list, else the ones this account can see (and an issue says so)."""
        if self._apps_cache is None:
            via_scanner = self._tenant()["via"] == "scanner"
            apps = self._try("apps / admin list", self._http.admin_apps, None, report=via_scanner)
            if apps is None:
                self._issue("apps", "The tenant-wide app list was not available; listed only the apps this account can see.", phase="app")
                apps = self._try("apps / list", self._http.apps, [])
            self._apps_cache = apps
        return self._apps_cache

    def fetch_apps(self) -> Iterator[App]:
        unreadable = 0
        for a in self._app_list():
            views = self._app_contents(a)
            unreadable += views is None
            yield App(
                id=_s(a.get("id")), name=a.get("name"), app_type="power_bi_app", owner_id=_uid(a.get("publishedBy")),
                updated_at=_when(a.get("lastUpdate")), workspace_id=_s(a.get("workspaceId")),
                views=[AppView(view_id=_s(v["id"]), title=v.get("name")) for v in views or []],
                raw_payload=a,
            )
        if unreadable:
            self._issue("apps", f"The reports and dashboards of {unreadable} app(s) could not be listed "
                                "(an app's contents can be read only by an account that has the app installed).", phase="app")

    def _app_contents(self, app: dict) -> list[dict] | None:
        """Reports and dashboards inside an app, as the workspace objects they were
        published from where the app says which (an app holds copies with their own ids)."""
        out = []
        for kind in ("reports", "dashboards"):
            try:
                body = self._http.pbi_get(f"/apps/{app['id']}/{kind}")
            except PowerBiApiError:
                return None
            for item in (body or {}).get("value") or []:
                out.append({"id": item.get("originalReportObjectId") or item.get("id"), "name": item.get("name") or item.get("displayName")})
        return out

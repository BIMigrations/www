from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from estate_scanner import graph as graph_module
from estate_scanner.core.registry import all_object_types, get_object_type

from ..deps import get_conn
from ..graph_cache import get_graph

router = APIRouter()

# Allow-listed sortable columns per object type -- never accept a raw
# column name from the request straight into SQL.
_SORTABLE = {
    "dataset": ["name", "provider_type", "row_count", "column_count", "updated_at", "downstream_card_count"],
    "dataflow": ["name", "engine", "num_inputs", "num_outputs", "last_execution_state", "modified_at"],
    "card": ["name", "type", "dataset_id"],
    "dashboard": ["name", "parent_dashboard_id"],
    "user": ["name", "email", "role"],
    "group": ["name"],
    "account": ["name", "connector_type"],
    "calculated_field": ["name", "formula_language", "status"],
    "alert": ["name", "resource_type", "disabled"],
    "app": ["name", "type"],
}


@router.get("/summary")
def summary(conn=Depends(get_conn), platform: str | None = None):
    counts = {}
    for descriptor in all_object_types():
        query = f"SELECT COUNT(*) FROM {descriptor.table}"
        params: tuple = ()
        if platform:
            query += " WHERE platform = ?"
            params = (platform,)
        counts[descriptor.object_type] = conn.execute(query, params).fetchone()[0]

    edge_query = "SELECT COUNT(*) FROM edges" + (" WHERE platform = ?" if platform else "")
    edge_count = conn.execute(edge_query, (platform,) if platform else ()).fetchone()[0]
    last_scan = conn.execute(
        "SELECT id, platform, instance, started_at, finished_at, status FROM scans ORDER BY id DESC LIMIT 1"
    ).fetchone()
    return {"counts": counts, "edge_count": edge_count, "last_scan": dict(last_scan) if last_scan else None}


@router.get("/{object_type}")
def list_objects(
    object_type: str,
    conn=Depends(get_conn),
    page: int = 1,
    page_size: int = 100,
    sort: str | None = None,
    dir: str = "asc",
    q: str | None = None,
    owner: str | None = None,
    platform: str | None = None,
):
    try:
        descriptor = get_object_type(object_type)
    except KeyError:
        raise HTTPException(404, f"Unknown object type: {object_type}") from None

    allowed_sorts = _SORTABLE.get(object_type, ["name"])
    sort_col = sort if sort in allowed_sorts else allowed_sorts[0]
    sort_dir = "DESC" if dir.lower() == "desc" else "ASC"

    where: list[str] = []
    params: list = []
    if platform:
        where.append("platform = ?")
        params.append(platform)
    if owner:
        where.append("owner_id = ?")
        params.append(owner)
    if q:
        where.append(f"{descriptor.name_column} LIKE ?")
        params.append(f"%{q}%")
    where_sql = f"WHERE {' AND '.join(where)}" if where else ""

    total = conn.execute(f"SELECT COUNT(*) FROM {descriptor.table} {where_sql}", params).fetchone()[0]  # noqa: S608 -- table/column names are allow-listed above, never request-supplied raw
    page = max(1, page)
    page_size = max(1, min(page_size, 500))
    offset = (page - 1) * page_size
    rows = conn.execute(
        f"SELECT * FROM {descriptor.table} {where_sql} ORDER BY {sort_col} {sort_dir} LIMIT ? OFFSET ?",  # noqa: S608
        [*params, page_size, offset],
    ).fetchall()
    return {"rows": [dict(r) for r in rows], "total": total, "page": page, "page_size": page_size}


@router.get("/{object_type}/{object_id}")
def get_object(object_type: str, object_id: str, conn=Depends(get_conn), platform: str | None = None):
    try:
        descriptor = get_object_type(object_type)
    except KeyError:
        raise HTTPException(404, f"Unknown object type: {object_type}") from None

    if platform:
        row = conn.execute(f"SELECT * FROM {descriptor.table} WHERE platform = ? AND id = ?", (platform, object_id)).fetchone()  # noqa: S608
    else:
        row = conn.execute(f"SELECT * FROM {descriptor.table} WHERE id = ? ORDER BY platform LIMIT 1", (object_id,)).fetchone()  # noqa: S608
    if row is None:
        raise HTTPException(404, "Object not found")
    platform = row["platform"]

    g = get_graph(conn, platform)
    node_key = f"{platform}:{object_type}:{object_id}"

    result = dict(row)
    result["upstream"] = [_node_summary(g, k) for k in _neighbors(g, node_key, upstream=True)]
    result["downstream"] = [_node_summary(g, k) for k in _neighbors(g, node_key, upstream=False)]
    return result


def _neighbors(g, node_key: str, upstream: bool) -> list[str]:
    if node_key not in g.nodes:
        return []
    reach = graph_module.upstream(g, node_key) if upstream else graph_module.downstream(g, node_key)
    return sorted(reach)


def _node_summary(g, node_key: str) -> dict:
    attrs = g.nodes[node_key]
    return {"platform": attrs["platform"], "type": attrs["type"], "id": attrs["id"], "name": attrs["name"]}

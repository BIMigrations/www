"""Read-only access to an EstateScanner database.

Strictly read-only, for three reasons: the file belongs to another tool and
its schema is EstateScanner's to change; a scan may be running against it
while we read; and it holds live platform credentials in
`platform_sessions` that this module must never touch or return. The
connection is opened with SQLite's `mode=ro` URI so a stray write raises
instead of silently succeeding.

Everything here speaks EstateScanner's vocabulary (dashboards, cards,
datasets, dataflows, calculated_fields, edges). Turning that into
migration units is closure.py's job, and turning those into a target
platform's artefacts is the pipelines' job.

Two layouts exist. A database made before EstateScanner #55 keys every row by
(platform, id); one made after it keys by (platform, instance, id), so two
instances of one platform (two Domo subdomains, two Power BI tenants) can hold
the same id. The layout is detected once, when the file is opened. The old one
is read exactly as it always was. In the new one every query is limited to ONE
instance and never mixes two: the reader takes `instance=`, or works out the
only instance the file holds, or refuses and lists them. BIMControl never
migrates a file (it is opened `mode=ro`); EstateScanner does that.
"""

from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Iterator

# Object type -> table, mirroring estate_scanner.core.registry's mapping.
# Kept as our own copy rather than imported: it is the shape of the data we
# read, which stays stable even if EstateScanner reorganises its code.
OBJECT_TABLES = {
    "user": "users",
    "group": "groups_",
    "account": "accounts",
    "dataset": "datasets",
    "dataflow": "dataflows",
    "card": "cards",
    "dashboard": "dashboards",
    "app": "apps",
    "calculated_field": "calculated_fields",
    "alert": "alerts",
}


class EstateNotFoundError(Exception):
    """The estate database, or an object inside it, isn't there."""


class AmbiguousInstanceError(EstateNotFoundError):
    """The database holds several instances of the platform and the caller named none.

    An EstateNotFoundError so every caller that already turns "cannot read this estate" into a
    message does the same here; `instances` lists the names to choose from.
    """

    def __init__(self, platform: str, instances: list[str], db_path: Path):
        self.platform = platform
        self.instances = instances
        super().__init__(
            f"{db_path} holds {len(instances)} instances of {platform!r}: "
            f"{', '.join(repr(i) for i in instances)}. Name the instance."
        )


_DOMO_SUFFIX = ".domo.com"


def normalise_instance(platform: str, name: str | None) -> str:
    """The spelling EstateScanner stores an instance under: trimmed and lower-cased, and a Domo
    name without a trailing `.domo.com` (the sign-in adds it). Mirrors
    estate_scanner.core.instances.normalise_instance, like OBJECT_TABLES it is the shape of the
    data we read."""
    value = (name or "").strip().lower()
    if platform == "domo" and value.endswith(_DOMO_SUFFIX):
        value = value[: -len(_DOMO_SUFFIX)]
    return value


@dataclass(frozen=True)
class EstateObject:
    """One row from a typed estate table, with the JSON columns parsed.

    `row` keeps every column as stored (including the raw payloads), so a
    pipeline can reach for a field that hasn't earned an accessor yet.
    """

    object_type: str
    id: str
    name: str | None
    platform: str
    row: dict[str, Any]

    def json_column(self, column: str) -> Any:
        """Parse one of the `*_json` columns, or None if it's absent/empty."""
        return _load_json(self.row.get(column))

    @property
    def raw(self) -> dict[str, Any]:
        return self.json_column("raw_json") or {}

    @property
    def definition(self) -> dict[str, Any]:
        return self.json_column("definition_json") or {}


@dataclass(frozen=True)
class Edge:
    src_type: str
    src_id: str
    dst_type: str
    dst_id: str
    edge_type: str
    weight: float | None = None


def _load_json(value: Any) -> Any:
    if value is None or value == "":
        return None
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(value)
    except (TypeError, ValueError):
        return None


class EstateReader:
    """Opens an EstateScanner database read-only and answers questions about it."""

    def __init__(self, db_path: str | Path, platform: str = "domo", instance: str | None = None):
        self.db_path = Path(db_path).expanduser()
        self.platform = platform
        if not self.db_path.exists():
            raise EstateNotFoundError(f"No estate database at {self.db_path}")
        # mode=ro also means SQLite will not create the file or any -wal/-shm
        # sidecar, so pointing this at a customer's scan leaves it untouched.
        self._conn = sqlite3.connect(
            f"file:{self.db_path}?mode=ro", uri=True, check_same_thread=False
        )
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA busy_timeout = 10000")
        # Layout, decided once. `instance` is None for a database made before EstateScanner #55
        # (nothing to filter on); otherwise the one instance every query is limited to.
        self.keyed_by_instance = "instance" in {
            row["name"] for row in self._conn.execute("PRAGMA table_info(datasets)")
        }
        try:
            self.instance: str | None = self._resolve_instance(instance) if self.keyed_by_instance else None
        except Exception:
            self._conn.close()
            raise

    @classmethod
    def newest(cls, db_path: str | Path, platform: str = "domo") -> "EstateReader":
        """A reader for the instance whose scan ran last (a completed one first), for the one
        caller that has to find out which estate a file is about. The old layout has no instances:
        this is then the ordinary reader."""
        probe = cls.__new__(cls)
        probe.db_path, probe.platform = Path(db_path).expanduser(), platform
        if not probe.db_path.exists():
            raise EstateNotFoundError(f"No estate database at {probe.db_path}")
        conn = sqlite3.connect(f"file:{probe.db_path}?mode=ro", uri=True)
        try:
            keyed = "instance" in {r[1] for r in conn.execute("PRAGMA table_info(datasets)")}
            row = conn.execute(
                "SELECT instance FROM scans WHERE platform = ? ORDER BY status = 'completed' DESC, id DESC LIMIT 1",
                (platform,),
            ).fetchone() if keyed else None
        finally:
            conn.close()
        return cls(db_path, platform, instance=row[0] if row else None)

    def close(self) -> None:
        self._conn.close()

    def __enter__(self) -> "EstateReader":
        return self

    def __exit__(self, *exc: object) -> None:
        self.close()

    # ---- metadata -------------------------------------------------------

    def scans(self) -> list[dict[str, Any]]:
        rows = self._conn.execute(
            "SELECT id, platform, instance, started_at, finished_at, status, notes"
            " FROM scans ORDER BY id DESC"
        ).fetchall()
        return [dict(r) for r in rows]

    def latest_completed_scan(self) -> dict[str, Any] | None:
        for scan in self.scans():
            if scan["status"] == "completed" and self._scan_is_mine(scan):
                return scan
        return None

    def instances(self) -> list[str]:
        """The instances of this reader's platform the file holds, sorted; [] for the old layout
        (which does not record them per row) and for a file nothing was scanned into."""
        if not self.keyed_by_instance:
            return []
        names = {r[0] for r in self._conn.execute(
            "SELECT DISTINCT instance FROM scans WHERE platform = ?", (self.platform,))}
        if not names:  # a file made by hand: objects, no scan row
            for table in OBJECT_TABLES.values():
                names.update(r[0] for r in self._conn.execute(
                    f"SELECT DISTINCT instance FROM {table} WHERE platform = ?", (self.platform,)))
        return sorted(names)

    def counts(self) -> dict[str, int]:
        out: dict[str, int] = {}
        for object_type, table in OBJECT_TABLES.items():
            where, params = self._scope()
            row = self._conn.execute(f"SELECT COUNT(*) AS n FROM {table} WHERE {where}", params).fetchone()
            out[object_type] = row["n"]
        return out

    # ---- objects --------------------------------------------------------

    def get(self, object_type: str, object_id: str) -> EstateObject:
        obj = self.find(object_type, object_id)
        if obj is None:
            raise EstateNotFoundError(f"No {object_type} with id {object_id!r} in {self.db_path}")
        return obj

    def find(self, object_type: str, object_id: str) -> EstateObject | None:
        table = self._table(object_type)
        where, params = self._scope()
        row = self._conn.execute(
            f"SELECT * FROM {table} WHERE {where} AND id = ?", (*params, str(object_id))
        ).fetchone()
        return self._to_object(object_type, row) if row is not None else None

    def get_many(self, object_type: str, object_ids: Iterable[str]) -> list[EstateObject]:
        """Fetch many objects of one type. Missing ids are simply absent from
        the result -- a scan can reference an object the scanning user could
        not see, and that is a warning for the pipeline, not an error here."""
        ids = [str(i) for i in dict.fromkeys(object_ids)]  # de-dupe, keep order
        if not ids:
            return []
        table = self._table(object_type)
        found: dict[str, EstateObject] = {}
        for chunk in _chunks(ids, 500):  # stay under SQLite's variable limit
            placeholders = ",".join("?" * len(chunk))
            where, params = self._scope()
            rows = self._conn.execute(
                f"SELECT * FROM {table} WHERE {where} AND id IN ({placeholders})", (*params, *chunk)
            ).fetchall()
            for row in rows:
                obj = self._to_object(object_type, row)
                found[obj.id] = obj
        return [found[i] for i in ids if i in found]

    def iter_objects(self, object_type: str) -> Iterator[EstateObject]:
        """Every object of one type, in id order, streamed. The exporter's
        way in: it needs the whole table, not the closure of one dashboard."""
        table = self._table(object_type)
        where, params = self._scope()
        cursor = self._conn.execute(f"SELECT * FROM {table} WHERE {where} ORDER BY id", params)
        for row in cursor:
            yield self._to_object(object_type, row)

    def iter_edges(self, exclude_types: Iterable[str] = ()) -> Iterator[Edge]:
        """Every edge of the latest scan state, optionally leaving out some edge types."""
        skip = tuple(exclude_types)
        where, params = self._scope()
        sql = f"SELECT src_type, src_id, dst_type, dst_id, edge_type, weight FROM edges WHERE {where}"
        if skip:
            sql += f" AND edge_type NOT IN ({','.join('?' * len(skip))})"
            params += skip
        for row in self._conn.execute(sql + " ORDER BY edge_type, src_id, dst_id", params):
            yield Edge(**dict(row))

    # ---- edges ----------------------------------------------------------

    def edges_from(self, src_type: str, src_id: str, edge_type: str | None = None) -> list[Edge]:
        where, params = self._scope()
        sql = (
            "SELECT src_type, src_id, dst_type, dst_id, edge_type, weight FROM edges"
            f" WHERE {where} AND src_type = ? AND src_id = ?"
        )
        params += [src_type, str(src_id)]
        if edge_type:
            sql += " AND edge_type = ?"
            params.append(edge_type)
        return [Edge(**dict(r)) for r in self._conn.execute(sql, params)]

    def edges_to(self, dst_type: str, dst_id: str, edge_type: str | None = None) -> list[Edge]:
        where, params = self._scope()
        sql = (
            "SELECT src_type, src_id, dst_type, dst_id, edge_type, weight FROM edges"
            f" WHERE {where} AND dst_type = ? AND dst_id = ?"
        )
        params += [dst_type, str(dst_id)]
        if edge_type:
            sql += " AND edge_type = ?"
            params.append(edge_type)
        return [Edge(**dict(r)) for r in self._conn.execute(sql, params)]

    # ---- dashboards -----------------------------------------------------

    def list_dashboards(
        self,
        search: str | None = None,
        limit: int = 100,
        offset: int = 0,
        order: str = "cards",
    ) -> list[dict[str, Any]]:
        """Dashboards with their card counts -- the migration unit picker's
        list. Ordering by card count ascending is the default because the
        smallest dashboards are the ones to migrate first."""
        order_sql = {
            "cards": "card_count ASC, d.name ASC",
            "cards_desc": "card_count DESC, d.name ASC",
            "name": "d.name ASC",
        }.get(order, "card_count ASC, d.name ASC")

        # One pass over the edges: a correlated count per dashboard rescanned them for each of 347 dashboards (26 s on the
        # the source Domo instance scan, paid at the start of every dashboard of a customer batch).
        edge_where, edge_params = self._scope()
        d_where, d_params = self._scope("d.")
        where = [d_where]
        params: list[Any] = [*edge_params, *d_params]
        if search:
            where.append("d.name LIKE ?")
            params.append(f"%{search}%")

        sql = f"""
            SELECT d.id, d.name, d.parent_dashboard_id, d.owner_id,
                   COALESCE(c.n, 0) AS card_count
              FROM dashboards d
              LEFT JOIN (SELECT dst_id, COUNT(*) AS n FROM edges
                          WHERE {edge_where} AND edge_type = 'part_of' AND dst_type = 'dashboard'
                          GROUP BY dst_id) c ON c.dst_id = d.id
             WHERE {' AND '.join(where)}
             ORDER BY {order_sql}
             LIMIT ? OFFSET ?
        """
        params += [limit, offset]
        return [dict(r) for r in self._conn.execute(sql, params)]

    def count_dashboards(self, search: str | None = None) -> int:
        where, params = self._scope()
        sql = f"SELECT COUNT(*) AS n FROM dashboards WHERE {where}"
        if search:
            sql += " AND name LIKE ?"
            params.append(f"%{search}%")
        return self._conn.execute(sql, params).fetchone()["n"]

    def cards_on_dashboard(self, dashboard_id: str) -> list[EstateObject]:
        edges = self.edges_to("dashboard", dashboard_id, edge_type="part_of")
        return self.get_many("card", [e.src_id for e in edges if e.src_type == "card"])

    def child_dashboards(self, dashboard_id: str) -> list[EstateObject]:
        edges = self.edges_from("dashboard", dashboard_id, edge_type="parent_of")
        return self.get_many("dashboard", [e.dst_id for e in edges])

    # ---- lineage --------------------------------------------------------

    def datasets_for_card(self, card: EstateObject) -> list[str]:
        """Dataset ids a card reads, most reliable source first.

        `visualized_by` edges are the scanner's own derivation; the card's
        raw `dataSourceIds` is the platform's. They usually agree, but a
        card whose dataset was deleted has the id only in the raw payload,
        and we would rather carry a dangling id into the migration report
        than silently drop a visual's data source.
        """
        ids = [e.src_id for e in self.edges_to("card", card.id, edge_type="visualized_by")]
        ids += [str(i) for i in (card.raw.get("dataSourceIds") or [])]
        if card.row.get("dataset_id"):
            ids.append(str(card.row["dataset_id"]))
        return list(dict.fromkeys(ids))

    def producing_dataflow(self, dataset_id: str) -> str | None:
        """The dataflow that writes this dataset, if any (`produces` edge)."""
        edges = self.edges_to("dataset", dataset_id, edge_type="produces")
        for edge in edges:
            if edge.src_type == "dataflow":
                return edge.src_id
        return None

    def input_datasets_for_dataflow(self, dataflow_id: str) -> list[str]:
        edges = self.edges_to("dataflow", dataflow_id, edge_type="consumed_by")
        return [e.src_id for e in edges if e.src_type == "dataset"]

    def calculated_fields_for(self, object_type: str, object_id: str) -> list[EstateObject]:
        """Beast modes used by a card or dataset (`used_by_calculated_field`)."""
        edges = self.edges_from(object_type, object_id, edge_type="used_by_calculated_field")
        return self.get_many("calculated_field", [e.dst_id for e in edges])

    # ---- internals ------------------------------------------------------

    def _scope(self, prefix: str = "") -> tuple[str, list[Any]]:
        """The WHERE terms that limit a query to this reader's platform, and in the new layout
        to its one instance. `prefix` is a table alias with its dot (`"d."`)."""
        if self.instance is None:
            return f"{prefix}platform = ?", [self.platform]
        return f"{prefix}platform = ? AND {prefix}instance = ?", [self.platform, self.instance]

    def _scan_is_mine(self, scan: dict[str, Any]) -> bool:
        if self.instance is None:  # old layout: as it always was, the newest scan of anything
            return True
        return scan["platform"] == self.platform and scan["instance"] == self.instance

    def _resolve_instance(self, requested: str | None) -> str:
        """The instance every query is limited to. A name is normalised the way EstateScanner
        stores it and must be one the file holds. None is accepted while the file holds one
        instance of the platform (or none yet); with several it raises and lists them."""
        known = self.instances()
        if requested is not None:
            wanted = normalise_instance(self.platform, requested)
            if known and wanted not in known:
                raise EstateNotFoundError(
                    f"{self.db_path} holds no instance {requested!r} of {self.platform!r}; "
                    f"it holds: {', '.join(repr(i) for i in known)}."
                )
            return wanted
        if len(known) > 1:
            raise AmbiguousInstanceError(self.platform, known, self.db_path)
        return known[0] if known else ""

    def _table(self, object_type: str) -> str:
        try:
            return OBJECT_TABLES[object_type]
        except KeyError:
            raise EstateNotFoundError(f"Unknown object type {object_type!r}") from None

    def _to_object(self, object_type: str, row: sqlite3.Row) -> EstateObject:
        data = dict(row)
        return EstateObject(
            object_type=object_type,
            id=str(data["id"]),
            name=data.get("name"),
            platform=data["platform"],
            row=data,
        )


def _chunks(items: list[str], size: int) -> Iterator[list[str]]:
    for start in range(0, len(items), size):
        yield items[start : start + size]

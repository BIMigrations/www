"""Credentials and services: what BIMControl can currently reach.

A migration stops dead on an expired Domo cookie or a Fabric token that
nobody renewed, and the error it stops with names a CLI command. That is
the wrong place to find out. This is the screen's view of the four things
a run needs -- the source platform, the target platform, the warehouse and
the converter -- and the one action that fixes each.

**Reading status never prompts.** `GET /connections` is called whenever the
screen opens, and a browser window appearing because somebody looked at a
page would be indefensible; every read here passes `allow_prompt=False`
and reports "signed out" instead. Only the explicit POSTs open a browser.

Checks are live, not cached: a session that was valid a minute ago is the
exact thing in doubt. Each one is wrapped, because a service being down is
the answer to the question, not a failure to answer it.
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Body, Depends, HTTPException, Request

from bimcontrol.core import runner
from bimcontrol.storage import db

router = APIRouter()

# Long enough for a real sign-in to be reachable, short enough that a
# screen waiting on a dead service does not wait for ever.
CHECK_TIMEOUT = 20


def get_conn(request: Request):
    conn = db.connect(request.app.state.db_path)
    try:
        yield conn
    finally:
        conn.close()


def _project(request: Request, conn) -> dict[str, Any]:
    return runner.resolve_project(conn, request.app.state.estate_db_path)


def domo_status(instance: str) -> dict[str, Any]:
    """Whether the saved Domo session still works, without opening anything."""
    from bimcontrol.sources.domo import login  # noqa: PLC0415

    stored = login.load(instance)
    if stored is None:
        return {"connected": False, "instance": instance,
                "detail": "No saved session. Sign in to export data and read card figures."}
    try:
        valid = login.is_valid(stored, timeout=CHECK_TIMEOUT)
    except Exception as exc:  # noqa: BLE001 -- unreachable is a status, not a crash
        return {"connected": False, "instance": instance, "detail": str(exc)[:200]}
    return {
        "connected": valid,
        "instance": instance,
        "account": getattr(stored, "user_email", None),
        "detail": "Session is live." if valid
                  else "The saved session has expired; sign in again.",
    }


def powerbi_status() -> dict[str, Any]:
    """The signed-in Fabric account, from the saved authentication record.

    The MSAL token cache alone does not say *which* account to look for,
    which is why the record is saved beside it; without it a silent refresh
    has nothing to refresh.
    """
    try:
        from bimcontrol.targets.powerbi import auth  # noqa: PLC0415
    except ImportError as exc:
        return {"connected": False, "detail": f"The Power BI extra is not installed ({exc})."}

    account = auth.signed_in_account()
    if account is None:
        return {"connected": False,
                "detail": "Not signed in. Publishing and parity checks both need this."}
    return {"connected": True, "account": account.get("username"),
            "tenant_id": account.get("tenant_id"),
            "detail": "Signed in; tokens refresh without asking."}


def converter_status(settings: dict[str, Any]) -> dict[str, Any]:
    from bimcontrol.converters import DomoEtlConverterClient  # noqa: PLC0415

    url = (settings.get("converters") or {}).get("domo_etl")
    if not url:
        return {"connected": False, "url": None,
                "detail": "No converter configured. Magic ETL dataflows cannot be converted "
                          "without one."}
    try:
        health = DomoEtlConverterClient(url).health()
    except Exception as exc:  # noqa: BLE001
        return {"connected": False, "url": url, "detail": str(exc)[:200]}
    return {
        "connected": bool(health.get("ok")),
        "url": url,
        "instance": health.get("instance"),
        "detail": ("Ready." if health.get("ok")
                   else str(health.get("error") or health.get("status") or "Not ready.")[:200]),
    }


def warehouse_status(settings: dict[str, Any]) -> dict[str, Any]:
    import os  # noqa: PLC0415

    from bimcontrol import warehouses  # noqa: PLC0415

    configured = settings.get("warehouse") or {}
    # What the form needs to pre-fill itself and to say what is missing. The
    # password's *name* and whether it is set, never its value.
    from .warehouses import ALLOWED_SETTINGS  # noqa: PLC0415

    form = {
        "settings": {k: v for k, v in configured.items() if k in ALLOWED_SETTINGS},
        "password_env": "REDSHIFT_PASSWORD",
        "password_set": bool(os.environ.get("REDSHIFT_PASSWORD")),
    }
    if not configured.get("key"):
        return {"connected": False, **form,
                "detail": "No warehouse configured. Data landing and SQL validation both need one."}
    try:
        result = warehouses.get_adapter(configured["key"], configured).check()
    except Exception as exc:  # noqa: BLE001
        return {"connected": False, "key": configured.get("key"), **form, "detail": str(exc)[:200]}
    return {
        "connected": bool(result.get("ok")),
        "key": configured.get("key"),
        # Host and database, never the password: it is read from the
        # environment at the point of use and is not ours to show.
        "host": configured.get("host"),
        "database": configured.get("database"),
        **form,
        "detail": result.get("error") or ", ".join(
            f"{k}={v}" for k, v in result.items() if k not in ("ok", "warehouse")) or "Reachable.",
    }


@router.get("/connections")
def list_connections(request: Request, conn=Depends(get_conn)) -> dict[str, Any]:
    project = _project(request, conn)
    settings = project.get("settings") or {}
    return {
        "project_id": project["id"],
        "domo": {"kind": "source", **domo_status(project["source_instance"])},
        "powerbi": {"kind": "target", **powerbi_status()},
        "warehouse": {"kind": "target", **warehouse_status(settings)},
        "converter": {"kind": "service", **converter_status(settings)},
    }


@router.post("/connections/domo/signin")
def sign_in_to_domo(request: Request, conn=Depends(get_conn)) -> dict[str, Any]:
    """Open a real browser and keep the session it produces.

    Domo's private API only accepts the cookies a genuine SSO flow
    produces, so there is no headless path to this. The request is held
    open for the length of the sign-in, which is what the screen shows as
    "waiting for you in the browser".
    """
    from bimcontrol.sources.domo import login  # noqa: PLC0415

    project = _project(request, conn)
    instance = project["source_instance"]
    try:
        login.login_interactive(instance)
    except Exception as exc:  # noqa: BLE001 -- shown in the screen, not a 500 page
        raise HTTPException(status_code=502, detail=str(exc)[:400]) from exc
    return domo_status(instance)


@router.delete("/connections/domo")
def forget_domo(request: Request, conn=Depends(get_conn)) -> dict[str, Any]:
    from bimcontrol.sources.domo import login  # noqa: PLC0415

    project = _project(request, conn)
    forgotten = login.forget(project["source_instance"])
    return {"forgotten": forgotten, **domo_status(project["source_instance"])}


@router.post("/connections/powerbi/signin")
def sign_in_to_powerbi(body: dict[str, Any] = Body(default={})) -> dict[str, Any]:
    """Sign in once for both Fabric and Power BI.

    The two audiences need separate tokens and the same account, so both
    are fetched here: doing it lazily made a single migration ask for a
    sign-in twice.
    """
    from bimcontrol.targets.powerbi import auth  # noqa: PLC0415

    try:
        auth.token(auth.FABRIC_SCOPE, allow_prompt=True)
        auth.token(auth.POWERBI_SCOPE, allow_prompt=True)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=502, detail=str(exc)[:400]) from exc
    return powerbi_status()


@router.delete("/connections/powerbi")
def sign_out_of_powerbi() -> dict[str, Any]:
    from bimcontrol.targets.powerbi import auth  # noqa: PLC0415

    return {"forgotten": auth.sign_out(), **powerbi_status()}


@router.post("/connections/converter")
def set_converter(
    request: Request, conn=Depends(get_conn), body: dict[str, Any] = Body(default={})
) -> dict[str, Any]:
    url = (body.get("url") or "").strip().rstrip("/")
    project = _project(request, conn)
    settings = dict(project.get("settings") or {})
    converters = dict(settings.get("converters") or {})
    if url:
        converters["domo_etl"] = url
    else:
        converters.pop("domo_etl", None)
    settings["converters"] = converters
    db.update_project(conn, project["id"], settings=settings)
    return converter_status(settings)

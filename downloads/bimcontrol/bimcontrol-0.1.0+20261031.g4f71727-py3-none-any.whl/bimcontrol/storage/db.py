"""Control database: connection, schema, and the typed row helpers.

Unlike the estate database (another tool's file, opened read-only), this
one is ours to write. It is opened in WAL mode because the engine writes
from its own thread while the webapp reads from request threads; WAL lets
those proceed without blocking each other.

Every function here takes a connection rather than opening its own, so a
caller can wrap several writes in one transaction.
"""

from __future__ import annotations

import datetime as _dt
import importlib.resources
import json
import sqlite3
import uuid
from pathlib import Path
from typing import Any, Iterable

from bimcontrol import paths

# Columns added to a table after its first release. `CREATE TABLE IF NOT
# EXISTS` is a no-op against an existing file, so a column added later has
# to be applied by hand, once, here.
_ADDED_COLUMNS: list[tuple[str, str, str]] = []


def connect(db_path: str | Path | None = None) -> sqlite3.Connection:
    db_path = Path(db_path or paths.default_db_path()).expanduser()
    db_path.parent.mkdir(parents=True, exist_ok=True)
    # check_same_thread=False for the same reason EstateScanner needs it:
    # FastAPI dispatches sync dependencies and endpoints to worker threads
    # with no guaranteed affinity. Each request and each job still opens and
    # closes its own connection.
    conn = sqlite3.connect(db_path, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout = 10000")
    # A run holds the write lock in bursts while the UI polls for events.
    # WAL keeps those readers from blocking, and survives a crashed worker.
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA foreign_keys = ON")
    init_schema(conn)
    _migrate_schema(conn)
    return conn


def init_schema(conn: sqlite3.Connection) -> None:
    schema_sql = importlib.resources.files("bimcontrol.storage").joinpath("schema.sql").read_text()
    conn.executescript(schema_sql)
    conn.commit()


def _migrate_schema(conn: sqlite3.Connection) -> None:
    for table, column, coltype in _ADDED_COLUMNS:
        existing = {row[1] for row in conn.execute(f"PRAGMA table_info({table})")}
        if column not in existing:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {coltype}")
    conn.commit()


def now() -> str:
    return _dt.datetime.now(_dt.timezone.utc).isoformat()


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:12]}"


def new_run_id() -> str:
    """Readable and sortable: run ids double as directory names."""
    stamp = _dt.datetime.now(_dt.timezone.utc).strftime("%Y%m%dT%H%M%S")
    return f"run_{stamp}_{uuid.uuid4().hex[:6]}"


def _dumps(value: Any) -> str | None:
    return None if value is None else json.dumps(value)


def loads(value: Any) -> Any:
    if value is None or value == "":
        return None
    try:
        return json.loads(value)
    except (TypeError, ValueError):
        return None


def row_to_dict(row: sqlite3.Row | None, json_columns: Iterable[str] = ()) -> dict[str, Any] | None:
    """A row as a plain dict, with the named `*_json` columns parsed.

    The parsed value replaces the column under its name minus the `_json`
    suffix, so an API response carries `summary`, not `summary_json` holding
    a string that every caller would have to parse again.
    """
    if row is None:
        return None
    data = dict(row)
    for column in json_columns:
        if column in data:
            data[column.removesuffix("_json")] = loads(data.pop(column))
    return data


# ---- projects -----------------------------------------------------------

PROJECT_JSON = ("settings_json",)


def create_project(
    conn: sqlite3.Connection,
    name: str,
    source_platform: str,
    source_instance: str,
    target_platform: str,
    estate_db_path: str | Path | None = None,
    settings: dict[str, Any] | None = None,
) -> str:
    project_id = new_id("prj")
    timestamp = now()
    conn.execute(
        "INSERT INTO projects (id, name, source_platform, source_instance, target_platform,"
        " estate_db_path, settings_json, created_at, updated_at)"
        " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (
            project_id, name, source_platform, source_instance, target_platform,
            str(estate_db_path) if estate_db_path else None, _dumps(settings), timestamp, timestamp,
        ),
    )
    conn.commit()
    return project_id


def update_project(conn: sqlite3.Connection, project_id: str, **fields: Any) -> None:
    if "settings" in fields:
        fields["settings_json"] = _dumps(fields.pop("settings"))
    fields["updated_at"] = now()
    assignments = ", ".join(f"{k} = ?" for k in fields)
    conn.execute(f"UPDATE projects SET {assignments} WHERE id = ?", (*fields.values(), project_id))
    conn.commit()


def get_project(conn: sqlite3.Connection, project_id: str) -> dict[str, Any] | None:
    row = conn.execute("SELECT * FROM projects WHERE id = ?", (project_id,)).fetchone()
    return row_to_dict(row, PROJECT_JSON)


def list_projects(conn: sqlite3.Connection) -> list[dict[str, Any]]:
    rows = conn.execute("SELECT * FROM projects ORDER BY created_at DESC").fetchall()
    return [row_to_dict(r, PROJECT_JSON) for r in rows]


def find_project(
    conn: sqlite3.Connection, source_platform: str, source_instance: str, target_platform: str
) -> dict[str, Any] | None:
    row = conn.execute(
        "SELECT * FROM projects WHERE source_platform = ? AND source_instance = ?"
        " AND target_platform = ? ORDER BY created_at LIMIT 1",
        (source_platform, source_instance, target_platform),
    ).fetchone()
    return row_to_dict(row, PROJECT_JSON)


def ensure_project(
    conn: sqlite3.Connection,
    source_platform: str,
    source_instance: str,
    target_platform: str,
    estate_db_path: str | Path | None = None,
) -> dict[str, Any]:
    """The project for this source/target pair, created if it is the first
    time this instance has been seen. Keeps `bimcontrol run` usable without
    making someone set a project up first."""
    existing = find_project(conn, source_platform, source_instance, target_platform)
    if existing:
        if estate_db_path and existing.get("estate_db_path") != str(estate_db_path):
            # A newer or imported scan of the same instance: follow it.
            conn.execute(
                "UPDATE projects SET estate_db_path = ?, updated_at = ? WHERE id = ?",
                (str(estate_db_path), now(), existing["id"]),
            )
            conn.commit()
            existing = get_project(conn, existing["id"])
        return existing
    name = f"{source_instance} {source_platform} to {target_platform}"
    project_id = create_project(
        conn, name, source_platform, source_instance, target_platform, estate_db_path
    )
    return get_project(conn, project_id)


# ---- units --------------------------------------------------------------

UNIT_JSON = ("summary_json",)


def ensure_unit(
    conn: sqlite3.Connection,
    project_id: str,
    source_object_id: str,
    name: str | None = None,
    unit_type: str = "dashboard",
) -> dict[str, Any]:
    row = conn.execute(
        "SELECT * FROM migration_units WHERE project_id = ? AND unit_type = ? AND source_object_id = ?",
        (project_id, unit_type, source_object_id),
    ).fetchone()
    if row is not None:
        unit = row_to_dict(row, UNIT_JSON)
        if name and name != unit.get("name"):
            conn.execute(
                "UPDATE migration_units SET name = ?, updated_at = ? WHERE id = ?",
                (name, now(), unit["id"]),
            )
            conn.commit()
            unit["name"] = name
        return unit

    unit_id = new_id("unit")
    timestamp = now()
    conn.execute(
        "INSERT INTO migration_units (id, project_id, unit_type, source_object_id, name,"
        " status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, 'pending', ?, ?)",
        (unit_id, project_id, unit_type, source_object_id, name, timestamp, timestamp),
    )
    conn.commit()
    return get_unit(conn, unit_id)


def get_unit(conn: sqlite3.Connection, unit_id: str) -> dict[str, Any] | None:
    row = conn.execute("SELECT * FROM migration_units WHERE id = ?", (unit_id,)).fetchone()
    return row_to_dict(row, UNIT_JSON)


def list_units(
    conn: sqlite3.Connection,
    project_id: str | None = None,
    status: str | None = None,
    limit: int = 200,
) -> list[dict[str, Any]]:
    sql = "SELECT * FROM migration_units WHERE 1 = 1"
    params: list[Any] = []
    if project_id:
        sql += " AND project_id = ?"
        params.append(project_id)
    if status:
        sql += " AND status = ?"
        params.append(status)
    sql += " ORDER BY updated_at DESC LIMIT ?"
    params.append(limit)
    return [row_to_dict(r, UNIT_JSON) for r in conn.execute(sql, params)]


def update_unit(conn: sqlite3.Connection, unit_id: str, **fields: Any) -> None:
    if "summary" in fields:
        fields["summary_json"] = _dumps(fields.pop("summary"))
    fields["updated_at"] = now()
    assignments = ", ".join(f"{k} = ?" for k in fields)
    conn.execute(
        f"UPDATE migration_units SET {assignments} WHERE id = ?", (*fields.values(), unit_id)
    )
    conn.commit()


# ---- runs ---------------------------------------------------------------

RUN_JSON = ("options_json",)


def create_run(
    conn: sqlite3.Connection,
    project_id: str,
    unit_id: str,
    pipeline: str,
    worker_id: str,
    run_dir: str | Path,
    options: dict[str, Any] | None = None,
) -> str:
    run_id = new_run_id()
    timestamp = now()
    conn.execute(
        "INSERT INTO runs (id, project_id, unit_id, pipeline, status, worker_id, run_dir,"
        " options_json, started_at, heartbeat_at) VALUES (?, ?, ?, ?, 'running', ?, ?, ?, ?, ?)",
        (run_id, project_id, unit_id, pipeline, worker_id, str(run_dir), _dumps(options), timestamp, timestamp),
    )
    conn.execute(
        "UPDATE migration_units SET latest_run_id = ?, status = 'running', updated_at = ? WHERE id = ?",
        (run_id, timestamp, unit_id),
    )
    conn.commit()
    return run_id


def get_run(conn: sqlite3.Connection, run_id: str) -> dict[str, Any] | None:
    row = conn.execute("SELECT * FROM runs WHERE id = ?", (run_id,)).fetchone()
    return row_to_dict(row, RUN_JSON)


def list_runs(
    conn: sqlite3.Connection,
    project_id: str | None = None,
    unit_id: str | None = None,
    status: str | None = None,
    limit: int = 50,
) -> list[dict[str, Any]]:
    # The unit's name is joined in because every caller wants it and none
    # wants a second query per row: a run list is read as "which dashboard",
    # not "which run id".
    sql = ("SELECT runs.*, migration_units.name AS unit_name,"
           " migration_units.source_object_id AS source_object_id"
           " FROM runs JOIN migration_units ON migration_units.id = runs.unit_id WHERE 1 = 1")
    params: list[Any] = []
    if project_id:
        sql += " AND runs.project_id = ?"
        params.append(project_id)
    if unit_id:
        sql += " AND runs.unit_id = ?"
        params.append(unit_id)
    if status:
        sql += " AND runs.status = ?"
        params.append(status)
    sql += " ORDER BY runs.started_at DESC LIMIT ?"
    params.append(limit)
    return [row_to_dict(r, RUN_JSON) for r in conn.execute(sql, params)]


def update_run(conn: sqlite3.Connection, run_id: str, **fields: Any) -> None:
    assignments = ", ".join(f"{k} = ?" for k in fields)
    conn.execute(f"UPDATE runs SET {assignments} WHERE id = ?", (*fields.values(), run_id))
    conn.commit()


def heartbeat(conn: sqlite3.Connection, run_id: str) -> None:
    """Stamped as each stage starts. A run whose heartbeat stopped long ago
    was killed with its worker rather than finishing -- which the UI, and
    later the control plane, needs to be able to tell apart from slow."""
    conn.execute("UPDATE runs SET heartbeat_at = ? WHERE id = ?", (now(), run_id))
    conn.commit()


# ---- stages -------------------------------------------------------------

STAGE_JSON = ("result_json",)


def seed_stages(conn: sqlite3.Connection, run_id: str, stages: list[tuple[str, str]]) -> None:
    """Write every stage of the pipeline as pending before the run starts,
    so the whole line is visible from the first event rather than appearing
    one stage at a time."""
    for ordinal, (name, title) in enumerate(stages):
        conn.execute(
            "INSERT OR IGNORE INTO stages (run_id, name, ordinal, title, status)"
            " VALUES (?, ?, ?, ?, 'pending')",
            (run_id, name, ordinal, title),
        )
    conn.commit()


def get_stage(conn: sqlite3.Connection, run_id: str, name: str) -> dict[str, Any] | None:
    row = conn.execute(
        "SELECT * FROM stages WHERE run_id = ? AND name = ?", (run_id, name)
    ).fetchone()
    return row_to_dict(row, STAGE_JSON)


def list_stages(conn: sqlite3.Connection, run_id: str) -> list[dict[str, Any]]:
    rows = conn.execute("SELECT * FROM stages WHERE run_id = ? ORDER BY ordinal", (run_id,)).fetchall()
    return [row_to_dict(r, STAGE_JSON) for r in rows]


def reset_stages_from(conn: sqlite3.Connection, run_id: str, from_stage: str | None = None) -> None:
    """Mark a stage and every later one pending, so that a resume does them again (all of them when no stage is named)."""
    names = [s["name"] for s in list_stages(conn, run_id)]
    if from_stage is not None:
        if from_stage not in names:
            raise KeyError(f"Unknown stage {from_stage!r}. Known: {', '.join(names)}")
        names = names[names.index(from_stage):]
    for name in names:
        update_stage(conn, run_id, name, status="pending", fingerprint=None)


def update_stage(conn: sqlite3.Connection, run_id: str, name: str, **fields: Any) -> None:
    if "result" in fields:
        fields["result_json"] = _dumps(fields.pop("result"))
    assignments = ", ".join(f"{k} = ?" for k in fields)
    conn.execute(
        f"UPDATE stages SET {assignments} WHERE run_id = ? AND name = ?",
        (*fields.values(), run_id, name),
    )
    conn.commit()


# ---- artefacts ----------------------------------------------------------


def record_artefact(
    conn: sqlite3.Connection,
    run_id: str,
    stage: str,
    kind: str,
    path: str,
    label: str | None = None,
    media_type: str | None = None,
    size_bytes: int | None = None,
    sha256: str | None = None,
) -> int:
    cursor = conn.execute(
        "INSERT OR REPLACE INTO artefacts (run_id, stage, kind, label, path, media_type,"
        " bytes, sha256, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (run_id, stage, kind, label, path, media_type, size_bytes, sha256, now()),
    )
    conn.commit()
    return int(cursor.lastrowid)


def list_artefacts(
    conn: sqlite3.Connection, run_id: str, stage: str | None = None
) -> list[dict[str, Any]]:
    sql = "SELECT * FROM artefacts WHERE run_id = ?"
    params: list[Any] = [run_id]
    if stage:
        sql += " AND stage = ?"
        params.append(stage)
    sql += " ORDER BY id"
    return [dict(r) for r in conn.execute(sql, params)]


def get_artefact(conn: sqlite3.Connection, artefact_id: int) -> dict[str, Any] | None:
    row = conn.execute("SELECT * FROM artefacts WHERE id = ?", (artefact_id,)).fetchone()
    return dict(row) if row else None


# ---- events -------------------------------------------------------------


def append_event(
    conn: sqlite3.Connection,
    run_id: str,
    event_type: str,
    message: str | None = None,
    stage: str | None = None,
    level: str = "info",
    payload: dict[str, Any] | None = None,
) -> int:
    """Append one event, allocating the next per-run sequence number.

    IMMEDIATE takes the write lock up front so the read of MAX(seq) and the
    insert that depends on it cannot interleave with another writer -- two
    events racing for the same seq would violate the primary key and lose
    one of them.
    """
    conn.execute("BEGIN IMMEDIATE")
    try:
        row = conn.execute(
            "SELECT COALESCE(MAX(seq), 0) + 1 AS next FROM events WHERE run_id = ?", (run_id,)
        ).fetchone()
        seq = int(row["next"])
        conn.execute(
            "INSERT INTO events (run_id, seq, created_at, stage, level, type, message, payload_json)"
            " VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (run_id, seq, now(), stage, level, event_type, message, _dumps(payload)),
        )
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    return seq


def list_events(
    conn: sqlite3.Connection, run_id: str, after_seq: int = 0, limit: int = 500
) -> list[dict[str, Any]]:
    rows = conn.execute(
        "SELECT * FROM events WHERE run_id = ? AND seq > ? ORDER BY seq LIMIT ?",
        (run_id, after_seq, limit),
    ).fetchall()
    return [row_to_dict(r, ("payload_json",)) for r in rows]


def max_event_seq(conn: sqlite3.Connection, run_id: str) -> int:
    row = conn.execute(
        "SELECT COALESCE(MAX(seq), 0) AS seq FROM events WHERE run_id = ?", (run_id,)
    ).fetchone()
    return int(row["seq"])


# ---- review items -------------------------------------------------------

REVIEW_JSON = ("detail_json",)


def add_review_item(
    conn: sqlite3.Connection,
    run_id: str,
    unit_id: str,
    kind: str,
    title: str,
    stage: str | None = None,
    severity: str = "warn",
    source_type: str | None = None,
    source_id: str | None = None,
    detail: dict[str, Any] | None = None,
) -> int:
    cursor = conn.execute(
        "INSERT INTO review_items (run_id, unit_id, stage, kind, severity, source_type,"
        " source_id, title, detail_json, status, created_at)"
        " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'open', ?)",
        (run_id, unit_id, stage, kind, severity, source_type, source_id, title, _dumps(detail), now()),
    )
    conn.commit()
    return int(cursor.lastrowid)


def clear_open_review_items(conn: sqlite3.Connection, run_id: str, stage: str) -> None:
    """Drop a stage's open items before it runs again, so the report shows
    what the latest attempt found and not the history of earlier ones.
    Items someone already resolved or dismissed stay."""
    conn.execute(
        "DELETE FROM review_items WHERE run_id = ? AND stage = ? AND status = 'open'",
        (run_id, stage),
    )
    conn.commit()


def list_review_items(
    conn: sqlite3.Connection,
    run_id: str | None = None,
    unit_id: str | None = None,
    status: str | None = "open",
    limit: int = 500,
) -> list[dict[str, Any]]:
    sql = "SELECT * FROM review_items WHERE 1 = 1"
    params: list[Any] = []
    if run_id:
        sql += " AND run_id = ?"
        params.append(run_id)
    if unit_id:
        sql += " AND unit_id = ?"
        params.append(unit_id)
    if status:
        sql += " AND status = ?"
        params.append(status)
    sql += " ORDER BY id LIMIT ?"
    params.append(limit)
    return [row_to_dict(r, REVIEW_JSON) for r in conn.execute(sql, params)]


def resolve_review_item(
    conn: sqlite3.Connection, item_id: int, status: str = "resolved", note: str | None = None
) -> dict[str, Any] | None:
    conn.execute(
        "UPDATE review_items SET status = ?, resolved_at = ?, resolution_note = ? WHERE id = ?",
        (status, now(), note, item_id),
    )
    conn.commit()
    row = conn.execute("SELECT * FROM review_items WHERE id = ?", (item_id,)).fetchone()
    return row_to_dict(row, REVIEW_JSON)


def count_open_reviews(conn: sqlite3.Connection, run_id: str) -> int:
    row = conn.execute(
        "SELECT COUNT(*) AS n FROM review_items WHERE run_id = ? AND status = 'open'", (run_id,)
    ).fetchone()
    return int(row["n"])

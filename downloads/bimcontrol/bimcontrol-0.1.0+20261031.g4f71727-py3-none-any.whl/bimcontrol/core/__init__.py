"""Platform-agnostic core: the run engine, the coordinator interface, and
the runner that ties a migration request to a pipeline.

Nothing here knows about Domo or Power BI. Source and target specifics
live in `sources/`, `targets/` and `pipelines/`.
"""

import React from 'react';

// Parity: the per-element evidence a migration is right (a report, not a gate).
//
// Everything else in this tool checks that a migration *ran*. This screen
// shows what the migrated visual returns next to what the Domo card
// returns, and the two never share a column -- source is amber on the
// left, target is teal on the right, in that order, as everywhere else.
//
// It opens on the differences. A card with 333 matching figures and 24
// broken ones is a broken card, and a table that opens on the 333 buries
// the answer.
//
// The report tab shows the real file, served from the run directory, not a
// re-rendering of it: what is on screen is what gets emailed.

// Element status leads: every element of the migration with a status word and a reason (Matches, Differs,
// Not compared, Not migrated). Parity is the evidence under it, on the next two tabs.
const ELEMENT_STATUS = {
  matches: { label: 'Matches', tone: 'target' },
  differs: { label: 'Differs', tone: 'warn' },
  not_compared: { label: 'Not compared', tone: 'neutral' },
  not_migrated: { label: 'Not migrated', tone: 'error' },
};
const ELEMENT_ORDER = ['differs', 'not_migrated', 'not_compared', 'matches'];

// The rows are the source's own values (account numbers, dates of birth, names on some dashboards): personal data on a
// local console. Nothing leaves the machine; nothing with this tab open belongs in a screenshot or a demo (#411).
const ROWS_NOTE = 'Rows show the source\'s own values and may be personal data: keep this tab out of screenshots and demos.';

const VIEWS = [
  { value: 'elements', label: 'Elements' },
  { value: 'error,warn', label: 'Differences' },
  { value: '', label: 'All figures' },
  { value: 'report', label: 'Report' },
];

export function ParityScreen({ runId, onSelectRun }) {
  const [runs, setRuns] = React.useState([]);
  const [parity, setParity] = React.useState(null);
  const [view, setView] = React.useState('elements');
  const [report, setReport] = React.useState(undefined); // undefined: loading, null: no report yet
  const [selected, setSelected] = React.useState(null);
  const [selectedElement, setSelectedElement] = React.useState(null);
  const [error, setError] = React.useState(null);

  React.useEffect(function () {
    fetchRuns({ limit: 50 }).then(function (body) { setRuns(body.items); }, function (e) { setError(e.message); });
  }, []);

  // Every row is fetched once and filtered here. Asking the API for the
  // differences alone would leave the card list in the sidebar showing only
  // cards that have one -- a card that matches would disappear from the
  // screen that exists to say whether it matches.
  React.useEffect(function () {
    if (!runId) { setParity(null); return undefined; }
    let stale = false;
    setSelected(null);
    setSelectedElement(null);
    setParity(null);
    setReport(undefined);
    fetchParity(runId).then(function (body) {
      if (!stale) setParity(body);
    }, function (e) { if (!stale) setError(e.message); });
    fetchReport(runId).then(function (body) { if (!stale) setReport(body); }, function () { if (!stale) setReport(null); });
    return function () { stale = true; };
  }, [runId]);

  const totals = (parity && parity.totals) || {};
  const allRows = (parity && parity.rows) || [];
  const rows = view === 'error,warn'
    ? allRows.filter(function (r) { return r.state !== 'ok'; })
    : allRows;
  const compared = (totals.ok || 0) + (totals.warn || 0) + (totals.error || 0);
  const elementTally = (report && report.element_tally) || null;
  // Most of "not migrated" on a dashboard with row-level security is the roles: built, their members not mapped. Say so under the tile.
  const rlsRoles = (elementTally && elementTally.by_kind && elementTally.by_kind.rls_role && elementTally.by_kind.rls_role.not_migrated) || 0;
  const publishedUrl = (report && report.published && report.published.report_url) || null;

  return (
    <React.Fragment>
      <Sidebar>
        <SidebarGroup label="Runs">
          {runs.map(function (r) {
            return (
              <NavItem
                key={r.id}
                label={r.unit_name || r.unit_id}
                meta={statusLabel(r.status)}
                active={r.id === runId}
                icon={<StatusDot status={statusDot(r.status)} />}
                onClick={function () { onSelectRun(r.id); }}
              />
            );
          })}
        </SidebarGroup>
        {parity && parity.checked ? (
          <React.Fragment>
            <SidebarRule />
            <SidebarGroup label="Cards">
              {cardSummaries(allRows).map(function (card) {
                return (
                  <NavItem
                    key={card.metric}
                    label={card.metric}
                    meta={card.error ? formatCount(card.error) + ' differ' : 'matches'}
                    provenance={card.error ? undefined : 'target'}
                    icon={<StatusDot status={card.error ? 'error' : card.warn ? 'warn' : 'ok'} />}
                  />
                );
              })}
            </SidebarGroup>
          </React.Fragment>
        ) : null}
      </Sidebar>

      <Main>
        {!runId ? (
          <div style={{ flex: 1, display: 'grid', placeItems: 'center', padding: 'var(--space-10)' }}>
            <EmptyState headline="No run" accent="selected."
              body="Pick a run on the left to see how its figures compare with Domo." />
          </div>
        ) : (
          <React.Fragment>
            <PageHeader
              title={view === 'elements' ? 'Migration status' : 'Value parity'}
              accent={view !== 'elements' && parity && parity.checked && !totals.error ? '1 : 1.' : undefined}
              meta={
                <span>
                  <span className="bit-num">{runId}</span>
                  {parity && parity.checked
                    ? ' · ' + formatCount(compared) + ' values across ' + formatCount(parity.cards || 0) + ' card(s), matched by category'
                    : ' · not checked'}
                </span>
              }
              actions={
                <div style={{ display: 'flex', gap: 10 }}>
                  {publishedUrl ? (
                    <a href={publishedUrl} target="_blank" rel="noopener noreferrer">
                      <Button variant="primary" size="md">Open in Power BI</Button>
                    </a>
                  ) : null}
                  <a href={reportHtmlUrl(runId, true)} download>
                    <Button variant="secondary" size="md" iconLeft={<Icon name="download" size={14} />}>
                      Migration report
                    </Button>
                  </a>
                </div>
              }>
              {view === 'elements' && report && report.verdict ? (
                <div style={{ marginTop: 14, fontSize: 'var(--text-md)', lineHeight: 1.5 }}>
                  <strong>{report.verdict.title}.</strong> {report.verdict.statement}
                </div>
              ) : null}
              {view === 'elements' && elementTally ? (
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,minmax(0,1fr))', gap: 28, margin: '22px 0 18px' }}>
                  <StatTile size="sm" tone="target" value={formatCount(elementTally.by_status.matches)} suffix="match" label="Source and Power BI agree" />
                  <StatTile size="sm" tone="source" value={formatCount(elementTally.by_status.differs)} suffix="differ" label="With the best-understood reason" />
                  <StatTile size="sm" value={formatCount(elementTally.by_status.not_compared)} suffix="not compared" label="Migrated; nothing to compare, and why" />
                  <StatTile size="sm" value={formatCount(elementTally.by_status.not_migrated)} suffix="not migrated"
                    label={rlsRoles ? 'Left out or part-built, and why; ' + formatCount(rlsRoles) + ' are security roles built without members' : 'Left out or part-built, and why'} />
                </div>
              ) : null}
              {view !== 'elements' && parity && parity.checked ? (
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,minmax(0,1fr))', gap: 28, margin: '22px 0 18px' }}>
                  <StatTile size="sm" tone="target" value={formatCount(totals.ok || 0)} suffix="match" label="Exactly what Domo returns" />
                  <StatTile size="sm" tone="source" value={formatCount(totals.warn || 0)} suffix="close" label="Within 0.1%, worth a look" />
                  <StatTile size="sm" tone={totals.error ? 'neutral' : 'neutral'} value={formatCount(totals.error || 0)} suffix="differ" label="Not the same number" />
                  <StatTile size="sm" value={compared ? ((totals.ok || 0) / compared * 100).toFixed(2) + '%' : '--'} label="Of compared values, matching" />
                </div>
              ) : null}
              <Tabs value={view} onChange={setView} tabs={VIEWS.map(function (v) {
                if (v.value === 'report') return v;
                if (v.value === 'elements') {
                  return Object.assign({}, v, { count: elementTally ? formatCount(elementTally.total - elementTally.by_status.matches) : undefined });
                }
                return Object.assign({}, v, {
                  count: formatCount(v.value ? (totals.error || 0) + (totals.warn || 0) : compared),
                });
              })} />
            </PageHeader>

            <ErrorBanner error={error} />

            {view === 'report'
              ? <ReportView runId={runId} />
              : view === 'elements'
                ? <ElementsTable report={report} selected={selectedElement} onSelect={setSelectedElement} />
                : <ParityTable parity={parity} rows={rows} total={allRows.length}
                  onSelect={setSelected} />}
          </React.Fragment>
        )}
      </Main>

      <Inspector>
        {view === 'elements' ? <ElementPanel element={selectedElement} /> : <ComparisonPanel row={selected} />}
      </Inspector>
    </React.Fragment>
  );
}

// Every element with its status word and reason. Opens on what is not a match: a reader goes to the things that
// differ or were not migrated first, and "Unexplained" says plainly that we do not know why yet. Colour is never
// the only signal: the status is a word in its own column.
export function ElementsTable({ report, selected, onSelect }) {
  const [show, setShow] = React.useState('');
  if (report === undefined) return <div style={{ padding: 20 }}><Spinner /></div>;
  if (report === null || !report.elements) {
    return (
      <div style={{ flex: 1, display: 'grid', placeItems: 'center', padding: 'var(--space-10)' }}>
        <EmptyState headline="No element status" accent="yet."
          body={report && report.element_status_error
            ? 'The status could not be worked out for this run: ' + report.element_status_error
            : 'The report is written by the last stage of the run. Carry the run on to produce it.'} />
      </div>
    );
  }
  const elements = report.elements;
  const tally = report.element_tally;
  const rows = elements.filter(function (e) {
    return show ? e.status === show : e.status !== 'matches';
  });
  return (
    <React.Fragment>
      <Toolbar right={
        <span className="bit-num" style={{ fontSize: 'var(--text-xs)', color: 'var(--text-tertiary)' }}>
          {formatCount(rows.length)} of {formatCount(elements.length)}
        </span>
      }>
        <Select size="sm" value={show} style={{ width: 240 }}
          options={[{ value: '', label: 'Not a match (' + formatCount(elements.length - tally.by_status.matches) + ')' }]
            .concat(ELEMENT_ORDER.map(function (s) {
              return { value: s, label: ELEMENT_STATUS[s].label + ' (' + formatCount(tally.by_status[s]) + ')' };
            }))}
          onChange={function (e) { setShow(e.target.value); }} />
      </Toolbar>
      <div style={{ flex: 1, minHeight: 0, overflow: 'auto' }}>
        <DataTable
          rows={rows}
          stickyHeader
          zebra
          selected={selected ? [selected.id] : []}
          onRowClick={onSelect}
          columns={[
            {
              key: 'status', header: 'Status', width: 130,
              render: function (e) {
                const s = ELEMENT_STATUS[e.status];
                return <Badge tone={s.tone} dot>{s.label}</Badge>;
              },
            },
            { key: 'kind', header: 'Kind', muted: true, width: 70, render: function (e) { return e.kind.replace('_', ' '); } },
            {
              key: 'name', header: 'Element', minWidth: 140,
              render: function (e) { return <span style={Object.assign({}, ELEMENT_CELL, { maxWidth: 170 })} title={e.name}>{e.name}</span>; },
            },
            {
              key: 'reason', header: 'Reason', minWidth: 200,
              render: function (e) {
                // The whole sentence wraps: the part that says why comes after the first words (#421). The evidence
                // is in the inspector on a click.
                return <span style={REASON_CELL}>{e.reason.text}</span>;
              },
            },
          ]}
        />
      </div>
    </React.Fragment>
  );
}

// A cell that never widens the table: the full text is in the tooltip and in the inspector.
const ELEMENT_CELL = { display: 'block', maxWidth: 360, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' };

const REASON_CELL = { display: 'block', minWidth: 260, maxWidth: 520, whiteSpace: 'normal' };

// What the inspector shows for one element: its status word, the whole reason (its code in the tooltip), and the evidence.
export function ElementPanel({ element }) {
  if (!element) {
    return (
      <InspectorBody>
        <EmptyState compact headline="Pick an element"
          body="Its status, the reason in full, and the evidence behind it appear here." />
      </InspectorBody>
    );
  }
  const s = ELEMENT_STATUS[element.status];
  return (
    <InspectorBody>
      <div>
        <span className="bit-eyebrow">{element.kind.replace('_', ' ')}</span>
        <div style={{ fontSize: 'var(--text-2xl)', fontWeight: 'var(--weight-semibold)', letterSpacing: 'var(--tracking-heading)', marginTop: 8, lineHeight: 1.2 }}>
          {element.name}
        </div>
        <div style={{ marginTop: 10 }}><Badge tone={s.tone} dot>{s.label}</Badge></div>
      </div>
      <div style={{ fontSize: 'var(--text-md)', lineHeight: 1.5 }} title={'Code: ' + element.reason.code}>{element.reason.text}</div>
      {element.evidence ? (
        <div style={{ fontSize: 'var(--text-sm)', color: 'var(--text-secondary)' }}>{elementEvidence(element.evidence).replace(/^\(|\)$/g, '')}</div>
      ) : null}
    </InspectorBody>
  );
}

const HELD_WORDS = {
  both: 'the data holds both the value and the text without its blank, which the engine cannot tell apart',
  unknown: 'what the data holds was not read',
};

// The part of a reason's evidence that its words point at ("see the evidence"): the filter values, or both row counts.
function reasonEvidence(ev) {
  const parts = (ev.blank_filter_values || []).map((f) => f.column + ' = ' + JSON.stringify(f.value)
    + ' (' + (HELD_WORDS[f.data_holds] || f.data_holds || 'unknown') + ')');
  (ev.moved_inputs || []).forEach((m) => parts.push((m.dataset || 'an input') + ': Domo ' + formatCount(m.domo_rows) + ' rows ('
    + (m.domo_rows_from === 'domo' ? 'asked now' : 'from the scan') + '), warehouse ' + formatCount(m.warehouse_rows)
    + (m.percent_apart === null || m.percent_apart === undefined ? '' : ' (' + m.percent_apart + ' % apart)')));
  return parts.length ? '; ' + parts.join('; ') : '';
}

function gapFigure(value) {
  return value === null || value === undefined ? 'has no value (blank)' : formatFigure(value);
}

export function elementEvidence(ev) {
  if (ev.largest_gap) {
    return '(' + formatCount(ev.values_differing) + ' of ' + formatCount(ev.values_compared) + ' values differ; largest: Domo '
      + gapFigure(ev.largest_gap.source) + ', Power BI ' + gapFigure(ev.largest_gap.target) + reasonEvidence(ev) + ')';
  }
  if (ev.source_rows !== undefined) return '(Domo ' + formatCount(ev.source_rows) + ' rows, warehouse ' + formatCount(ev.warehouse_rows) + ')';
  if (ev.values_compared !== undefined) return '(' + formatCount(ev.values_compared) + ' values compared)';
  if (ev.domo_says) return '(Domo says: ' + ev.domo_says + ')';
  if (ev.model_says) return '(Power BI says: ' + ev.model_says + ')';
  if (ev.visual_type) return '(Visual type: ' + ev.visual_type + ')';
  return ev.review ? '(' + ev.review + ')' : '';
}

export function ParityTable({ parity, rows, total, onSelect }) {
  if (!parity) {
    return <div style={{ padding: 20 }}><Spinner /></div>;
  }
  if (!parity.checked) {
    return (
      <div style={{ flex: 1, display: 'grid', placeItems: 'center', padding: 'var(--space-10)' }}>
        <EmptyState
          headline="Not compared"
          accent="against Domo."
          body={'This run did not reach the parity check, so nothing here is evidence the '
            + 'migrated figures are right. Carry the run on from the Migrate screen.'}
        />
      </div>
    );
  }
  if (rows.length === 0) {
    return (
      <div style={{ flex: 1, display: 'grid', placeItems: 'center', padding: 'var(--space-10)' }}>
        <EmptyState tone="target" headline="Every figure" accent="matches."
          body={'All ' + formatCount(total) + ' compared values are what Domo returns.'} />
      </div>
    );
  }

  return (
    <React.Fragment>
      <Toolbar right={
        <span className="bit-num" style={{ fontSize: 'var(--text-xs)', color: 'var(--text-tertiary)' }}>
          {formatCount(rows.length)} of {formatCount(total)}
        </span>
      }>
        <ProvenanceChip side="source" platform="Domo card" size="sm" />
        <Icon name="arrowRight" size={13} color="var(--text-disabled)" />
        <ProvenanceChip side="target" platform="Power BI visual" size="sm" />
      </Toolbar>
      <div style={{ padding: '6px 16px', fontSize: 'var(--text-xs)', color: 'var(--text-tertiary)' }}>
        {ROWS_NOTE}
      </div>
      <div style={{ flex: 1, minHeight: 0, overflow: 'auto' }}>
        <DataTable
          rows={rows}
          stickyHeader
          zebra
          onRowClick={onSelect}
          columns={[
            { key: 'metric', header: 'Card', minWidth: 200 },
            { key: 'grain', header: 'Grain', muted: true, minWidth: 180 },
            {
              key: 'source', header: 'Domo', mono: true, align: 'right', width: 150,
              render: function (r) { return <Figure side="source" value={formatFigure(r.source)} />; },
            },
            {
              key: 'target', header: 'Power BI', mono: true, align: 'right', width: 150,
              render: function (r) { return <Figure side="target" value={formatFigure(r.target)} />; },
            },
            {
              key: 'delta', header: 'Difference', mono: true, align: 'right', width: 130,
              render: function (r) {
                return (
                  <span style={{
                    color: r.state === 'ok' ? 'var(--text-tertiary)'
                      : r.state === 'warn' ? 'var(--status-warn)' : 'var(--status-error)',
                  }}>{formatPercent(r.delta)}</span>
                );
              },
            },
            {
              key: 'state', header: 'Result', width: 150,
              render: function (r) {
                return r.state === 'ok' ? <Badge tone="target" dot>Matches</Badge>
                  : r.state === 'warn' ? <Badge tone="warn" dot>Close</Badge>
                    : <Badge tone="error" dot>Differs</Badge>;
              },
            },
          ]}
        />
      </div>
    </React.Fragment>
  );
}

// The report, served from the run directory. An iframe rather than a
// re-rendering, so what is reviewed here is byte-for-byte what gets sent.
export function ReportView({ runId }) {
  const [missing, setMissing] = React.useState(false);

  React.useEffect(function () {
    let stale = false;
    setMissing(false);
    fetchReport(runId).then(function () {}, function () { if (!stale) setMissing(true); });
    return function () { stale = true; };
  }, [runId]);

  if (missing) {
    return (
      <div style={{ flex: 1, display: 'grid', placeItems: 'center', padding: 'var(--space-10)' }}>
        <EmptyState headline="No report" accent="yet."
          body="The report is written by the last stage of the run. Carry the run on to produce it." />
      </div>
    );
  }
  return (
    <div style={{ flex: 1, minHeight: 0, padding: '16px 20px 20px' }}>
      <iframe
        title="Migration report"
        src={reportHtmlUrl(runId)}
        style={{
          width: '100%', height: '100%', border: '1px solid var(--border-hairline)',
          borderRadius: 'var(--radius-card)', background: 'var(--surface-card)',
        }}
      />
    </div>
  );
}

export function ComparisonPanel({ row }) {
  if (!row) {
    return (
      <InspectorBody>
        <EmptyState compact headline="Pick a figure"
          body="Both sides of the comparison, and where the number came from, appear here." />
      </InspectorBody>
    );
  }
  const tone = row.state === 'ok' ? 'var(--status-ok)'
    : row.state === 'warn' ? 'var(--status-warn)' : 'var(--status-error)';

  return (
    <InspectorBody>
      <div>
        <span className="bit-eyebrow">Comparison</span>
        <div style={{ fontSize: 'var(--text-2xl)', fontWeight: 'var(--weight-semibold)', letterSpacing: 'var(--tracking-heading)', marginTop: 8, lineHeight: 1.2 }}>
          {row.metric}
        </div>
        <div style={{ fontSize: 'var(--text-md)', color: 'var(--text-secondary)', marginTop: 4 }}>
          {row.grain}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 10 }}>
          <StatusDot status={statusDot(row.state)} />
          <span className="bit-num" style={{ fontSize: 'var(--text-md)', color: tone }}>
            {formatPercent(row.delta)}
          </span>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
        <StatTile size="sm" tone="source" value={formatFigure(row.source)} label="Domo card" />
        <StatTile size="sm" tone="target" value={formatFigure(row.target)} label="Power BI visual" />
      </div>

      {row.target === null || row.target === undefined ? (
        <Banner tone="error" title="Power BI returned nothing for this category">
          A whole category missing from the target, while the others match, is the shape of a
          dropped branch upstream -- in the converted SQL rather than in the report.
        </Banner>
      ) : null}
      {row.source === null || row.source === undefined ? (
        <Banner tone="warn" title="Domo returned nothing for this category">
          The migrated report shows a category the card does not. Check the card's own filters:
          the scan does not hold their values, so a run cannot apply them.
        </Banner>
      ) : null}

      <KeyValueList dense dividers items={[
        { label: 'Domo card', value: row.card_id, mono: true },
        { label: 'Result', value: row.state === 'ok' ? 'Matches' : row.state === 'warn' ? 'Close' : 'Differs' },
      ]} />
    </InspectorBody>
  );
}

// Per-card counts for the sidebar. Computed here rather than asked of the
// API: the rows are already on the client, and a second request to count
// what is in front of you is a request too many.
export function cardSummaries(rows) {
  const byCard = {};
  (rows || []).forEach(function (row) {
    const key = row.metric || row.card_id;
    if (!byCard[key]) byCard[key] = { metric: key, ok: 0, warn: 0, error: 0 };
    byCard[key][row.state] = (byCard[key][row.state] || 0) + 1;
  });
  return Object.values(byCard).sort(function (a, b) { return b.error - a.error; });
}
